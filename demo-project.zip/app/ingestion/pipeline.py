"""
Ingestion pipeline — converts a NormalizedDocument into indexed pgvector chunks.

Pipeline steps:
  NormalizedDocument  (content already cleaned text/Markdown from connector)
    → wrap as ExtractedDocument
    → chunk  (RecursiveChunker, strategy from RAG_CHUNK_STRATEGY env var)
    → embed  (Gemini 3072-d)
    → delete old chunks from pgvector for this doc_id  (idempotent re-ingest)
    → insert new chunks into pgvector
    → upsert document_index row in PostgreSQL
"""
from __future__ import annotations
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.ingestion.extractors.base import ExtractedDocument, PageBlock
from app.ingestion.chunking.factory import get_chunker
from app.ingestion.chunking.types import ACL
from app.llm.embeddings import build_embedder
from app.domains.permissions.repositories.permission_repository import PermissionRepository
from app.retrieval.vector_store import get_vector_store
from app.domains.confluence.schemas.schemas import NormalizedDocument

logger = logging.getLogger(__name__)
# Stable namespace: deterministic doc_id from connector_id + document_id so
# re-syncing the same page always maps to the same UUID in document_index.
_DOC_ID_NAMESPACE = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # uuid.NAMESPACE_URL


class IngestionPipeline:
    """
    Orchestrates a single document through chunk → embed → index.
    Chunker, embedder and vector store are singletons built lazily on first use.
    """

    def __init__(self) -> None:
        self._chunker      = get_chunker()
        self._embedder     = build_embedder()
        self._vector_store = get_vector_store()
        self._permission_repo = PermissionRepository()

    async def run(
        self,
        doc: NormalizedDocument,
        *,
        db: AsyncSession,
        connector_id: str,
    ) -> int:
        """
        Ingest one document. Returns the number of chunks successfully indexed.
        Idempotent: re-running for the same document replaces all existing chunks.
        """
        # ── 1. Stable doc_id ─────────────────────────────────────────────────
        # Deterministic UUID so the same Confluence page always maps to the same
        # doc_id across incremental syncs.
        doc_id = str(uuid.uuid5(_DOC_ID_NAMESPACE, f"{connector_id}/{doc.document_id}"))

        # ── 2. Fresh version_id ───────────────────────────────────────────────
        # New UUID on every ingest so old-version chunks can be targeted for
        # deletion while new ones are inserted atomically.
        version_id = str(uuid.uuid4())

        # ── 3. ACL ───────────────────────────────────────────────────────────
        # Translate connector-specific account IDs (e.g. Atlassian accountId)
        # into internal user_id UUIDs so ACL comparisons at query time use the
        # same identity source as Azure AD authentication.
        # Accounts with no matching user row are silently skipped with a warning
        # — they cannot be granted access until the user is provisioned.
        connector_account_ids = list(getattr(doc, "allowed_user_ids", []))
        internal_user_ids = self._resolve_internal_user_ids(
            connector_id=connector_id,
            connector_account_ids=connector_account_ids,
        )

        role_groups = list(doc.permissions)
        # A page is public only when the connector reported NO restrictions at all.
        # If restrictions exist but none resolved to internal users yet (identity
        # mapping not yet populated), treat the page as deny-all rather than
        # world-readable — acl_public must never be True for a restricted page.
        had_restrictions = len(connector_account_ids) > 0
        acl = ACL(
            users=internal_user_ids,
            roles=role_groups,
            public=(not had_restrictions and len(internal_user_ids) == 0 and len(role_groups) == 0),
        )

        # ── 4. ExtractedDocument ─────────────────────────────────────────────
        # Confluence content is already cleaned plain text / Markdown.
        content = doc.content or doc.title
        extracted = ExtractedDocument(
            markdown=content,
            pages=[PageBlock(page_no=1, text=content)],
            metadata={
                "title":  doc.title,
                "source": doc.source,
            },
        )

        # ── 5. Chunk ─────────────────────────────────────────────────────────
        logger.info("  [chunk]  title=%r doc_id=%s", doc.title, doc_id)
        chunks = self._chunker.chunk(
            extracted,
            doc_id=doc_id,
            version_id=version_id,
            connector_id=connector_id,
            source_uri=doc.url or "",
            acl=acl,
        )

        if not chunks:
            logger.warning(
                "  [chunk]  no chunks produced — skipping  title=%r", doc.title,
            )
            return 0
        logger.info("  [chunk]  produced %d chunks", len(chunks))

        # ── 6. Embed ─────────────────────────────────────────────────────────
        logger.info("  [embed]  embedding %d chunks  model=%s", len(chunks), self._embedder.model_name)
        texts   = [c.content for c in chunks]
        vectors = self._embedder.embed_documents(texts)
        logger.info("  [embed]  done  vectors=%d  dim=%d", len(vectors), len(vectors[0]) if vectors else 0)

        # ── 7. Delete old chunks (idempotent re-ingest) ───────────────────────
        logger.info("  [pgvector]deleting old chunks  doc_id=%s", doc_id)
        try:
            self._vector_store.delete_chunks_by_doc(doc_id)
        except Exception as exc:
            logger.warning("  [pgvector]delete_chunks_by_doc failed: %s — continuing", exc)

        # ── 8. Insert into pgvector ───────────────────────────────────────────
        logger.info("  [pgvector]inserting %d chunks", len(chunks))
        self._vector_store.insert_chunks(chunks, vectors)
        logger.info("  [pgvector]insert done")

        # ── 9. Upsert document_index ──────────────────────────────────────────
        logger.info("  [db]  upserting document_index  doc_id=%s", doc_id)
        await _upsert_document_index(
            db=db,
            doc=doc,
            doc_id=doc_id,
            connector_id=connector_id,
            chunk_count=len(chunks),
        )
        logger.info("  [db]  document_index updated")

        return len(chunks)

    def _resolve_internal_user_ids(
        self,
        connector_id: str,
        connector_account_ids: list[str],
    ) -> list[str]:
        """
        Translate a list of connector-specific account IDs into internal user_id UUIDs.

        Looks up each accountId in users.metadata -> 'connector_accounts' -> connector_id.
        Accounts that have no matching row are skipped with a warning — they cannot
        be granted access until provisioned.

        Example: Confluence accountId "6374abc" → internal UUID "a0000001-..."
        """
        if not connector_account_ids:
            return []

        resolved: list[str] = []
        for account_id in connector_account_ids:
            internal_id = self._permission_repo.get_user_id_by_connector_account(
                connector_id=connector_id,
                account_id=account_id,
            )
            if internal_id:
                resolved.append(internal_id)
            else:
                logger.warning(
                    "acl_translation: no user found for connector=%s account_id=%s "
                    "— this account cannot access restricted content until provisioned",
                    connector_id,
                    account_id,
                )

        logger.debug(
            "acl_translation: connector=%s accounts=%d resolved=%d",
            connector_id,
            len(connector_account_ids),
            len(resolved),
        )
        return resolved


async def _upsert_document_index(
    db: AsyncSession,
    doc: NormalizedDocument,
    doc_id: str,
    connector_id: str,
    chunk_count: int,
) -> None:
    """Create or update the document_index row for this document."""
    from sqlalchemy import select
    from app.domains.confluence.models.document_index_model import DocumentIndex

    doc_uuid        = uuid.UUID(doc_id)
    allowed_user_ids = list(getattr(doc, "allowed_user_ids", []))
    permissions_acl: dict = {}
    if not doc.permissions and not allowed_user_ids:
        permissions_acl = {"public": True}
    else:
        if doc.permissions:
            permissions_acl["roles"] = list(doc.permissions)
        if allowed_user_ids:
            permissions_acl["connector_account_ids"] = allowed_user_ids
    now = datetime.now(timezone.utc)

    result = await db.execute(
        select(DocumentIndex).where(DocumentIndex.doc_id == doc_uuid)
    )
    record = result.scalar_one_or_none()

    if record is None:
        record = DocumentIndex(
            doc_id=doc_uuid,
            connector_id=connector_id,
            source_url=doc.url or "",
            title=doc.title,
            last_synced_at=now,
            permissions_acl=permissions_acl,
            chunk_count=chunk_count,
            metadata_=doc.metadata or {},
        )
        db.add(record)
    else:
        record.title           = doc.title
        record.source_url      = doc.url or ""
        record.last_synced_at  = now
        record.permissions_acl = permissions_acl
        record.chunk_count     = chunk_count
        record.metadata_       = doc.metadata or {}

    await db.commit()
