"""
Chunk dataclass — carries ACL and source metadata through embedding into pgvector.

ACL travels with each chunk at creation time so it never needs to be
reconstructed at query time.
"""
from __future__ import annotations
from dataclasses import dataclass, field

from app.shared.enums import ChunkType


@dataclass
class ACL:
    """Access control list for a document / chunk."""
    users: list[str] = field(default_factory=list)    # user_id strings
    roles: list[str] = field(default_factory=list)
    public: bool = False


@dataclass
class Chunk:
    """A single indexed unit of text with full provenance and ACL."""
    chunk_id: str                                      # UUID as str
    doc_id: str                                        # UUID as str
    version_id: str                                    # UUID as str
    connector_id: str
    title: str
    source_uri: str
    section_path: list[str]                            # ["Chap 2", "2.1 Spec"]
    chunk_type: ChunkType
    content: str
    acl: ACL
    page_no: int | None = None
    score: float = 0.0                                 # set after retrieval / reranking
