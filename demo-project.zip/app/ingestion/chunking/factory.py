"""ChunkerFactory — returns the right chunker based on strategy name."""
from __future__ import annotations

from app.core.config import settings
from app.shared.enums import ChunkStrategy
from app.ingestion.chunking.recursive import RecursiveChunker
from app.ingestion.chunking.token import TokenChunker
from app.ingestion.chunking.semantic import SemanticChunker


def get_chunker(strategy: str | None = None):
    """
    Return a chunker for the given strategy.(Recursive is present in RAGConfig)
    Strategy defaults to settings.rag.chunk_strategy if not provided.
    """
    
    # TODO - Recursive is used by default -- later upgrade to proper chunking
    resolved_strategy = (strategy or settings.rag.chunk_strategy).lower()
    chunk_size = settings.rag.chunk_size
    chunk_overlap = settings.rag.chunk_overlap

    if resolved_strategy == ChunkStrategy.TOKEN:
        return TokenChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    elif resolved_strategy == ChunkStrategy.SEMANTIC:
        return SemanticChunker()
    else:
        return RecursiveChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
