"""Semantic chunker — splits at cosine-distance peaks between sentence embeddings."""
from __future__ import annotations

import logging
import re
import uuid

import numpy as np

from app.shared.enums import ChunkStrategy, ChunkType
from app.ingestion.chunking.types import ACL, Chunk
from app.ingestion.extractors.base import ExtractedDocument
from app.llm.embeddings import build_embedder

logger = logging.getLogger(__name__)

_BREAKPOINT_THRESHOLD_DEFAULT: float = 0.3
_MIN_SENTENCES_FOR_SPLIT: int = 2
_PAGE_SNIPPET_LENGTH: int = 80

# Splits on sentence-ending punctuation (.!?) followed by whitespace.
# Lookbehind preserves the punctuation as part of the preceding sentence token.
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def _make_chunk(
    *,
    chunk_type: ChunkType,
    content: str,
    doc_id: str,
    version_id: str,
    connector_id: str,
    title: str,
    source_uri: str,
    acl: ACL,
    section_path: list[str] | None = None,
    page_no: int | None = None,
) -> Chunk:
    return Chunk(
        chunk_id=str(uuid.uuid4()),
        doc_id=doc_id,
        version_id=version_id,
        connector_id=connector_id,
        title=title,
        source_uri=source_uri,
        section_path=section_path or [],
        chunk_type=chunk_type,
        content=content,
        acl=acl,
        page_no=page_no,
    )


class SemanticChunker:
    """Splits text at embedding-space breakpoints between consecutive sentences.

    Falls back to a single text chunk when the document is too short to split
    or the embedding backend is unavailable. Tables and images are always
    emitted as atomic chunks regardless of the text splitting outcome.
    """

    strategy = ChunkStrategy.SEMANTIC

    def __init__(self, breakpoint_threshold: float = _BREAKPOINT_THRESHOLD_DEFAULT) -> None:
        self._threshold = breakpoint_threshold

    def chunk(
        self,
        extracted: ExtractedDocument,
        *,
        doc_id: str,
        version_id: str,
        connector_id: str,
        source_uri: str,
        acl: ACL,
    ) -> list[Chunk]:
        title = extracted.metadata.get("title", source_uri)
        common = dict(
            doc_id=doc_id,
            version_id=version_id,
            connector_id=connector_id,
            title=title,
            source_uri=source_uri,
            acl=acl,
        )

        chunks: list[Chunk] = [
            *self._text_chunks(extracted, **common),
            *self._table_chunks(extracted, **common),
            *self._image_chunks(extracted, **common),
        ]

        logger.debug("Produced %d chunks for doc_id=%s", len(chunks), doc_id)
        return chunks

    # ── Private helpers ────────────────────────────────────────────────────────

    def _text_chunks(self, extracted: ExtractedDocument, **common) -> list[Chunk]:
        text = extracted.markdown.strip()
        if not text:
            return []

        # Preserve sentence-ending punctuation by using a lookbehind split.
        sentences = [s for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]

        if len(sentences) <= _MIN_SENTENCES_FOR_SPLIT:
            return [_make_chunk(chunk_type=ChunkType.TEXT, content=text, **common)]

        try:
            return self._semantic_split(sentences, extracted, **common)
        except Exception as exc:
            logger.warning(
                "Semantic split failed for doc_id=%s: %s — falling back to single chunk",
                common.get("doc_id"),
                exc,
            )
            return [_make_chunk(chunk_type=ChunkType.TEXT, content=text, **common)]

    def _semantic_split(
        self,
        sentences: list[str],
        extracted: ExtractedDocument,
        **common,
    ) -> list[Chunk]:
        """Embed sentences, find cosine-distance breakpoints, and return chunks."""
        embedder = build_embedder()
        vecs_np = np.array(embedder.embed_documents(sentences), dtype=np.float32)

        norms = np.maximum(np.linalg.norm(vecs_np, axis=1, keepdims=True), 1e-10)
        normed = vecs_np / norms
        distances = 1.0 - np.sum(normed[:-1] * normed[1:], axis=1)

        split_indices = [i + 1 for i, d in enumerate(distances) if d > self._threshold]
        boundaries = [0] + split_indices + [len(sentences)]

        chunks = []
        for start, end in zip(boundaries[:-1], boundaries[1:]):
            # Join with a space — each sentence already carries its terminal punctuation.
            content = " ".join(sentences[start:end]).strip()
            if not content:
                continue
            chunks.append(_make_chunk(
                chunk_type=ChunkType.TEXT,
                content=content,
                page_no=self._estimate_page(content, extracted),
                **common,
            ))
        return chunks

    @staticmethod
    def _table_chunks(extracted: ExtractedDocument, **common) -> list[Chunk]:
        chunks = []
        for table in extracted.tables:
            content = table.markdown.strip()
            if not content:
                continue
            chunks.append(_make_chunk(
                chunk_type=ChunkType.TABLE,
                content=content,
                page_no=table.page_no,
                **common,
            ))
        return chunks

    @staticmethod
    def _image_chunks(extracted: ExtractedDocument, **common) -> list[Chunk]:
        chunks = []
        for img in extracted.images:
            desc = (img.alt_text or img.caption or "").strip()
            if not desc:
                continue
            chunks.append(_make_chunk(
                chunk_type=ChunkType.IMAGE,
                content=desc,
                page_no=img.page_no,
                **common,
            ))
        return chunks

    @staticmethod
    def _estimate_page(text: str, extracted: ExtractedDocument) -> int | None:
        """Return the page number whose raw text contains the start of this chunk."""
        if not extracted.pages:
            return None
        snippet = text[:_PAGE_SNIPPET_LENGTH].strip()
        if not snippet:
            return None
        for page in extracted.pages:
            if snippet in page.text:
                return page.page_no
        return None
