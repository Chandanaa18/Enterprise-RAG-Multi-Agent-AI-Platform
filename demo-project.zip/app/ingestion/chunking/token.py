"""Token-based chunker — splits on tiktoken token boundaries."""
from __future__ import annotations
import uuid
from app.ingestion.chunking.types import Chunk, ACL
from app.ingestion.extractors.base import ExtractedDocument
from app.shared.enums import ChunkStrategy, ChunkType

class TokenChunker:
    strategy = ChunkStrategy.TOKEN

    def __init__(self, chunk_size: int = 512, chunk_overlap: int = 64) -> None:
        from langchain_text_splitters import TokenTextSplitter
        self._splitter = TokenTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    def chunk(
        self,
        extracted: ExtractedDocument,
        *,
        doc_id: str,
        version_id: str,
        connector_id: str,
        source_uri: str,
        acl: ACL,
    ) -> list[Chunk]:
        title = extracted.metadata.get("title", source_uri)
        splits = self._splitter.split_text(extracted.markdown)
        chunks: list[Chunk] = []
        for split in splits:
            if split.strip():
                chunks.append(Chunk(
                    chunk_id=str(uuid.uuid4()),
                    doc_id=doc_id,
                    version_id=version_id,
                    connector_id=connector_id,
                    title=title,
                    source_uri=source_uri,
                    section_path=[],
                    chunk_type=ChunkType.TEXT,
                    content=split.strip(),
                    acl=acl,
                ))

        # Tables and images are always atomic
        for table in extracted.tables:
            if table.markdown.strip():
                chunks.append(Chunk(
                    chunk_id=str(uuid.uuid4()),
                    doc_id=doc_id, version_id=version_id,
                    connector_id=connector_id, title=title, source_uri=source_uri,
                    section_path=[], chunk_type=ChunkType.TABLE,
                    content=table.markdown.strip(), acl=acl, page_no=table.page_no,
                ))

        for img in extracted.images:
            desc = (img.alt_text or img.caption or "").strip()
            if desc:
                chunks.append(Chunk(
                    chunk_id=str(uuid.uuid4()),
                    doc_id=doc_id, version_id=version_id,
                    connector_id=connector_id, title=title, source_uri=source_uri,
                    section_path=[], chunk_type=ChunkType.IMAGE,
                    content=desc, acl=acl, page_no=img.page_no,
                ))

        return chunks
