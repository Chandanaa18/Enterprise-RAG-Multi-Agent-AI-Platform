"""Recursive character text splitter — default chunking strategy."""
from __future__ import annotations

import logging
import re
import uuid

from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.shared.enums import ChunkStrategy, ChunkType
from app.ingestion.chunking.types import ACL, Chunk
from app.ingestion.extractors.base import ExtractedDocument

logger = logging.getLogger(__name__)

# Separators tried in order; matches Markdown structure before falling back to whitespace.
_MARKDOWN_SEPARATORS: list[str] = ["\n## ", "\n### ", "\n\n", "\n", " "]

_MAX_SECTION_DEPTH = 3       # heading levels kept in section_path
_PAGE_SNIPPET_LENGTH = 80    # chars used to locate the chunk's page

# Matches one or more consecutive Markdown heading lines at the start of a string.
# Used to strip injected headings from chunks before searching page text.
_LEADING_HEADINGS_RE = re.compile(r"^(#{1,6}[^\n]*\n+)+")


class RecursiveChunker:
    """Splits an ExtractedDocument into text, table, and image chunks."""

    strategy = ChunkStrategy.RECURSIVE

    def __init__(self, chunk_size: int = 800, chunk_overlap: int = 120) -> None:
        self._splitter = RecursiveCharacterTextSplitter(
            separators=_MARKDOWN_SEPARATORS,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
        )

    def chunk(
        self,
        extracted: ExtractedDocument,
        *,
        doc_id: str,
        version_id: str,
        connector_id: str,
        source_uri: str,
        acl: ACL,
    ) -> list[Chunk]:
        title = extracted.metadata.get("title", source_uri)
        common = dict(
            doc_id=doc_id,
            version_id=version_id,
            connector_id=connector_id,
            title=title,
            source_uri=source_uri,
            acl=acl,
        )

        chunks: list[Chunk] = [
            *self._text_chunks(extracted, **common),
            *self._table_chunks(extracted, **common),
            *self._image_chunks(extracted, **common),
        ]

        logger.debug("Produced %d chunks for doc_id=%s", len(chunks), doc_id)
        return chunks

    # ── Private helpers ────────────────────────────────────────────────────────

    def _text_chunks(
        self,
        extracted: ExtractedDocument,
        **common,
    ) -> list[Chunk]:
        chunks = []
        last_section_path: list[str] = []
        for split in self._splitter.split_text(extracted.markdown):
            text = split.strip()
            if not text:
                continue
            section_path = self._extract_section_path(text)
            # Continuation chunks (no headings of their own) inherit the last
            # known section so retrieval can find them by section context.
            if section_path:
                last_section_path = section_path
            else:
                section_path = last_section_path
            chunks.append(Chunk(
                chunk_id=str(uuid.uuid4()),
                section_path=section_path,
                chunk_type=ChunkType.TEXT,
                content=text,
                page_no=self._estimate_page(text, extracted),
                **common,
            ))
        return chunks

    @staticmethod
    def _table_chunks(
        extracted: ExtractedDocument,
        **common,
    ) -> list[Chunk]:
        chunks = []
        for table in extracted.tables:
            content = table.markdown.strip()
            if not content:
                continue
            chunks.append(Chunk(
                chunk_id=str(uuid.uuid4()),
                section_path=[],
                chunk_type=ChunkType.TABLE,
                content=content,
                page_no=table.page_no,
                **common,
            ))
        return chunks

    @staticmethod
    def _image_chunks(
        extracted: ExtractedDocument,
        **common,
    ) -> list[Chunk]:
        chunks = []
        for img in extracted.images:
            desc = (img.alt_text or img.caption or "").strip()
            if not desc:
                continue
            chunks.append(Chunk(
                chunk_id=str(uuid.uuid4()),
                section_path=[],
                chunk_type=ChunkType.IMAGE,
                content=desc,
                page_no=img.page_no,
                **common,
            ))
        return chunks

    @staticmethod
    def _extract_section_path(text: str) -> list[str]:
        """Return up to _MAX_SECTION_DEPTH heading titles found in the chunk."""
        headings = re.findall(r"^#{1,6}\s+(.+)$", text, re.MULTILINE)
        return headings[:_MAX_SECTION_DEPTH]

    @staticmethod
    def _estimate_page(text: str, extracted: ExtractedDocument) -> int | None:
        """Return the page number whose text contains this chunk's content, or None."""
        if not extracted.pages:
            return None
        # Strip all leading heading lines (injected by the splitter's separators)
        # so the snippet matches the original page text, which has no such headings.
        clean = _LEADING_HEADINGS_RE.sub("", text).strip()
        snippet = clean[:_PAGE_SNIPPET_LENGTH]
        if not snippet:
            return None
        for page in extracted.pages:
            if snippet in page.text:
                return page.page_no
        return None
