"""
Base types for file extraction.

Each extractor takes a file path and returns an ExtractedDocument.
Add a new file type by implementing FileExtractor and registering it in factory.py.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class PageBlock:
    """A single page of text content."""
    page_no: int
    text: str
    char_start: int = 0
    char_end: int = 0


@dataclass
class TableBlock:
    """A table extracted from the document, preserved as Markdown."""
    page_no: int
    markdown: str
    original: str = ""       # raw representation (CSV, HTML, etc.)
    caption: str = ""


@dataclass
class ImageBlock:
    """An image with alt-text or caption."""
    page_no: int
    alt_text: str = ""
    caption: str = ""


@dataclass
class ExtractedDocument:
    """Canonical output of any FileExtractor."""
    markdown: str                            # full document as Markdown
    pages: list[PageBlock] = field(default_factory=list)
    tables: list[TableBlock] = field(default_factory=list)
    images: list[ImageBlock] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)   # author, title, page_count, mime_type, etc.


@runtime_checkable
class FileExtractor(Protocol):
    """Protocol every extractor must satisfy."""
    supported_mimes: list[str]

    def extract(self, path: str) -> ExtractedDocument:
        """Extract content from the file at path."""
        ...
