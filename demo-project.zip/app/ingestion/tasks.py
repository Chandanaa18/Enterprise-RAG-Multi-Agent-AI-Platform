"""
Celery tasks for ingestion and identity resolution.

The worker process is separate from FastAPI — it is safe to call asyncio.run()
here because there is no pre-existing event loop to conflict with.

Tasks
-----
ingestion.sync_confluence_space        — fetch, chunk, embed and index Confluence pages
ingestion.sync_confluence_permissions  — permission-only sync (no re-embedding);
                                         updates document_index.permissions_acl and
                                         clears knowledge_chunks.acl_user_ids for
                                         changed pages, then triggers ACL backfill
identity.resolve_user_identities       — map connector account IDs to internal user UUIDs
                                         and backfill acl_user_ids on knowledge_chunks
"""
from __future__ import annotations

import asyncio
import json
import logging
import psycopg2

from celery import Celery
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

from app.core.config import settings

# Must be imported before any ORM query so all models are registered with the
# shared Base and string-based relationship() references resolve correctly.
import app.infrastructure.database.model_registry  # noqa: F401

from app.domains.confluence.services.confluence_sync_service import ConfluenceSyncService
from app.domains.users.repositories.user_repository import UserRepository
from app.infrastructure.identity.identity_service import ConnectorIdentityService
from app.infrastructure.identity.registry import get_registered_resolvers

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Celery application
# ──────────────────────────────────────────────────────────────────────────────

celery_app = Celery(
    "ingestion",
    broker=settings.redis.url,
    backend=settings.redis.url,
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    beat_schedule={
        # ── Content sync ──────────────────────────────────────────────────────
        # Incremental: picks up pages created or modified since the last run.
        # Runs every 5 minutes. Uses lastModified filter — only changed pages
        # are fetched, chunked, and embedded. API cost is proportional to
        # the number of changed pages, not total pages.
        "confluence-incremental-sync": {
            "task": "ingestion.sync_confluence_space",
            "schedule": 120,    # 2 minutes
            "kwargs": {"force_full": False},
        },

        # ── Permission sync ───────────────────────────────────────────────────
        # Runs every 1 minute. Checks whether page-level restrictions have
        # changed in Confluence and updates permissions_acl + clears
        # acl_user_ids so the ACL backfill can rebuild access correctly.
        # Does NOT call the embedding API — only Confluence REST + DB writes.
        "confluence-permission-sync": {
            "task": "ingestion.sync_confluence_permissions",
            "schedule": 60,     # 1 minute
        },
    },
)

# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _make_session_factory(echo: bool = False):
    """Return a fresh (engine, session_factory) pair for use inside asyncio.run().

    A new engine is created per asyncio.run() call so connection pools are
    never shared across event loops — required because each Celery task spins
    up its own loop via asyncio.run().
    """
    engine = create_async_engine(settings.db.url, echo=echo, pool_pre_ping=True)
    factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    return engine, factory


def _db_echo() -> bool:
    return settings.db.logging.lower() in ("true", "1", "yes")


def _trigger_acl_backfill_for_all_users() -> None:
    """Queue resolve_user_identities for every provisioned user.

    Called after a full resync so Confluence-side permission changes
    (no content edit) are reflected in acl_user_ids without requiring
    each user to log in.
    """
    async def _fetch_users():
        engine, factory = _make_session_factory()
        try:
            async with factory() as db:
                return await UserRepository(db).list_all()
        finally:
            await engine.dispose()

    try:
        users = asyncio.run(_fetch_users())
        queued = 0
        for user in users:
            if user.email:
                resolve_user_identities.delay(str(user.user_id), user.email)
                queued += 1
        logger.info("ACL backfill queued for %d users after full resync", queued)
    except Exception as exc:
        logger.warning("_trigger_acl_backfill_for_all_users failed: %s", exc)


def _acl_backfill_new_chunks() -> int:
    """Backfill acl_user_ids on newly indexed chunks in a single SQL query.

    Called after every incremental sync instead of queuing one Celery task per
    user. Finds all knowledge_chunks where acl_user_ids is still empty but
    permissions_acl has connector_account_ids, then cross-references
    connector_permissions to resolve the matching internal user UUIDs and
    writes them in one shot.

    No external API calls. No per-user Celery tasks. Safe to run every 2 minutes.
    """
    db_cfg = settings.db
    conn = psycopg2.connect(
        host=db_cfg.host,
        port=db_cfg.port,
        user=db_cfg.username,
        password=db_cfg.password,
        dbname=db_cfg.database,
    )
    try:
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE enterprise_rag_system.knowledge_chunks kc
                SET    acl_user_ids = array_append(kc.acl_user_ids, u.user_id::text)
                FROM   enterprise_rag_system.document_index di
                JOIN   enterprise_rag_system.connector_permissions cp
                       ON  cp.connector_name = di.connector_id
                       AND cp.subject_type   = 'user'
                       AND cp.enabled        = TRUE
                       AND cp.metadata_    ->> 'account_id' IS NOT NULL
                JOIN   enterprise_rag_system.users u
                       ON  u.user_id::text  = cp.subject_id
                       OR  u.azure_ad_oid   = cp.subject_id
                WHERE  kc.doc_id = di.doc_id
                  AND  kc.acl_user_ids = '{}'
                  AND  di.permissions_acl -> 'connector_account_ids'
                       @> jsonb_build_array(cp.metadata_ ->> 'account_id')
                  AND  NOT (u.user_id::text = ANY(kc.acl_user_ids))
            """)
            updated = cur.rowcount
        conn.commit()
        if updated:
            logger.info("acl_backfill_new_chunks: updated acl_user_ids on %d chunks", updated)
        return updated
    except Exception as exc:
        logger.warning("acl_backfill_new_chunks failed: %s", exc)
        return 0
    finally:
        conn.close()


def _acl_backfill(user_id: str, connector_accounts: dict) -> int:
    """Update acl_user_ids on knowledge_chunks for resolved connector accounts.

    Uses psycopg2 (sync) directly to avoid asyncpg type-inference issues with
    uuid[] array comparisons. Closes the race window where ingestion ran before
    identity resolution completed, and handles Confluence-side permission changes.

    Returns the total number of chunk rows updated.
    """
    if not connector_accounts:
        return 0

    db_cfg = settings.db
    conn = psycopg2.connect(
        host=db_cfg.host,
        port=db_cfg.port,
        user=db_cfg.username,
        password=db_cfg.password,
        dbname=db_cfg.database,
    )
    total_updated = 0
    try:
        with conn.cursor() as cur:
            for connector_name, identity_data in connector_accounts.items():
                account_id = identity_data.get("account_id")
                if not account_id:
                    continue

                cur.execute("""
                    UPDATE enterprise_rag_system.knowledge_chunks kc
                    SET acl_user_ids = array_append(kc.acl_user_ids, %s)
                    FROM enterprise_rag_system.document_index di
                    WHERE kc.doc_id = di.doc_id
                      AND di.connector_id = %s
                      AND di.permissions_acl -> 'connector_account_ids' @> %s::jsonb
                      AND NOT (%s = ANY(kc.acl_user_ids))
                """, (
                    user_id,
                    connector_name,
                    json.dumps([account_id]),
                    user_id,
                ))

                updated = cur.rowcount
                total_updated += updated
                if updated:
                    logger.info(
                        "acl_backfill: connector=%s account_id=%s user_id=%s — updated %d chunks",
                        connector_name, account_id, user_id, updated,
                    )
                else:
                    logger.debug(
                        "acl_backfill: connector=%s account_id=%s user_id=%s — no chunks to update",
                        connector_name, account_id, user_id,
                    )

        conn.commit()
    finally:
        conn.close()

    return total_updated


# ──────────────────────────────────────────────────────────────────────────────
# Tasks
# ──────────────────────────────────────────────────────────────────────────────

@celery_app.task(
    bind=True,
    name="ingestion.sync_confluence_space",
    max_retries=settings.ingestion.max_retries,
    default_retry_delay=settings.ingestion.default_retry_delay,
)
def sync_confluence_space(
    self,
    space_keys: list[str] | None = None,
    force_full: bool = False,
) -> dict:
    """Fetch updated Confluence pages, chunk + embed + index into pgvector.

    Incremental mode (force_full=False): only pages modified since last sync.
    Full mode (force_full=True): re-processes all pages and triggers ACL
    backfill for all users so permission-only changes are picked up.

    Retried up to 3 times on failure (60-second delay between attempts).
    """
    task_id = self.request.id
    logger.info("=" * 60)
    logger.info("SYNC STARTED  task_id=%s", task_id)
    logger.info("  space_keys : %s", space_keys or "all")
    logger.info("  force_full : %s", force_full)
    logger.info("=" * 60)

    async def _run() -> dict:
        engine, factory = _make_session_factory(echo=_db_echo())
        try:
            async with factory() as db:
                result = await ConfluenceSyncService(db).run_sync(
                    space_keys=space_keys,
                    force_full=force_full,
                )
                return {
                    "status":           result.status.value,
                    "pages_synced":     result.pages_synced,
                    "duration_seconds": result.duration_seconds,
                    "error":            result.error,
                }
        finally:
            await engine.dispose()

    try:
        outcome = asyncio.run(_run())
        logger.info("=" * 60)
        logger.info("SYNC FINISHED  task_id=%s", task_id)
        logger.info("  status   : %s", outcome["status"])
        logger.info("  pages    : %d", outcome["pages_synced"])
        logger.info("  duration : %.2fs", outcome["duration_seconds"])
        logger.info("=" * 60)

        if outcome.get("pages_synced", 0) > 0:
            if force_full:
                # Full resync: re-resolve all users so permission-only changes
                # (no content edit) are reflected in acl_user_ids.
                _trigger_acl_backfill_for_all_users()
            else:
                # Incremental sync: single SQL backfill for newly indexed chunks only.
                # No per-user Celery tasks, no external API calls.
                _acl_backfill_new_chunks()

        return outcome
    except Exception as exc:
        logger.error("=" * 60)
        logger.error("SYNC FAILED  task_id=%s — %s", task_id, exc, exc_info=True)
        logger.error("=" * 60)
        raise self.retry(exc=exc)


@celery_app.task(
    bind=True,
    name="ingestion.sync_confluence_permissions",
    max_retries=settings.ingestion.max_retries,
    default_retry_delay=settings.ingestion.permissions_retry_delay,
)
def sync_confluence_permissions(self) -> dict:
    """Check all indexed Confluence pages for permission changes and update the DB.

    This task does NOT re-chunk or re-embed content — it only calls the
    Confluence REST API to fetch page restrictions and updates:
      - document_index.permissions_acl  (fresh restrictions from Confluence)
      - knowledge_chunks.acl_user_ids   (cleared so backfill can rebuild it)

    If any permissions changed, resolve_user_identities is re-queued for all
    users so acl_user_ids is repopulated from the updated permissions_acl.

    Runs every 5 minutes via Celery Beat. Retried up to 3 times on failure.
    """
    task_id: str = self.request.id
    logger.info("PERMISSION SYNC STARTED  task_id=%s", task_id)

    async def _run() -> dict:
        engine, factory = _make_session_factory(echo=_db_echo())
        try:
            async with factory() as db:
                result = await ConfluenceSyncService(db).run_permission_sync()
                return {
                    "pages_checked": result.pages_checked,
                    "pages_changed": result.pages_changed,
                    "pages_failed":  result.pages_failed,
                }
        finally:
            await engine.dispose()

    try:
        outcome: dict = asyncio.run(_run())

        logger.info(
            "PERMISSION SYNC FINISHED  task_id=%s "
            "pages_checked=%d pages_changed=%d pages_failed=%d",
            task_id,
            outcome["pages_checked"],
            outcome["pages_changed"],
            outcome["pages_failed"],
        )

        # Re-queue ACL backfill for all users only if at least one page
        # had its permissions updated — avoids unnecessary DB work.
        if outcome["pages_changed"] > 0:
            logger.info(
                "PERMISSION SYNC: %d page(s) changed — triggering ACL backfill for all users",
                outcome["pages_changed"],
            )
            _trigger_acl_backfill_for_all_users()

        return outcome

    except Exception as exc:
        logger.error(
            "PERMISSION SYNC FAILED  task_id=%s error='%s'",
            task_id, exc, exc_info=True,
        )
        raise self.retry(exc=exc)


@celery_app.task(
    bind=True,
    name="identity.resolve_user_identities",
    max_retries=settings.ingestion.max_retries,
    default_retry_delay=settings.ingestion.permissions_retry_delay,
)
def resolve_user_identities(self, user_id: str, email: str) -> dict:
    """Resolve connector account IDs for a user and backfill acl_user_ids.

    Looks up the user's account ID in each connector (e.g. Confluence accountId)
    and maps it to their internal UUID. Then updates acl_user_ids on all
    knowledge_chunks the user is permitted to read.

    Triggered on login, Admin Panel permission grant, and after full resync.
    Retried up to 3 times on failure (30-second delay between attempts).
    """
    task_id = self.request.id
    logger.info(
        "IDENTITY RESOLUTION STARTED  task_id=%s user_id=%s email=%s",
        task_id, user_id, email,
    )

    async def _run() -> dict:
        engine, factory = _make_session_factory(echo=_db_echo())
        try:
            async with factory() as db:
                resolvers = get_registered_resolvers()
                if not resolvers:
                    logger.info("IDENTITY RESOLUTION  no resolvers registered — skipping")
                    return {}
                return await ConnectorIdentityService(
                    db=db, resolvers=resolvers
                ).resolve_identities_for_user(user_id=user_id, email=email)
        finally:
            await engine.dispose()

    try:
        connector_accounts = asyncio.run(_run())
        logger.info(
            "IDENTITY RESOLUTION FINISHED  task_id=%s user_id=%s connectors=%s",
            task_id, user_id, list(connector_accounts.keys()),
        )

        if connector_accounts:
            backfilled = _acl_backfill(user_id, connector_accounts)
            if backfilled:
                logger.info(
                    "ACL BACKFILL DONE  task_id=%s user_id=%s total_chunks_updated=%d",
                    task_id, user_id, backfilled,
                )

        return connector_accounts
    except Exception as exc:
        logger.error(
            "IDENTITY RESOLUTION FAILED  task_id=%s user_id=%s — %s",
            task_id, user_id, exc, exc_info=True,
        )
        raise self.retry(exc=exc)
