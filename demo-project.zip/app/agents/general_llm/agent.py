"""
GeneralLLMAgent — answers world-knowledge and general questions directly
via LLM with no document retrieval.

Uses the GENERAL_LLM logical model (cheap/fast chain: llama-3.1-8b-instant
first, falling through to Gemini Flash Lite, then OpenRouter free models).
"""
from __future__ import annotations
import logging

from app.agents.knowledge_rag.agent import AgentResult

logger = logging.getLogger("platform.general_llm")

_SYSTEM_PROMPT = """\
You are a knowledgeable assistant embedded in an enterprise platform.

Answer the user's question directly, accurately, and concisely.
- For factual or scientific questions, give a clear, confident answer.
- For conceptual or open-ended questions, provide a focused explanation.
- Keep responses appropriately brief — expand only when depth is genuinely needed.
- Do not mention internal systems, document retrieval, or knowledge bases.
- Do not preface answers with phrases like "As an AI..." or "I should note...".
- Always respond in a polite, humble, and respectful tone.
- Do not use markdown formatting such as bold (**text**), italics, or headers. Use plain text only.\
"""


class GeneralLLMAgent:
    def __init__(self, llm=None) -> None:
        self._llm = llm or self._build_default_llm()

    @staticmethod
    def _build_default_llm():
        try:
            from app.llm.provider_factory import get_provider_factory
            return get_provider_factory().get_chat_model("GENERAL_LLM")
        except Exception as exc:
            logger.warning("Could not build GENERAL_LLM: %s — using FakeChatModel", exc)
            from app.llm.provider_factory import _FakeChatModel
            return _FakeChatModel("GENERAL_LLM")

    def handle(
        self,
        *,
        question: str,
        session_id: str,
        user_id: str,
        user_roles: list[str],
        db=None,
        **_kwargs,
    ) -> AgentResult:
        logger.info(
            "event=request_received agent=general_llm session=%s user=%s question=%r",
            session_id, user_id, question[:80],
        )
        try:
            response = self._llm.invoke([
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user",   "content": question},
            ])
            answer = response.content if hasattr(response, "content") else str(response)
            logger.info("event=response_returned agent=general_llm session=%s", session_id)
            return AgentResult(
                text=answer,
                agent="general_llm",
                session_id=session_id,
                can_answer=True,
            )
        except Exception as exc:
            logger.error("general_llm failed session=%s error=%s", session_id, exc)
            return AgentResult(
                text="I'm sorry, I couldn't process your request. Please try again.",
                agent="general_llm",
                session_id=session_id,
                can_answer=False,
            )
