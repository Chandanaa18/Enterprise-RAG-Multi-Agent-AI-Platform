"""
KnowledgeRAGState — the TypedDict shared across all nodes in the parent graph
and the retrieval subgraph.

Only reasoning nodes (parse_intent, rewrite_query, generate_answer) call an LLM.
All other nodes are deterministic.
"""
from __future__ import annotations
from typing import Literal, Optional
from typing_extensions import TypedDict
from dataclasses import dataclass

from app.domains.permissions.schemas.permission_context import PermissionContext


@dataclass(frozen=True)
class ChatMessage:
    role: str   # "user" | "assistant" | "system"
    content: str
    mlflow_run_id: Optional[str] = None


@dataclass(frozen=True)
class Citation:
    doc_id: str
    title: str
    source_uri: str
    page_no: Optional[int]
    score: float
    snippet: str    # short excerpt from the chunk


class KnowledgeRAGState(TypedDict, total=False):
    # ── Identity / session ────────────────────────────────────────────────────
    session_id: str
    user_id: str
    user_roles: list[str]
    request_id: str
    mlflow_run_id: str
    mlflow_trace_id: str

    # ── Conversation ──────────────────────────────────────────────────────────
    history: list[ChatMessage]       # prior turns loaded from DB
    user_input: str

    # ── Reasoning artifacts ───────────────────────────────────────────────────
    intent: Literal["knowledge_qa", "smalltalk", "out_of_scope"]
    intent_confidence: float
    rewritten_queries: list[str]     # multi-query expansion (1–3 variants)

    # Permission resolution (set by resolve_permissions node)
    permission_context: PermissionContext
    user_groups: list[str]           # mirrors permission_context.user_groups for convenience

    # Retrieval
    retrieved_chunks: list           # list[RetrievedChunk]
    context_ok: bool                 # grade_context result

    # Answer
    answer: str
    citations: list[Citation]

    # ── Control / diagnostics ─────────────────────────────────────────────────
    errors: list[str]
    retrieval_count: int
    avg_retrieval_score: float
    cache_hit: bool
    token_usage: dict           # populated by generate_answer from LLM response
    accumulated_tokens: dict    # running total across ALL LLM nodes         # populated by generate_answer from LLM response

    # ── Infrastructure pass-throughs (not serialised, never logged) ───────────
    _db: object                 # AsyncSession injected by ChatService for DB writes
