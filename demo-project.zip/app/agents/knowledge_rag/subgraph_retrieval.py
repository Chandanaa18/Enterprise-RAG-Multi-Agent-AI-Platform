"""
Retrieval subgraph — invoked as a single node from the parent graph.

Structure:
    START
      │
      ▼
    [fan_out_queries]          deterministic — one tool call per rewritten query
      │
      ▼
    [search_tool_node]         ToolNode — runs vector_search tool for each connector
      │
      ▼
    [merge_results]            deterministic — dedup + sort by score
      │
      ▼
    [rerank_subgraph]          deterministic — cross-encoder rerank
      │
      ▼
    END

Future connectors (SharePoint, Confluence) are added as parallel branches
inside this subgraph — the parent graph never changes.
"""
from __future__ import annotations
import json
import logging
from typing import Optional, TypedDict

from app.core.config import settings
from app.retrieval.vector_store import RetrievedChunk

from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import END, START, StateGraph
from langgraph.prebuilt import ToolNode
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Subgraph state
# ──────────────────────────────────────────────────────────────────────────────

class RetrievalSubgraphState(TypedDict, total=False):
    queries: list[str]
    user_id: str
    user_roles: list[str]
    allowed_connector_ids: list[str]
    messages: list          # used by ToolNode
    retrieved_chunks: list  # final merged result


# ──────────────────────────────────────────────────────────────────────────────
# Tools
# ──────────────────────────────────────────────────────────────────────────────

class VectorSearchInput(BaseModel):
    query: str = Field(description="Search query text")
    user_id: str = Field(description="User ID for ACL filtering")
    user_roles: list[str] = Field(default_factory=list, description="User roles for ACL filtering")
    allowed_connector_ids: Optional[list[str]] = Field(default_factory=list, description="Allowed connector IDs for connector-level filtering")
    top_k: int = Field(default=20, description="Max chunks to retrieve")


def _make_vector_search_tool(connector_id: str = "uploads") -> StructuredTool:
    """Creates a vector search tool for a specific connector."""

    def vector_search(
        query: str,
        user_id: str,
        user_roles: list[str] | None = None,
        allowed_connector_ids: list[str] | None = None,
        top_k: int = 20,
    ):
        """Search indexed documents using semantic + keyword hybrid search."""
        from app.retrieval.search import get_retrieval_service, RetrievalService
        service: RetrievalService = get_retrieval_service()
        chunks = service.retrieve(
            query=query,
            user_id=user_id,
            user_roles=user_roles or [],
            allowed_connector_ids=allowed_connector_ids or [],
            top_k_dense=top_k,
        )
        return [
            {
                "chunk_id":    c.chunk_id,
                "doc_id":      c.doc_id,
                "version_id":  c.version_id,
                "connector_id": c.connector_id,
                "title":       c.title,
                "source_uri":  c.source_uri,
                "content":     c.content,
                "chunk_type":  c.chunk_type,
                "page_no":     c.page_no,
                "section_path": c.section_path,
                "score":       c.score,
            }
            for c in chunks
        ]

    return StructuredTool.from_function(  # type: ignore[call-arg]
        func=vector_search,
        name=f"vector_search_{connector_id}",
        description=f"Hybrid semantic+keyword search over {connector_id} documents",
        args_schema=VectorSearchInput,
    )


# ──────────────────────────────────────────────────────────────────────────────
# Subgraph nodes
# ──────────────────────────────────────────────────────────────────────────────

def _make_fan_out_node(tools: list[StructuredTool]):
    """Creates one tool call per query per connector tool."""
    tool_names = [t.name for t in tools]

    def fan_out_queries(state: RetrievalSubgraphState) -> dict:
        queries                = state.get("queries", [])
        user_id                = state.get("user_id", "")
        user_roles             = state.get("user_roles", [])
        allowed_connector_ids  = state.get("allowed_connector_ids", [])

        if not queries:
            return {"messages": []}

        # Create one tool call per (query, tool) pair
        # The ToolNode will run all of them
        tool_calls = []
        call_id = 0
        for query in queries:
            for tool_name in tool_names:
                tool_calls.append({
                    "name": tool_name,
                    "args": {
                        "query": query,
                        "user_id": user_id,
                        "user_roles": user_roles,
                        "allowed_connector_ids": allowed_connector_ids,
                        "top_k": settings.rag.top_k_dense,
                    },
                    "id": f"call_{call_id}",
                    "type": "tool_call",
                })
                call_id += 1

        logger.info(
            "fan_out_queries queries=%d tools=%d total_calls=%d",
            len(queries), len(tool_names), len(tool_calls),
        )
        ai_msg = AIMessage(content="", tool_calls=tool_calls)
        return {"messages": [ai_msg]}

    return fan_out_queries


def _merge_results(state: RetrievalSubgraphState) -> dict:
    """Merge and deduplicate results from all tool call responses."""
    messages = state.get("messages", [])
    all_chunks: list[dict] = []

    for msg in messages:
        if isinstance(msg, ToolMessage):
            content = msg.content

            # ToolMessage.content is `str | list[str | dict]`.
            # When it arrives as a JSON string, parse it into a list first.
            if isinstance(content, str):
                try:
                    content = json.loads(content)
                except (json.JSONDecodeError, ValueError):
                    continue

            # Filter to dict-only items — a tool could return a mixed list
            # containing strings alongside chunk dicts. Only dicts are valid chunks.
            if isinstance(content, list):
                all_chunks.extend(item for item in content if isinstance(item, dict))

    # Deduplicate by chunk_id, keeping highest score.
    # Use -inf as sentinel so that ANY real score (even negative cross-encoder
    # scores like -1.97) beats an unseen chunk_id.
    seen: dict[str, dict] = {}
    for chunk in all_chunks:
        cid = chunk.get("chunk_id", "") or str(id(chunk))   # fallback key if empty
        if chunk.get("score", 0.0) > seen.get(cid, {}).get("score", float("-inf")):
            seen[cid] = chunk

    merged = sorted(seen.values(), key=lambda c: c.get("score", 0), reverse=True)
    logger.info("merge_results total=%d deduplicated=%d", len(all_chunks), len(merged))

    # Convert dicts back to RetrievedChunk objects
    chunks = [
        RetrievedChunk(
            chunk_id=c.get("chunk_id", ""),
            doc_id=c.get("doc_id", ""),
            version_id=c.get("version_id", ""),
            connector_id=c.get("connector_id", ""),
            title=c.get("title", ""),
            source_uri=c.get("source_uri", ""),
            content=c.get("content", ""),
            chunk_type=c.get("chunk_type", "TEXT"),
            page_no=c.get("page_no"),
            section_path=c.get("section_path") or [],
            score=float(c.get("score", 0)),
        )
        for c in merged
    ]
    return {"retrieved_chunks": chunks}


def _rerank_subgraph(state: RetrievalSubgraphState) -> dict:
    """Cross-encoder rerank merged results."""
    from app.retrieval.rerank import rerank_chunks, diversify_chunks
    chunks  = state.get("retrieved_chunks", [])
    queries = state.get("queries", [])
    if not chunks or not queries:
        return {}

    # Use the first (original) query for reranking
    reranked = rerank_chunks(queries[0], chunks)
    diversified = diversify_chunks(reranked)
    return {"retrieved_chunks": diversified}


# ──────────────────────────────────────────────────────────────────────────────
# Build function
# ──────────────────────────────────────────────────────────────────────────────

def build_retrieval_subgraph():
    """
    Build and compile the retrieval subgraph.
    Returns a compiled LangGraph graph that can be invoked as a node.
    """
    tools = [_make_vector_search_tool("uploads")]

    graph = StateGraph(RetrievalSubgraphState)

    graph.add_node("fan_out_queries",  _make_fan_out_node(tools))
    graph.add_node("search_tool_node", ToolNode(tools))
    graph.add_node("merge_results",    _merge_results)
    graph.add_node("rerank_subgraph",  _rerank_subgraph)

    graph.add_edge(START,             "fan_out_queries")
    graph.add_edge("fan_out_queries", "search_tool_node")
    graph.add_edge("search_tool_node","merge_results")
    graph.add_edge("merge_results",   "rerank_subgraph")
    graph.add_edge("rerank_subgraph", END)

    return graph.compile()
