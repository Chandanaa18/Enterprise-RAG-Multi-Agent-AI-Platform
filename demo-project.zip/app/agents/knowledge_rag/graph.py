"""
KnowledgeRAG parent graph — LangGraph StateGraph that powers the knowledge retrieval pipeline.

Execution flow
--------------
    START
      │
      ▼
    [load_history]           Loads prior conversation turns from the session store.
      │
      ▼
    [parse_intent]           LLM classifies the message: knowledge_qa / smalltalk / out_of_scope.
      │
      ├─ smalltalk / out_of_scope ──────────────────────────────────────────────────┐
      │                                                                               │
      ▼  knowledge_qa                                                                │
    [rewrite_query]          LLM expands the question into 1–3 search variants.      │
      │                                                                               │
      ▼                                                                               │
    [resolve_permissions]    Loads user's PermissionContext (allowed connectors).     │
      │                                                                               │
      ▼                                                                               │
    [retrieve]               Invokes the retrieval subgraph (pgvector hybrid search). │
      │                                                                               │
      ├─ no chunks found ───────────────────────────────────────────────────────────┐│
      │                                                                              ││
      ▼  chunks found                                                                ││
    [permission_recheck]     Defence-in-depth ACL re-validation of every chunk.     ││
      │                                                                              ││
      ▼                                                                              ││
    [grade_context]          LLM judges whether retrieved context is sufficient.    ││
      │                                                                              ││
      ▼                                                                              ││
    [generate_answer]        LLM produces a grounded, cited answer.                 ││
      │                       ◄────────────────────────────────────────────────────┘ │
      ▼                       ◄─────────────────────────────────────────────────────┘
    [format_citations]       Deduplicates and structures Citation objects.
      │
      ▼
    [persist_turn]           Writes user + assistant messages to DB and session store.
      │
      ▼
    END

Routing decisions
-----------------
  After [parse_intent]        → IntentRoute enum   (knowledge_qa | smalltalk)
  After [permission_recheck]  → RetrievalRoute enum (grade_context | no_results)

Adding a new node
-----------------
  1. Add a member to KnowledgeRAGNode.
  2. Implement the node/factory and import it in the imports section below.
  3. Register it with graph.add_node() and wire edges in build_graph().
  No other changes needed — routing and state are fully decoupled from node logic.
"""
from __future__ import annotations

import logging
from typing import Any

import mlflow
from langgraph.graph import END, START, StateGraph

from app.shared.enums import KnowledgeRAGNode, IntentRoute, RetrievalRoute
from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.agents.knowledge_rag.nodes.load_history       import make_load_history_node
from app.agents.knowledge_rag.nodes.parse_intent       import make_parse_intent_node
from app.agents.knowledge_rag.nodes.rewrite_query      import make_rewrite_query_node
from app.agents.knowledge_rag.nodes.grade_context      import make_grade_context_node
from app.agents.knowledge_rag.nodes.generate_answer    import make_generate_answer_node, make_generate_smalltalk_node
from app.agents.knowledge_rag.nodes.format_citations   import format_citations
from app.agents.knowledge_rag.nodes.persist_turn       import make_persist_turn_node
from app.agents.knowledge_rag.nodes.permission_recheck  import permission_recheck
from app.agents.knowledge_rag.nodes.resolve_permissions import resolve_permissions

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Node: no_results (inline — no LLM, no factory needed)
# ──────────────────────────────────────────────────────────────────────────────

def _no_results_node(state: KnowledgeRAGState) -> dict:
    """
    Reached when the vector store returns zero chunks for all rewritten queries.
    Returns a user-friendly message without invoking any LLM.

    If the user has no connector access at all, returns a permission-specific
    message instead of a generic "documents not indexed" one.
    """
    session_id         = state.get("session_id", "")
    permission_context = state.get("permission_context")

    logger.info("event=no_results session=%s", session_id)

    # No connector access → permission problem, not a missing-docs problem.
    if permission_context is not None and not permission_context.allowed_connectors:
        from app.core.constants import ALL_SUPPORTED_CONNECTORS
        connectors_list = ", ".join(ALL_SUPPORTED_CONNECTORS) or "any connector"
        logger.info(
            "event=no_results_permission_denied session=%s user=%s",
            session_id, state.get("user_id", ""),
        )
        return {
            "answer": (
                "You don't have permission to access any document connectors "
                f"({connectors_list}). "
                "Please contact your administrator to request access."
            ),
            "context_ok": False,
            "citations": [],
        }

    return {
        "answer": (
            "I couldn't find any documents accessible to you that are relevant to your question. "
            "The content may be restricted or not yet indexed. "
            "If you believe you should have access, please contact your administrator."
        ),
        "context_ok": False,
        "citations": [],
    }


# ──────────────────────────────────────────────────────────────────────────────
# Node: retrieve (class-based — wraps the compiled retrieval subgraph)
# ──────────────────────────────────────────────────────────────────────────────

class _RetrieveNode:
    """
    Invokes the retrieval subgraph and returns the collected chunks with metrics.

    A class is used instead of a closure so the subgraph dependency is explicit
    (visible in __init__) and the node callable itself (_call__) stays clean.
    """

    def __init__(self, subgraph: Any) -> None:
        self._subgraph = subgraph

    def __call__(self, state: KnowledgeRAGState) -> dict:
        # Fall back to the raw user_input if query rewriting produced nothing.
        queries    = state.get("rewritten_queries") or [state.get("user_input", "")]
        user_id    = state.get("user_id", "")
        user_roles = state.get("user_roles", [])
        session_id = state.get("session_id", "")

        # Read connector allow-list from the permission context resolved by
        # resolve_permissions.  Fallback to an empty list keeps the deny-all
        # contract in vector_store.hybrid_search intact.
        permission_context     = state.get("permission_context")
        allowed_connector_ids: list[str] = (
            list(permission_context.allowed_connectors)
            if permission_context is not None
            else []
        )

        logger.info(
            "event=retrieve_start session=%s query_count=%d connectors=%s",
            session_id, len(queries), allowed_connector_ids,
        )

        # Mlflow
        with mlflow.start_span(name="retrieve", span_type="RETRIEVAL") as span:
            span.set_attribute("session_id",       session_id)
            span.set_attribute("query_count",      len(queries))
            span.set_attribute("allowed_connectors", allowed_connector_ids)
            span.set_inputs({"queries": queries[:3]})

            result = self._subgraph.invoke({
                "queries":               queries,
                "user_id":               user_id,
                "user_roles":            user_roles,
                "allowed_connector_ids": allowed_connector_ids,
            })
            chunks    = result.get("retrieved_chunks", [])
            avg_score = (
                sum(getattr(c, "score", 0.0) for c in chunks) / max(len(chunks), 1)
            )

            span.set_attribute("chunks_retrieved", len(chunks))
            span.set_attribute("avg_score",        round(avg_score, 4))
            span.set_outputs({"chunks_retrieved": len(chunks)})

        logger.info(
            "event=retrieve_done session=%s chunks=%d avg_score=%.3f",
            session_id, len(chunks), avg_score,
        )

        return {
            "retrieved_chunks":    chunks,
            "retrieval_count":     len(chunks),
            "avg_retrieval_score": round(avg_score, 4),
        }


# ──────────────────────────────────────────────────────────────────────────────
# Conditional edge routers
# ──────────────────────────────────────────────────────────────────────────────

def _route_after_intent(state: KnowledgeRAGState) -> str:
    """
    Called after [parse_intent] to decide the next node.

    Returns IntentRoute.KNOWLEDGE_QA  → full RAG path (rewrite → retrieve → answer)
    Returns IntentRoute.SMALLTALK     → lightweight LLM response, no retrieval
    """
    intent = state.get("intent", IntentRoute.KNOWLEDGE_QA.value)
    if intent in ("smalltalk", "out_of_scope"):
        return IntentRoute.SMALLTALK.value
    return IntentRoute.KNOWLEDGE_QA.value


def _route_after_retrieve(state: KnowledgeRAGState) -> str:
    """
    Called after [permission_recheck] (which runs immediately after [retrieve]).

    Returns RetrievalRoute.GRADE_CONTEXT  → chunks found, proceed to grading
    Returns RetrievalRoute.NO_RESULTS     → nothing found, skip generation entirely
    """
    chunks = state.get("retrieved_chunks", [])
    return RetrievalRoute.NO_RESULTS.value if not chunks else RetrievalRoute.GRADE_CONTEXT.value


# ──────────────────────────────────────────────────────────────────────────────
# Graph builder — called once at application startup, not per request
# ──────────────────────────────────────────────────────────────────────────────

def build_graph(
    llm_fast:      Any,
    llm_default:   Any,
    session_store: Any,
    subgraph:      Any,
):
    """
    Assemble and compile the KnowledgeRAG LangGraph.

    Called once in KnowledgeRAGAgent.__init__(). The compiled graph is reused
    for every request — LangGraph compilation is expensive and must not happen
    per-request.

    Parameters
    ----------
    llm_fast      : Fast LLM — used for intent classification, query rewriting,
                    and context grading where latency matters more than quality.
    llm_default   : Capable LLM — used for final answer generation where quality
                    is the priority.
    session_store : SessionStore implementation (PostgresSessionStore in production)
                    for loading history and persisting turns.
    subgraph      : Pre-compiled retrieval subgraph that handles vector search
                    and ACL filtering inside pgvector.

    Returns
    -------
    Compiled LangGraph CompiledStateGraph ready for .invoke().
    """
    graph = StateGraph(KnowledgeRAGState)

    # ── Node registration ─────────────────────────────────────────────────────
    graph.add_node(KnowledgeRAGNode.LOAD_HISTORY.value,         make_load_history_node(session_store))
    graph.add_node(KnowledgeRAGNode.PARSE_INTENT.value,         make_parse_intent_node(llm_fast))
    graph.add_node(KnowledgeRAGNode.REWRITE_QUERY.value,        make_rewrite_query_node(llm_fast))
    graph.add_node(KnowledgeRAGNode.RESOLVE_PERMISSIONS.value,  resolve_permissions)
    graph.add_node(KnowledgeRAGNode.RETRIEVE.value,             _RetrieveNode(subgraph))
    graph.add_node(KnowledgeRAGNode.PERMISSION_RECHECK.value,   permission_recheck)
    graph.add_node(KnowledgeRAGNode.GRADE_CONTEXT.value,        make_grade_context_node(llm_fast))
    graph.add_node(KnowledgeRAGNode.GENERATE_ANSWER.value,      make_generate_answer_node(llm_default))
    graph.add_node(KnowledgeRAGNode.GENERATE_SMALLTALK.value,   make_generate_smalltalk_node(llm_fast))
    graph.add_node(KnowledgeRAGNode.NO_RESULTS.value,           _no_results_node)
    graph.add_node(KnowledgeRAGNode.FORMAT_CITATIONS.value,     format_citations)
    graph.add_node(KnowledgeRAGNode.PERSIST_TURN.value,         make_persist_turn_node(session_store))

    # ── Linear edges (deterministic, single next node) ────────────────────────
    graph.add_edge(START,                                       KnowledgeRAGNode.LOAD_HISTORY.value)
    graph.add_edge(KnowledgeRAGNode.LOAD_HISTORY.value,         KnowledgeRAGNode.PARSE_INTENT.value)
    # resolve_permissions sits between rewrite_query and retrieve so that
    # permission_context.allowed_connectors is populated before retrieval.
    graph.add_edge(KnowledgeRAGNode.REWRITE_QUERY.value,        KnowledgeRAGNode.RESOLVE_PERMISSIONS.value)
    graph.add_edge(KnowledgeRAGNode.RESOLVE_PERMISSIONS.value,  KnowledgeRAGNode.RETRIEVE.value)
    graph.add_edge(KnowledgeRAGNode.RETRIEVE.value,           KnowledgeRAGNode.PERMISSION_RECHECK.value)
    graph.add_edge(KnowledgeRAGNode.GRADE_CONTEXT.value,      KnowledgeRAGNode.GENERATE_ANSWER.value)
    graph.add_edge(KnowledgeRAGNode.GENERATE_ANSWER.value,    KnowledgeRAGNode.FORMAT_CITATIONS.value)
    graph.add_edge(KnowledgeRAGNode.FORMAT_CITATIONS.value,   KnowledgeRAGNode.PERSIST_TURN.value)
    graph.add_edge(KnowledgeRAGNode.PERSIST_TURN.value,       END)

    # ── Shortcut paths (non-knowledge intents and empty retrieval) ────────────
    # Both generate_smalltalk and no_results skip RAG and go straight to END.
    graph.add_edge(KnowledgeRAGNode.GENERATE_SMALLTALK.value, END)
    graph.add_edge(KnowledgeRAGNode.NO_RESULTS.value,         END)

    # ── Conditional edge 1: after intent classification ───────────────────────
    # knowledge_qa  → full RAG path starting at rewrite_query
    # smalltalk     → lightweight generation (also covers out_of_scope)
    graph.add_conditional_edges(
        KnowledgeRAGNode.PARSE_INTENT.value,
        _route_after_intent,
        {
            IntentRoute.KNOWLEDGE_QA.value: KnowledgeRAGNode.REWRITE_QUERY.value,
            IntentRoute.SMALLTALK.value:    KnowledgeRAGNode.GENERATE_SMALLTALK.value,
        },
    )

    # ── Conditional edge 2: after permission-aware retrieval + ACL check ────────
    # grade_context → chunks were found, assess quality before generating
    # no_results    → nothing retrieved, return a template message immediately
    graph.add_conditional_edges(
        KnowledgeRAGNode.PERMISSION_RECHECK.value,
        _route_after_retrieve,
        {
            RetrievalRoute.GRADE_CONTEXT.value: KnowledgeRAGNode.GRADE_CONTEXT.value,
            RetrievalRoute.NO_RESULTS.value:    KnowledgeRAGNode.NO_RESULTS.value,
        },
    )

    return graph.compile()
