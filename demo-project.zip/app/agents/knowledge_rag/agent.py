"""
KnowledgeRAGAgent — entry point for the knowledge retrieval pipeline.

Wraps the compiled LangGraph with session management and MLflow tracing.
Called from the FastAPI chat endpoint (and later from RouterSupervisor).
"""
from __future__ import annotations
import logging
import threading
import time
import uuid

import mlflow

from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.infrastructure.database.session_store import SessionStore
from app.shared.utils.logger.logger import Logger

logger = Logger(__file__)
class AgentResult:
    """Return type from KnowledgeRAGAgent.handle()."""
    __slots__ = ("text", "agent", "session_id", "can_answer", "citations",
                 "mlflow_run_id", "mlflow_trace_id")

    def __init__(
        self,
        text: str,
        agent: str,
        session_id: str,
        can_answer: bool,
        citations: tuple = (),
        mlflow_run_id: str = "",
        mlflow_trace_id: str = "",
    ) -> None:
        self.text            = text
        self.agent           = agent
        self.session_id      = session_id
        self.can_answer      = can_answer
        self.citations       = citations
        self.mlflow_run_id   = mlflow_run_id
        self.mlflow_trace_id = mlflow_trace_id


class KnowledgeRAGAgent:
    def __init__(
        self,
        *,
        llm_fast=None,
        llm_default=None,
        llm=None,           # legacy single-llm fallback
        session_store: SessionStore,
    ) -> None:
        self._session_store = session_store

        _llm_fast    = llm_fast    or llm or self._build_default_llm("KNOWLEDGE_FAST")
        _llm_default = llm_default or llm or self._build_default_llm("KNOWLEDGE_DEFAULT")

        from app.agents.knowledge_rag.subgraph_retrieval import build_retrieval_subgraph
        from app.agents.knowledge_rag.graph import build_graph
        self._subgraph = build_retrieval_subgraph()
        self._graph    = build_graph(
            llm_fast=_llm_fast,
            llm_default=_llm_default,
            session_store=session_store,
            subgraph=self._subgraph,
        )
        logger.info("KnowledgeRAGAgent initialized")

    @staticmethod
    def _patch_mlflow_run_id(session_id: str, run_id: str) -> None:
        """Update the most recent assistant message row with the MLflow run ID.

        Runs in a daemon thread after graph.invoke() returns — avoids blocking
        the response and works around LangGraph state key propagation issues.
        """
        import asyncio
        import uuid as _uuid
        from sqlalchemy import text
        from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
        from app.core.config import settings

        async def _run() -> None:
            engine = create_async_engine(settings.db.url, pool_pre_ping=True)
            try:
                async with AsyncSession(engine) as db:
                    await db.execute(text("""
                        UPDATE enterprise_rag_system.messages
                        SET mlflow_run_id = :run_id
                        WHERE message_id = (
                            SELECT message_id
                            FROM enterprise_rag_system.messages
                            WHERE session_id = :session_id
                              AND role = 'assistant'
                            ORDER BY created_at DESC
                            LIMIT 1
                        )
                    """), {"run_id": run_id, "session_id": str(session_id)})
                    await db.commit()
            finally:
                await engine.dispose()

        try:
            asyncio.run(_run())
        except Exception as exc:
            logger.warn("_patch_mlflow_run_id failed session=%s: %s", session_id, exc)

    @staticmethod
    def _build_default_llm(logical_id: str):
        try:
            from app.llm.provider_factory import get_provider_factory
            return get_provider_factory().get_chat_model(logical_id)
        except Exception as exc:
            logger.warn("Could not build LLM for %s: %s — using FakeChatModel", logical_id, exc)
            from app.llm.provider_factory import _FakeChatModel
            return _FakeChatModel(logical_id)

    def handle(
        self,
        *,
        question: str,
        session_id: str,
        user_id: str,
        user_roles: list[str],
        db=None,
    ) -> AgentResult:
        logger.info(
            "request received",
            event="request_received",
            agent_name="knowledge_rag",
            session_id=session_id,
            user_id=user_id,
        )

        expired_holder: list = [False]

        def _check_expired() -> None:
            expired_holder[0] = self._session_store.is_expired(session_id)

        thread = threading.Thread(target=_check_expired, daemon=True)
        thread.start()
        thread.join(timeout=5)

        if expired_holder[0]:
            logger.warn("session expired", event="session_expired", session_id=session_id)
            return AgentResult(
                text="Your session has expired. Please start a new conversation.",
                agent="knowledge_rag",
                session_id=session_id,
                can_answer=False,
            )

        request_id = str(uuid.uuid4())
        run_id     = ""
        trace_id   = ""

        try:
            mlflow_ctx = mlflow.start_run(run_name=f"rag_{session_id[:8]}", nested=True)
        except Exception:
            from contextlib import nullcontext
            mlflow_ctx = nullcontext()

        with mlflow_ctx as run:
            if run is not None:
                run_id = run.info.run_id
                try:
                    mlflow.set_tags({
                        "session_id": session_id,
                        "user_id":    user_id,
                        "agent":      "knowledge_rag",
                        "request_id": request_id,
                    })
                    mlflow.log_params({
                        "question":   question[:256],
                        "user_roles": ",".join(user_roles),
                    })
                except Exception:
                    pass

            try:
                span_ctx = mlflow.start_span(name="knowledge_rag_request", span_type="CHAIN")
            except Exception:
                from contextlib import nullcontext
                span_ctx = nullcontext()

            with span_ctx as span:
                if span is not None:
                    try:
                        span.set_attribute("session_id", session_id)
                        span.set_attribute("user_id",    user_id)
                        span.set_attribute("request_id", request_id)
                        span.set_inputs({"question": question, "session_id": session_id})
                        trace_id = span.request_id if hasattr(span, "request_id") else ""
                    except Exception:
                        pass

                init_state: KnowledgeRAGState = {
                    "session_id":    session_id,
                    "user_id":       user_id,
                    "user_roles":    user_roles,
                    "user_input":    question,
                    "request_id":    request_id,
                    "mlflow_run_id": run_id,
                    "errors":        [],
                    "_db":           db,
                }
                _t0 = time.monotonic()
                final = self._graph.invoke(init_state)
                _duration = round(time.monotonic() - _t0, 3)
                if span is not None:
                    try:
                        span.set_outputs({"answer": final.get("answer"), "citations_count": len(final.get("citations", []))})
                    except Exception:
                        pass

            token_usage       = final.get("token_usage") or {}
            accumulated       = final.get("accumulated_tokens") or {}

            total_input  = accumulated.get("input_tokens",  0) + token_usage.get("input_tokens",  0)
            total_output = accumulated.get("output_tokens", 0) + token_usage.get("output_tokens", 0)
            total        = accumulated.get("total_tokens",  0) + token_usage.get("total_tokens",  0)

            if run is not None:
                try:
                    mlflow.log_metrics({
                        "retrieval_count":     final.get("retrieval_count",     0),
                        "avg_retrieval_score": final.get("avg_retrieval_score", 0.0),
                        "context_ok":          1 if final.get("context_ok") else 0,
                        "answer_length":       len(final.get("answer", "")),
                        "citations_count":     len(final.get("citations", [])),
                        "total_input_tokens":  total_input,
                        "total_output_tokens": total_output,
                        "total_tokens":        total,
                        "total_cost_usd":      token_usage.get("cost_usd", 0.0),
                    })
                except Exception:
                    pass

        answer     = final.get("answer", "")
        citations  = tuple(final.get("citations", []))
        can_answer = final.get("context_ok", False)

        logger.info(
            "response returned",
            event="response_returned",
            agent_name="knowledge_rag",
            session_id=session_id,
            can_answer=can_answer,
            duration_seconds=_duration,
            total_tokens=total,
            retrieval_count=final.get("retrieval_count", 0),
            avg_retrieval_score=final.get("avg_retrieval_score", 0.0),
            citations_count=len(citations),
        )

        return AgentResult(
            text=answer,
            agent="knowledge_rag",
            session_id=session_id,
            can_answer=can_answer,
            citations=citations,
            mlflow_run_id=run_id,
            mlflow_trace_id=trace_id,
        )