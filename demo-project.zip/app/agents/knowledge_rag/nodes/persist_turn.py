"""
persist_turn node — deterministic.

Writes the user + assistant messages via the session store, updates
last_active_at via touch(), and appends an audit log row.

No LLM involved.

Threading note: same as load_history — the DB calls inside PostgresSessionStore
use asyncio.run(), so we must invoke them from a daemon thread rather than
the FastAPI event-loop thread directly.
"""
from __future__ import annotations
import asyncio
import logging
import threading
import uuid

import mlflow

from app.shared.enums import AgentName, AuditOutcome, MessageRole
from app.agents.knowledge_rag.state import KnowledgeRAGState
logger = logging.getLogger(__name__)
def make_persist_turn_node(session_store):

    def persist_turn(state: KnowledgeRAGState) -> dict:
        session_id  = state.get("session_id", "")
        user_id     = state.get("user_id", "")
        user_input  = state.get("user_input", "")
        answer      = state.get("answer", "")
        chunks      = state.get("retrieved_chunks", [])
        mlflow_run  = state.get("mlflow_run_id")
        token_usage = state.get("token_usage")
        agent_name  = AgentName.KNOWLEDGE_RAG

        logger.info("node=persist_turn session=%s", session_id)

        with mlflow.start_span(name="persist_turn", span_type="FUNC") as span:
            span.set_inputs({
                "session_id":    session_id,
                "answer_length": len(answer),
                "chunk_count":   len(chunks),
            })

            if not session_id:
                logger.warning("persist_turn: no session_id — skipping DB write")
                span.set_outputs({"status": "skipped_no_session"})
                return {}

            error_holder: list = []

            def _run() -> None:
                try:
                    from app.agents.knowledge_rag.state import ChatMessage

                    # Write user + assistant messages via the session store
                    session_store.append_turn(session_id, ChatMessage(role=MessageRole.USER.value.lower(),      content=user_input))
                    session_store.append_turn(session_id, ChatMessage(role=MessageRole.ASSISTANT.value.lower(), content=answer, mlflow_run_id=mlflow_run))
                    session_store.touch(session_id)

                    # Audit log — separate concern, written directly via ORM
                    asyncio.run(_write_audit_log(
                        session_id=session_id,
                        user_id=user_id,
                        agent_name=agent_name,
                        chunks=chunks,
                        mlflow_run_id=mlflow_run,
                        token_usage=token_usage,
                    ))

                except Exception as exc:
                    error_holder.append(exc)

            thread = threading.Thread(target=_run, daemon=True)
            thread.start()
            thread.join(timeout=15)

            if error_holder:
                logger.error("persist_turn: DB write failed: %s", error_holder[0])
                span.set_outputs({"status": "error"})
            elif thread.is_alive():
                logger.warning("persist_turn: DB write timed out (>15s)")
                span.set_outputs({"status": "timeout"})
            else:
                logger.info("persist_turn: ok session=%s", session_id)
                span.set_outputs({"status": "ok"})

        return {}

    return persist_turn


# ──────────────────────────────────────────────────────────────────────────────
# Audit log helper
# ──────────────────────────────────────────────────────────────────────────────

async def _write_audit_log(
    *,
    session_id: str,
    user_id: str,
    agent_name: str,
    chunks: list,
    mlflow_run_id,
    token_usage,
) -> None:
    """Insert one audit_logs row using a fresh engine (safe for asyncio.run() in threads)."""
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from app.core.config import settings
    from app.domains.chat.models.audit_log_model import AuditLog

    doc_ids = list({
        getattr(c, "doc_id", "") for c in chunks if getattr(c, "doc_id", "")
    })

    try:
        sid = uuid.UUID(session_id) if session_id else None
        uid = uuid.UUID(user_id)    if user_id    else None
    except ValueError:
        sid = None
        uid = None

    engine = create_async_engine(settings.db.url, pool_pre_ping=True)
    try:
        async with AsyncSession(engine) as db:
            db.add(AuditLog(
                log_id=uuid.uuid4(),
                user_id=uid,
                session_id=sid,
                agent_name=agent_name,
                action="answer",
                target_system="knowledge_rag",
                target_resource=str(doc_ids[:10]),
                outcome=AuditOutcome.SUCCESS,
                metadata_={
                    "mlflow_run_id": str(mlflow_run_id) if mlflow_run_id else None,
                    "token_usage": token_usage or {},
                    "doc_ids": doc_ids[:10],
                },
            ))
            await db.commit()
    finally:
        await engine.dispose()
