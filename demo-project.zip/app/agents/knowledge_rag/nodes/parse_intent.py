"""
parse_intent node — LLM reasoning node.
Classifies the user's intent as knowledge_qa / smalltalk / out_of_scope.
Prompt is loaded from MLflow prompt registry; falls back to embedded default.
"""
from __future__ import annotations
import json
import logging
import re
import mlflow
from app.agents.knowledge_rag.nodes.generate_answer import _extract_token_usage
from app.agents.knowledge_rag.state import KnowledgeRAGState

logger = logging.getLogger(__name__)
# INTERNAL PROMPT
INTENT_PROMPT_DEFAULT = """You are an intent classifier for an enterprise knowledge assistant.

Classify the user's message into exactly one of:
- knowledge_qa  — asking a question whose answer should come from internal documents
- smalltalk     — greetings, thanks, casual chit-chat
- out_of_scope  — asking for actions (create ticket, send email) or clearly irrelevant

Return JSON only: {{"intent": "<one of above>", "confidence": 0.0..1.0}}

User message: {user_input}"""


def make_parse_intent_node(llm):
    """Factory: returns a node function bound to the LLM."""

    def parse_intent(state: KnowledgeRAGState) -> dict:
        user_input = state.get("user_input", "")
        session_id = state.get("session_id", "")
        logger.info("node=parse_intent session=%s input=%r", session_id, user_input[:80])

        prompt_template = _load_prompt_or_default()
        prompt = prompt_template.format(user_input=user_input)

        with mlflow.start_span(name="parse_intent_llm", span_type="LLM") as span:
            span.set_attribute("prompt.name",    "intent_classify")
            span.set_attribute("prompt.version", "1")
            span.set_attribute("node",           "parse_intent")
            span.set_inputs({"prompt": prompt, "user_input": user_input})

            response    = llm.invoke([{"role": "user", "content": prompt}])
            content     = response.content if hasattr(response, "content") else str(response)
            token_usage = _extract_token_usage(response)

            model_name = getattr(llm, "model_used", "llama-3.3-70b-versatile")
            from app.agents.knowledge_rag.nodes.generate_answer import _compute_cost
            cost_usd = _compute_cost(
                model_name,
                token_usage.get("input_tokens",  0),
                token_usage.get("output_tokens", 0),
            )
            span.set_attribute("llm.provider",  getattr(llm, "provider_used", "unknown"))
            span.set_attribute("llm.model",     model_name)
            span.set_attribute("llm.cost_usd",  cost_usd)
            if token_usage:
                span.set_attribute("tokens.input",  token_usage.get("input_tokens",  0))
                span.set_attribute("tokens.output", token_usage.get("output_tokens", 0))
                span.set_attribute("tokens.total",  token_usage.get("total_tokens",  0))
            span.set_outputs({"response": content, "cost_usd": cost_usd})

        intent, confidence = _parse_response(content)
        logger.info("node=parse_intent session=%s intent=%s confidence=%.2f",
                    session_id, intent, confidence)

        try:
            mlflow.set_tag("intent", intent)
        except Exception:
            pass

        # Accumulate tokens across all LLM nodes
        existing = state.get("accumulated_tokens") or {}
        accumulated = {
            "input_tokens":  existing.get("input_tokens",  0) + token_usage.get("input_tokens",  0),
            "output_tokens": existing.get("output_tokens", 0) + token_usage.get("output_tokens", 0),
            "total_tokens":  existing.get("total_tokens",  0) + token_usage.get("total_tokens",  0),
        }
        return {"intent": intent, "intent_confidence": confidence, "accumulated_tokens": accumulated}

    return parse_intent


def _load_prompt_or_default() -> str:
    """Load from MLflow prompt registry; return embedded default on any failure."""
    try:
        prompt_obj = mlflow.genai.load_prompt("intent_classify", version=1)
        template   = prompt_obj.template
        if isinstance(template, str):
            return template
        return "\n".join(
            msg.get("content", "") for msg in template if isinstance(msg, dict)
        )
    except Exception:
        return INTENT_PROMPT_DEFAULT


def _parse_response(content: str) -> tuple[str, float]:
    """Parse intent classification JSON from LLM response."""
    valid_intents = {"knowledge_qa", "smalltalk", "out_of_scope"}
    try:
        data       = json.loads(content.strip())
        intent     = data.get("intent", "knowledge_qa")
        confidence = float(data.get("confidence", 0.8))
        if intent not in valid_intents:
            intent = "knowledge_qa"
        return intent, confidence
    except Exception:
        pass

    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", content, re.DOTALL)
    if m:
        try:
            data       = json.loads(m.group(1))
            intent     = data.get("intent", "knowledge_qa")
            confidence = float(data.get("confidence", 0.8))
            if intent in valid_intents:
                return intent, confidence
        except Exception:
            pass

    lower = content.lower()
    if "smalltalk" in lower:
        return "smalltalk", 0.7
    if "out_of_scope" in lower or "out of scope" in lower:
        return "out_of_scope", 0.7
    return "knowledge_qa", 0.6