"""
load_history node — deterministic.

Loads the last N conversation turns for this session from the session store
(PostgresSessionStore in production).  No LLM involved.

Threading note: LangGraph invoke() is synchronous but runs inside the FastAPI
asyncio event loop.  The session store's DB calls use asyncio.run() internally,
which requires a thread without an active event loop.  We therefore run the
store call in a short-lived daemon thread, identical to the old approach but
now the raw psycopg2 code is gone — the session store handles all DB access.
"""
from __future__ import annotations
import logging
import threading

import mlflow

from app.agents.knowledge_rag.state import KnowledgeRAGState

logger = logging.getLogger(__name__)
def make_load_history_node(session_store):

    def load_history(state: KnowledgeRAGState) -> dict:
        session_id = state.get("session_id", "")
        logger.info("node=load_history session=%s", session_id)

        with mlflow.start_span(name="load_history", span_type="FUNC") as span:
            span.set_inputs({"session_id": session_id})

            if not session_id:
                span.set_outputs({"history_count": 0, "status": "skipped_no_session"})
                return {"history": []}

            result_holder: list = []
            error_holder: list = []

            def _run() -> None:
                try:
                    history = session_store.load_history(session_id)
                    result_holder.extend(history)
                except Exception as exc:
                    error_holder.append(exc)

            thread = threading.Thread(target=_run, daemon=True)
            thread.start()
            thread.join(timeout=10)

            if error_holder:
                logger.warning("load_history: failed: %s", error_holder[0])
                span.set_outputs({"history_count": 0, "status": "error"})
                return {"history": []}
            if thread.is_alive():
                logger.warning("load_history: timed out after 10s")
                span.set_outputs({"history_count": 0, "status": "timeout"})
                return {"history": []}

            logger.info("load_history session=%s loaded=%d messages", session_id, len(result_holder))
            span.set_outputs({"history_count": len(result_holder), "status": "ok"})
            return {"history": result_holder}

    return load_history
