"""
permission_recheck node — deterministic, defence-in-depth security check.

Why this node exists
--------------------
pgvector already filters chunks by ACL before they reach application memory.
This node is a second, independent check in pure Python — a "tripwire" that
detects regressions in the pgvector ACL filter before they silently serve
unauthorized data to users.

Two chunk types are handled differently:

  RetrievedChunk  (modern — from UploadsConnector)
      pgvector enforced the ACL at query time via acl_user_ids / acl_roles /
      acl_public properties on the collection. No additional metadata to
      inspect here — the database-level filter is trusted.

  Legacy Chunk  (from stub connectors)
      May carry metadata["allowed_roles"]. If that field is present, the user
      must hold at least one of those roles. If it is absent, the chunk is
      treated as public and accessible to everyone.

Security contract
-----------------
If ANY chunk fails the ACL check, this node raises RuntimeError immediately.
We do NOT silently drop the offending chunk — a violation means the primary
ACL filter has a regression that must be investigated and fixed urgently.
"""
from __future__ import annotations

import logging
from enum import StrEnum
from typing import Any

import mlflow

from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.retrieval.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────────────────────────────────────

class ChunkCheckOutcome(StrEnum):
    """
    Result of the ACL validation for a single chunk.

    Each value is written to the structured log so security audits can filter
    on specific outcomes (e.g. grep for 'outcome=denied' in production logs).
    """
    TRUSTED    = "trusted"     # RetrievedChunk — pgvector ACL already enforced
    PUBLIC     = "public"      # Legacy chunk — no allowed_roles → open access
    AUTHORISED = "authorised"  # Legacy chunk — user holds at least one required role
    DENIED     = "denied"      # Legacy chunk — user holds none of the required roles


class NodeOutcome(StrEnum):
    """
    Overall result of the permission_recheck node execution.
    Written to the structured log on every exit path.
    """
    SKIPPED = "skipped"   # No chunks were present — nothing to validate
    PASSED  = "passed"    # All chunks cleared the ACL check
    FAILED  = "failed"    # At least one unauthorized chunk detected → RuntimeError


# ──────────────────────────────────────────────────────────────────────────────
# Node
# ──────────────────────────────────────────────────────────────────────────────

def permission_recheck(state: KnowledgeRAGState) -> dict:
    """
    Validate that every retrieved chunk is accessible to the requesting user.

    Runs immediately after [retrieve] as a defence-in-depth layer.
    This node only validates — it does not modify the retrieved_chunks list
    and does not add new fields to the state.

    Returns
    -------
    dict
        Empty dict on success (no state changes needed).

    Raises
    ------
    RuntimeError
        If any chunk fails the ACL check. This signals an ACL filter regression
        in pgvector that must be investigated as a security incident.
    """
    chunks     = state.get("retrieved_chunks", [])
    user_id    = state.get("user_id", "")
    user_roles = frozenset(state.get("user_roles", []))
    session_id = state.get("session_id", "")

    with mlflow.start_span(name="permission_recheck", span_type="FUNC") as span:
        span.set_inputs({"chunk_count": len(chunks), "user_id": user_id})

        # Nothing to validate — retrieval returned zero chunks.
        if not chunks:
            logger.info(
                "event=permission_recheck outcome=%s session=%s",
                NodeOutcome.SKIPPED, session_id,
            )
            span.set_outputs({"outcome": NodeOutcome.SKIPPED, "chunks_validated": 0})
            return {}

        logger.info(
            "event=permission_recheck_start session=%s user=%s chunk_count=%d",
            session_id, user_id, len(chunks),
        )

        # Check every chunk and collect the IDs of any that fail.
        denied_chunk_ids: list[str] = []

        for chunk in chunks:
            outcome, chunk_id = _check_chunk(chunk, user_roles, user_id=user_id)
            if outcome == ChunkCheckOutcome.DENIED:
                denied_chunk_ids.append(chunk_id)

        # Any denial is a hard failure — raise immediately, do not continue.
        if denied_chunk_ids:
            span.set_outputs({"outcome": NodeOutcome.FAILED, "denied_count": len(denied_chunk_ids)})
            _raise_acl_regression(session_id, user_id, denied_chunk_ids)

        logger.info(
            "event=permission_recheck outcome=%s session=%s user=%s "
            "chunks_validated=%d sampled_doc_ids=%s",
            NodeOutcome.PASSED,
            session_id,
            user_id,
            len(chunks),
            _sample_doc_ids(chunks),
        )

        span.set_outputs({"outcome": NodeOutcome.PASSED, "chunks_validated": len(chunks)})

    return {}


# ──────────────────────────────────────────────────────────────────────────────
# Per-chunk validation
# ──────────────────────────────────────────────────────────────────────────────

def _check_chunk(
    chunk: Any,
    user_roles: frozenset[str],
    user_id: str = "",
) -> tuple[ChunkCheckOutcome, str]:
    """
    Decide whether a single chunk is accessible to the current user.

    Parameters
    ----------
    chunk      : Either a RetrievedChunk (modern) or a legacy Chunk object.
    user_roles : Immutable set of roles the requesting user holds.
    user_id    : Internal user UUID string for acl_user_ids membership check.

    Returns
    -------
    tuple[ChunkCheckOutcome, str]
        The access decision and a stable chunk identifier for logging.
    """
    # ── Path 1: RetrievedChunk (modern, from pgvector) ────────────────────────
    # pgvector enforces ACL in the WHERE-clause, but we re-verify here as a
    # defence-in-depth tripwire. If pgvector ever has a regression, this node
    # catches it before the LLM sees the content.
    if isinstance(chunk, RetrievedChunk):
        acl_user_ids: list[str] = getattr(chunk, "acl_user_ids", []) or []
        acl_roles:    list[str] = getattr(chunk, "acl_roles",    []) or []
        acl_public:   bool      = getattr(chunk, "acl_public",   False)

        # If the chunk carries no ACL fields (older schema / missing attrs),
        # fall back to TRUSTED so we don't break existing deployments.
        # A chunk with explicit non-empty ACL fields MUST pass the check.
        has_acl = acl_user_ids or acl_roles or acl_public is True

        if not has_acl:
            # No ACL stored on chunk object — trust the SQL filter result.
            return ChunkCheckOutcome.TRUSTED, chunk.chunk_id

        if acl_public:
            return ChunkCheckOutcome.TRUSTED, chunk.chunk_id

        if user_id and user_id in acl_user_ids:
            return ChunkCheckOutcome.TRUSTED, chunk.chunk_id

        if user_roles & set(acl_roles):
            return ChunkCheckOutcome.TRUSTED, chunk.chunk_id

        return ChunkCheckOutcome.DENIED, chunk.chunk_id

    # ── Path 2: Legacy Chunk (from stub connectors) ───────────────────────────
    # These chunks may carry a metadata dict with an "allowed_roles" field.
    chunk_id: str = (
        getattr(chunk, "chunk_id", None)
        or getattr(chunk, "id", None)
        or "unknown"
    )
    allowed_roles: list[str] | None = (
        getattr(chunk, "metadata", {}).get("allowed_roles")
    )

    # No allowed_roles entry → the chunk is public, accessible to everyone.
    if allowed_roles is None:
        return ChunkCheckOutcome.PUBLIC, chunk_id

    # User holds at least one of the required roles → access granted.
    if user_roles & set(allowed_roles):
        return ChunkCheckOutcome.AUTHORISED, chunk_id

    # User holds none of the required roles → access denied.
    return ChunkCheckOutcome.DENIED, chunk_id


# ──────────────────────────────────────────────────────────────────────────────
# Logging helpers
# ──────────────────────────────────────────────────────────────────────────────

def _sample_doc_ids(chunks: list[Any], limit: int = 5) -> list[str]:
    """
    Return up to `limit` unique document IDs from the validated chunk list.
    Used in the success log to confirm which documents were cleared.
    """
    seen: set[str] = set()
    result: list[str] = []
    for chunk in chunks:
        doc_id = chunk.doc_id if isinstance(chunk, RetrievedChunk) else ""
        if doc_id and doc_id not in seen:
            seen.add(doc_id)
            result.append(doc_id)
        if len(result) >= limit:
            break
    return result


def _raise_acl_regression(
    session_id: str,
    user_id: str,
    denied_chunk_ids: list[str],
) -> None:
    """
    Emit a CRITICAL security log and raise RuntimeError.

    This is intentionally loud and non-recoverable. Reaching this function
    means the pgvector ACL filter allowed unauthorized data through — that is a
    security incident, not a routine error to be caught and retried.
    """
    logger.critical(
        "event=acl_regression_detected outcome=%s "
        "session=%s user=%s denied_count=%d denied_chunk_ids=%s "
        "— UNAUTHORIZED CHUNKS PASSED THE PGVECTOR ACL FILTER. "
        "Treat this as a security incident and investigate immediately.",
        NodeOutcome.FAILED,
        session_id,
        user_id,
        len(denied_chunk_ids),
        denied_chunk_ids,
    )
    raise RuntimeError(
        f"ACL filter regression: {len(denied_chunk_ids)} unauthorized chunk(s) "
        f"passed the pgvector ACL filter for user '{user_id}'. "
        f"Denied chunk IDs: {denied_chunk_ids}. "
        f"See CRITICAL log for full context."
    )
