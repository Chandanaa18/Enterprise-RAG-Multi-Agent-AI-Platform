"""
resolve_permissions node — loads and stores the requesting user's PermissionContext.

Position in the graph
---------------------
    [rewrite_query]
         │
         ▼
    [resolve_permissions]   ← this node
         │
         ▼
    [retrieve_context]

Why a dedicated node
--------------------
Separating permission resolution from retrieval keeps the two concerns
independently testable and observable:

  1. The permission system can evolve (new group sources, new connectors)
     without touching retrieval logic.
  2. The resolved PermissionContext is stored in state so it appears in
     MLflow traces and is available to any future node that needs it.
  3. Retrieval only has to call build_filters() — it never queries the DB
     for permission data.

Failure strategy
----------------
If permission loading fails for any reason (DB unavailable, user not yet
provisioned), this node returns a fallback PermissionContext built from the
token-supplied roles alone.  Retrieval will still apply the existing
user_id + user_roles ACL filter — the group-enrichment is an enhancement,
not the primary gate.
"""
from __future__ import annotations

import logging

import mlflow

from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.domains.permissions.schemas.permission_context import PermissionContext
from app.domains.permissions.repositories.permission_repository import PermissionRepository
from app.domains.permissions.services.permission_service import PermissionService

logger = logging.getLogger(__name__)
# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------

# Constructed lazily so that the DB pool is not opened at import time (avoids
# spurious connections during test collection or application startup probes).
_permission_repository: PermissionRepository | None = None
_permission_service:    PermissionService    | None = None

def _get_permission_service() -> PermissionService:
    """
    Return the shared PermissionService, constructing it on the first call.

    Thread-safe for reads after the first initialisation (both objects are
    immutable after construction).  A race on the very first call is benign —
    at worst two pools are opened and one is immediately eligible for GC.
    """
    global _permission_repository, _permission_service

    if _permission_service is None:
        _permission_repository = PermissionRepository()
        _permission_service    = PermissionService(_permission_repository)

    return _permission_service


# ---------------------------------------------------------------------------
# Node function
# ---------------------------------------------------------------------------

def resolve_permissions(state: KnowledgeRAGState) -> dict:
    """
    Load the requesting user's full permission set and store it in agent state.

    Reads user_id and user_roles from the current state (populated by the API
    layer from the Azure AD token), then enriches them with group memberships
    loaded from the database.

    Returns
    -------
    dict
        State update containing:
        - ``permission_context``: the resolved PermissionContext object
        - ``user_groups``: list of group names (mirrors permission_context.user_groups
          for convenience — existing nodes that read user_groups directly still work)
    """
    user_id     = state.get("user_id", "")
    token_roles = state.get("user_roles", [])
    session_id  = state.get("session_id", "")

    with mlflow.start_span(name="resolve_permissions", span_type="FUNC") as span:
        span.set_inputs({"user_id": user_id, "role_count": len(token_roles)})

        if not user_id:
            logger.warning(
                "event=resolve_permissions_skipped session=%s reason=missing_user_id",
                session_id,
            )
            fallback_context = _build_fallback_permission_context(
                user_id="",
                token_roles=token_roles,
            )
            span.set_outputs({"status": "fallback_no_user_id", "group_count": 0})
            return {
                "permission_context": fallback_context,
                "user_groups":        [],
            }

        permission_service = _get_permission_service()

        try:
            permission_context: PermissionContext = permission_service.get_user_permissions(
                user_id=user_id,
                token_roles=token_roles,
            )

            logger.info(
                "event=resolve_permissions_success session=%s user=%s "
                "roles=%d groups=%d connectors=%s",
                session_id,
                user_id,
                len(permission_context.user_roles),
                len(permission_context.user_groups),
                permission_context.allowed_connectors,
            )

            span.set_outputs({
                "status":             "ok",
                "group_count":        len(permission_context.user_groups),
                "allowed_connectors": permission_context.allowed_connectors,
            })
            return {
                "permission_context": permission_context,
                "user_groups":        permission_context.user_groups,
            }

        except Exception as exc:
            logger.error(
                "event=resolve_permissions_error session=%s user=%s error=%s "
                "— falling back to token-only permission context",
                session_id,
                user_id,
                exc,
            )
            # TODO - Fix build fallback permission
            fallback_context = _build_fallback_permission_context(
                user_id=user_id,
                token_roles=token_roles,
            )
            span.set_outputs({"status": "fallback_error", "group_count": 0})
            return {
                "permission_context": fallback_context,
                "user_groups":        [],
            }


# ---------------------------------------------------------------------------
# Private helper
# ---------------------------------------------------------------------------

def _build_fallback_permission_context(
    user_id: str,
    token_roles: list[str],
) -> PermissionContext:
    """
    Build a minimal PermissionContext using only the token-supplied roles.

    Used when the database is unreachable or the user record does not yet
    exist.  The fallback preserves token roles so the existing user_id +
    user_roles ACL path continues to function.

    Connector permissions default to deny-all in the fallback path because
    connector grants live in the database — if the database is unreachable,
    we cannot verify what connectors the user is authorised to query.
    Fail-closed is the safe default.
    """
    return PermissionContext(
        user_id=user_id,
        user_roles=token_roles,
        user_groups=[],
        connector_permissions={},
        allowed_connectors=[],
    )
