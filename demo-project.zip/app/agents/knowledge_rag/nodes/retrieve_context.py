"""
retrieve_context node — permission-aware vector retrieval.

Position in the graph
---------------------
    [resolve_permissions]
         │
         ▼
    [retrieve_context]   ← this node
         │
         ▼
    [permission_recheck]

Relationship to the permission pipeline
----------------------------------------
This node is the integration point between the permission system and the
vector store.  It reads the PermissionContext that resolve_permissions stored
in state, converts it to RetrievalFilters via MetadataFilterBuilder, and then
passes those filters directly into each vector-store hybrid_search call.

Unauthorized chunks are excluded by the SQL WHERE-clause inside hybrid_search
before any Python code ever sees them.  permission_recheck (the next node)
provides a second independent check as defence-in-depth.

Multi-query strategy
--------------------
For each rewritten query variant produced by rewrite_query, this node:
  1. Embeds the query text into a vector.
  2. Calls hybrid_search with the combined role+group filter.
  3. Collects all results into a flat list.
After all queries are processed, the results are deduplicated by chunk_id
(keeping the highest score), cross-encoder reranked, and per-document
diversified (max 3 chunks per doc).
"""
from __future__ import annotations

import logging

import mlflow

from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.core.config import settings
from app.llm.embeddings import build_embedder
from app.domains.permissions.services.metadata_filter_builder import (
    MetadataFilterBuilder,
    RetrievalFilters,
)
from app.domains.permissions.schemas.permission_context import PermissionContext
from app.retrieval.rerank import diversify_chunks, rerank_chunks
from app.retrieval.vector_store import RetrievedChunk, get_vector_store

logger = logging.getLogger(__name__)
# Module-level singleton — MetadataFilterBuilder is stateless so one instance
# is safe to share across all requests without synchronisation.
_filter_builder = MetadataFilterBuilder()


# ---------------------------------------------------------------------------
# Node function
# ---------------------------------------------------------------------------

def retrieve_context(state: KnowledgeRAGState) -> dict:
    """
    Execute permission-aware hybrid retrieval for all rewritten query variants.

    Steps
    -----
    1. Read the PermissionContext from state (set by resolve_permissions).
    2. Build RetrievalFilters — merges user roles and group memberships into
       the combined list passed to the SQL ACL WHERE-clause.
    3. Embed and search each query variant independently.
    4. Deduplicate results across query variants, keeping the highest score.
    5. Cross-encoder rerank and per-document diversify.
    6. Return the final chunk list with retrieval metrics.

    Returns
    -------
    dict
        State update containing:
        - ``retrieved_chunks``    : list[RetrievedChunk] after reranking
        - ``retrieval_count``     : number of chunks returned
        - ``avg_retrieval_score`` : mean score across returned chunks
    """
    permission_context: PermissionContext | None = state.get("permission_context")  
    queries    = state.get("rewritten_queries") or [state.get("user_input", "")]
    session_id = state.get("session_id", "")

    # Guard: resolve_permissions must always run before this node.
    # If the context is missing something went wrong in the graph wiring.
    if permission_context is None:
        logger.error(
            "event=retrieve_context_missing_permission_context session=%s "
            "— resolve_permissions must run before retrieve_context. "
            "Returning empty result.",
            session_id,
        )
        return {
            "retrieved_chunks":    [],
            "retrieval_count":     0,
            "avg_retrieval_score": 0.0,
        }

    retrieval_filters: RetrievalFilters = _filter_builder.build_filters(permission_context)

    logger.info(
        "event=retrieve_context_start session=%s user=%s "
        "query_variants=%d roles=%d groups=%d connectors=%s",
        session_id,
        permission_context.user_id,
        len(queries),
        len(permission_context.user_roles),
        len(permission_context.user_groups),
        permission_context.allowed_connectors,
    )

    cache_hit: bool = bool(state.get("cache_hit", False))

    with mlflow.start_span(name="retrieve_context", span_type="RETRIEVAL") as span:
        span.set_attribute("session_id",   session_id)
        span.set_attribute("query_count",  len(queries))
        span.set_attribute("cache_hit",    cache_hit)
        span.set_inputs({"queries": queries[:3]})

        raw_chunks          = _search_all_query_variants(queries, retrieval_filters)
        deduplicated_chunks = _deduplicate_by_chunk_id(raw_chunks)
        final_chunks        = _rerank_and_diversify(queries, deduplicated_chunks)
        average_score       = _compute_average_score(final_chunks)

        span.set_attribute("chunks_raw",         len(raw_chunks))
        span.set_attribute("chunks_deduplicated", len(deduplicated_chunks))
        span.set_attribute("chunks_final",        len(final_chunks))
        span.set_attribute("avg_score",           round(average_score, 4))
        span.set_outputs({"chunks_retrieved": len(final_chunks)})

    logger.info(
        "event=retrieve_context_done session=%s user=%s "
        "raw=%d deduped=%d final=%d avg_score=%.3f cache_hit=%s",
        session_id,
        permission_context.user_id,
        len(raw_chunks),
        len(deduplicated_chunks),
        len(final_chunks),
        average_score,
        cache_hit,
    )

    return {
        "retrieved_chunks":    final_chunks,
        "retrieval_count":     len(final_chunks),
        "avg_retrieval_score": round(average_score, 4),
        "cache_hit":           cache_hit,
    }


# ---------------------------------------------------------------------------
# Private helpers — each does exactly one thing
# ---------------------------------------------------------------------------

def _search_all_query_variants(
    queries:           list[str],
    retrieval_filters: RetrievalFilters,
) -> list[RetrievedChunk]:
    """
    Embed and hybrid-search each query variant, collecting all results.

    Running each variant independently allows different phrasings of the same
    question to surface complementary chunks before deduplication.
    """
    vector_store = get_vector_store()
    embedder     = build_embedder()
    all_chunks:  list[RetrievedChunk] = []

    for query_text in queries:
        try:
            query_vector = embedder.embed_query(query_text)
        except Exception as exc:
            logger.error(
                "embed_query failed for query=%r error=%s "
                "— skipping this query variant",
                query_text[:80],
                exc,
            )
            continue

        # Two independent filters are enforced inside the SQL WHERE-clause:
        #   1. Connector filter: connector_id = ANY(allowed_connector_ids)
        #      — restricts which data sources the user may query.
        #   2. ACL filter: acl_public / acl_user_ids / acl_roles
        #      — restricts which chunks within allowed connectors are visible.
        # Unauthorized chunks never exit the database layer.
        chunks_for_this_query = vector_store.hybrid_search(
            query_text=query_text,
            query_vector=query_vector,
            user_id=retrieval_filters.user_id,
            user_roles=retrieval_filters.combined_roles_and_groups,
            allowed_connector_ids=retrieval_filters.allowed_connector_ids,
            top_k=settings.rag.top_k_dense,
        )
        all_chunks.extend(chunks_for_this_query)

    return all_chunks


def _deduplicate_by_chunk_id(
    chunks: list[RetrievedChunk],
) -> list[RetrievedChunk]:
    """
    Keep only the highest-scoring copy of each chunk across all query variants.

    Uses negative infinity as the sentinel score so that any real score (even
    negative cross-encoder scores) beats an unseen chunk_id on first encounter.
    """
    best_chunk_by_id: dict[str, RetrievedChunk] = {}

    for chunk in chunks:
        existing_chunk = best_chunk_by_id.get(chunk.chunk_id)
        if existing_chunk is None or chunk.score > existing_chunk.score:
            best_chunk_by_id[chunk.chunk_id] = chunk

    return sorted(best_chunk_by_id.values(), key=lambda chunk: chunk.score, reverse=True)


def _rerank_and_diversify(
    queries: list[str],
    chunks:  list[RetrievedChunk],
) -> list[RetrievedChunk]:
    """
    Apply cross-encoder reranking followed by per-document diversification.

    The first (original) query is used for reranking because it best represents
    the user's intent before multi-query expansion added paraphrases.
    """
    if not chunks or not queries:
        return chunks

    primary_query = queries[0]
    top_k_final   = settings.rag.top_k_after_rerank

    reranked    = rerank_chunks(primary_query, chunks, top_k=top_k_final)
    diversified = diversify_chunks(reranked, max_per_doc=3)
    return diversified


def _compute_average_score(chunks: list[RetrievedChunk]) -> float:
    """Return the mean retrieval score, or 0.0 if the chunk list is empty."""
    if not chunks:
        return 0.0
    return sum(chunk.score for chunk in chunks) / len(chunks)
