"""
rewrite_query node — LLM reasoning node.

Purpose
-------
Expands the user's raw question into 1–3 semantically distinct query variants.
Multiple variants improve retrieval recall by approaching the same information
need from different angles (rephrasing, acronym expansion, synonym substitution).

Example
-------
User input : "how do I reset my AD password?"
Output     : [
    "how to reset Active Directory password",
    "AD password reset procedure enterprise",
    "forgot domain account password steps"
]

LLM used   : llm_fast  (speed matters — structured JSON output, short prompt)
MLflow     : one child span "rewrite_query_llm" nested under the request root span
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

import mlflow

from app.agents.knowledge_rag.nodes.generate_answer import _extract_token_usage
from app.agents.knowledge_rag.state import ChatMessage, KnowledgeRAGState

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────

# How many prior conversation turns to include in the rewrite prompt.
# More turns help with follow-up questions ("what about the second step?")
# but increase token cost — 4 strikes the right balance.
_MAX_HISTORY_TURNS = 4

# Hard cap on query variants passed to the retrieval subgraph.
# More variants = better recall but higher pgvector query cost.
_MAX_QUERY_VARIANTS = 3

# ──────────────────────────────────────────────────────────────────────────────
# Prompt template
# ──────────────────────────────────────────────────────────────────────────────

_REWRITE_PROMPT = """\
You are a query expansion assistant for enterprise document search.

Given the user's question and recent conversation history, generate 1 to 3 \
search queries that together maximise recall from a document index.

Rules:
- ALWAYS include the original question as the first query, verbatim and unchanged
- Add rephrased variants only to capture alternative ways the same content \
might be worded in documents
- NEVER interpret, expand, or guess the meaning of abbreviations, acronyms, \
or domain-specific terms — you do not know what they mean in this organisation; \
keep them exactly as the user wrote them
- Keep each query specific and focused — no filler words
- If the original question is already clear and specific, return it as the only query

Return a JSON array of strings only — no explanation, no markdown wrapper.
Example: ["query one", "query two", "query three"]

Conversation history (most recent {max_turns} turns):
{history}

User question: {user_input}"""


# ──────────────────────────────────────────────────────────────────────────────
# Node factory
# ──────────────────────────────────────────────────────────────────────────────

def make_rewrite_query_node(llm: Any):
    """
    Factory that binds the LLM to the rewrite_query node callable.

    Called once at graph build time (not per request). The returned
    inner function becomes the LangGraph node that runs on every request.

    Parameters
    ----------
    llm : Any LangChain chat model. Should be a fast model since this node
          runs on every knowledge_qa request before retrieval begins.
    """

    def rewrite_query(state: KnowledgeRAGState) -> dict:
        user_input = state.get("user_input", "")
        history    = state.get("history", [])
        session_id = state.get("session_id", "")

        logger.info(
            "event=rewrite_query_start session=%s history_turns=%d",
            session_id, len(history),
        )

        history_str = _format_history(history)
        prompt = _REWRITE_PROMPT.format(
            max_turns=_MAX_HISTORY_TURNS,
            history=history_str or "None",
            user_input=user_input,
        )

        with mlflow.start_span(name="rewrite_query_llm", span_type="LLM") as span:
            span.set_attribute("node",          "rewrite_query")
            span.set_attribute("history_turns", len(history))
            span.set_attribute("llm.provider",  getattr(llm, "provider_used", "unknown"))
            span.set_inputs({
                "prompt":        prompt,
                "user_input":    user_input,
                "history_turns": len(history),
            })

            response = llm.invoke([{"role": "user", "content": prompt}])
            raw_content = (
                response.content if hasattr(response, "content") else str(response)
            )
            token_usage = _extract_token_usage(response)

            queries = _parse_queries(raw_content, fallback=user_input)

            model_name = getattr(llm, "model_used", "llama-3.3-70b-versatile")
            from app.agents.knowledge_rag.nodes.generate_answer import _compute_cost
            cost_usd = _compute_cost(
                model_name,
                token_usage.get("input_tokens",  0),
                token_usage.get("output_tokens", 0),
            )
            span.set_attribute("llm.model",    model_name)
            span.set_attribute("llm.cost_usd", cost_usd)
            if token_usage:
                span.set_attribute("tokens.input",  token_usage.get("input_tokens", 0))
                span.set_attribute("tokens.output", token_usage.get("output_tokens", 0))
                span.set_attribute("tokens.total",  token_usage.get("total_tokens", 0))
            span.set_outputs({
                "response":    raw_content,
                "query_count": len(queries),
                "queries":     queries,
                "cost_usd":    cost_usd,
            })

        logger.info(
            "event=rewrite_query_done session=%s query_count=%d queries=%s",
            session_id, len(queries), queries,
        )

        existing = state.get("accumulated_tokens") or {}
        accumulated = {
            "input_tokens":  existing.get("input_tokens",  0) + token_usage.get("input_tokens",  0),
            "output_tokens": existing.get("output_tokens", 0) + token_usage.get("output_tokens", 0),
            "total_tokens":  existing.get("total_tokens",  0) + token_usage.get("total_tokens",  0),
        }
        return {"rewritten_queries": queries, "accumulated_tokens": accumulated}

    return rewrite_query


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _format_history(history: list[ChatMessage]) -> str:
    """
    Serialize the most recent conversation turns into a plain-text block
    suitable for prompt injection.

    ChatMessage is a frozen dataclass (role: str, content: str) — NOT a dict.
    Attributes are accessed directly; .get() does not exist on dataclasses.
    """
    recent = history[-_MAX_HISTORY_TURNS:] if history else []
    return "\n".join(f"{msg.role}: {msg.content}" for msg in recent)


def _parse_queries(raw_content: str, fallback: str) -> list[str]:
    """
    Extract a list of query strings from the LLM's raw response.

    Tries three strategies in order of strictness:
      1. Direct JSON parse of the full response string.
      2. Extract a JSON array from inside a markdown code block.
      3. Return the original user question as a single-element fallback list.

    The fallback guarantees this node never blocks the retrieval pipeline —
    even a malformed LLM response produces at least one usable query.

    Parameters
    ----------
    raw_content : Raw string returned by the LLM.
    fallback    : The original user_input — used when all parse attempts fail.

    Returns
    -------
    list[str]
        Between 1 and _MAX_QUERY_VARIANTS non-empty, stripped query strings.
    """
    # Strategy 1: the entire response is a valid JSON array
    try:
        parsed = json.loads(raw_content.strip())
        if isinstance(parsed, list) and all(isinstance(q, str) for q in parsed):
            queries = [q.strip() for q in parsed if q.strip()]
            if queries:
                return queries[:_MAX_QUERY_VARIANTS]
    except (json.JSONDecodeError, ValueError):
        pass

    # Strategy 2: JSON array is wrapped inside a markdown code block
    code_block = re.search(
        r"```(?:json)?\s*(\[.*?\])\s*```",
        raw_content,
        re.DOTALL,
    )
    if code_block:
        try:
            parsed = json.loads(code_block.group(1))
            if isinstance(parsed, list):
                queries = [
                    q.strip() for q in parsed
                    if isinstance(q, str) and q.strip()
                ]
                if queries:
                    return queries[:_MAX_QUERY_VARIANTS]
        except (json.JSONDecodeError, ValueError):
            pass

    # Strategy 3: LLM returned something unparseable — use the raw question
    logger.warning(
        "event=rewrite_query_parse_failed session=unknown "
        "— LLM did not return valid JSON; falling back to original user input. "
        "raw_response=%r",
        raw_content[:200],
    )
    return [fallback]