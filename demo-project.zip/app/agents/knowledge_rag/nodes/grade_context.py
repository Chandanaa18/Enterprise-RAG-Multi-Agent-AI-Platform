"""
grade_context node — LLM reasoning node.

Purpose
-------
Acts as a quality gate between retrieval and answer generation.
After chunks are fetched from pgvector, this node asks the LLM a simple
binary question: "Is this context actually relevant to the user's question?"

If the answer is NO, the pipeline short-circuits — generate_answer is skipped
and the user gets a "no relevant documents found" response instead of a
hallucinated or off-topic answer.

Why a separate grading step?
-----------------------------
pgvector returns the top-K most similar chunks by vector distance, but
"most similar" does not always mean "sufficient to answer the question."
A query about a very niche topic may return loosely related chunks that
look plausible but would produce a misleading answer. This node catches that.

LLM used   : llm_fast  (yes/no judgment — latency matters, not deep reasoning)
MLflow     : one child span "grade_context_llm" under the request root span,
             with token usage attributes.
"""
from __future__ import annotations

import logging
from enum import StrEnum
from typing import Any

import mlflow

from app.agents.knowledge_rag.nodes.generate_answer import _extract_token_usage
from app.agents.knowledge_rag.state import KnowledgeRAGState
from app.retrieval.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────────────────────────────────────

class ContextGrade(StrEnum):
    """
    The LLM's verdict on whether retrieved context is sufficient to answer
    the user's question.

    SUFFICIENT   → proceed to generate_answer
    INSUFFICIENT → skip generation, return a "no relevant documents" message
    """
    SUFFICIENT   = "sufficient"
    INSUFFICIENT = "insufficient"


# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────

# How many top chunks to include in the grading preview.
_CHUNKS_FOR_PREVIEW  = 6

# Maximum characters taken from each chunk when building the preview.
_CHARS_PER_CHUNK = 500

# Total character cap on the full context block sent to the LLM.
_MAX_CONTEXT_CHARS = 3000

# Separator between chunk previews inside the prompt.
_CHUNK_SEPARATOR = "\n---\n"


# ──────────────────────────────────────────────────────────────────────────────
# Prompt template
# ──────────────────────────────────────────────────────────────────────────────

_GRADE_PROMPT = """\
You are a relevance evaluator for an enterprise knowledge assistant.

Your task: decide whether the retrieved context contains enough information
to answer the user's question accurately.

User question (raw):
{user_input}

Interpreted search queries (typo-corrected, intent-resolved):
{rewritten_queries}

Retrieved context ({chunk_count} source(s), truncated to {max_chars} chars):
{context_preview}

Instructions:
- Use the interpreted search queries as ground truth for what the user actually meant.
- Focus on whether the context is topically relevant to the user's underlying need,
  not on whether it fully or precisely answers the question. Completeness and precision
  are the answer generator's responsibility — yours is only relevance.
- Grade "yes" if the context overlaps meaningfully with the topic of the question.
- Grade "no" only if the context has no meaningful overlap with the topic at all.
- Answer with a single word only: yes or no
- Do NOT explain your reasoning — one word only"""


# ──────────────────────────────────────────────────────────────────────────────
# Node factory
# ──────────────────────────────────────────────────────────────────────────────

def make_grade_context_node(llm: Any):
    """
    Factory that binds the LLM to the grade_context node callable.

    Called once at graph build time (not per request). The returned inner
    function becomes the LangGraph node that runs after every retrieval.

    Parameters
    ----------
    llm : Any LangChain chat model. Should be a fast model — this is a
          yes/no judgment that does not require deep reasoning capability.
    """

    def grade_context(state: KnowledgeRAGState) -> dict:
        chunks            = state.get("retrieved_chunks", [])
        user_input        = state.get("user_input", "")
        rewritten_queries = state.get("rewritten_queries") or []
        session_id        = state.get("session_id", "")

        logger.info(
            "event=grade_context_start session=%s chunk_count=%d",
            session_id, len(chunks),
        )

        # No chunks retrieved at all — skip the LLM call, grade as insufficient.
        if not chunks:
            logger.info(
                "event=grade_context_done session=%s grade=%s reason=no_chunks",
                session_id, ContextGrade.INSUFFICIENT,
            )
            return {"context_ok": False}

        queries_str = (
            "\n".join(f"- {q}" for q in rewritten_queries)
            if rewritten_queries else user_input
        )
        context_preview = _build_context_preview(chunks)
        prompt = _GRADE_PROMPT.format(
            user_input=user_input,
            rewritten_queries=queries_str,
            chunk_count=min(len(chunks), _CHUNKS_FOR_PREVIEW),
            max_chars=_MAX_CONTEXT_CHARS,
            context_preview=context_preview,
        )

        with mlflow.start_span(name="grade_context_llm", span_type="LLM") as span:
            span.set_attribute("node",          "grade_context")
            span.set_attribute("chunk_count",   len(chunks))
            span.set_attribute("llm.provider",  getattr(llm, "provider_used", "unknown"))
            span.set_inputs({
                "prompt":        prompt,
                "user_input":    user_input,
                "chunk_count":   len(chunks),
                "preview_chars": len(context_preview),
            })

            llm_response = llm.invoke([{"role": "user", "content": prompt}])
            raw_verdict  = (
                llm_response.content
                if hasattr(llm_response, "content")
                else str(llm_response)
            )
            token_usage = _extract_token_usage(llm_response)

            grade      = _parse_grade(raw_verdict)
            context_ok = grade == ContextGrade.SUFFICIENT

            model_name = getattr(llm, "model_used", "llama-3.3-70b-versatile")
            from app.agents.knowledge_rag.nodes.generate_answer import _compute_cost
            cost_usd = _compute_cost(
                model_name,
                token_usage.get("input_tokens",  0),
                token_usage.get("output_tokens", 0),
            )
            span.set_attribute("llm.model",    model_name)
            span.set_attribute("llm.cost_usd", cost_usd)
            span.set_attribute("grade.parsed", grade)
            if token_usage:
                span.set_attribute("tokens.input",  token_usage.get("input_tokens",  0))
                span.set_attribute("tokens.output", token_usage.get("output_tokens", 0))
                span.set_attribute("tokens.total",  token_usage.get("total_tokens",  0))
            span.set_outputs({
                "response":   raw_verdict,
                "grade":      grade,
                "context_ok": context_ok,
                "cost_usd":   cost_usd,
            })

        logger.info(
            "event=grade_context_done session=%s grade=%s context_ok=%s tokens=%s",
            session_id, grade, context_ok, token_usage,
        )

        existing = state.get("accumulated_tokens") or {}
        accumulated = {
            "input_tokens":  existing.get("input_tokens",  0) + token_usage.get("input_tokens",  0),
            "output_tokens": existing.get("output_tokens", 0) + token_usage.get("output_tokens", 0),
            "total_tokens":  existing.get("total_tokens",  0) + token_usage.get("total_tokens",  0),
        }
        return {"context_ok": context_ok, "accumulated_tokens": accumulated}

    return grade_context


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _build_context_preview(chunks: list[Any]) -> str:
    """
    Build a truncated, human-readable context block from the top chunks.

    Takes the first _CHUNKS_FOR_PREVIEW chunks, extracts up to _CHARS_PER_CHUNK
    characters from each, joins them with a separator, then hard-caps the total
    at _MAX_CONTEXT_CHARS.
    """
    previews: list[str] = []

    for chunk in chunks[:_CHUNKS_FOR_PREVIEW]:
        text: str = (
            chunk.content
            if isinstance(chunk, RetrievedChunk)
            else getattr(chunk, "content", "")
        )
        if text:
            previews.append(text[:_CHARS_PER_CHUNK])

    return _CHUNK_SEPARATOR.join(previews)[:_MAX_CONTEXT_CHARS]


def _parse_grade(raw_verdict: str) -> ContextGrade:
    """
    Parse the LLM's single-word yes/no response into a ContextGrade enum value.

    Handles common LLM response variations:
      "yes"              → SUFFICIENT
      "**yes**"          → SUFFICIENT
      "no"               → INSUFFICIENT
      anything else      → INSUFFICIENT  (safe default — don't risk hallucination)
    """
    normalised = raw_verdict.strip().lower()

    # Strip markdown and quotes just in case the LLM wrapped the word
    cleaned = (
        normalised
        .replace("*", "")
        .replace('"', "")
        .replace("'", "")
        .replace(".", "")
        .strip()
    )

    if cleaned.startswith("yes") or "\nyes" in cleaned or " yes " in f" {cleaned} ":
        return ContextGrade.SUFFICIENT

    if cleaned.startswith("no") or "\nno" in cleaned or " no " in f" {cleaned} ":
        return ContextGrade.INSUFFICIENT

    logger.warning(
        "event=grade_context_unexpected_response raw=%r — "
        "defaulting to %s",
        raw_verdict[:100], ContextGrade.INSUFFICIENT,
    )
    return ContextGrade.INSUFFICIENT