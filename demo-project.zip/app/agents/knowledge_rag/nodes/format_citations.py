"""
format_citations node — deterministic.
Builds Citation objects from retrieved chunks.
Deduplicates by doc_id.
"""
from __future__ import annotations
import logging

import mlflow

from app.agents.knowledge_rag.state import Citation, KnowledgeRAGState
from app.retrieval.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)
def format_citations(state: KnowledgeRAGState) -> dict:
    """Build deduplicated citations from retrieved chunks."""
    chunks = state.get("retrieved_chunks", [])
    session_id = state.get("session_id", "")
    logger.info("node=format_citations session=%s chunks=%d", session_id, len(chunks))

    with mlflow.start_span(name="format_citations", span_type="FUNC") as span:
        span.set_inputs({"chunk_count": len(chunks)})

        seen_docs: dict[str, Citation] = {}
        for chunk in chunks:
            if isinstance(chunk, RetrievedChunk):
                doc_id    = chunk.doc_id
                title     = chunk.title or chunk.source_uri or "Unknown"
                source_uri = chunk.source_uri
                page_no   = chunk.page_no
                score     = chunk.score
                content   = chunk.content
            else:
                # Legacy Chunk or dict
                doc_id    = getattr(chunk, "source", None) or chunk.get("source", "")
                title     = doc_id
                source_uri = ""
                page_no   = None
                score     = getattr(chunk, "score", 0.0)
                content   = getattr(chunk, "text", "") or chunk.get("text", "")

            if doc_id not in seen_docs:
                seen_docs[doc_id] = Citation(
                    doc_id=doc_id,
                    title=title,
                    source_uri=source_uri,
                    page_no=page_no,
                    score=round(score, 4),
                    snippet=content[:300] if content else "",
                )

        citations = list(seen_docs.values())
        logger.info("node=format_citations session=%s citations=%d", session_id, len(citations))
        span.set_outputs({"citation_count": len(citations)})

    return {"citations": citations}
