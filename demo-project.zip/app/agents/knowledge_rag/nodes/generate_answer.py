"""
generate_answer node — LLM reasoning node.

Purpose
-------
Generates a grounded, cited answer using the retrieved context chunks.
This is the final LLM call in the knowledge_qa path — it sees the full
context and produces the answer the user receives.

Also contains make_generate_smalltalk_node, used for casual / out_of_scope
messages that bypass retrieval entirely.

LLM used   : llm_default (quality matters — long context, grounded generation)
             llm_fast    (smalltalk — short, conversational, low-stakes)
MLflow     : child span "generate_answer_llm" or "generate_smalltalk_llm"
             under the request root span, with token usage and cost attributes.
"""
from __future__ import annotations

import logging
from typing import Any

import mlflow

from app.agents.knowledge_rag.state import ChatMessage, KnowledgeRAGState
from app.core.config import settings
from app.retrieval.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────────────────────

# How many recent conversation turns to include in the answer prompt for context.
_MAX_HISTORY_TURNS = 6

# Groq model pricing (USD per 1M tokens, as of 2025)
_GROQ_PRICING: dict[str, dict[str, float]] = {
    "llama-3.3-70b-versatile": {"input": 0.59,  "output": 0.79},
    "llama-3.1-70b-versatile": {"input": 0.59,  "output": 0.79},
    "llama-3.1-8b-instant":    {"input": 0.05,  "output": 0.08},
    "llama3-70b-8192":         {"input": 0.59,  "output": 0.79},
    "llama3-8b-8192":          {"input": 0.05,  "output": 0.08},
    "gemma2-9b-it":            {"input": 0.20,  "output": 0.20},
    "mixtral-8x7b-32768":      {"input": 0.24,  "output": 0.24},
}

# Default pricing used when model is not in the table above
_DEFAULT_PRICING = {"input": 0.59, "output": 0.79}


# ──────────────────────────────────────────────────────────────────────────────
# Prompt templates
# ──────────────────────────────────────────────────────────────────────────────

# Embedded fallback — used when the MLflow prompt registry is unavailable.
_RAG_ANSWER_PROMPT_FALLBACK = """\
You are a precise enterprise knowledge assistant.
Answer the question using ONLY the numbered context chunks below.
- Be concise and direct. Use bullet points or numbered lists when listing multiple items.
- Cite every fact with [n] referring to the source chunk number.
- Do not add information beyond what the context provides.
- If the answer is not in the context, say exactly: "I don't know based on the indexed documents."
- Do not use markdown formatting such as bold (**text**), italics, or headers. Use plain text only.

Context:
{context}

Conversation history:
{history}

Question: {user_input}
Answer:"""

_SMALLTALK_PROMPT = """\
You are a friendly enterprise assistant. Respond briefly and helpfully. Use plain text only, no markdown bold or formatting.
User: {user_input}
Assistant:"""

# Returned when context_ok is False — no LLM call, no risk of hallucination.
_NO_CONTEXT_ANSWER = (
    "I couldn't find relevant documents to answer your question. "
    "Please check that the relevant documents have been uploaded and indexed, "
    "or rephrase your question."
)

# Returned for out_of_scope intent — directs user to the right tool.
_OUT_OF_SCOPE_ANSWER = (
    "I'm a knowledge retrieval assistant and can answer questions about "
    "your indexed documents. For actions like creating tickets or sending "
    "emails, please use the appropriate specialized agent."
)


# ──────────────────────────────────────────────────────────────────────────────
# Cost helper
# ──────────────────────────────────────────────────────────────────────────────

def _compute_cost(model: str, input_tokens: int | float, output_tokens: int | float) -> float:
    """
    Compute the estimated USD cost for one LLM call.

    Uses the Groq pricing table. Falls back to default pricing for unknown models.
    Cost = (input_tokens / 1_000_000 * input_price)
         + (output_tokens / 1_000_000 * output_price)

    Parameters
    ----------
    model         : Model name string (e.g. "llama-3.3-70b-versatile")
    input_tokens  : Number of prompt tokens consumed
    output_tokens : Number of completion tokens generated

    Returns
    -------
    float : Estimated cost in USD, rounded to 8 decimal places
    """
    pricing = _GROQ_PRICING.get(model, _DEFAULT_PRICING)
    cost = (
        input_tokens  * pricing["input"]  / 1_000_000 +
        output_tokens * pricing["output"] / 1_000_000
    )
    return round(cost, 8)


# ──────────────────────────────────────────────────────────────────────────────
# Node factories
# ──────────────────────────────────────────────────────────────────────────────

def make_generate_answer_node(llm: Any):
    """
    Factory that binds the LLM to the generate_answer node callable.

    Called once at graph build time. The returned inner function runs on
    every knowledge_qa request after grade_context approves the context.

    Parameters
    ----------
    llm : A capable LangChain chat model (llm_default). Quality is the priority
          here — this node sees the full context and produces the final answer.
    """

    def generate_answer(state: KnowledgeRAGState) -> dict:
        user_input = state.get("user_input", "")
        chunks     = state.get("retrieved_chunks", [])
        context_ok = state.get("context_ok", False)
        history    = state.get("history", [])
        session_id = state.get("session_id", "")

        logger.info(
            "event=generate_answer_start session=%s context_ok=%s chunk_count=%d",
            session_id, context_ok, len(chunks),
        )

        # grade_context said the context is insufficient — skip LLM call entirely.
        # Returning a template message is safer than generating from poor context.
        if not context_ok or not chunks:
            logger.info(
                "event=generate_answer_skipped session=%s reason=insufficient_context",
                session_id,
            )
            return {"answer": _NO_CONTEXT_ANSWER, "context_ok": False}

        context_str = _format_context(chunks)
        history_str = _format_history(history)

        prompt_template, prompt_name, prompt_version = _load_prompt()
        prompt = prompt_template.format(
            context=context_str,
            history=history_str or "None",
            user_input=user_input,
        )

        with mlflow.start_span(name="generate_answer_llm", span_type="LLM") as span:
            span.set_attribute("node",                 "generate_answer")
            span.set_attribute("prompt.name",          prompt_name)
            span.set_attribute("prompt.version",       str(prompt_version))
            span.set_attribute("context.chunk_count",  len(chunks))
            span.set_attribute("context.length",       len(context_str))
            span.set_attribute("llm.provider",         getattr(llm, "provider_used", "unknown"))
            span.set_attribute("llm.model",            getattr(llm, "model_used", "unknown"))
            span.set_inputs({
                "prompt":         prompt,
                "user_input":     user_input,
                "chunk_count":    len(chunks),
                "context_length": len(context_str),
            })

            response    = llm.invoke([{"role": "user", "content": prompt}])
            answer      = response.content if hasattr(response, "content") else str(response)
            token_usage = _extract_token_usage(response)

            # ── Token attributes ──────────────────────────────────────────────
            span.set_attribute("answer.length",   len(answer))
            span.set_attribute("tokens.input",    token_usage.get("input_tokens",  0))
            span.set_attribute("tokens.output",   token_usage.get("output_tokens", 0))
            span.set_attribute("tokens.total",    token_usage.get("total_tokens",  0))

            # ── Cost attributes ───────────────────────────────────────────────
            model_name = getattr(llm, "model_used", "llama-3.3-70b-versatile")
            cost_usd   = _compute_cost(
                model_name,
                token_usage.get("input_tokens",  0),
                token_usage.get("output_tokens", 0),
            )
            span.set_attribute("llm.cost_usd", cost_usd)
            token_usage["cost_usd"] = cost_usd

            span.set_outputs({
                "response":      answer,
                "answer_length": len(answer),
                "cost_usd":      cost_usd,
            })

        logger.info(
            "event=generate_answer_done session=%s answer_len=%d tokens=%s cost_usd=%s",
            session_id, len(answer), token_usage, cost_usd,
        )
        return {"answer": answer, "context_ok": True, "token_usage": token_usage}

    return generate_answer


def make_generate_smalltalk_node(llm: Any):
    """
    Factory that binds the LLM to the generate_smalltalk node callable.

    Handles two non-retrieval intents:
      - smalltalk    : greetings, casual conversation → short LLM response
      - out_of_scope : action requests (create ticket, send email) → template response

    Parameters
    ----------
    llm : A fast LangChain chat model. Smalltalk responses are short and
          low-stakes — speed matters more than depth.
    """

    def generate_smalltalk(state: KnowledgeRAGState) -> dict:
        user_input = state.get("user_input", "")
        intent     = state.get("intent", "smalltalk")
        session_id = state.get("session_id", "")

        logger.info(
            "event=generate_smalltalk_start session=%s intent=%s",
            session_id, intent,
        )

        # out_of_scope: no LLM needed — return a fixed template message.
        if intent == "out_of_scope":
            logger.info(
                "event=generate_smalltalk_done session=%s intent=%s reason=template",
                session_id, intent,
            )
            return {"answer": _OUT_OF_SCOPE_ANSWER, "context_ok": False}

        # smalltalk: short conversational LLM response.
        prompt = _SMALLTALK_PROMPT.format(user_input=user_input)

        with mlflow.start_span(name="generate_smalltalk_llm", span_type="LLM") as span:
            span.set_attribute("node",         "generate_smalltalk")
            span.set_attribute("intent",       intent)
            span.set_attribute("llm.provider", getattr(llm, "provider_used", "unknown"))
            span.set_inputs({"user_input": user_input[:300], "intent": intent})

            response    = llm.invoke([{"role": "user", "content": prompt}])
            answer      = response.content if hasattr(response, "content") else str(response)
            token_usage = _extract_token_usage(response)

            # ── Token + cost attributes ───────────────────────────────────────
            span.set_attribute("tokens.input",  token_usage.get("input_tokens",  0))
            span.set_attribute("tokens.output", token_usage.get("output_tokens", 0))
            span.set_attribute("tokens.total",  token_usage.get("total_tokens",  0))

            model_name = getattr(llm, "model_used", "llama-3.3-70b-versatile")
            cost_usd   = _compute_cost(
                model_name,
                token_usage.get("input_tokens",  0),
                token_usage.get("output_tokens", 0),
            )
            span.set_attribute("llm.cost_usd", cost_usd)

            span.set_outputs({"answer_length": len(answer), "cost_usd": cost_usd})

        logger.info(
            "event=generate_smalltalk_done session=%s intent=%s answer_len=%d",
            session_id, intent, len(answer),
        )
        return {"answer": answer, "context_ok": False}

    return generate_smalltalk


# ──────────────────────────────────────────────────────────────────────────────
# Prompt helpers
# ──────────────────────────────────────────────────────────────────────────────

def _format_context(chunks: list[Any]) -> str:
    """
    Build a numbered context block from the retrieved chunks.

    Each entry is formatted as:
        [n] (source: <title>, page <n>)
        <content>

    RetrievedChunk is a dataclass — fields are accessed via attributes directly.
    For legacy dict-like objects, getattr is used as a safe fallback.
    """
    parts: list[str] = []

    for i, chunk in enumerate(chunks, start=1):
        if isinstance(chunk, RetrievedChunk):
            content  = chunk.content
            title    = chunk.title
            page_no  = chunk.page_no
        else:
            content  = getattr(chunk, "content", "")
            title    = getattr(chunk, "title",   "")
            page_no  = getattr(chunk, "page_no", None)

        page_str = f", page {page_no}" if page_no else ""
        parts.append(f"[{i}] (source: {title}{page_str})\n{content}")

    return "\n\n".join(parts)


def _format_history(history: list[ChatMessage]) -> str:
    """
    Serialize recent conversation turns into a plain-text block for the prompt.

    ChatMessage is a frozen dataclass (role: str, content: str) — NOT a dict.
    Attributes are accessed directly; .get() does not exist on dataclasses.
    """
    recent = history[-_MAX_HISTORY_TURNS:] if history else []
    return "\n".join(f"{msg.role}: {msg.content}" for msg in recent)


def _load_prompt() -> tuple[str, str, int]:
    """
    Load the RAG answer prompt from the MLflow prompt registry.

    Returns (template_str, prompt_name, version).
    Falls back to the embedded _RAG_ANSWER_PROMPT_FALLBACK on any failure
    so the node continues working even if MLflow is unreachable.

    MLflow PromptVersion.template is typed `str | list[dict]` because prompts
    can be either a plain string or a chat-style message list. We normalise
    both to a single string before returning.
    """
    try:
        cfg_version = settings.rag.answer_prompt_version
        prompt_obj  = mlflow.genai.load_prompt("rag_answer", version=cfg_version)
        template    = prompt_obj.template

        # Plain string — use as-is.
        if isinstance(template, str):
            return template, "rag_answer", cfg_version

        # Chat-style list of {"role": ..., "content": ...} dicts —
        # join the content fields into a single string template.
        joined = "\n".join(
            msg.get("content", "") for msg in template if isinstance(msg, dict)
        )
        return joined, "rag_answer", cfg_version

    except Exception:
        pass

    return _RAG_ANSWER_PROMPT_FALLBACK, "rag_answer_embedded", 2


# ──────────────────────────────────────────────────────────────────────────────
# Token usage extraction
# ──────────────────────────────────────────────────────────────────────────────

def _extract_token_usage(response: Any) -> dict[str, int | float]:
    """
    Extract input/output/total token counts from a LangChain LLM response.

    Handles three response shapes produced by different providers:
      1. response.usage_metadata      — LangChain standard (most providers)
      2. response_metadata["usage_metadata"]  — Gemini v1 nested dict
      3. response_metadata["token_usage"]     — OpenAI-compatible (OpenRouter)

    Returns an empty dict if no token data is available — callers must
    handle the empty case gracefully.
    """
    # Shape 1: LangChain standard AIMessage attribute
    if hasattr(response, "usage_metadata") and response.usage_metadata:
        um = response.usage_metadata
        return {
            "input_tokens":  um.get("input_tokens",  0) if isinstance(um, dict) else getattr(um, "input_tokens",  0),
            "output_tokens": um.get("output_tokens", 0) if isinstance(um, dict) else getattr(um, "output_tokens", 0),
            "total_tokens":  um.get("total_tokens",  0) if isinstance(um, dict) else getattr(um, "total_tokens",  0),
        }

    # Shape 2 & 3: provider-specific response_metadata dict
    if hasattr(response, "response_metadata") and response.response_metadata:
        rm = response.response_metadata

        # Gemini v1 — nested usage_metadata dict
        gemini_usage = rm.get("usage_metadata") or {}
        if gemini_usage:
            return {
                "input_tokens":  gemini_usage.get("prompt_token_count",     0),
                "output_tokens": gemini_usage.get("candidates_token_count", 0),
                "total_tokens":  gemini_usage.get("total_token_count",      0),
            }

        # OpenAI-compatible (OpenRouter) — token_usage dict
        openai_usage = rm.get("token_usage") or {}
        if openai_usage:
            return {
                "input_tokens":  openai_usage.get("prompt_tokens",     0),
                "output_tokens": openai_usage.get("completion_tokens", 0),
                "total_tokens":  openai_usage.get("total_tokens",      0),
            }

    return {}