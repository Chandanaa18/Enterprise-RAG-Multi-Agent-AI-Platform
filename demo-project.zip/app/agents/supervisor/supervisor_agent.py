"""
SupervisorAgent — routes an incoming chat message to the correct agent.

Graph:
    START → [planner] → [dispatch] → END

Dispatch handles three execution modes:
    single     — calls one agent
    sequential — calls agents in order, passing each result as context to the next
    parallel   — calls all agents at the same time, merges results
"""
from __future__ import annotations
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Protocol, runtime_checkable, TypedDict


from langgraph.graph import END, START, StateGraph

from app.agents.knowledge_rag.agent import AgentResult
from app.agents.supervisor.planner import run_planner, RouteDecision
from app.shared.enums import AgentName, ConnectorType, AGENT_ROLE_MAP, UserRole
from app.shared.utils.logger.logger import Logger

logger = Logger(__file__)

_DEFAULT_AGENT = "knowledge_rag"


# ──────────────────────────────────────────────────────────────────────────────
# Agent protocol — the contract every specialist agent must satisfy
# ──────────────────────────────────────────────────────────────────────────────

@runtime_checkable
class AgentProtocol(Protocol):
    """
    Structural interface that every specialist agent must implement.

    SupervisorAgent depends on this protocol, not on any concrete agent class,
    so new agents can be plugged in without touching supervisor logic.
    """

    def handle(
        self,
        *,
        question: str,
        session_id: str,
        user_id: str,
        user_roles: list[str],
        db: Any,
    ) -> AgentResult: ...


# ──────────────────────────────────────────────────────────────────────────────
# LangGraph state — data passed between graph nodes
# ──────────────────────────────────────────────────────────────────────────────

class SupervisorState(TypedDict, total=False):
    session_id:             str
    user_id:                str
    user_roles:             list[str]
    user_input:             str
    target_agent:           str
    result:                 Any
    _db:                    object
    route_decision:         Any
    jira_allowed_projects:  list[str]   # injected after permission check
    _jira_permission:       tuple | None  # (has_permission, allowed_projects) pre-fetched async


# ──────────────────────────────────────────────────────────────────────────────
# Jira permission check
# ──────────────────────────────────────────────────────────────────────────────

async def _check_jira_permission_async(
    user_roles: list[str],
    db: Any,
    user_id: str,
) -> tuple[bool, list[str]]:
    """Async version — call from async contexts (FastAPI handlers, chat_service)."""
    if UserRole.ADMIN.value in user_roles:
        logger.info("jira_permission: granted — admin bypass user_id=%s", user_id)
        return True, []

    required_role = AGENT_ROLE_MAP[AgentName.JIRA].value
    if required_role not in user_roles:
        logger.info("jira_permission: denied — missing role=%s user_id=%s", required_role, user_id)
        return False, []

    if db is None:
        logger.warning("jira_permission: no db session, skipping connector check")
        return True, []

    try:
        from app.domains.permissions.repositories.connector_permission_repository import ConnectorPermissionRepository
        from app.domains.permissions.models.connector_permission_model import SubjectType

        repo = ConnectorPermissionRepository(db)
        row  = await repo.get_one(
            subject_id=str(user_id),
            connector_name=ConnectorType.JIRA.value,
            subject_type=SubjectType.USER,
        )

        if row is None or not row.enabled:
            logger.info("jira_permission: denied — no enabled connector row user_id=%s", user_id)
            return False, []

        allowed_projects: list[str] = []
        project_names: dict = {}
        if row.metadata_ and isinstance(row.metadata_, dict):
            allowed_projects = row.metadata_.get("allowed_projects", [])
            project_names    = row.metadata_.get("project_names", {})

        logger.info("jira_permission: granted user_id=%s allowed_projects=%s", user_id, allowed_projects)
        return True, allowed_projects, project_names

    except Exception as exc:
        logger.error("jira_permission: DB check failed, failing open. error=%s", exc)
        return True, [], {}


def _check_jira_permission(
    user_roles: list[str],
    db: Any,
    user_id: str,
) -> tuple[bool, list[str], dict]:
    """
    Two-level Jira permission check.

    Returns:
        (has_permission, allowed_projects, project_names)
        project_names: {key: display_name} from connector metadata, e.g. {"ADP": "Agent Demo"}
    """
    # Admin bypass — admins have access to all agents
    if UserRole.ADMIN.value in user_roles:
        logger.info("jira_permission: granted — admin bypass user_id=%s", user_id)
        return True, [], {}

    # Level 1: role check — no DB needed
    required_role = AGENT_ROLE_MAP[AgentName.JIRA].value  # "agent.jira"
    if required_role not in user_roles:
        logger.info(
            "jira_permission: denied — missing role=%s user_id=%s",
            required_role, user_id,
        )
        return False, [], {}

    # Level 2: connector_permissions table check
    if db is None:
        logger.warn("jira_permission: no db session, skipping connector check")
        return True, [], {}

    try:
        from asgiref.sync import async_to_sync
        from app.domains.permissions.repositories.connector_permission_repository import ConnectorPermissionRepository
        from app.domains.permissions.models.connector_permission_model import SubjectType

        repo = ConnectorPermissionRepository(db)

        row = async_to_sync(repo.get_one)(
            subject_id=str(user_id),
            connector_name=ConnectorType.JIRA.value,
            subject_type=SubjectType.USER,
        )

        if row is None or not row.enabled:
            logger.info(
                "jira_permission: denied — no enabled connector row user_id=%s",
                user_id,
            )
            return False, [], {}

        allowed_projects: list[str] = []
        project_names: dict = {}
        if row.metadata_ and isinstance(row.metadata_, dict):
            allowed_projects = row.metadata_.get("allowed_projects", [])
            project_names    = row.metadata_.get("project_names", {})

        logger.info(
            "jira_permission: granted user_id=%s allowed_projects=%s",
            user_id, allowed_projects,
        )
        return True, allowed_projects, project_names

    except Exception as exc:
        logger.error("jira_permission: DB check failed, failing open. error=%s", exc)
        return True, [], {}


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _call_agent(
    agent_name: str,
    agents: dict[str, Any],
    question: str,
    state: SupervisorState,
    max_retries: int = 3,
) -> AgentResult:
    """Call an agent with retry support."""

    agent = agents.get(agent_name)

    if agent is None:
        logger.warning(
            "dispatch: agent_not_found agent=%s — connector may be disabled or pending",
            agent_name,
        )
        from app.connectors.registry import registry
        return registry.disabled_agent_response(
            agent_key=agent_name,
            session_id=state.get("session_id", ""),
        )

    last_exception = None
    session_id = state.get("session_id", "")

    for attempt in range(max_retries):
        try:
            logger.info(
                "Dispatching agent",
                event="agent_dispatched",
                agent_name=agent_name,
                session_id=session_id,
                attempt=attempt + 1,
                max_retries=max_retries,
            )

            call_start = time.monotonic()

            try:
                result = agent.handle(
                    question=question,
                    session_id=session_id,
                    user_id=state.get("user_id", ""),
                    user_roles=state.get("user_roles", []),
                    db=state.get("_db"),
                    jira_allowed_projects=state.get("jira_allowed_projects", []),
                    jira_project_names=state.get("jira_project_names", {}),
                )
            except TypeError:
                # Agent does not accept jira_allowed_projects — call without it
                result = agent.handle(
                    question=question,
                    session_id=session_id,
                    user_id=state.get("user_id", ""),
                    user_roles=state.get("user_roles", []),
                    db=state.get("_db"),
                )

            duration_seconds = round(time.monotonic() - call_start, 3)

            logger.info(
                "Agent returned response",
                event="response_returned",
                agent_name=agent_name,
                session_id=session_id,
                duration_seconds=duration_seconds,
                can_answer=result.can_answer,
            )
            return result

        except Exception as exc:
            last_exception = exc
            logger.warn(
                "Agent attempt failed",
                agent_name=agent_name,
                session_id=session_id,
                attempt=attempt + 1,
                max_retries=max_retries,
                error=str(exc),
            )
            if attempt < max_retries - 1:
                time.sleep(attempt + 1)

    logger.error(
        "Agent retries exhausted",
        agent_name=agent_name,
        session_id=session_id,
        max_retries=max_retries,
    )
    return AgentResult(
        text=f"{agent_name} failed after {max_retries} attempts.",
        agent=agent_name,
        session_id=state.get("session_id", ""),
        can_answer=False,
    )


def _merge_results(results: list[AgentResult], session_id: str) -> AgentResult:
    """Merge multiple AgentResults into one for the response."""
    if not results:
        return AgentResult(
            text="No agents could answer.",
            agent="supervisor",
            session_id=session_id,
            can_answer=False,
        )

    if len(results) == 1:
        return results[0]

    successful_results = [r for r in results if r.can_answer]
    display_results    = successful_results if successful_results else results
    combined_text      = "\n\n".join(r.text for r in display_results)
    any_answered       = any(r.can_answer for r in results)

    return AgentResult(
        text=combined_text,
        agent=", ".join(r.agent for r in results),
        session_id=session_id,
        can_answer=any_answered,
        citations=tuple(c for r in results for c in r.citations),
    )


# ──────────────────────────────────────────────────────────────────────────────
# Node factories
# ──────────────────────────────────────────────────────────────────────────────

def _make_planner_node(session_store=None):
    def planner_node(state: SupervisorState) -> dict:
        query_for_planning = state.get("user_input", "")

        if session_store is not None:
            session_id = state.get("session_id", "")
            if session_id:
                try:
                    from app.agents.supervisor.context_enricher import enrich_query_with_context
                    history = session_store.load_history(session_id, limit=SUPERVISOR_HISTORY_LIMIT)
                    query_for_planning = enrich_query_with_context(history, query_for_planning)
                except Exception as exc:
                    logger.warn("planner: context enrichment failed: %s", exc)

        # jira_allowed_projects is set by dispatch (runs after planner), so it won't
        # be in state yet. Fall back to the pre-fetched _jira_permission tuple which
        # is injected before the graph starts — this ensures the fallback keyword
        # check includes the user's project keys even when the LLM planner fails.
        jira_project_keys = state.get("jira_allowed_projects") or None
        jira_project_names = state.get("jira_project_names") or None
        if not jira_project_keys:
            prefetched = state.get("_jira_permission")
            if prefetched:
                parts = (list(prefetched) + [[], {}])[:3]
                jira_project_keys = parts[1] or None
                jira_project_names = parts[2] or None

        decision = run_planner(
            user_query=query_for_planning,
            user_roles=state.get("user_roles", []),
            jira_project_keys=jira_project_keys,
            jira_project_names=jira_project_names,
        )
        target = decision.selected_agents[0] if decision.selected_agents else _DEFAULT_AGENT
        logger.info(
            "Planner selected agent",
            event="agent_selected",
            session_id=state.get("session_id"),
            agent_name=target,
            selected_agents=decision.selected_agents,
            execution_mode=decision.execution,
        )
        return {
            "route_decision": decision,
            "target_agent":   target,
        }
    return planner_node


def _make_dispatch(agents: dict[str, Any]):
    def dispatch(state: SupervisorState) -> dict:
        decision:   RouteDecision = state.get("route_decision")  # type: ignore[assignment]
        session_id: str           = state.get("session_id", "")
        user_input: str           = state.get("user_input", "")

        # ── No decision (fallback) ────────────────────────────────────────
        if not decision or not decision.selected_agents:
            result = _call_agent(_DEFAULT_AGENT, agents, user_input, state)
            return {"result": result}

        selected  = decision.selected_agents
        execution = decision.execution

        # ── Jira permission check ─────────────────────────────────────────
        # Use pre-fetched async result if available (set by chat_service before
        # entering the sync graph); fall back to the sync check otherwise.
        if "jira" in selected:
            prefetched = state.get("_jira_permission")
            if prefetched is not None:
                has_permission, allowed_projects, project_names = (prefetched + ({},))[:3]
            else:
                has_permission, allowed_projects, project_names = _check_jira_permission(
                    user_roles=state.get("user_roles", []),
                    db=state.get("_db"),
                    user_id=state.get("user_id", ""),
                )
            if not has_permission:
                if len(selected) == 1:
                    return {"result": AgentResult(
                        text=(
                            "You don't have permission to access the Jira agent. "
                            "Please contact your administrator."
                        ),
                        agent="supervisor",
                        session_id=session_id,
                        can_answer=False,
                    )}
                selected = [a for a in selected if a != "jira"]
                logger.info(
                    "Jira removed from selected agents due to permission denial",
                    event="permission_denied",
                    agent_name="jira",
                    session_id=session_id,
                    outcome="DENIED",
                )
            else:
                state["jira_allowed_projects"] = allowed_projects
                state["jira_project_names"]    = project_names

        # ── Single agent ──────────────────────────────────────────────────
        if execution == "single" or len(selected) == 1:
            result = _call_agent(selected[0], agents, user_input, state)
            return {"result": result}

        # ── Sequential ────────────────────────────────────────────────────
        if execution == "sequential":
            results      = []
            prior_output = None

            for agent_name in selected:
                question = (
                    f"{user_input}\n\n[Context from previous step]:\n{prior_output}"
                    if prior_output else user_input
                )
                result = _call_agent(agent_name, agents, question, state)
                results.append(result)
                if result.can_answer and result.text:
                    prior_output = result.text

            return {"result": _merge_results(results, session_id)}

        # ── Parallel ──────────────────────────────────────────────────────
        if execution == "parallel":
            results = []
            with ThreadPoolExecutor(max_workers=len(selected)) as pool:
                futures = {
                    pool.submit(_call_agent, name, agents, user_input, state): name
                    for name in selected
                }
                for future in as_completed(futures):
                    try:
                        results.append(future.result())
                    except Exception as exc:
                        agent_name = futures[future]
                        logger.error("parallel agent %s failed: %s", agent_name, exc)
                        results.append(AgentResult(
                            text=f"{agent_name} failed.",
                            agent=agent_name,
                            session_id=session_id,
                            can_answer=False,
                        ))

            return {"result": _merge_results(results, session_id)}

        # Fallback
        result = _call_agent(selected[0], agents, user_input, state)
        return {"result": result}

    return dispatch


# ──────────────────────────────────────────────────────────────────────────────
# Graph builder
# ──────────────────────────────────────────────────────────────────────────────

def _build_graph(agents: dict[str, Any], session_store=None):
    graph = StateGraph(SupervisorState)
    graph.add_node("planner",  _make_planner_node(session_store))
    graph.add_node("dispatch", _make_dispatch(agents))
    graph.add_edge(START,      "planner")
    graph.add_edge("planner",  "dispatch")
    graph.add_edge("dispatch", END)
    return graph.compile()


# ──────────────────────────────────────────────────────────────────────────────
# Public class
# ──────────────────────────────────────────────────────────────────────────────

SUPERVISOR_HISTORY_LIMIT = 12


class SupervisorAgent:
    def __init__(self, agents: dict[str, Any], session_store=None, auth_service=None) -> None:
        if not agents:
            raise ValueError("SupervisorAgent requires at least one agent.")
        self._agents        = agents
        self._session_store = session_store
        self._auth_service  = auth_service
        self._graph         = _build_graph(agents, session_store)
        logger.info("SupervisorAgent initialized agents=%s", list(agents.keys()))

    def handle(
        self,
        *,
        question:        str,
        session_id:      str,
        user_id:         str,
        user_roles:      list[str],
        db=None,
        jira_permission: tuple | None = None,
    ) -> AgentResult:
        init_state: SupervisorState = {
            "session_id":      session_id,
            "user_id":         user_id,
            "user_roles":      user_roles,
            "user_input":      question,
            "_db":             db,
            "_jira_permission": jira_permission,
        }
        final  = self._graph.invoke(init_state)
        result = final.get("result")

        if result is None:
            logger.error("supervisor.handle: dispatch returned no result")
            return AgentResult(
                text="An unexpected error occurred. Please try again.",
                agent="supervisor",
                session_id=session_id,
                can_answer=False,
            )
        return result