"""
app/agents/supervisor/context_enricher.py
-----------------------------------------
Lightweight session-aware query enrichment for the Supervisor planner.

Design principles
-----------------
* Stateless — this module holds no state; it receives history and returns a string.
* Non-invasive — it never rewrites the user's query; it only prepends a short
  conversational context block so the planner can resolve pronouns like "that",
  "it", "the document above", etc.
* Limited window — only the most recent `limit` messages (default 6) are included
  to avoid bloating the planner prompt.
* Graceful degradation — if history is empty or unavailable the original query
  is returned unchanged, so the planner behaves exactly as before.
* No entity resolution — intentionally deferred; enrichment is purely textual
  context injection at this stage.

Usage (in supervisor_agent.py)
-------------------------------
    from app.agents.supervisor.context_enricher import enrich_query_with_context

    history = session_store.load_history(session_id, limit=SUPERVISOR_HISTORY_LIMIT)
    query_for_planning = enrich_query_with_context(history, state["user_input"])
    decision = run_planner(user_query=query_for_planning, ...)
"""
from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

# Strips **[agent_name]**: prefixes injected by _merge_results for multi-agent turns.
# Without this, the planner sees Jira/teams markers in history and misroutes subsequent
# single-agent questions.
_AGENT_MARKER_RE = re.compile(r"\*\*\[[^\]]+\]\*\*:\s*", re.MULTILINE)

if TYPE_CHECKING:
    # Avoid a hard import cycle at module load time; the type is only needed
    # for type-checking and docstrings.
    from app.agents.knowledge_rag.state import ChatMessage

logger = logging.getLogger("platform.supervisor.context_enricher")


def enrich_query_with_context(
    history: "list[ChatMessage]",
    current_query: str,
) -> str:
    """
    Prepend recent conversation history to the current query so the planner
    can resolve contextual references ("that document", "the ticket above").

    Args:
        history:       Recent messages oldest-first (already limited to 4
                       by the caller via load_history(limit=SUPERVISOR_HISTORY_LIMIT)).
        current_query: The raw user input for the current turn.

    Returns:
        An enriched query string when history is non-empty, or the original
        *current_query* unchanged when there is nothing to add.

    Examples:
        # No history — returns query unchanged
        enrich_query_with_context([], "Find onboarding guide")
        # → "Find onboarding guide"

        # With history — returns enriched string
        history = [
            ChatMessage(role="user",      content="Find onboarding guide"),
            ChatMessage(role="assistant", content="Here is the onboarding guide …"),
        ]
        enrich_query_with_context(history, "Create Jira ticket for that")
        # →
        # \"\"\"
        # [Conversation context]
        # user: Find onboarding guide
        # assistant: Here is the onboarding guide …
        #
        # [Current request]
        # Create Jira ticket for that
        # \"\"\"
    """
    if not history:
        logger.debug("context_enricher: no history — returning raw query")
        return current_query

    # Build a compact transcript — one line per message, role-prefixed.
    # We intentionally keep this minimal: no timestamps, no metadata, no
    # token-heavy formatting.
    lines = [
        f"{msg.role}: {_AGENT_MARKER_RE.sub('', msg.content).strip()}"
        for msg in history
    ]
    transcript = "\n".join(lines)

    enriched = (
        "[Conversation context]\n"
        f"{transcript}\n\n"
        "[Current request]\n"
        f"{current_query}"
    )

    logger.debug(
        "context_enricher: enriched query with %d history messages",
        len(history),
    )
    return enriched


def format_history_for_log(history: "list[ChatMessage]") -> str:
    """
    Compact single-line summary for structured logging.
    Not used in the hot path — purely for debug/audit logs.
    """
    if not history:
        return "[]"
    roles = [m.role[0].upper() for m in history]   # U, A, U, A …
    return f"[{','.join(roles)}] ({len(history)} messages)"