# app/agents/supervisor/planner.py
from __future__ import annotations
import logging
from typing import Literal
from pydantic import BaseModel
from langchain_core.prompts import ChatPromptTemplate
from app.llm.providers.groq import build_groq_chat

logger = logging.getLogger("platform.supervisor.planner")


class RouteDecision(BaseModel):
    selected_agents: list[str]
    execution: Literal["parallel", "sequential", "single"]
    reasoning: str


# ──────────────────────────────────────────────────────────────────────────────
# Agent Registry
#
# Drives both the planner prompt and future agent-capability checks.
# To add a new agent: append one dict, set status="active". No other changes.
#
# Fields
# ------
# name         : key used in selected_agents and the supervisor agents dict
# description  : what this agent does
# handles      : intent signals that indicate this agent should be selected
# routing_rule : decision guidance shown directly to the planner LLM
# excludes     : explicit carve-outs to prevent overlap with other agents
# status       : "active" | "pending" — pending agents are excluded from routing
# ──────────────────────────────────────────────────────────────────────────────

AGENT_REGISTRY: list[dict] = [
    {
        "name": "knowledge_rag",
        "description": (
            "Answers using connected enterprise knowledge sources. "
            "Available sources are dynamic and may contain any type of organisational content."
        ),
        "handles": [
            "any informational question — the enterprise may have its own content on any subject",
            "questions where enterprise retrieval may improve, modify, personalise, or determine the answer",
            "questions that may depend on organisation-specific data",
            "questions referencing existing information, documents, records, or stored knowledge",
        ],
        "routing_rule": (
            "This is the DEFAULT agent for all informational questions. "
            "Never assume a topic lacks enterprise coverage based on how common or general it seems. "
            "Choose general_llm only when you are certain the question cannot have an enterprise-specific answer."
        ),
        "excludes": [
            "requests whose primary intent is executing an operational action in another system",
        ],
        "status": "active",
    },
    {
        "name": "jira",
        "description": "Executes operations and retrieves information from Jira.",
        "handles": [
            "requests to show, list, search, or find Jira issues or tickets",
            "requests that mention a Jira project by name or key AND ask about issues/tickets/tasks in it",
            "requests to create, update, comment on, assign, or transition a Jira issue",
            "requests mentioning assignee, priority, label, or issue type in the context of fetching/modifying tasks",
            "requests asking what issues, tickets, or tasks are open, in progress, or assigned to someone",
            "requests about overdue tasks: 'do I have anything overdue', 'what's overdue', 'overdue tickets'",
            "requests about the user's own tasks: 'my tasks', 'my tickets', 'my issues', 'assigned to me'",
        ],
        "routing_rule": (
            "Choose jira ONLY when the user wants to fetch, search, create, or modify issues/tickets. "
            "The user must be asking about TASKS or TICKETS — not about a topic or subject in general. "
            "A known project key alone is NOT enough — the query must also be about issues/tasks IN that project. "
            "Words like 'overdue', 'my tasks', 'my tickets', 'assigned to me' always imply Jira. "
            "DO NOT choose jira for: 'what is X', 'what are X', 'explain X', 'tell me about X' — "
            "those are informational and belong to knowledge_rag even if X is a project or technical term."
        ),
        "excludes": [
            "questions asking what something IS or means — those are informational, use knowledge_rag",
            "questions starting with 'what is', 'what are', 'how does', 'explain', 'tell me about'",
            "questions about policies, procedures, or processes — those belong to knowledge_rag",
            "questions where no ticket/task/issue action is implied",
        ],
        "status": "active",
    },
    {
        "name": "general_llm",
        "description": "Answers directly from model knowledge without enterprise retrieval.",
        "handles": [
            "conversational questions with no enterprise or project context",
            "greetings, small talk, or questions that are clearly not work-system related",
            "pure world-knowledge questions about science, technology, geography, history, or public concepts",
            "questions where no company document or project data could possibly be relevant",
        ],
        "routing_rule": (
            "Last resort only. Use general_llm only for pure world-knowledge questions "
            "(science, public facts, general concepts) or greetings/smalltalk. "
            "If the question involves company policies, internal processes, documents, "
            "projects, or tasks — use knowledge_rag or jira instead."
        ),
        "excludes": [
            "any question about company policies, HR, internal processes, or documents",
            "any question about tasks, tickets, issues, or project status",
            "questions requiring actions in external systems",
        ],
        "status": "pending",
    },
    # ── Pending agents — set status="active" when the agent is ready ──────────
    # {
    #     "name": "teams",
    #     "description": "Sends messages and manages Microsoft Teams channels.",
    #     "handles": [...],
    #     "routing_rule": "...",
    #     "excludes": [...],
    #     "status": "pending",
    # },
    # {
    #     "name": "m365",
    #     "description": "Reads and manages Microsoft 365 email and calendar.",
    #     "handles": [...],
    #     "routing_rule": "...",
    #     "excludes": [...],
    #     "status": "pending",
    # },
]


def _build_agent_list_for_prompt(
    user_roles: list[str],
    jira_project_keys: list[str] | None = None,
    jira_project_names: dict | None = None,
) -> str:
    """Render only active agents the user is permitted to use into the planner prompt."""
    from app.shared.enums import AGENT_ROLE_MAP, AgentName
    lines = []
    for agent in AGENT_REGISTRY:
        if agent.get("status") != "active":
            continue
        try:
            required_role = AGENT_ROLE_MAP.get(AgentName(agent["name"]))
            if required_role and required_role.value not in user_roles:
                continue
        except ValueError:
            pass  # agent name not in AgentName enum — always include

        handles      = list(agent["handles"])
        routing_rule = agent["routing_rule"]

        # Inject the user's accessible project names/keys into the jira agent block
        if agent["name"] == "jira" and (jira_project_keys or jira_project_names):
            project_refs: list[str] = []
            if jira_project_names:
                for key, name in jira_project_names.items():
                    project_refs.append(f"{name} ({key})")
            elif jira_project_keys:
                project_refs = list(jira_project_keys)

            if project_refs:
                ref_str = ", ".join(project_refs)
                handles = [
                    h if "project by name or key" not in h
                    else f"requests that mention a Jira project by name or key — known projects: {ref_str}"
                    for h in handles
                ]
                routing_rule = routing_rule.replace(
                    "Any reference to a known project name or key always implies Jira.",
                    f"Project references like {ref_str} always imply Jira.",
                )

        handles_str  = "\n    ".join(f"- {h}" for h in handles)
        excludes_str = "\n    ".join(f"- {e}" for e in agent["excludes"])
        lines.append(
            f"[{agent['name']}]\n"
            f"  {agent['description']}\n"
            f"  USE FOR:\n    {handles_str}\n"
            f"  ROUTING RULE: {routing_rule}\n"
            f"  DO NOT USE FOR:\n    {excludes_str}"
        )
    return "\n\n".join(lines)


_SYSTEM = """\
You are an enterprise AI routing planner for a multi-agent system.

AVAILABLE AGENTS:
{available_agents}

EXECUTION MODES:
- single     = exactly one agent needed.
- sequential = multiple agents needed IN ORDER — first agent's output feeds the next.
               Example: "Find the leave policy AND create a Jira ticket for it"
               → selected_agents: [knowledge_rag, jira], execution: sequential
- parallel   = multiple independent agents can run simultaneously.
               Example: "check my Jira tickets AND summarise the leave policy"
               → selected_agents: [jira, knowledge_rag], execution: parallel

ROUTING RULE — start from knowledge_rag and override only when necessary:
  The default answer is always knowledge_rag.
  Ask yourself TWO questions before overriding:

  Q1. Does this request explicitly ask to PERFORM an operation in an external system
      (e.g. "create a Jira ticket", "update issue X", "fetch my open tickets")?
      - INFORMATIONAL questions about how to do something, what a policy says, or
        what the rules are → knowledge_rag only. NOT an action agent.
      - Only add an action agent when the user wants the system to DO something
        in that external system right now, not just learn about it.

  Q2. Is it IMPOSSIBLE for the enterprise to have any content related to this subject?
      Only if the answer is definitively yes — choose general_llm instead.
      If you are not sure, keep knowledge_rag.

  KEY DISTINCTION — informational vs operational:
    "How do I request leave?"          → knowledge_rag (asking about a policy/process)
    "Is wedding leave paid?"           → knowledge_rag (asking what a policy says)
    "Create a Jira ticket for my leave"→ jira (explicit operational action)
    "What are my open Jira tickets?"   → jira (fetch from external system)
    "Do I have anything overdue?"      → jira (live task data)
    "What's pending in [project]?"     → jira (live task data)
    "What is renewable energy?"        → general_llm (pure world knowledge, no company angle)
    "What are our sustainability policies?" → knowledge_rag (company-specific)

  HARD RULE — always jira when:
    - The query contains: overdue, my tasks, my tickets, my issues, assigned to me
    - The query asks to show/find/list/create/update issues or tickets
    - The query mentions a known project key/name AND asks about tasks/issues in it

  HARD RULE — always knowledge_rag when:
    - The query starts with or implies: "what is", "what are", "explain", "tell me about", "how does"
    - The query asks about a policy, process, procedure, or document
    - No ticket/task action is implied — even if a project name is mentioned

reasoning = your internal thought process — never shown to the user.
"""

_PROMPT = ChatPromptTemplate.from_messages([
    ("system", _SYSTEM),
    ("human", "User query: {user_query}"),
])

# Built once — reused for every request
_chain = None


def get_planner_chain():
    global _chain
    if _chain is None:
        from app.core.config import settings
        llm = build_groq_chat(settings.llm.planner_model)
        _chain = _PROMPT | llm.with_structured_output(RouteDecision)
    return _chain


def run_planner(
    user_query: str,
    user_roles: list[str],
    jira_project_keys: list[str] | None = None,
    jira_project_names: dict | None = None,
) -> RouteDecision:
    """Call the LLM planner and return a RouteDecision."""
    available = _build_agent_list_for_prompt(
        user_roles,
        jira_project_keys=jira_project_keys,
        jira_project_names=jira_project_names,
    )
    try:
        decision: RouteDecision = get_planner_chain().invoke({  # type: ignore[assignment]
            "available_agents": available,
            "user_query": user_query,
        })
        logger.info(
            "planner.decision selected=%s execution=%s reasoning=%r",
            decision.selected_agents, decision.execution, decision.reasoning[:120],
        )
        return decision
    except Exception as exc:
        # Generic Jira signals — no project-specific names
        _JIRA_SIGNALS = {
            "jira", "issue", "ticket", "bug", "task", "story", "epic",
            "sprint", "assignee", "assigned",
            "create issue", "update issue", "open issues", "show issues",
        }
        # Add the user's own project keys/names to the fallback signals
        if jira_project_keys:
            _JIRA_SIGNALS.update(k.lower() for k in jira_project_keys)
        if jira_project_names:
            for key, name in jira_project_names.items():
                _JIRA_SIGNALS.add(key.lower())
                _JIRA_SIGNALS.update(w.lower() for w in name.split())

        lower_query = user_query.lower()
        fallback = "jira" if any(s in lower_query for s in _JIRA_SIGNALS) else "knowledge_rag"
        logger.error(
            "planner.decision status=failed error='%s' fallback=%s", exc, fallback
        )
        return RouteDecision(
            selected_agents=[fallback],
            execution="single",
            reasoning=f"Planner error: {exc}",
        )
