"""
Node: clarify
Checks whether the selected tool has all the information it needs.
If anything is missing, generates a friendly question back to the user
instead of proceeding to execution.

Sits between select_tool and validate_action in the graph.
Sets state["needs_clarification"] = True and state["response"] if
clarification is needed — the graph routes to END in that case.
"""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

_PROJECT_KEY_RE = re.compile(r'^[A-Z][A-Z0-9_]+$')

# Fields to check per tool and their human-readable prompts
_CLARIFICATION_CHECKS: dict[str, list[dict]] = {
    "create_issue": [
        {"field": "project_key", "prompt": "Project key"},
        {"field": "summary",     "prompt": "Summary / title — what is this issue about?"},
        {"field": "issue_type",  "prompt": "Issue type — Task, Bug, Story, or Epic? (default: Task)", "optional": True},
        {"field": "description", "prompt": "Description — any details? (optional)", "optional": True},
        {"field": "assignee",    "prompt": "Assignee — name or email to assign to (optional)", "optional": True},
        {"field": "priority",    "prompt": "Priority — High, Medium, or Low? (default: Medium)", "optional": True},
    ],
    "update_issue": [
        {
            "field":  "issue_key",
            "prompt": "Which issue should I update? (e.g. ABC-123)",
        },
    ],
    "add_comment": [
        {
            "field":  "issue_key",
            "prompt": "Which issue should I add the comment to? (e.g. ABC-123)",
        },
        {
            "field":  "body",
            "prompt": "What should the comment say?",
        },
    ],
    "transition_issue": [
        {
            "field":  "issue_key",
            "prompt": "Which issue should I move? (e.g. ABC-123)",
        },
        {
            "field":  "transition_name",
            "prompt": "Which status should I move it to? (e.g. In Progress, Done, To Do)",
        },
    ],
    "get_issue": [
        {
            "field":  "issue_key",
            "prompt": "Which issue would you like to see? (e.g. ABC-123)",
        },
    ],
    "search_issues": [
        {
            "field":  "jql",
            "prompt": "What would you like to search for? (e.g. 'open bugs in project ABC')",
        },
    ],
}


def clarify_node(state: dict[str, Any]) -> dict[str, Any]:
    tool_name        = state.get("selected_tool")
    tool_args        = state.get("tool_args", {})
    allowed_projects = state.get("jira_allowed_projects", [])

    if not tool_name:
        response = (
            "I'm not sure what you'd like to do in Jira. Here's what I can help with:\n\n"
            "• Show an issue — e.g. 'Show ADP-13'\n"
            "• Search issues — e.g. 'Show all open bugs in ADP'\n"
            "• Create an issue — e.g. 'Create a bug in ADP'\n"
            "• Update an issue — e.g. 'Update ADP-5 priority to High'\n"
            "• Add a comment — e.g. 'Add a comment to ADP-3'\n"
            "• Move an issue — e.g. 'Move ADP-13 to In Progress'\n\n"
            "What would you like to do?"
        )
        return {
            **state,
            "needs_clarification": True,
            "response": response,
            "messages": list(state.get("messages", [])) + [
                {"role": "assistant", "content": response}
            ],
        }

    checks = _CLARIFICATION_CHECKS.get(tool_name, [])

    # For create_issue: ask for ALL fields (required + optional) if ANY required field is missing.
    # For other tools: only block on missing required fields.
    if tool_name == "create_issue":
        def _field_missing(check: dict) -> bool:
            val = tool_args.get(check["field"])
            if not val:
                return True
            if check["field"] == "project_key":
                return not _PROJECT_KEY_RE.match(str(val).strip().upper())
            return False

        # Collect only the required fields that are missing or invalid
        missing_required = [
            c for c in checks
            if not c.get("optional") and _field_missing(c)
        ]

        if missing_required:
            # If only project_key is wrong (full name given), ask specifically for it
            if len(missing_required) == 1 and missing_required[0]["field"] == "project_key":
                response = (
                    "I need the project key, not the full project name. "
                    "Please provide the short project key for the project you meant."
                )
                logger.info("clarify: create_issue needs details session=%s", state.get("session_id", ""))
                return {
                    **state,
                    "needs_clarification": True,
                    "response": response,
                    "messages": list(state.get("messages", [])) + [
                        {"role": "assistant", "content": response}
                    ],
                }

            # If summary is the only missing required field, auto-fill a default
            # derived from the user's message so we don't interrupt the flow.
            missing_fields = {c["field"] for c in missing_required}
            if missing_fields == {"summary"}:
                user_input = state.get("user_input", "").strip()
                default_summary = user_input if user_input else "Task"
                tool_args = {**tool_args, "summary": default_summary}
                logger.info(
                    "clarify: auto-filled summary=%r session=%s",
                    default_summary, state.get("session_id", ""),
                )
                return {**state, "tool_args": tool_args, "needs_clarification": False}

            # For any other missing required fields, ask only for those
            lines: list[str] = [f"• {c['prompt']}" for c in missing_required]
            response = (
                "Almost there! I just need a bit more info:\n\n"
                + "\n".join(lines)
            )
            logger.info("clarify: create_issue needs details session=%s", state.get("session_id", ""))
            return {
                **state,
                "needs_clarification": True,
                "response": response,
                "messages": list(state.get("messages", [])) + [
                    {"role": "assistant", "content": response}
                ],
            }
    else:
        missing_prompts: list[str] = []
        for check in checks:
            if check.get("optional"):
                continue
            value = tool_args.get(check["field"])
            if not value:
                missing_prompts.append(f"• {check['prompt']}")

        if missing_prompts:
            response = (
                "I'd be happy to help! I just need a couple more details:\n\n"
                + "\n".join(missing_prompts)
                + "\n\nPlease reply and I'll take care of it."
            )
            logger.info("clarify: missing fields tool=%s session=%s", tool_name, state.get("session_id", ""))
            return {
                **state,
                "needs_clarification": True,
                "response": response,
                "messages": list(state.get("messages", [])) + [
                    {"role": "assistant", "content": response}
                ],
            }

    logger.info("clarify: all fields present tool=%s session=%s", tool_name, state.get("session_id", ""))
    return {**state, "needs_clarification": False}