"""
Node: validate_action
Validates required fields for the selected tool and enforces per-user
project-level access restrictions stored in state['jira_allowed_projects'].
"""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# Minimum required args per tool
_REQUIRED_ARGS: dict[str, list[str]] = {
    "get_issue":        ["issue_key"],
    "search_issues":    ["jql"],
    "create_issue":     ["project_key", "summary"],
    "update_issue":     ["issue_key"],
    "add_comment":      ["issue_key", "body"],
    "transition_issue": ["issue_key", "transition_name"],
}


def _extract_project_keys_from_jql(jql: str) -> set[str]:
    """Extract project keys referenced in a JQL string."""
    keys: set[str] = set()
    # project = KEY  or  project = "KEY"  or  project = 'KEY'
    for m in re.finditer(r'project\s*=\s*["\']?([A-Z][A-Z0-9]+)["\']?', jql, re.IGNORECASE):
        keys.add(m.group(1).upper())
    # project in (ADP, SIO)  or  project in ("ADP", "SIO")
    for m in re.finditer(r'project\s+in\s*\(([^)]+)\)', jql, re.IGNORECASE):
        for key in re.findall(r'[A-Z][A-Z0-9]+', m.group(1).upper()):
            keys.add(key)
    return keys


def _project_key_from_issue_key(issue_key: str) -> str:
    """Extract project key from an issue key like ADP-123 → ADP."""
    return issue_key.split("-")[0].upper() if "-" in issue_key else ""


def _check_project_access(
    tool_name: str,
    tool_args: dict[str, Any],
    allowed_projects: list[str],
) -> str | None:
    """
    Returns an error message string if the tool targets a project the user
    is not allowed to access, otherwise returns None.
    Only enforced when allowed_projects is non-empty.
    """
    if not allowed_projects:
        return None

    allowed = {p.upper() for p in allowed_projects}

    if tool_name == "search_issues":
        jql = tool_args.get("jql", "")
        requested = _extract_project_keys_from_jql(jql)
        blocked = requested - allowed
        if blocked:
            allowed_str = ", ".join(sorted(allowed))
            blocked_str = ", ".join(sorted(blocked))
            return (
                f"You don't have access to project(s): {blocked_str}. "
                f"Your accessible projects are: {allowed_str}."
            )

    elif tool_name == "create_issue":
        project_key = (tool_args.get("project_key") or "").upper()
        if project_key and project_key not in allowed:
            return (
                f"You don't have access to project {project_key}. "
                f"Your accessible projects are: {', '.join(sorted(allowed))}."
            )

    elif tool_name in ("get_issue", "update_issue", "add_comment", "transition_issue"):
        issue_key = tool_args.get("issue_key", "")
        project_key = _project_key_from_issue_key(issue_key)
        if project_key and project_key not in allowed:
            return (
                f"You don't have access to project {project_key}. "
                f"Your accessible projects are: {', '.join(sorted(allowed))}."
            )

    return None


def validate_action_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    Synchronous validation — no I/O needed.
    Checks tool selected, tool known, required fields present, and project access.
    """
    tool_name = state.get("selected_tool")
    tool_args = state.get("tool_args", {})
    allowed_projects: list[str] = state.get("jira_allowed_projects", [])

    # ── 1. Tool must be selected ──────────────────────────────────────
    if not tool_name:
        return {**state, "tool_error": "No tool was selected."}

    # ── 2. Tool must be known ─────────────────────────────────────────
    required = _REQUIRED_ARGS.get(tool_name)
    if required is None:
        return {**state, "tool_error": f"Unknown tool: {tool_name}"}

    # ── 3. Required fields must be present ────────────────────────────
    missing = [arg for arg in required if not tool_args.get(arg)]
    if missing:
        return {
            **state,
            "tool_error": (
                f"Tool '{tool_name}' is missing required arguments: {missing}. "
                f"Please provide the missing details."
            ),
        }

    # ── 4. Project-level access check ────────────────────────────────
    access_error = _check_project_access(tool_name, tool_args, allowed_projects)
    if access_error:
        logger.warning(
            "validate_action: project access denied tool=%s session=%s",
            tool_name, state.get("session_id", ""),
        )
        return {**state, "tool_error": access_error}

    logger.info(
        "validate_action: passed tool=%s session=%s",
        tool_name, state.get("session_id", ""),
    )
    return {**state, "tool_error": None}
