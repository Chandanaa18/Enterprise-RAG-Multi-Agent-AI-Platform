"""
Node: load_session
Loads the session from the session store and injects Jira context into state.
Nodes never call MCP directly — they call JiraService.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def load_session_node(state: dict[str, Any], *, session_service: Any) -> dict[str, Any]:
    session_id = state.get("session_id", "")
    if not session_id:
        return state

    try:
        history = session_service.load_history(session_id, limit=6)

        # Build message history for context (so select_tool sees prior turns)
        history_messages = []
        jira_context = {}
        for turn in history:
            role    = getattr(turn, "role", None)
            content = getattr(turn, "content", None)
            if role in ("user", "assistant") and content:
                history_messages.append({"role": role, "content": content})
            if hasattr(turn, "metadata") and turn.metadata:
                ctx = turn.metadata.get("jira_context", {})
                if ctx:
                    jira_context = ctx

        logger.info("load_session: session=%s history=%d jira_context=%s",
                    session_id, len(history_messages), jira_context)
    except Exception as exc:
        logger.warning("load_session: failed session=%s error=%s", session_id, exc)
        history_messages = []
        jira_context = {}

    # Prepend history so select_tool has full conversation context
    current_messages = state.get("messages", [])
    all_messages = history_messages + current_messages

    return {**state, "messages": all_messages, "jira_context": jira_context}