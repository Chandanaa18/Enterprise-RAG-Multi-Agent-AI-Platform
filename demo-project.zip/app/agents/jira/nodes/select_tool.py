"""
Node: select_tool
Uses the LLM to decide which Jira tool to call and extract its arguments
from the user's natural-language message.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import date
from typing import Any

logger = logging.getLogger(__name__)

_SUPPORTED_TOOLS = [
    "get_issue",
    "search_issues",
    "create_issue",
    "update_issue",
    "add_comment",
    "transition_issue",
    "add_project_member",
]

_TOOL_SELECTION_BASE = (
    'You are a Jira assistant that selects the correct tool(s) and extracts arguments from the conversation.\n\n'
    'Available tools: get_issue, search_issues, create_issue, update_issue, add_comment, transition_issue, add_project_member\n\n'
    'For a SINGLE action, respond with ONE JSON object:\n'
    '{"tool_name": "<tool>", "arguments": {<args>}, "reasoning": "<one sentence>"}\n\n'
    'For MULTIPLE actions (e.g. "move X to Done AND create Y in project Z"), respond with a JSON ARRAY:\n'
    '[\n'
    '  {"tool_name": "<tool1>", "arguments": {<args1>}, "reasoning": "<one sentence>"},\n'
    '  {"tool_name": "<tool2>", "arguments": {<args2>}, "reasoning": "<one sentence>"}\n'
    ']\n\n'
    'IMPORTANT RULES:\n'
    '- Only plan actions for the CURRENT user message (the last one). Do NOT repeat or replay\n'
    '  actions described in previous assistant messages — those are already done.\n'
    '- If the message contains "[Context from previous step]:", ignore everything after that marker.\n'
    '  Focus ONLY on the action requested in the part before the marker.\n'
    '- Only include an argument if the user explicitly provided that value.\n'
    '- NEVER invent or guess values (e.g. do not make up a summary, project key, or assignee).\n'
    '- If the user has not stated a value for a field, omit that field from arguments entirely.\n'
    '- If a prior assistant message asked a clarifying question, extract the user\'s answer from\n'
    '  the follow-up message as arguments — but do not replay any other prior actions.\n'
    '- If the user wants to create the same issue in MULTIPLE projects, include a create_issue entry\n'
    '  for each project in the array.\n'
    '- SEARCH THEN ACT: When the user says "find issue X, then do Y to it", use a JSON ARRAY:\n'
    '  Step 1: search_issues to find the issue.\n'
    '  Step 2+: use "__FOUND_KEY__" as the issue_key — the system will substitute the real key.\n\n'
    'Tool argument schemas (only include fields the user provided):\n'
    '- get_issue:        {"issue_key": "ABC-123"}\n'
    '- search_issues:    {"jql": "<jql string>", "max_results": 20}\n'
    '  Valid statuses: "To Do", "In Progress", "In Review", "Done"\n'
    '  IMPORTANT: use "issuetype" (no underscore) in JQL, not "issue_type".\n'
    '  IMPORTANT: use "assignee is EMPTY" to find unassigned issues.\n'
    '  IMPORTANT: when the user says "my issues", "my tickets", "my tasks", "assigned to me",\n'
    '  "what I created", "I opened", "my open", "my recent", "my recently", or ANY phrase\n'
    '  starting with "my" referring to issues/tickets/tasks,\n'
    '  use currentUser() in JQL — e.g. assignee = currentUser() or reporter = currentUser().\n'
    '  IMPORTANT: ALWAYS use the project KEY — never the full project name in JQL.\n'
    '  Full project names with spaces will cause a JQL syntax error.\n'
    '  IMPORTANT: If the user mentions a project that is not in the known list,\n'
    '  convert it to an uppercase key by removing spaces and use that literally.\n'
    '  Do NOT guess or map unknown names to a known project key.\n'
    '  IMPORTANT: string values with spaces MUST be quoted in JQL.\n'
    '  Correct:   assignee = "Full Name"\n'
    '  Wrong:     assignee = Full Name\n'
    '  IMPORTANT: When the user asks to COMPARE or contrast two projects, use a SINGLE\n'
    '  search_issues call with "project in (KEY1, KEY2)" — do NOT generate two separate tool calls.\n'
    '- create_issue:     {"project_key": "...", "summary": "...", "issue_type": "Task",\n'
    '                     "description": "...", "assignee": "email or name", "priority": "High"}\n'
    '  issue_type must match exactly what the user says: Task, Bug, Story, Epic, Subtask.\n'
    '  USE create_issue when user says: "raise a ticket", "create a ticket", "open a ticket",\n'
    '  "log a ticket", "file a ticket", "add a ticket", "raise an issue", "create an issue".\n'
    '- update_issue:     {"issue_key": "KEY-1", "summary": "...", "priority": "High", "assignee": "email or display name",\n'
    '                     "due_date": "YYYY-MM-DD", "start_date": "YYYY-MM-DD"}\n'
    '  Use today\'s date (in YYYY-MM-DD format) when the user says "today" for start_date or due_date.\n'
    '  If the user says "same issue" or "that issue" or "it", use the issue key from the prior assistant message.\n'
    '  IMPORTANT: "update due date", "set due date", "change due date", "due date is" → update_issue with due_date.\n'
    '  If no issue_key is given, still select update_issue and let the system ask which issue.\n'
    '- add_comment:      {"issue_key": "KEY-1", "body": "..."}\n'
    '- transition_issue: {"issue_key": "KEY-1", "transition_name": "Done"}\n'
    '  IMPORTANT: Always pass transition_name exactly as the user stated it.\n'
    '  Natural-language status mapping:\n'
    '    "close", "closed", "complete", "done", "finish", "finished", "resolved" → "Done"\n'
    '    "start", "begin", "work on", "in progress"                              → "In Progress"\n'
    '    "review", "in review", "code review"                                    → "In Review"\n'
    '    "reopen", "back to todo", "to do", "not started"                        → "To Do"\n'
    '- add_project_member: {"project_key": "...", "user": "email or display name", "role": "Administrator"}\n'
    '  role defaults to "Administrator". Use when user says "add X to project Y", "give X access to Y".\n\n'
    'SHORTHAND & HURRIED INPUT RULES:\n'
    '- Bare issue key alone (e.g. "KEY-5", "key-5?") → get_issue. Strip punctuation, uppercase the key.\n'
    '- "my stuff", "my issues", "my tickets", "assigned to me" → search with assignee = currentUser().\n'
    '- "my recently updated", "my recent tickets" → assignee = currentUser() ORDER BY updated DESC.\n'
    '- "recently updated" / "recently changed" (without "my") → ORDER BY updated DESC, no assignee filter.\n'
    '- "high prio" / "urgent" → search with priority = High.\n'
    '- "anything new" / "recent" → search ordered by created or updated desc.\n'
    '- "unassigned" alone → search with assignee is EMPTY.\n'
    '- For update_issue, "assign to me" / "I\'ll take it" → assignee: "currentUser()".\n'
    '- Lowercase issue keys (e.g. "adp-11") must be uppercased in arguments.\n'
    '- Ignore typos in verbs — focus on intent.\n'
)


async def select_tool_node(
    state: dict[str, Any],
    *,
    llm: Any,
) -> dict[str, Any]:
    """
    Calls the LLM to select a Jira tool and extract its arguments.
    """
    messages = state.get("messages", [])

    # Send only the current user message to the LLM.
    # Exception: if the immediately preceding assistant message was a clarifying
    # question (contains "?"), include it so the user's follow-up answer can be
    # used to extract argument values.
    # Never include more than 2 messages — prior assistant responses describing
    # completed actions must NOT be visible here or the LLM will replay them.
    all_turns = [m for m in messages if m.get("role") in ("user", "assistant") and m.get("content")]
    if len(all_turns) >= 2:
        prev = all_turns[-2]
        last = all_turns[-1]
        # Always include the previous assistant message as context so the LLM
        # can resolve references like "same issue", "that ticket", "update it".
        # The system prompt instructs it NOT to replay completed actions.
        if prev.get("role") == "assistant":
            recent = [prev, last]
        else:
            recent = [last]
    else:
        recent = all_turns

    # Build the dynamic project section from state — no hardcoding
    allowed_projects = state.get("jira_allowed_projects", [])
    project_names    = state.get("jira_project_names", {})   # {key: display_name}

    system_prompt = _TOOL_SELECTION_BASE + f"\nToday's date is {date.today().isoformat()}. Use this when the user says 'today', 'now', or 'current date'.\n"

    # Inject known project key → name mapping if available
    if allowed_projects or project_names:
        lines = ["\nPROJECT CONTEXT:"]
        if project_names:
            lines.append("Known project name → key mappings (use the KEY in all tool arguments and JQL):")
            for key, name in project_names.items():
                lines.append(f"  {name}  →  {key}")
        if allowed_projects:
            keys = ", ".join(allowed_projects)
            lines.append(f"This user can access these project keys: {keys}")
            lines.append(f"- For search_issues ONLY: if the user does NOT mention a specific project, search across all: project in ({keys})")
            lines.append("- For create_issue: use ONLY the single project the user explicitly named. Never generate extra create_issue calls for other projects.")
            lines.append("- If the user DOES mention a project by name or key, use that project as normal.")
            lines.append("- CRITICAL: Generate EXACTLY as many tool calls as the user explicitly requested. 'create X and show me Y' = exactly 2 tool calls.")
        system_prompt += "\n".join(lines) + "\n"
    prompt_messages = [{"role": "system", "content": system_prompt}] + [
        {"role": m["role"], "content": m["content"]} for m in recent
    ]

    try:
        response = await llm.ainvoke(prompt_messages)
        raw_content = response.content if hasattr(response, "content") else str(response)

        # Strip markdown code fences if present
        clean = re.sub(r"```(?:json)?|```", "", raw_content).strip()

        # If LLM returned multiple JSON objects side-by-side instead of an array,
        # detect and wrap them so multi-action parsing works correctly.
        if not clean.startswith("["):
            objects: list[Any] = []
            try:
                decoder = json.JSONDecoder()
                idx = 0
                while idx < len(clean):
                    obj, end = decoder.raw_decode(clean, idx)
                    objects.append(obj)
                    idx = end
                    while idx < len(clean) and clean[idx] in " \t\n\r":
                        idx += 1
            except Exception:
                objects = []
            if len(objects) > 1:
                clean = json.dumps(objects)

        parsed = json.loads(clean)

        # Multi-action: LLM returned a list
        if isinstance(parsed, list) and parsed:
            # Deduplicate: remove identical (tool_name, arguments) pairs the LLM may have hallucinated
            seen_actions: set[str] = set()
            deduped: list[Any] = []
            for item in parsed:
                action_key = f"{item.get('tool_name')}::{json.dumps(item.get('arguments', {}), sort_keys=True)}"
                if action_key not in seen_actions:
                    seen_actions.add(action_key)
                    deduped.append(item)
            if len(deduped) < len(parsed):
                logger.warning(
                    "select_tool: removed %d duplicate action(s) session=%s",
                    len(parsed) - len(deduped), state.get("session_id", ""),
                )
                parsed = deduped

            first = parsed[0]
            rest = parsed[1:]
            tool_name = first.get("tool_name", "")
            tool_args = first.get("arguments", {})
            pending = [
                {"tool_name": a.get("tool_name", ""), "tool_args": a.get("arguments", {})}
                for a in rest
            ]
            logger.info(
                "tool_selected tool=%s pending=%d session=%s",
                tool_name, len(pending), state.get("session_id", ""),
            )
            return {
                **state,
                "selected_tool": tool_name,
                "tool_args": tool_args,
                "pending_actions": pending,
                "action_results": [],
            }

        # Single action
        tool_name = parsed.get("tool_name", "")
        tool_args = parsed.get("arguments", {})
        reasoning = parsed.get("reasoning", "")

        logger.info(
            "tool_selected tool=%s args=%s reasoning=%s session=%s",
            tool_name, tool_args, reasoning, state.get("session_id", ""),
        )
        return {
            **state,
            "selected_tool": tool_name,
            "tool_args": tool_args,
            "pending_actions": [],
            "action_results": [],
        }
    except (json.JSONDecodeError, Exception) as exc:  # noqa: BLE001
        logger.error("select_tool: LLM parsing failed error=%s", exc)
        return {
            **state,
            "selected_tool": None,
            "tool_args": {},
            "tool_error": f"Could not determine which Jira action to take: {exc}",
        }
