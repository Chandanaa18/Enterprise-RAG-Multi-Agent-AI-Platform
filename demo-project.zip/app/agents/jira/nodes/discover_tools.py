"""
Node: discover_tools
Fetches the available Jira MCP tools and stores their names in state.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def discover_tools_node(state: dict[str, Any], *, jira_service: Any) -> dict[str, Any]:
    """
    Calls JiraService.discover_tools() and stores tool names in state.
    """
    try:
        tools = await jira_service.discover_tools()
        tool_names = [t.name for t in tools]
        logger.info("discover_tools: found=%s", tool_names)
        return {**state, "tools_available": tool_names}
    except Exception as exc:  # noqa: BLE001
        logger.error("discover_tools: failed error=%s", exc)
        return {**state, "tools_available": [], "tool_error": str(exc)}
