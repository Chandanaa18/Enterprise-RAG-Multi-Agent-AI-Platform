"""
Node: persist_session
Saves the user message and assistant response to the session store so that
multi-turn conversations (e.g. clarification flows) have full context on the
next turn.
"""

from __future__ import annotations

import logging
from typing import Any

from app.agents.knowledge_rag.state import ChatMessage as Turn

logger = logging.getLogger(__name__)


async def persist_session_node(state: dict[str, Any], *, session_service: Any) -> dict[str, Any]:
    session_id = state.get("session_id", "")
    if not session_id:
        return state

    try:
        messages  = state.get("messages", [])
        response  = state.get("response", "")

        # Save the last user message and the assistant response so the next
        # turn's load_session has full conversation context for select_tool.
        user_msgs = [m for m in messages if m.get("role") == "user"]
        if user_msgs:
            last_user = user_msgs[-1]["content"]
            session_service.append_turn(session_id, Turn(role="user", content=last_user))

        if response:
            session_service.append_turn(session_id, Turn(role="assistant", content=response))

        logger.info("persist_session: saved session=%s", session_id)
    except Exception as exc:
        logger.error("persist_session: failed session=%s error=%s", session_id, exc)

    return state
