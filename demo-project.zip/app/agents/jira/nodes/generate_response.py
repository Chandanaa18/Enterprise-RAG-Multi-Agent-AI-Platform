"""
Node: generate_response
Converts the tool_result (or tool_error) into a human-readable response string.
Uses the LLM for natural language formatting when a result is present;
falls back to a structured error message when tool_error is set.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pydantic import BaseModel

logger = logging.getLogger(__name__)

_RESPONSE_SYSTEM = """
You are a helpful Jira assistant. Convert Jira API results into clean, concise plain-text responses.

WHAT TO INCLUDE:
- For create_issue: issue key, summary, project name, status. Nothing else.
  Example: "Created Task 'Infra Review' → SIO-12 (To Do, unassigned)"
- For search_issues: total count, then a list of issues. Each line: key, summary, status, assignee.
  Example: "17 open issues in Agent Demo Project:\n- ADP-20: MLflow tracing test (In Progress)\n- ..."
- For transition_issue: which issue moved to which status.
- For update_issue / add_comment: one sentence confirming what changed.
- For get_issue: key fields only — summary, status, assignee, priority.

WHAT TO OMIT (never include any of these):
- JQL query strings
- Internal IDs, timestamps, created/updated dates
- Raw API field names (e.g. "issuetype", "reporter", "id: 10232")
- Notes, disclaimers, caveats, or meta-commentary
- Suggestions to send follow-up messages
- Any mention of how the search was performed or what query was used

Formatting:
- Plain text only. No markdown bold (**text**), no headers.
- Use simple numbered or hyphen-prefixed lines for lists.
""".strip()


def _serialise_result(result: Any) -> str:
    """Convert Pydantic model or dict to a JSON string for the LLM prompt."""
    if isinstance(result, BaseModel):
        return result.model_dump_json(indent=2)
    try:
        return json.dumps(result, indent=2, default=str)
    except TypeError:
        return str(result)


def _error_to_text(tool_name: str, error: str) -> str:
    """Convert a tool error string to a human-readable sentence."""
    err_lower = error.lower()
    # Auth errors (401) — token expired or invalid
    if any(kw in err_lower for kw in ("401", "authentication failed", "token may be expired", "token expired", "verify credentials", "invalid token", "unauthenticated")):
        return f"❌ {tool_name}: Your Jira session has expired. Please reconnect your Atlassian account from the sidebar."
    # Connection errors — MCP process not ready (usually right after a server restart)
    if any(kw in err_lower for kw in ("taskgroup", "connection refused", "connection reset", "connectionrefused")):
        return f"❌ {tool_name}: Jira is warming up after a restart. Please try again in a few seconds."
    # Transition errors first (their messages also contain "not found")
    if "transition" in err_lower and ("available" in err_lower or "not found" in err_lower):
        return f"❌ {tool_name}: That transition is not available. {error}"
    # Check 404/not-found BEFORE permission — Jira combines both:
    # "Issue does not exist or you do not have permission to see it"
    if any(kw in err_lower for kw in ("404", "does not exist", "not found")):
        return f"❌ {tool_name}: Issue or project not found — {error}"
    if any(kw in err_lower for kw in ("403", "forbidden", "not have permission", "permission denied", "not authorized", "don't have access", "accessible projects")):
        return f"❌ {tool_name}: You don't have permission to access that project. {error}"
    return f"❌ {tool_name}: {error}"


async def generate_response_node(
    state: dict[str, Any],
    *,
    llm: Any,
) -> dict[str, Any]:
    """
    Produces the final text response stored in state['response'].
    """
    tool_error = state.get("tool_error")
    tool_result = state.get("tool_result")
    tool_name = state.get("selected_tool", "unknown")

    # ── Multi-action path ─────────────────────────────────────────────
    action_results = state.get("action_results", [])
    if action_results:
        all_results = action_results + [{"tool_name": tool_name, "result": tool_result, "error": tool_error}]
        parts = []
        for i, r in enumerate(all_results, 1):
            tn = r.get("tool_name", "unknown")
            if r.get("error"):
                parts.append(_error_to_text(tn, r["error"]))
            else:
                parts.append(f"✓ {tn}: " + _serialise_result(r["result"]))
        combined = "\n\n".join(parts)
        prompt_messages = [
            {"role": "system", "content": _RESPONSE_SYSTEM},
            {"role": "user", "content": f"Multiple Jira actions were performed:\n\n{combined}\n\nSummarise all outcomes clearly."},
        ]
        try:
            llm_response = await llm.ainvoke(prompt_messages)
            response_text = llm_response.content if hasattr(llm_response, "content") else str(llm_response)
        except Exception as exc:  # noqa: BLE001
            logger.error("generate_response: LLM failed for multi-action. error=%s", exc)
            response_text = combined
        return {**state, "response": response_text}

    # Error path — no LLM call needed
    if tool_error:
        error_lower = tool_error.lower()
        # Pydantic / argument validation errors — missing or malformed fields
        if any(kw in error_lower for kw in ("validation error", "string_pattern_mismatch", "string should match pattern", "missing required", "value_error", "type=string")):
            response_text = (
                "I need a bit more information to do that. Could you please provide:\n"
                "- The project key\n"
                "- A title or summary for the issue\n"
                "- Optionally: issue type, assignee, priority"
            )
            return {**state, "response": response_text}
        # Auth errors (401) — token expired / invalid
        if any(kw in error_lower for kw in ("401", "authentication failed", "token may be expired", "token expired", "verify credentials", "invalid token", "unauthenticated")):
            response_text = (
                "Your Jira session has expired. "
                "Please reconnect your Atlassian account from the sidebar and try again."
            )
            logger.warning("generate_response: auth error tool=%s", tool_name)
            return {**state, "response": response_text}
        # Connection errors — MCP process not ready after server restart
        if any(kw in error_lower for kw in ("taskgroup", "connection refused", "connection reset", "connectionrefused")):
            response_text = (
                "Jira is warming up after a restart. Please try again in a few seconds."
            )
            logger.warning("generate_response: mcp connection error tool=%s", tool_name)
            return {**state, "response": response_text}
        # Transition errors first (their messages contain "not found" too)
        if "transition" in error_lower and ("available" in error_lower or "not found" in error_lower):
            response_text = (
                f"That transition is not available for this issue. {tool_error}"
            )
        # Check 404/not-found BEFORE permission — Jira combines both in one message
        elif any(kw in error_lower for kw in ("404", "does not exist", "not found")):
            response_text = (
                "I couldn't find that issue or project in Jira. "
                "Please double-check the issue key or project name and try again."
            )
        elif any(kw in error_lower for kw in ("403", "forbidden", "not have permission", "permission denied", "not authorized", "don't have access", "accessible projects")):
            response_text = (
                f"You don't have permission to access that Jira project. "
                f"Details: {tool_error} "
                f"Please contact your Jira administrator if you need access."
            )
        elif any(kw in error_lower for kw in ("jql", "jql query", "expecting either a value", "syntax error in query", "error in query")):
            response_text = (
                "I couldn't complete the search because the query had a syntax issue. "
                "Please try rephrasing your request — for example, be specific about the project name or status."
            )
        else:
            response_text = (
                f"I was unable to complete the Jira action '{tool_name}'. "
                f"Reason: {tool_error}"
            )
        logger.warning(
            "generate_response: error path tool=%s error=%s", tool_name, tool_error
        )
        return {**state, "response": response_text}

    if tool_result is None:
        return {**state, "response": "No result was returned from Jira."}

    # Empty search results — no LLM needed
    if tool_name == "search_issues":
        total = getattr(tool_result, "total", None)
        issues = getattr(tool_result, "issues", None)
        if total == 0 or issues == []:
            return {**state, "response": "No issues found matching your search criteria."}

    # Happy path — ask LLM to format
    result_json = _serialise_result(tool_result)
    prompt_messages = [
        {"role": "system", "content": _RESPONSE_SYSTEM},
        {
            "role": "user",
            "content": f"Tool: {tool_name}\n\nResult:\n{result_json}",
        },
    ]

    try:
        llm_response = await llm.ainvoke(prompt_messages)
        response_text = (
            llm_response.content
            if hasattr(llm_response, "content")
            else str(llm_response)
        )
    except Exception as exc:  # noqa: BLE001
        logger.error("generate_response: LLM failed, falling back to raw result. error=%s", exc)
        response_text = f"Jira result for {tool_name}:\n{result_json}"

    logger.info(
        "generate_response: done tool=%s session=%s",
        tool_name, state.get("session_id", ""),
    )
    return {**state, "response": response_text}
