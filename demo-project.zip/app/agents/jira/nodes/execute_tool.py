"""
Node: execute_tool
Routes the selected tool call to JiraService. Never calls MCP directly.
All I/O goes through JiraService to preserve the service-layer abstraction.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import mlflow

from app.domains.jira.schemas.schemas import (
    AddCommentRequest,
    AddProjectMemberRequest,
    CreateIssueRequest,
    GetIssueRequest,
    SearchIssueRequest,
    TransitionIssueRequest,
    UpdateIssueRequest,
)

logger = logging.getLogger(__name__)


async def execute_tool_node(
    state: dict[str, Any],
    *,
    jira_service: Any,
) -> dict[str, Any]:
    """
    Dispatches to the appropriate JiraService method based on state.selected_tool.
    Captures MCP latency and stores result / error in state.
    """
    if state.get("tool_error"):
        # Validation already failed — skip execution
        return state

    tool_name: str = state.get("selected_tool", "")
    tool_args: dict[str, Any] = state.get("tool_args", {})
    session_id: str = state.get("session_id", "")

    t0 = time.monotonic()
    try:
        with mlflow.start_span(name=f"jira_{tool_name}", span_type="TOOL") as span:
            span.set_attribute("tool", tool_name)
            span.set_attribute("session_id", session_id)
            span.set_attribute("user_id", state.get("user_id", ""))
            span.set_inputs({"tool_args": str(tool_args)})

            result = await _dispatch(jira_service, session_id, tool_name, tool_args)
            duration_ms = (time.monotonic() - t0) * 1000

            issue_key = getattr(result, "key", None) or getattr(result, "issue_key", None)
            if issue_key:
                span.set_attribute("issue_key", issue_key)
            span.set_attribute("latency_ms", round(duration_ms, 1))
            span.set_outputs({"status": "success"})

        logger.info(
            "tool_executed tool=%s session=%s duration_ms=%.1f",
            tool_name, session_id, duration_ms,
        )
        return {
            **state,
            "tool_result": result,
            "mcp_latency_ms": duration_ms,
            "tool_error": None,
        }
    except Exception as exc:  # noqa: BLE001
        duration_ms = (time.monotonic() - t0) * 1000
        logger.error(
            "jira_failure tool=%s session=%s error=%s duration_ms=%.1f",
            tool_name, session_id, exc, duration_ms,
        )
        return {
            **state,
            "tool_result": None,
            "mcp_latency_ms": duration_ms,
            "tool_error": str(exc),
        }


async def _dispatch(
    jira_service: Any,
    session_id: str,
    tool_name: str,
    args: dict[str, Any],
) -> Any:
    """Fan-out to the correct JiraService method."""
    match tool_name:
        case "get_issue":
            return await jira_service.get_issue(
                session_id, GetIssueRequest(**args)
            )
        case "search_issues":
            return await jira_service.search_issues(
                session_id, SearchIssueRequest(**args)
            )
        case "create_issue":
            return await jira_service.create_issue(
                session_id, CreateIssueRequest(**args)
            )
        case "update_issue":
            return await jira_service.update_issue(
                session_id, UpdateIssueRequest(**args)
            )
        case "add_comment":
            return await jira_service.add_comment(
                session_id, AddCommentRequest(**args)
            )
        case "transition_issue":
            return await jira_service.transition_issue(
                session_id, TransitionIssueRequest(**args)
            )
        case "add_project_member":
            return await jira_service.add_project_member(
                session_id, AddProjectMemberRequest(**args)
            )
        case _:
            raise ValueError(f"No dispatch handler for tool: {tool_name}")
