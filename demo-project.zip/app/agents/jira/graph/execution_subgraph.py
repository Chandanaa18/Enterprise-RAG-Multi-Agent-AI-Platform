"""
Execution subgraph — validate → execute → persist.

This is a self-contained LangGraph subgraph that handles the
tool execution cycle for the Jira agent.

Subgraph flow:
    START
      ↓
    validate_action   ← checks required fields, known tool
      ↓
    [conditional edge]
      ├── tool_error set  →  END  (skip execution, carry error forward)
      └── no error        →  execute_tool  →  persist_session  →  END
"""
from __future__ import annotations

import functools
from typing import Any

from langgraph.graph import END, START, StateGraph

from app.agents.jira.state import JiraAgentState
from app.agents.jira.nodes.validate_action import validate_action_node
from app.agents.jira.nodes.execute_tool import execute_tool_node


def _route_after_validate(state: JiraAgentState) -> str:
    """
    If validate_action set a tool_error, skip execution entirely.
    Otherwise proceed to execute_tool.
    """
    if state.get("tool_error"):
        return "end"
    return "execute_tool"


def build_execution_subgraph(
    jira_service: Any,
    session_service: Any = None,  # kept for backwards-compat, no longer used here
) -> Any:
    """
    Compile and return the execution subgraph.

    Args:
        jira_service:    Initialised JiraService for this request.
        session_service: Session store for touching sessions.

    Returns:
        Compiled LangGraph runnable (used as a node in the main graph).
    """
    graph = StateGraph(JiraAgentState)

    graph.add_node("validate_action", validate_action_node)
    graph.add_node(
        "execute_tool",
        functools.partial(execute_tool_node, jira_service=jira_service),
    )

    graph.add_edge(START, "validate_action")

    graph.add_conditional_edges(
        "validate_action",
        _route_after_validate,
        {
            "end":          END,
            "execute_tool": "execute_tool",
        },
    )

    graph.add_edge("execute_tool", END)

    return graph.compile()
