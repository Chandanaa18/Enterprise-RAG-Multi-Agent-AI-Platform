"""
Jira Agent Graph.

Graph flow:
    START
      ↓
    load_session
      ↓
    discover_tools
      ↓
    select_tool
      ↓
    clarify
      ↓  [conditional edge]
      ├── needs_clarification = True  →  END  (return clarifying question to user)
      └── needs_clarification = False →  execution_subgraph (node)
                                              ↓
                                         generate_response
                                              ↓
                                            END

execution_subgraph (compiled separately — see execution_subgraph.py):
    START → validate_action
                ↓  [conditional edge inside subgraph]
                ├── tool_error set  →  END
                └── no error        →  execute_tool → persist_session → END
"""
from __future__ import annotations

import functools
from typing import Any

from langgraph.graph import END, START, StateGraph

from app.agents.jira.state import JiraAgentState
from app.agents.jira.nodes.load_session import load_session_node
from app.agents.jira.nodes.discover_tools import discover_tools_node
from app.agents.jira.nodes.select_tool import select_tool_node
from app.agents.jira.nodes.clarify import clarify_node
from app.agents.jira.nodes.generate_response import generate_response_node
from app.agents.jira.nodes.persist_session import persist_session_node
from app.agents.jira.graph.execution_subgraph import build_execution_subgraph


def _route_after_clarify(state: JiraAgentState) -> str:
    if state.get("needs_clarification"):
        return "end"
    return "execution_subgraph"


def _route_after_execution(state: JiraAgentState) -> str:
    """If more actions are queued, loop; otherwise generate the final response."""
    if state.get("pending_actions"):
        # If the current action was a search that returned nothing,
        # skip follow-up actions — there's nothing to act on.
        if state.get("selected_tool") == "search_issues":
            result = state.get("tool_result")
            issues = getattr(result, "issues", []) if result else []
            if not issues:
                return "generate_response"
        return "next_action"
    return "generate_response"


_FOUND_KEY_PLACEHOLDER = "__FOUND_KEY__"


def _resolve_placeholders(tool_args: dict, found_key: str) -> dict:
    """Replace __FOUND_KEY__ with the resolved issue key from a prior search."""
    if not found_key or _FOUND_KEY_PLACEHOLDER not in str(tool_args):
        return tool_args
    return {
        k: (v.replace(_FOUND_KEY_PLACEHOLDER, found_key) if isinstance(v, str) else v)
        for k, v in tool_args.items()
    }


def _next_action_node(state: JiraAgentState) -> JiraAgentState:
    """Accumulate the current result then pop the next queued action."""
    results = list(state.get("action_results", []))
    results.append({
        "tool_name": state.get("selected_tool"),
        "result":    state.get("tool_result"),
        "error":     state.get("tool_error"),
    })

    # Collect all found keys from the search result (may be multiple issues)
    found_keys: list[str] = []
    if state.get("selected_tool") == "search_issues":
        issues = getattr(state.get("tool_result"), "issues", [])
        found_keys = [i.key for i in issues]
    # Fallback: single key stored from a prior step
    found_key: str = state.get("_found_key", "") or (found_keys[0] if found_keys else "")

    pending = list(state.get("pending_actions", []))
    next_action = pending.pop(0)
    raw_args = next_action.get("tool_args", {})

    # If the next action uses __FOUND_KEY__ and we have multiple results,
    # expand into one action per result key and push extras back to pending.
    if found_keys and len(found_keys) > 1 and _FOUND_KEY_PLACEHOLDER in str(raw_args):
        # First key → current action; remaining keys → prepend to pending
        extra_actions = [
            {"tool_name": next_action["tool_name"],
             "tool_args": _resolve_placeholders(raw_args, k)}
            for k in found_keys[1:]
        ]
        pending = extra_actions + pending
        found_key = found_keys[0]

    resolved_args = _resolve_placeholders(raw_args, found_key)

    return {
        **state,
        "action_results":  results,
        "pending_actions": pending,
        "_found_key":      found_key,
        "selected_tool":   next_action["tool_name"],
        "tool_args":       resolved_args,
        "tool_result":     None,
        "tool_error":      None,
    }


def build_jira_graph(
    jira_service: Any,
    session_service: Any,
    llm: Any,
) -> Any:
    """
    Constructs and compiles the Jira LangGraph agent.

    The execution cycle (validate → execute → persist) is extracted into
    a compiled subgraph and mounted as a single node here.

    Args:
        jira_service:    Initialised JiraService instance.
        session_service: Existing SessionService from domains/sessions.
        llm:             LangChain-compatible LLM instance.

    Returns:
        Compiled LangGraph runnable.
    """
    # ── Build the execution subgraph first ───────────────────────────
    execution_subgraph = build_execution_subgraph(
        jira_service=jira_service,
        session_service=session_service,
    )

    # ── Main graph ────────────────────────────────────────────────────
    graph = StateGraph(JiraAgentState)

    graph.add_node(
        "load_session",
        functools.partial(load_session_node, session_service=session_service),
    )
    graph.add_node(
        "discover_tools",
        functools.partial(discover_tools_node, jira_service=jira_service),
    )
    graph.add_node(
        "select_tool",
        functools.partial(select_tool_node, llm=llm),
    )
    graph.add_node(
        "clarify",
        clarify_node,
    )

    # Execution subgraph mounted as a single node in the main graph
    graph.add_node("execution_subgraph", execution_subgraph)
    graph.add_node("next_action", _next_action_node)

    graph.add_node(
        "generate_response",
        functools.partial(generate_response_node, llm=llm),
    )
    graph.add_node(
        "persist_session",
        functools.partial(persist_session_node, session_service=session_service),
    )

    # ── Edges ─────────────────────────────────────────────────────────
    graph.add_edge(START,            "load_session")
    graph.add_edge("load_session",   "discover_tools")
    graph.add_edge("discover_tools", "select_tool")
    graph.add_edge("select_tool",    "clarify")

    # Conditional edge: clarification needed → persist → END, else → subgraph
    graph.add_conditional_edges(
        "clarify",
        _route_after_clarify,
        {
            "end":                "persist_session",
            "execution_subgraph": "execution_subgraph",
        },
    )

    # After execution: loop if more actions pending, else respond
    graph.add_conditional_edges(
        "execution_subgraph",
        _route_after_execution,
        {
            "next_action":     "next_action",
            "generate_response": "generate_response",
        },
    )
    graph.add_edge("next_action",       "execution_subgraph")
    graph.add_edge("generate_response", "persist_session")
    graph.add_edge("persist_session",   END)

    return graph.compile()
