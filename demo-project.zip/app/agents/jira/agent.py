"""
Jira Agent — per-user OAuth MCP auth via MCPProcessPool.

For every request:
  1. Fetch the user's Atlassian OAuth access token from DB
  2. Get (or spawn) their personal mcp-atlassian process via MCPProcessPool
  3. Build JiraMCPClient pointing at that process's localhost SSE port
  4. Build JiraService around that client
  5. Compile + run the LangGraph pipeline
  6. Return the response string

If the user has not connected their Atlassian account, a clear message
is returned asking them to connect first. Falls back to service-account
auth if pool is not configured or token fetch fails unexpectedly.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import logging
from contextlib import nullcontext
from typing import Any

import mlflow

from app.agents.jira.graph.graph import build_jira_graph
from app.agents.jira.state import JiraAgentState
from app.agents.knowledge_rag.agent import AgentResult
from app.domains.auth.services.atlassian_token_service import AtlassianTokenService
from app.domains.jira.connector.mcp_client import JiraMCPClient, APITokenAuth, NoAuth
from app.domains.jira.connector.mcp_process_pool import MCPProcessPool
from app.domains.jira.services.jira_service import JiraService
from app.shared.exceptions.connector_exceptions import (
    AtlassianNotConnectedError,
    AtlassianTokenRevokedError,
)

logger = logging.getLogger(__name__)


class JiraAgent:
    """
    Thin shell around the LangGraph Jira pipeline.

    Constructed once at startup. run() gets or spawns a per-user
    mcp-atlassian process and builds a fresh JiraMCPClient per request.
    """

    def __init__(
        self,
        token_service: AtlassianTokenService,
        session_service: Any,
        llm: Any,
        mcp_base_url: str,
        jira_base_url: str = "",
        mcp_timeout_seconds: float = 30.0,
        pool: MCPProcessPool | None = None,
    ) -> None:
        self._token_service = token_service
        self._session_service = session_service
        self._llm = llm
        self._mcp_base_url = mcp_base_url       # fallback (service-account)
        self._jira_base_url = jira_base_url
        self._mcp_timeout = mcp_timeout_seconds
        self._pool = pool

        mode = "per-user OAuth pool" if pool else "service-account fallback"
        logger.info("JiraAgent: initialised (%s)", mode)

    # ------------------------------------------------------------------
    # Public async entry-point (called directly by jira.py route)
    # ------------------------------------------------------------------

    async def run(
        self,
        message: str,
        session_id: str,
        user_id: str,
        db: Any = None,
        jira_allowed_projects: list[str] | None = None,
        jira_project_names: dict | None = None,
    ) -> str:
        """Execute the Jira agent pipeline for one user message."""
        mcp_base_url = self._mcp_base_url
        auth: Any

        if self._pool is not None:
            # Always validate/refresh the token before using the process.
            # Create a fresh engine per call so this works in any event loop
            # (FastAPI loop, ThreadPoolExecutor loop, etc.) without pool conflicts.
            try:
                from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
                from app.core.config import settings as _db_settings
                _engine = create_async_engine(_db_settings.db.url, pool_size=1, max_overflow=0)
                try:
                    _Session = async_sessionmaker(bind=_engine, class_=AsyncSession, expire_on_commit=False)
                    async with _Session() as fresh_db:
                        token = await self._token_service.get_valid_token(user_id, fresh_db)
                finally:
                    await _engine.dispose()
                port  = await self._pool.get_or_spawn(user_id, token)
                mcp_base_url = f"http://localhost:{port}"
                auth = NoAuth()
                logger.info(
                    "JiraAgent.run: process ready user=%s port=%d session=%s",
                    user_id, port, session_id,
                )
            except (AtlassianNotConnectedError, AtlassianTokenRevokedError) as exc:
                logger.warning(
                    "JiraAgent.run: user not connected user=%s err=%s", user_id, exc
                )
                return str(exc)
            except Exception as exc:
                logger.error(
                    "JiraAgent.run: spawn error user=%s err=%s", user_id, exc, exc_info=True
                )
                # Can't refresh token — use running process if available, else fail clearly
                running_port = self._pool.get_running_port(user_id)
                if running_port is not None:
                    mcp_base_url = f"http://localhost:{running_port}"
                    auth = NoAuth()
                else:
                    return "Unable to connect to Jira. Please reconnect your Atlassian account from the sidebar."
        else:
            from app.core.config import settings as _s
            auth = APITokenAuth(
                email=_s.atlassian_email, api_token=_s.atlassian_api_token
            )

        mcp_client = JiraMCPClient(
            base_url=mcp_base_url,
            auth=auth,
            timeout_seconds=self._mcp_timeout,
        )

        jira_service = JiraService(
            mcp_client=mcp_client,
            session_service=self._session_service,
            jira_base_url=self._jira_base_url,
        )

        graph = build_jira_graph(
            jira_service=jira_service,
            session_service=self._session_service,
            llm=self._llm,
        )

        # Open a root MLflow run + span so child spans in execute_tool attach correctly
        try:
            mlflow_ctx = mlflow.start_run(run_name=f"jira_{session_id[:8]}", nested=True)
        except Exception:
            mlflow_ctx = nullcontext()

        initial_state: JiraAgentState = {
            "messages":              [{"role": "user", "content": message}],
            "session_id":            session_id,
            "user_id":               user_id,
            "jira_allowed_projects": jira_allowed_projects or [],
            "jira_project_names":    jira_project_names or {},
            "selected_tool":         None,
            "tool_args":             {},
            "pending_actions":       [],
            "action_results":        [],
            "_found_key":            "",
            "tool_result":           None,
            "tool_error":            None,
            "needs_clarification":   False,
            "mcp_latency_ms":        None,
            "tools_available":       [],
            "response":              None,
        }

        logger.info("JiraAgent.run: start session=%s user=%s", session_id, user_id)
        with mlflow_ctx as run:
            if run is not None:
                try:
                    mlflow.set_tags({"session_id": session_id, "user_id": user_id, "agent": "jira"})
                    mlflow.log_param("message", message[:256])
                except Exception:
                    pass

            try:
                span_ctx = mlflow.start_span(name="jira_request", span_type="CHAIN")
            except Exception:
                span_ctx = nullcontext()

            with span_ctx as span:
                if span is not None:
                    try:
                        span.set_attribute("session_id", session_id)
                        span.set_attribute("user_id", user_id)
                        span.set_inputs({"message": message})
                    except Exception:
                        pass

                final_state: JiraAgentState = await graph.ainvoke(initial_state)

                if span is not None:
                    try:
                        span.set_outputs({"response": final_state.get("response", "")[:512]})
                    except Exception:
                        pass

        logger.info("JiraAgent.run: complete session=%s", session_id)
        return final_state.get("response") or "No response generated."

    # ------------------------------------------------------------------
    # Synchronous handle() — satisfies AgentProtocol used by supervisor
    # ------------------------------------------------------------------

    def handle(
        self,
        *,
        question: str,
        session_id: str,
        user_id: str,
        user_roles: list[str] = (),        # noqa: ARG002
        db: Any = None,                    # noqa: ARG002
        jira_allowed_projects: list[str] | None = None,
        jira_project_names: dict | None = None,
    ) -> AgentResult:
        """
        Sync wrapper around run(). Called by the supervisor.
        When the FastAPI event loop is already running, schedules the
        coroutine on it via run_coroutine_threadsafe (avoids creating a
        second asyncpg connection pool in a new loop).
        """
        try:
            # db from the supervisor is an AsyncSession tied to the FastAPI event loop.
            # We pass it so run() can use it IF the process is spawned on the direct
            # route path. In the ThreadPoolExecutor path run() detects no running
            # process + db is unusable → falls back to service account safely.
            coro = self.run(
                message=question,
                session_id=session_id,
                user_id=user_id,
                db=db,
                jira_allowed_projects=jira_allowed_projects,
                jira_project_names=jira_project_names,
            )

            try:
                asyncio.get_running_loop()
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    response = pool.submit(asyncio.run, coro).result()
            except RuntimeError:
                response = asyncio.run(coro)

        except Exception as exc:
            logger.error("JiraAgent.handle: error=%s", exc, exc_info=True)
            response = f"Jira agent encountered an error: {exc}"

        return AgentResult(
            text=response,
            agent="jira",
            session_id=session_id,
            can_answer=bool(response),
        )
