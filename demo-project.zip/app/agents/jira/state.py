"""
Jira Agent State — updated with clarification and project permission fields.
"""
from __future__ import annotations

from typing import Any, Optional
from typing_extensions import TypedDict


class JiraAgentState(TypedDict, total=False):
    # Core conversation
    messages: list[dict[str, str]]         # [{role, content}]
    session_id: str
    user_id: str

    # Permissions (injected by supervisor before agent runs)
    jira_allowed_projects: list[str]       # e.g. ["ABC", "DEVOPS"] — empty = no restriction
    jira_project_names: dict               # e.g. {"ADP": "Agent Demo", "SIO": "Sigmoid Internal Ops"} — from DB metadata

    # Tool selection
    selected_tool: Optional[str]           # e.g. "get_issue"
    tool_args: dict[str, Any]             # parsed arguments for the selected tool

    # Multi-action queue
    pending_actions: list[dict]           # [{tool_name, tool_args}, ...] — remaining actions
    action_results: list[dict]            # [{tool_name, result, error}, ...] — completed actions
    _found_key: str                       # issue key resolved from a search result — persists across steps

    # Clarification
    needs_clarification: bool             # True if agent needs more info from user

    # Execution
    tool_result: Optional[Any]            # normalised response object from JiraService
    tool_error: Optional[str]             # error message if execution failed

    # Observability
    mcp_latency_ms: Optional[float]
    tools_available: list[str]

    # Final
    response: Optional[str]              # human-readable answer returned to user