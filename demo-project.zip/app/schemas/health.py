from typing import Optional
from pydantic import BaseModel


class HealthDetailSchema(BaseModel):
    status: str
    duration_ms: Optional[float] = None
    error: Optional[str] = None


class HealthDetailsSchema(BaseModel):
    database: HealthDetailSchema
    docs: HealthDetailSchema
    api: HealthDetailSchema


class HealthCheckResponseSchema(BaseModel):
    status: str
    details: HealthDetailsSchema
