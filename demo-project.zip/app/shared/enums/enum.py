from enum import Enum


# ---------------------------------------------------------------------------
# Connectors
# ---------------------------------------------------------------------------

class ConnectorType(str, Enum):
    CONFLUENCE = "confluence"
    SHAREPOINT = "sharepoint"
    JIRA       = "jira"
    TEAMS      = "teams"
    M365       = "m365"
    OUTLOOK    = "outlook"
    ONEDRIVE   = "onedrive"
    CALENDAR   = "calendar"


# ---------------------------------------------------------------------------
# Authentication / authorisation
# ---------------------------------------------------------------------------

class AuthPath(str, Enum):
    LOGIN = "/login"
    CALLBACK = "/auth/callback"
    HEALTH = "/health_check"
    DOCS = "/docs"
    REDOC = "/redoc"
    OPENAPI = "/openapi.json"
    OAUTH2_REDIRECT = "/oauth2-redirect"
    ATLASSIAN_CONNECT = "/auth/atlassian/connect"
    ATLASSIAN_CALLBACK = "/auth/atlassian/callback"


class AuditOutcome(str, Enum):
    SUCCESS = "SUCCESS"
    DENIED = "DENIED"
    FAILED = "FAILED"
    ERROR = "ERROR"
    UNKNOWN = "UNKNOWN"


class UserRole(str, Enum):
    ADMIN               = "admin"
    AGENT_KNOWLEDGE_RAG = "agent.knowledge_rag"
    AGENT_JIRA          = "agent.jira"
    AGENT_TEAMS         = "agent.teams"
    AGENT_M365          = "agent.m365"
    AGENT_GENERAL       = "agent.general_assistant"
    CONNECTOR_MANAGE    = "connector.manage"


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

class AgentName(str, Enum):
    KNOWLEDGE_RAG     = "knowledge_rag"
    JIRA              = "jira"
    TEAMS             = "teams"
    M365              = "m365"


class AgentKey(str, Enum):
    """Registry of specialist agents known to the supervisor."""
    KNOWLEDGE_RAG = "knowledge_rag"


# Maps each agent key to the UserRole required to invoke it.
# Used by both the API gate (any-agent check) and the supervisor (per-agent check).
AGENT_ROLE_MAP: dict[AgentName, UserRole] = {
    AgentName.KNOWLEDGE_RAG:      UserRole.AGENT_KNOWLEDGE_RAG,
    AgentName.JIRA:               UserRole.AGENT_JIRA,
    AgentName.TEAMS:              UserRole.AGENT_TEAMS,
    AgentName.M365:               UserRole.AGENT_M365
}


# ---------------------------------------------------------------------------
# Messaging / sessions
# ---------------------------------------------------------------------------

class MessageRole(str, Enum):
    USER      = "USER"
    ASSISTANT = "ASSISTANT"
    SYSTEM    = "SYSTEM"


class SessionStatus(str, Enum):
    ACTIVE   = "ACTIVE"
    INACTIVE = "INACTIVE"
    EXPIRED  = "EXPIRED"
    CREATED  = "CREATED"


# ---------------------------------------------------------------------------
# Ingestion / chunking
# ---------------------------------------------------------------------------

class ChunkType(str, Enum):
    TEXT   = "TEXT"
    TABLE  = "TABLE"
    IMAGE  = "IMAGE"
    CODE   = "CODE"
    HEADER = "HEADER"


class ChunkStrategy(str, Enum):
    RECURSIVE = "recursive"
    TOKEN     = "token"
    SEMANTIC  = "semantic"


class EmbedderProvider(str, Enum):
    GOOGLE = "google"


class GoogleEmbedTaskType(str, Enum):
    RETRIEVAL_DOCUMENT = "retrieval_document"
    RETRIEVAL_QUERY    = "retrieval_query"
    SEMANTIC_SIMILARITY = "semantic_similarity"
    CLASSIFICATION     = "classification"
    CLUSTERING         = "clustering"


# ---------------------------------------------------------------------------
# LangGraph nodes / routing
# ---------------------------------------------------------------------------

class GraphNode(str, Enum):
    """LangGraph node identifiers. Must match the names used in _build_graph()."""
    CLASSIFY_INTENT = "classify_intent"
    DISPATCH        = "dispatch"


class KnowledgeRAGNode(str, Enum):
    """
    Every node registered in the KnowledgeRAG graph.

    Using an enum instead of raw strings means a typo in a node name is caught
    at import time (ValueError) rather than silently misbehaving at runtime.
    Add a new member here when introducing a new graph node.
    """
    LOAD_HISTORY        = "load_history"
    PARSE_INTENT        = "parse_intent"
    REWRITE_QUERY       = "rewrite_query"
    RESOLVE_PERMISSIONS = "resolve_permissions"
    RETRIEVE_CONTEXT    = "retrieve_context"
    RETRIEVE            = "retrieve"            # kept for backwards compatibility
    PERMISSION_RECHECK  = "permission_recheck"
    GRADE_CONTEXT       = "grade_context"
    GENERATE_ANSWER     = "generate_answer"
    GENERATE_SMALLTALK  = "generate_smalltalk"
    NO_RESULTS          = "no_results"
    FORMAT_CITATIONS    = "format_citations"
    PERSIST_TURN        = "persist_turn"


class IntentRoute(str, Enum):
    """
    Routing keys produced by _route_after_intent().

    These values must match the keys in the conditional edge map inside build_graph().
    SMALLTALK covers both 'smalltalk' and 'out_of_scope' intents — both bypass RAG.
    """
    KNOWLEDGE_QA = "knowledge_qa"
    SMALLTALK    = "smalltalk"


class RetrievalRoute(str, Enum):
    """
    Routing keys produced by _route_after_retrieve().

    These values must match the keys in the conditional edge map inside build_graph().
    """
    GRADE_CONTEXT = "grade_context"   # chunks found → continue to grading
    NO_RESULTS    = "no_results"      # nothing retrieved → short-circuit to template
