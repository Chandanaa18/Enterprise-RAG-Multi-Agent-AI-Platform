"""
HTML processing utilities for connector content extraction.

Confluence (and other enterprise tools) return content as HTML.
These utilities convert it to clean plain text suitable for:
  - storage in NormalizedDocument.content
  - downstream LLM / embedding processing

Uses only Python stdlib — no external parser dependency.
"""
from __future__ import annotations

import html as _html_module
import re
from html.parser import HTMLParser
from typing import List


# ---------------------------------------------------------------------------
# Structured text extractor
# ---------------------------------------------------------------------------

class _TextExtractor(HTMLParser):
    """
    HTMLParser subclass that walks the tag tree and emits structured text.

    Preservation rules:
      - Headings   → "## Heading text" style prefix
      - Block tags → newline separator before content
      - Inline tags → text content only, no separator
      - script / style / noscript → completely skipped
      - HTML entities → decoded to Unicode
    """

    _BLOCK_TAGS = frozenset({
        "p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6",
        "tr", "td", "th", "blockquote", "pre", "article", "section",
        "header", "footer", "ul", "ol", "dl", "dt", "dd",
    })
    _HEADING_TAGS = frozenset({"h1", "h2", "h3", "h4", "h5", "h6"})
    _SKIP_TAGS = frozenset({"script", "style", "noscript", "head", "iframe"})

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self._parts: List[str] = []
        self._skip_depth: int = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        tag = tag.lower()
        if tag in self._SKIP_TAGS:
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag in self._HEADING_TAGS:
            level = int(tag[1])
            self._parts.append(f"\n{'#' * level} ")
        elif tag in self._BLOCK_TAGS:
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in self._SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)

    def handle_data(self, data: str) -> None:
        if not self._skip_depth:
            self._parts.append(data)

    def handle_entityref(self, name: str) -> None:
        if not self._skip_depth:
            self._parts.append(_html_module.unescape(f"&{name};"))

    def handle_charref(self, name: str) -> None:
        if not self._skip_depth:
            self._parts.append(_html_module.unescape(f"&#{name};"))

    def get_text(self) -> str:
        raw = "".join(self._parts)
        # Collapse runs of 3+ newlines to a single blank line
        return re.sub(r"\n{3,}", "\n\n", raw).strip()



# Extract text from HTML
def extract_plain_text(html_content: str) -> str:
    """
    Convert Confluence HTML to readable plain text.

    Preserves:
      - Heading hierarchy (## prefix)
      - Paragraph and list structure (newlines)
      - Link text (anchor text, not href)

    Removes:
      - All HTML tags
      - script / style blocks entirely
      - HTML entities → decoded Unicode characters
    """
    if not html_content:
        return ""
    extractor = _TextExtractor()
    extractor.feed(html_content)
    return extractor.get_text()


def clean_html(html_content: str) -> str:
    """
    Extract plain text from HTML and apply light normalization.

    Steps:
      1. extract_plain_text()  — structural parsing
      2. Normalize intra-line whitespace (collapse spaces/tabs)
      3. Remove empty lines

    Returns an empty string if html_content is empty.
    No length cap is applied — the downstream chunker splits content into
    appropriately-sized pieces and must receive the full document text.
    """
    if not html_content:
        return ""

    text = extract_plain_text(html_content)

    # Normalize spaces within each line; preserve newlines for structure
    normalized_lines = [
        re.sub(r"[ \t]+", " ", line).strip()
        for line in text.splitlines()
    ]
    return "\n".join(line for line in normalized_lines if line)
