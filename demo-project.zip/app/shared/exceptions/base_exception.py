from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from app.shared.exceptions.error_enums import ErrorCode, LogEvent


class ErrorResponse(BaseModel):
    error: ErrorCode
    message: str
    details: Any = None


class AppBaseException(Exception):
    """Base for all platform exceptions."""
    status_code: int = 500
    event: LogEvent = LogEvent.ERROR_UNKNOWN
    error_code: ErrorCode = ErrorCode.INTERNAL_ERROR

    def __init__(self, message: str, details: Optional[Any] = None):
        self.message = message
        self.details = details
        super().__init__(self.message)

    def to_error_payload(self) -> Dict[str, Any]:
        return ErrorResponse(
            error=self.error_code,
            message=self.message,
            details=self.details
        ).model_dump(mode="json", exclude_none=True)


class PermissionDeniedError(AppBaseException):
    status_code = 403
    event = LogEvent.RETRIEVAL_DENIED
    error_code = ErrorCode.PERMISSION_DENIED

    def __init__(self, message: str = "Access denied", user_id: Optional[str] = None,
                 resource: Optional[str] = None, details: Optional[Any] = None):
        self.user_id = user_id
        self.resource = resource
        super().__init__(message, details)


class ConnectorUnavailableError(AppBaseException):
    status_code = 503
    event = LogEvent.CONNECTOR_UNAVAILABLE
    error_code = ErrorCode.CONNECTOR_UNAVAILABLE

    def __init__(self, connector_name: str, message: Optional[str] = None,
                 details: Optional[Any] = None):
        self.connector_name = connector_name
        msg = message or f"Connector '{connector_name}' is currently unavailable"
        super().__init__(msg, details)


class AgentExecutionError(AppBaseException):
    status_code = 500
    event = LogEvent.AGENT_FAILED
    error_code = ErrorCode.AGENT_EXECUTION_FAILED

    def __init__(self, agent_name: str, node_name: Optional[str] = None,
                 message: Optional[str] = None, details: Optional[Any] = None):
        self.agent_name = agent_name
        self.node_name = node_name
        msg = message or f"Agent '{agent_name}' failed during execution"
        super().__init__(msg, details)


class SessionExpiredError(AppBaseException):
    """Raised when a session has exceeded its inactivity timeout."""
    status_code = 401
    event = LogEvent.SESSION_EXPIRED
    error_code = ErrorCode.SESSION_EXPIRED

    def __init__(self, session_id: Optional[str] = None):
        self.session_id = session_id
        super().__init__("Session has expired due to inactivity. Please start a new session.")


class CustomPydanticException(Exception):
    def __init__(self, errors: List[Dict[str, Any]], body: Any = None):
        self.errors = errors
        self.body = body
        super().__init__("Validation Error")

    def to_error_payload(self) -> Dict[str, Any]:
        return {
            "message": "Validation Error",
            "errors": self.errors,
            "body": self.body,
        }
