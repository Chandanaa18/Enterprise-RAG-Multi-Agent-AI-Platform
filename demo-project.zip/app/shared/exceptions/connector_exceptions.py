import asyncio
from typing import Any, Awaitable, Callable
import httpx

from app.shared.exceptions.base_exception import AppBaseException
from app.shared.exceptions.error_enums import ErrorCode, LogEvent
from app.shared.enums import ConnectorType
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)
class ConfluenceAPIError(AppBaseException):
    """Base for all Confluence HTTP errors."""
    event = LogEvent.CONNECTOR_UNAVAILABLE
    error_code = ErrorCode.CONNECTOR_UNAVAILABLE

    def __init__(self, status_code: int, message: str, url: str = "") -> None:
        self.status_code = status_code
        self.url = url
        self.connector_name = ConnectorType.CONFLUENCE.value
        details = {"url": url} if url else None
        super().__init__(f"[Confluence {status_code}] {url} — {message}", details=details)


class ConfluenceAuthError(ConfluenceAPIError):
    """401 Unauthorized or 403 Forbidden."""


class ConfluenceNotFoundError(ConfluenceAPIError):
    """404 Not Found."""


class ConfluenceRateLimitError(ConfluenceAPIError):
    """429 Too Many Requests — eligible for retry."""


class ConfluenceServerError(ConfluenceAPIError):
    """5xx Internal Server Error."""


# ---------------------------------------------------------------------------
# Jira connector exceptions
# ---------------------------------------------------------------------------

class JiraMCPError(AppBaseException):
    """Base for all Jira MCP transport errors."""
    status_code = 503
    event = LogEvent.CONNECTOR_UNAVAILABLE
    error_code = ErrorCode.CONNECTOR_UNAVAILABLE

    def __init__(self, message: str) -> None:
        self.connector_name = ConnectorType.JIRA.value
        super().__init__(message)


class JiraMCPConnectionError(JiraMCPError):
    """Cannot reach or authenticate with the MCP server."""


class JiraMCPTimeoutError(JiraMCPError):
    """Request exceeded the configured timeout."""


class JiraMCPInvalidToolError(JiraMCPError):
    """Requested tool is not advertised by the MCP server."""


class JiraMCPExecutionError(JiraMCPError):
    """MCP server returned an error result for a tool call."""


# ---------------------------------------------------------------------------
# Atlassian token exceptions
# ---------------------------------------------------------------------------

class AtlassianTokenError(Exception):
    """Base class for all Atlassian token service errors."""


class AtlassianNotConnectedError(AtlassianTokenError):
    """User has not connected their Atlassian account yet."""


class AtlassianTokenRevokedError(AtlassianTokenError):
    """User's Atlassian connection was revoked — needs to reconnect."""


class AtlassianTokenRefreshError(AtlassianTokenError):
    """Refresh token exchange failed for an unexpected reason."""


_CONFLUENCE_RETRYABLE = (ConfluenceRateLimitError, httpx.TransportError, httpx.TimeoutException)


async def with_confluence_retry(
    coro_fn: Callable[[], Awaitable[Any]],
    *,
    max_retries: int,
    backoff: float,
) -> Any:
    delay = backoff
    last_exc: Exception = RuntimeError("with_confluence_retry called with max_retries=0")
    for attempt in range(1, max_retries + 1):
        try:
            return await coro_fn()
        except _CONFLUENCE_RETRYABLE as exc:
            last_exc = exc
            if attempt < max_retries:
                logger.warn(
                    "Confluence request failed (attempt %d/%d): %s — retrying in %.1fs",
                    attempt, max_retries, exc, delay,
                )
                await asyncio.sleep(delay)
                delay *= 2
    raise last_exc
