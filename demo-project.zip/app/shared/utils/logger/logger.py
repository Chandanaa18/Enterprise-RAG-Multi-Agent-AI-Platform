import logging
import os
import sys
import contextvars
import structlog

from app.core.config import settings

# Context variables for structured logging across async code
log_agent_name = contextvars.ContextVar("log_agent_name", default=None)
log_node_name  = contextvars.ContextVar("log_node_name",  default=None)
log_session_id = contextvars.ContextVar("log_session_id", default=None)
log_user_id    = contextvars.ContextVar("log_user_id",    default=None)
log_trace_id   = contextvars.ContextVar("log_trace_id",   default=None)


def add_custom_contextvars(logger, method_name, event_dict):
    """structlog processor: inject context vars into every log record."""
    for key, var in (
        ("trace_id",   log_trace_id),
        ("session_id", log_session_id),
        ("user_id",    log_user_id),
        ("agent_name", log_agent_name),
        ("node_name",  log_node_name),
    ):
        val = var.get()
        if val:
            event_dict[key] = val
    return event_dict


import re

def map_fields_for_elk(logger, method_name, event_dict):
    """Rename fields to avoid Elasticsearch ECS mapping conflicts.

    ECS reserves 'event' as a nested object and 'service' as a nested object.
    We use 'log_event' and 'app_service' as top-level keyword fields instead.
    """
    if "event" in event_dict:
        event_dict["message"] = event_dict.pop("event")
    if "elk_event" in event_dict:
        event_dict["log_event"] = event_dict.pop("elk_event")
    return event_dict


class GreenPrefixRenderer:
    """Wraps structlog's ConsoleRenderer to color only the timestamp/level/logger prefix green."""
    def __init__(self, colorize: bool = True):
        self._renderer_colored = structlog.dev.ConsoleRenderer(colors=colorize)
        self._renderer_plain = structlog.dev.ConsoleRenderer(colors=False)
        self.colorize = colorize
        
    def __call__(self, logger, name, event_dict):
        # We must copy event_dict because ConsoleRenderer mutates it (pops keys)
        line_plain = self._renderer_plain(logger, name, event_dict.copy())
        line_colored = self._renderer_colored(logger, name, event_dict)
        
        match = re.match(r"^(\d{4}-\d{2}-\d{2}T[^\s]+ \[[^\]]+\](?: \[[^\]]+\])?)", line_plain)
        if match:
            prefix_plain = match.group(1)
            
            # If colors are completely disabled, we still output plain text (or we can force green if we want, 
            # but usually if colorize=False we want plain). Since user wants it green, we'll make it green.
            if not self.colorize:
                rest = line_plain[len(prefix_plain):]
                return f"\x1b[32m{prefix_plain}\x1b[0m{rest}"
            
            # If colored, we find the end of the prefix in the colored string
            visible_len = 0
            idx = 0
            in_ansi = False
            while idx < len(line_colored) and visible_len < len(prefix_plain):
                if line_colored[idx:idx+2] == '\x1b[':
                    in_ansi = True
                if not in_ansi:
                    visible_len += 1
                if in_ansi and line_colored[idx] == 'm':
                    in_ansi = False
                idx += 1
                
            rest_colored = line_colored[idx:]
            
            return f"\x1b[32m{prefix_plain}\x1b[0m{rest_colored}"
            
        return line_colored


_structlog_configured = False


class Logger:
    DEFAULT_SCOPE = "app"

    def __init__(self, scope: str = None, log_file_path: str = None, colorize: bool = True):
        global _structlog_configured
        self.set_scope(scope)
        self.LOG_FILE_PATH = log_file_path or settings.logging.log_file
        self.log_level     = settings.logging.log_level.upper()
        self.service       = "enterprise-rag-platform"

        if not _structlog_configured:
            self._configure_structlog(colorize)
            _structlog_configured = True

        self.logger = structlog.get_logger().bind(scope=self.scope, app_service=self.service)

    def _ensure_log_directory(self):
        log_dir = os.path.dirname(self.LOG_FILE_PATH)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

    def _configure_structlog(self, colorize: bool):
        self._ensure_log_directory()
        root_logger = logging.getLogger()
        root_logger.setLevel(self.log_level)
        root_logger.handlers.clear()

        shared_processors = [
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            add_custom_contextvars,
            map_fields_for_elk,
        ]

        stream_handler = logging.StreamHandler(sys.stdout)
        if colorize and sys.stdout.isatty():
            stream_handler.setFormatter(structlog.stdlib.ProcessorFormatter(
                processor=GreenPrefixRenderer(colorize=True),
                foreign_pre_chain=shared_processors,
            ))
        else:
            stream_handler.setFormatter(structlog.stdlib.ProcessorFormatter(
                processor=structlog.processors.JSONRenderer(),
                foreign_pre_chain=shared_processors,
            ))
        root_logger.addHandler(stream_handler)

        file_handler = logging.FileHandler(self.LOG_FILE_PATH)
        file_handler.setFormatter(structlog.stdlib.ProcessorFormatter(
            processor=structlog.processors.JSONRenderer(),
            foreign_pre_chain=shared_processors,
        ))
        root_logger.addHandler(file_handler)

        structlog.configure(
            processors=shared_processors + [structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
            logger_factory=structlog.stdlib.LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )

    @staticmethod
    def parse_path_to_scope(filepath: str) -> str:
        if filepath is None:
            return Logger.DEFAULT_SCOPE
        cwd = os.getcwd()
        return filepath.replace(cwd, "").replace("/app", "app").replace(".py", "")

    def set_scope(self, scope: str = None):
        self.scope = self.parse_path_to_scope(str(scope)) if scope is not None else self.DEFAULT_SCOPE

    def debug(self, message: str, *args, event: str = None, **kwargs):
        if event:
            kwargs["elk_event"] = event
        self.logger.debug(message, *args, **kwargs)

    def info(self, message: str, *args, event: str = None, **kwargs):
        if event:
            kwargs["elk_event"] = event
        self.logger.info(message, *args, **kwargs)

    def warn(self, message: str, *args, event: str = None, **kwargs):
        if event:
            kwargs["elk_event"] = event
        self.logger.warning(message, *args, **kwargs)

    def error(self, message: str, *args, event: str = None, exc_info=None, **kwargs):
        if event:
            kwargs["elk_event"] = event
        self.logger.error(message, *args, exc_info=exc_info, **kwargs)
