from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError

from app.shared.exceptions.base_exception import (
    AppBaseException,
    CustomPydanticException,
    ErrorResponse,
    PermissionDeniedError,
)
from app.shared.enums import AuditOutcome
from app.shared.exceptions.error_enums import ErrorCode, LogEvent
from app.domains.chat.services.audit_service import AuditService
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

def setup_exception_handlers(app: FastAPI):
    @app.exception_handler(HTTPException)
    async def custom_exception_handler(request: Request, httpException: HTTPException):
        logger.error(
            f"HTTPException: {httpException.detail}",
            event=LogEvent.HTTP_ERROR.value,
            status_code=httpException.status_code,
            trace_id=getattr(request.state, "trace_id", None),
        )
        response_model = ErrorResponse(error=ErrorCode.HTTP_ERROR, message=str(httpException.detail))
        return JSONResponse(
            status_code=httpException.status_code,
            content=response_model.model_dump(mode="json", exclude_none=True),
        )

    @app.exception_handler(AppBaseException)
    async def app_base_exception_handler(request: Request, exc: AppBaseException):
        trace_id: str | None = getattr(request.state, "trace_id", None)

        logger.error(
            exc.message,
            event=exc.event.value,
            status_code=exc.status_code,
            details=exc.details,
            connector_name=getattr(exc, "connector_name", None),
            agent_name=getattr(exc, "agent_name", None),
            resource=getattr(exc, "resource", None),
            trace_id=trace_id,
        )

        if isinstance(exc, PermissionDeniedError):
            user_id: str | None = getattr(exc, "user_id", None)
            session_id: str | None = request.headers.get("X-Session-ID")

            if user_id and session_id:
                AuditService.fire_and_forget(
                    user_id=user_id,
                    session_id=session_id,
                    action=LogEvent.RETRIEVAL_DENIED.value,
                    target_resource=getattr(exc, "resource", None),
                    outcome=AuditOutcome.DENIED,
                    trace_id=trace_id,
                )

        return JSONResponse(status_code=exc.status_code, content=exc.to_error_payload())

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        logger.error("RequestValidationError", event=LogEvent.VALIDATION_ERROR.value)
        custom_exc = CustomPydanticException(errors=jsonable_encoder(exc.errors()), body=exc.body)
        response_model = ErrorResponse(
            error=ErrorCode.VALIDATION_ERROR, message="Validation Error",
            details=custom_exc.to_error_payload()
        )
        return JSONResponse(status_code=422, content=response_model.model_dump(mode="json", exclude_none=True))
