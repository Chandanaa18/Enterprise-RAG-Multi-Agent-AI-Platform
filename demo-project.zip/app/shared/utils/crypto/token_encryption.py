"""
TokenEncryption — symmetric encryption for OAuth tokens stored in DB.

Uses Fernet (AES-128-CBC + HMAC-SHA256) from the cryptography library.
The encryption key is loaded once from settings at startup.

Usage:
    from app.shared.utils.crypto import TokenEncryption

    enc = TokenEncryption()
    encrypted = enc.encrypt("my-secret-token")
    original  = enc.decrypt(encrypted)
"""
from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import settings
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class TokenEncryptionError(Exception):
    """Raised when encryption or decryption fails."""


class TokenEncryption:
    """
    Encrypts and decrypts tokens using Fernet symmetric encryption.
    Safe to instantiate once and reuse across requests.
    """

    def __init__(self) -> None:
        key = settings.token.encryption_key
        if not key:
            raise TokenEncryptionError(
                "TOKEN_ENCRYPTION_KEY is not set in environment. "
                "Generate one with: python3 -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
            )
        self._fernet = Fernet(key.encode() if isinstance(key, str) else key)

    def encrypt(self, plaintext: str) -> str:
        """Encrypt a plaintext string. Returns a base64 Fernet token string."""
        if not plaintext:
            raise TokenEncryptionError("Cannot encrypt empty token.")
        try:
            return self._fernet.encrypt(plaintext.encode()).decode()
        except Exception as exc:
            raise TokenEncryptionError(f"Encryption failed: {exc}") from exc

    def decrypt(self, ciphertext: str) -> str:
        """Decrypt a Fernet token string. Returns the original plaintext."""
        if not ciphertext:
            raise TokenEncryptionError("Cannot decrypt empty ciphertext.")
        try:
            return self._fernet.decrypt(ciphertext.encode()).decode()
        except InvalidToken as exc:
            raise TokenEncryptionError(
                "Decryption failed — token is invalid or key has changed."
            ) from exc
        except Exception as exc:
            raise TokenEncryptionError(f"Decryption failed: {exc}") from exc
