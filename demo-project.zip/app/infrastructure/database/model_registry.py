"""
Central SQLAlchemy model registry.

WHY THIS FILE EXISTS
--------------------
After the DDD migration all ORM models live in separate domain packages.
SQLAlchemy resolves string-based relationship() references (e.g.
relationship("DocumentIndex")) at mapper-configuration time by scanning
the *class registry* of the shared Base.  A class only appears in that
registry after its module has been imported.

If any model module is imported AFTER the mapper is first configured
(which can happen at FastAPI startup or at the first DB query), SQLAlchemy
raises:

    expression 'DocumentIndex' failed to locate a name ('DocumentIndex')

Importing this module once — before any ORM operation — guarantees that
every model is registered with Base and all string-based relationship
references resolve correctly.

USAGE
-----
Import this module early in the application bootstrap, before any database
operation or mapper configuration:

    from app.infrastructure.database.model_registry import *  # noqa: F401

Or in alembic/env.py alongside Base:

    from app.infrastructure.database.database import Base
    from app.infrastructure.database import model_registry  # noqa: F401
"""

# ── users domain ──────────────────────────────────────────────────────────
from app.domains.users.models.user_model import User  # noqa: F401

# ── sessions domain ───────────────────────────────────────────────────────
from app.domains.sessions.models.session_model import Session  # noqa: F401
from app.domains.sessions.models.message_model import Message  # noqa: F401

# ── chat domain ───────────────────────────────────────────────────────────
from app.domains.chat.models.audit_log_model import AuditLog  # noqa: F401

# ── confluence domain ─────────────────────────────────────────────────────
from app.domains.confluence.models.connector_config_model import ConnectorConfig  # noqa: F401
from app.domains.confluence.models.document_index_model import DocumentIndex  # noqa: F401

# ── permissions domain ────────────────────────────────────────────────────
from app.domains.permissions.models.connector_permission_model import ConnectorPermission  # noqa: F401
from app.domains.permissions.models.user_connector_credentials_model import UserConnectorCredentials  # noqa: F401

__all__ = [
    "User",
    "Session",
    "Message",
    "AuditLog",
    "ConnectorConfig",
    "DocumentIndex",
    "ConnectorPermission",
    "UserConnectorCredentials",
]
