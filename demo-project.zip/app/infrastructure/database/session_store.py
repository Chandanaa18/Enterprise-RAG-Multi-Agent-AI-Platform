"""
Session store implementations.

SessionStore (Protocol)     — interface both implementations satisfy
InMemorySessionStore        — dev/test only; lost on restart
PostgresSessionStore        — production; backed by the messages + sessions tables

Both implementations are called from daemon threads (LangGraph nodes are sync
but run inside the FastAPI asyncio loop).  PostgresSessionStore uses
asyncio.run() to create a fresh event loop per call — safe from a non-loop
thread.
"""
from __future__ import annotations

import asyncio
import logging
import uuid as _uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from typing import Protocol

from app.agents.knowledge_rag.state import ChatMessage as Turn
from app.core.config import settings

logger = logging.getLogger(__name__)
MAX_HISTORY = 20   # last N messages loaded into the context window


# ──────────────────────────────────────────────────────────────────────────────
# Protocol
# ──────────────────────────────────────────────────────────────────────────────

class SessionStore(Protocol):
    def load_history(self, session_id: str, limit: int = MAX_HISTORY) -> list[Turn]: ...
    def append_turn(self, session_id: str, turn: Turn) -> None: ...
    def is_expired(self, session_id: str) -> bool: ...
    def touch(self, session_id: str) -> None: ...


# ──────────────────────────────────────────────────────────────────────────────
# PostgreSQL-backed store  (production)
# ──────────────────────────────────────────────────────────────────────────────

class PostgresSessionStore:
    """
    Persistent session store backed by enterprise_rag_system.messages
    and enterprise_rag_system.sessions.

    All public methods are synchronous so they can be called directly from
    LangGraph nodes (which are sync functions).  Internally they offload
    async work to a dedicated background thread with its own event loop,
    which is safe regardless of whether the caller is inside the FastAPI
    event loop or a daemon thread.
    """

    _executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="session-store")

    # ------------------------------------------------------------------
    # Sync-to-async bridge
    # ------------------------------------------------------------------

    @staticmethod
    def _run_async(coro):
        """
        Run an async coroutine from synchronous code, even when a loop
        is already running (e.g. inside FastAPI's event loop thread).

        Offloads the coroutine to a background thread that creates its
        own event loop, avoiding the 'cannot call asyncio.run() from a
        running event loop' error.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            # We are inside an active event loop (FastAPI) — run in a
            # separate thread that has its own loop.
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=30)
        else:
            # No running loop — safe to use asyncio.run() directly.
            return asyncio.run(coro)

    # ------------------------------------------------------------------
    # Public sync interface (SessionStore Protocol)
    # ------------------------------------------------------------------

    def load_history(self, session_id: str, limit: int = MAX_HISTORY) -> list[Turn]:
        """Return the last `limit` messages for the session, oldest first."""
        try:
            return self._run_async(self._load_async(session_id, limit))
        except Exception as exc:
            logger.warning("PostgresSessionStore.load_history failed: %s", exc)
            return []

    def append_turn(self, session_id: str, turn: Turn) -> None:
        """Insert a single message row."""
        try:
            self._run_async(self._append_async(session_id, turn))
        except Exception as exc:
            logger.error("PostgresSessionStore.append_turn failed: %s", exc)

    def is_expired(self, session_id: str) -> bool:
        """True if the session has been inactive longer than SESSION_INACTIVITY_TIMEOUT_HOURS."""
        try:
            return self._run_async(self._is_expired_async(session_id))
        except Exception as exc:
            logger.warning("PostgresSessionStore.is_expired failed: %s", exc)
            return False

    def touch(self, session_id: str) -> None:
        """Update last_active_at to now."""
        try:
            self._run_async(self._touch_async(session_id))
        except Exception as exc:
            logger.warning("PostgresSessionStore.touch failed: %s", exc)

    # ------------------------------------------------------------------
    # Internal: create a fresh engine per asyncio.run() call.
    # AsyncSessionLocal's engine is bound to FastAPI's event loop and its
    # asyncpg connection pool cannot be shared across different event loops.
    # Creating a fresh engine inside each asyncio.run() call avoids that.
    # ------------------------------------------------------------------

    @staticmethod
    def _make_engine():
        from sqlalchemy.ext.asyncio import create_async_engine
        return create_async_engine(settings.db.url, pool_pre_ping=True)

    async def _load_async(self, session_id: str, limit: int = MAX_HISTORY) -> list[Turn]:
        from sqlalchemy import select
        from sqlalchemy.ext.asyncio import AsyncSession
        from app.domains.sessions.models.message_model import Message

        sid = _parse_uuid(session_id)
        if sid is None:
            return []

        engine = self._make_engine()
        try:
            async with AsyncSession(engine) as db:
                result = await db.execute(
                    select(Message)
                    .where(Message.session_id == sid)
                    .order_by(Message.created_at.asc())
                    .limit(limit)
                )
                rows = result.scalars().all()
        finally:
            await engine.dispose()

        turns = [
            Turn(role=m.role, content=m.content)
            for m in rows
            if m.role and m.content
        ]
        logger.debug("load_history session=%s messages=%d", session_id, len(turns))
        return turns

    async def _append_async(self, session_id: str, turn: Turn) -> None:
        from sqlalchemy.ext.asyncio import AsyncSession
        from app.domains.sessions.models.message_model import Message

        sid = _parse_uuid(session_id)
        if sid is None:
            logger.warning("append_turn: invalid session_id=%r — skipping", session_id)
            return

        engine = self._make_engine()
        try:
            async with AsyncSession(engine) as db:
                db.add(Message(
                    message_id=_uuid.uuid4(),
                    session_id=sid,
                    role=turn.role,
                    content=turn.content,
                    mlflow_run_id=getattr(turn, "mlflow_run_id", None),
                ))
                await db.commit()
        finally:
            await engine.dispose()

    async def _is_expired_async(self, session_id: str) -> bool:
        from sqlalchemy import select
        from sqlalchemy.ext.asyncio import AsyncSession
        from app.domains.sessions.models.session_model import Session

        sid = _parse_uuid(session_id)
        if sid is None:
            return False

        engine = self._make_engine()
        try:
            async with AsyncSession(engine) as db:
                result = await db.execute(
                    select(Session).where(Session.session_id == sid)
                )
                session = result.scalar_one_or_none()
        finally:
            await engine.dispose()

        if session is None or session.last_active_at is None:
            return False

        ttl = timedelta(hours=settings.session.inactivity_timeout_hours)
        last = session.last_active_at
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - last) > ttl

    async def _touch_async(self, session_id: str) -> None:
        from sqlalchemy import select
        from sqlalchemy.ext.asyncio import AsyncSession
        from app.domains.sessions.models.session_model import Session

        sid = _parse_uuid(session_id)
        if sid is None:
            return

        engine = self._make_engine()
        try:
            async with AsyncSession(engine) as db:
                result = await db.execute(
                    select(Session).where(Session.session_id == sid)
                )
                session = result.scalar_one_or_none()
                if session:
                    session.last_active_at = datetime.now(timezone.utc)
                    await db.commit()
        finally:
            await engine.dispose()


# ──────────────────────────────────────────────────────────────────────────────
# In-memory store  (dev / unit tests only)
# ──────────────────────────────────────────────────────────────────────────────

class InMemorySessionStore:
    """
    In-memory store for local development and unit tests.
    Data is lost on restart and not shared across workers.
    """
    def __init__(self, ttl_seconds: int = 1800) -> None:
        import collections
        self._turns: dict[str, list[Turn]] = collections.defaultdict(list)
        self._last_seen: dict[str, float] = {}
        self._ttl = ttl_seconds

    def load_history(self, session_id: str, limit: int = MAX_HISTORY) -> list[Turn]:
        if self.is_expired(session_id):
            self._turns.pop(session_id, None)
            self._last_seen.pop(session_id, None)
            return []
        return list(self._turns[session_id])[-limit:]

    def append_turn(self, session_id: str, turn: Turn) -> None:
        self._turns[session_id].append(turn)
        self.touch(session_id)

    def is_expired(self, session_id: str) -> bool:
        import time
        last = self._last_seen.get(session_id)
        return False if last is None else (time.time() - last) > self._ttl

    def touch(self, session_id: str) -> None:
        import time
        self._last_seen[session_id] = time.time()


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _parse_uuid(value: str) -> "_uuid.UUID | None":
    try:
        return _uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None
