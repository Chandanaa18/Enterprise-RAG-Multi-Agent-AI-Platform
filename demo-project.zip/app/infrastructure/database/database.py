from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings

DATABASE_URL = settings.db.url
echo_sql     = settings.db.logging.lower() in ["true", "1", "yes"]
engine = create_async_engine(DATABASE_URL, echo=echo_sql)

# Create an async session maker
AsyncSessionLocal = async_sessionmaker(
    bind=engine, class_=AsyncSession, expire_on_commit=False
)

class Base(DeclarativeBase):
    pass

async def get_db():
    """Async dependency to get a DB session."""
    async with AsyncSessionLocal() as session:
        yield session
