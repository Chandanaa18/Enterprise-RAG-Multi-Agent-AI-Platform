"""
Connector Identity Resolver Registry — central list of all active resolvers.

Adding a new connector
----------------------
  1. Implement ``ConnectorIdentityResolver`` in ``app/connectors/<name>/identity_resolver.py``.
  2. Import and append the instance to ``_RESOLVERS`` below.
  3. Done — the Celery task and ConnectorIdentityService pick it up automatically.

Why a module-level list instead of auto-discovery?
--------------------------------------------------
Explicit registration is safer in production than classpath scanning:
  - No hidden side-effects from importing untested connector packages.
  - Clear, auditable list of which resolvers are active.
  - Easy to disable a resolver by commenting out one line.
"""
from __future__ import annotations

from app.infrastructure.identity.resolver_interface import ConnectorIdentityResolver


def get_registered_resolvers() -> list[ConnectorIdentityResolver]:
    """
    Return all active connector identity resolvers.

    Each resolver is instantiated lazily inside this function to avoid
    import-time side effects (e.g. reading settings, opening HTTP clients).
    """
    resolvers: list[ConnectorIdentityResolver] = []

    # ── Confluence ────────────────────────────────────────────────────
    try:
        from app.domains.confluence.connector.identity_resolver import (
            ConfluenceIdentityResolver,
        )
        resolvers.append(ConfluenceIdentityResolver())
    except ImportError:
        pass  # Confluence connector package not installed — skip

    # ── Jira (future) ────────────────────────────────────────────────
    # from app.connectors.jira.identity_resolver import JiraIdentityResolver
    # resolvers.append(JiraIdentityResolver())

    # ── M365 (future) ────────────────────────────────────────────────
    # from app.connectors.m365.identity_resolver import M365IdentityResolver
    # resolvers.append(M365IdentityResolver())

    # ── SharePoint (future) ──────────────────────────────────────────
    # from app.connectors.sharepoint.identity_resolver import SharePointIdentityResolver
    # resolvers.append(SharePointIdentityResolver())

    # ── Teams (future) ───────────────────────────────────────────────
    # from app.connectors.teams.identity_resolver import TeamsIdentityResolver
    # resolvers.append(TeamsIdentityResolver())

    return resolvers
