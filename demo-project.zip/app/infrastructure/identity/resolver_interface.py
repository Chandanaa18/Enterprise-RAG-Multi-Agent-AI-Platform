"""
ConnectorIdentityResolver — abstract interface for connector-specific identity
resolution.

Every enterprise connector (Confluence, Jira, SharePoint, Teams, M365) that
uses external user identifiers must implement this interface.  The framework
guarantees:

  1. Resolver implementations live *inside* their connector package (plug-and-play).
  2. The orchestrator (ConnectorIdentityService) calls each registered resolver
     with the user's Azure AD email after login.
  3. Failures are isolated — a single resolver failure never blocks login or
     affects other resolvers.

Adding a new connector
----------------------
  1. Create ``app/connectors/<name>/identity_resolver.py``.
  2. Implement ``ConnectorIdentityResolver``.
  3. Register the resolver in ``app/core/identity/registry.py``.
  4. Done — zero changes to auth or database code.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class ConnectorIdentityResolver(ABC):
    """
    Resolves a user's external identity for a specific connector.

    Given an Azure AD email, the resolver queries the external system's API
    (e.g. Atlassian, Microsoft Graph) and returns a dictionary of identity
    attributes (e.g. ``{"account_id": "712020:abc..."}``) or ``None`` if the
    user cannot be found in that system.
    """

    @property
    @abstractmethod
    def connector_name(self) -> str:
        """
        Canonical connector identifier (e.g. ``"confluence"``, ``"jira"``).

        Must match the value used in ``ConnectorType`` enum and in the
        ``connector_permissions`` table.
        """

    @abstractmethod
    async def resolve_identity(self, email: str) -> dict[str, Any] | None:
        """
        Resolve the external identity for a user given their Azure AD email.

        Parameters
        ----------
        email
            The user's email address from Azure AD (``preferred_username``
            or ``upn`` claim).

        Returns
        -------
        dict[str, Any] | None
            A dictionary of connector-specific identity attributes if the
            user was found (e.g. ``{"account_id": "...", "account_type": "atlassian"}``).
            ``None`` if the user does not exist in the external system.

        Raises
        ------
        Exception
            Implementations may raise on network/auth errors.  The caller
            (``ConnectorIdentityService``) catches all exceptions and logs
            them — they never propagate to the login flow.
        """
