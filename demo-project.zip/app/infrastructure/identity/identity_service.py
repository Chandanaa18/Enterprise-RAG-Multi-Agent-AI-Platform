"""
ConnectorIdentityService — orchestrates identity resolution across all
registered connector resolvers.

This service is invoked by a Celery background task after user provisioning.
It iterates through all registered ConnectorIdentityResolver implementations,
resolves external identities, and persists the resolved accountId into
``connector_permissions.metadata_`` for the corresponding (user, connector) row.

Storage target
--------------
Identity data is stored in ``connector_permissions.metadata_`` (not users.metadata).
This co-locates the identity mapping with the access grant and avoids a
separate lookup table. The column already exists in the schema.

Example stored value::

    connector_permissions row:
      subject_id     = "0333f554-..."   (internal user UUID)
      connector_name = "confluence"
      enabled        = true
      metadata_      = {
          "account_id":   "712020:abc...",
          "account_type": "atlassian",
          "display_name": "Apoorva SB",
          "resolved_at":  "2026-06-01T12:00:00Z"
      }

Design principles
-----------------
  - **Never block login**: runs asynchronously in a Celery background task.
  - **Skip-if-present**: skips connectors where account_id is already stored.
  - **Fault-isolated**: a single resolver failure never affects other resolvers.
  - **Idempotent**: running twice for the same user produces the same outcome.
  - **No row = no access**: if no connector_permissions row exists for the user,
    the identity is silently skipped — the user has no connector access anyway.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Sequence

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from app.infrastructure.identity.resolver_interface import ConnectorIdentityResolver
from app.domains.users.repositories.user_repository import UserRepository
from app.domains.permissions.repositories.connector_permission_repository import (
    ConnectorPermissionRepository,
)
from app.domains.permissions.models.connector_permission_model import SubjectType

logger = logging.getLogger(__name__)


class ConnectorIdentityService:
    """
    Orchestrator that drives identity resolution for a single user across
    all registered connector resolvers.
    """

    def __init__(
        self,
        db: AsyncSession,
        resolvers: Sequence[ConnectorIdentityResolver],
    ) -> None:
        self._user_repo = UserRepository(db)
        self._perm_repo = ConnectorPermissionRepository(db)
        self._db = db
        self._resolvers = {r.connector_name: r for r in resolvers}

    async def resolve_identities_for_user(
        self,
        user_id: str,
        email: str,
        *,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """
        Resolve external identities and persist into connector_permissions.metadata_.

        For each registered resolver:
          1. Load the connector_permissions row for (user_id, connector_name).
          2. Skip if account_id is already present (unless force_refresh=True).
          3. Call the resolver to get the external accountId via email lookup.
          4. Merge the result into connector_permissions.metadata_ and commit.

        Parameters
        ----------
        user_id
            The internal ``users.user_id`` UUID (as string).
        email
            The user's Azure AD email address.
        force_refresh
            Re-resolve even if account_id already exists in metadata_.

        Returns
        -------
        dict[str, Any]
            Map of connector_name → stored identity data for all resolved connectors.
        """
        user = await self._user_repo.get_by_id(user_id)
        if not user:
            logger.warning(
                "identity_resolution user_id=%s not found — skipping",
                user_id,
            )
            return {}

        resolved_connectors: dict[str, Any] = {}

        for connector_name, resolver in self._resolvers.items():
            # connector_permissions.subject_id may be either the internal
            # user_id UUID or the azure_ad_oid depending on how the admin
            # created the row. Try both so writes succeed regardless.
            perm_row = await self._perm_repo.get_one(
                subject_id=user_id,
                connector_name=connector_name,
                subject_type=SubjectType.USER,
            )
            if perm_row is None and user.azure_ad_oid:
                perm_row = await self._perm_repo.get_one(
                    subject_id=user.azure_ad_oid,
                    connector_name=connector_name,
                    subject_type=SubjectType.USER,
                )

            if perm_row is None:
                logger.info(
                    "identity_resolution connector=%s user=%s — "
                    "no connector_permissions row found (tried user_id and azure_ad_oid)",
                    connector_name,
                    email,
                )
                continue

            # Skip-if-present unless force_refresh
            existing_account_id = (perm_row.metadata_ or {}).get("account_id")
            if existing_account_id and not force_refresh:
                logger.debug(
                    "identity_resolution connector=%s user=%s — "
                    "account_id already stored, skipping",
                    connector_name,
                    email,
                )
                resolved_connectors[connector_name] = perm_row.metadata_
                continue

            try:
                identity_data = await resolver.resolve_identity(email)
            except Exception as exc:
                logger.error(
                    "identity_resolution connector=%s user=%s — "
                    "resolver raised: %s",
                    connector_name,
                    email,
                    exc,
                    exc_info=True,
                )
                continue

            if identity_data is None:
                logger.info(
                    "identity_resolution connector=%s user=%s — "
                    "user not found in external system",
                    connector_name,
                    email,
                )
                continue

            # Merge into existing metadata (preserve any admin-set fields)
            merged: dict[str, Any] = {**(perm_row.metadata_ or {}), **identity_data}
            merged["resolved_at"] = datetime.now(timezone.utc).isoformat()

            perm_row.metadata_ = merged
            flag_modified(perm_row, "metadata_")

            # Persist Atlassian group memberships into users.metadata["groups"]
            # so the pgvector ACL group filter works at query time.
            atlassian_groups: list[str] = identity_data.get("groups", [])
            if atlassian_groups:
                await self._store_user_groups(user, atlassian_groups)

            await self._db.commit()
            await self._db.refresh(perm_row)

            resolved_connectors[connector_name] = merged
            logger.info(
                "identity_resolution connector=%s user=%s accountId=%s groups=%s — "
                "stored in connector_permissions.metadata_",
                connector_name,
                email,
                identity_data.get("account_id"),
                atlassian_groups,
            )

        return resolved_connectors

    async def _store_user_groups(self, user: Any, new_groups: list[str]) -> None:
        """
        Merge Atlassian group names into users.metadata["groups"].

        Existing groups are preserved and new ones are unioned in so that
        group memberships from multiple connectors accumulate correctly.
        The updated metadata is flushed to the DB in the caller's commit.
        """
        existing: list[str] = (user.metadata_ or {}).get("groups", [])
        merged_groups = list(set(existing) | set(new_groups))
        updated_metadata = {**(user.metadata_ or {}), "groups": merged_groups}
        user.metadata_ = updated_metadata
        flag_modified(user, "metadata_")
        logger.info(
            "identity_resolution user=%s — stored %d Atlassian groups in users.metadata",
            user.user_id,
            len(merged_groups),
        )
