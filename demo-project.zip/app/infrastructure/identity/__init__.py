"""
Core identity resolution framework.

Public API
----------
  - ``ConnectorIdentityResolver`` — interface for connector-specific resolvers
  - ``ConnectorIdentityService``  — orchestrator that drives resolution
  - ``get_registered_resolvers``  — returns all active resolver instances
"""
from app.infrastructure.identity.resolver_interface import ConnectorIdentityResolver
from app.infrastructure.identity.identity_service import ConnectorIdentityService
from app.infrastructure.identity.registry import get_registered_resolvers

__all__ = [
    "ConnectorIdentityResolver",
    "ConnectorIdentityService",
    "get_registered_resolvers",
]
