"""
ConnectorPermissionRepository — async database access for connector_permissions.

Responsibilities
----------------
* All SQL for the connector_permissions table lives here.
* No permission logic — only data access.
* Follows the same AsyncSession + SQLAlchemy pattern used by UserRepository.

V1 / V2 note
------------
All public methods accept an optional `subject_type` parameter defaulting to
SubjectType.USER.  V2 group resolution calls the same methods with
SubjectType.GROUP — no new methods are needed.
"""
from __future__ import annotations

import logging
import uuid
from typing import Optional

from sqlalchemy import and_, func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.permissions.models.connector_permission_model import ConnectorPermission, SubjectType

logger = logging.getLogger(__name__)


class ConnectorPermissionRepository:
    """
    Data-access layer for the connector_permissions table.

    All writes use PostgreSQL upsert (INSERT … ON CONFLICT DO UPDATE) so
    the caller never needs to distinguish between create and update.
    The unique constraint on (subject_type, subject_id, connector_name)
    guarantees at most one authoritative row per subject/connector pair.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    async def get_all_for_subject(
        self,
        subject_id: str,
        subject_type: SubjectType = SubjectType.USER,
    ) -> list[ConnectorPermission]:
        """
        Return all permission rows for a given subject.

        V1: subject_type=USER, subject_id=user UUID string.
        V2: subject_type=GROUP, subject_id=group name string.
        """
        query = select(ConnectorPermission).where(
            and_(
                ConnectorPermission.subject_type == subject_type,
                ConnectorPermission.subject_id   == subject_id,
            )
        )
        result = await self._db.execute(query)
        return list(result.scalars().all())

    async def get_one(
        self,
        subject_id:     str,
        connector_name: str,
        subject_type:   SubjectType = SubjectType.USER,
    ) -> Optional[ConnectorPermission]:
        """Return the single row for (subject_type, subject_id, connector_name), or None."""
        query = select(ConnectorPermission).where(
            and_(
                ConnectorPermission.subject_type    == subject_type,
                ConnectorPermission.subject_id      == subject_id,
                ConnectorPermission.connector_name  == connector_name,
            )
        )
        result = await self._db.execute(query)
        return result.scalar_one_or_none()


    # ------------------------------------------------------------------
    # Writes (upsert pattern throughout)
    # ------------------------------------------------------------------

    async def upsert(
        self,
        subject_id:     str,
        connector_name: str,
        enabled:        bool,
        subject_type:   SubjectType = SubjectType.USER,
        granted_by:     Optional[uuid.UUID] = None,
        metadata:       Optional[dict]      = None,
    ) -> ConnectorPermission:
        """
        Insert or update a single (subject_type, subject_id, connector_name) row.

        Uses PostgreSQL INSERT … ON CONFLICT DO UPDATE so this method is safe
        to call for both new grants and modifications to existing ones.
        The unique constraint (uq_subject_connector) is the conflict target.

        Returns the refreshed ORM row after the upsert.
        """
        # "metadata" conflicts with SQLAlchemy's own Base.metadata attribute, so
        # we reference the DB column explicitly to avoid the wrong name in the
        # ON CONFLICT DO UPDATE SET clause (would emit `metadata_` otherwise).
        _meta_col = ConnectorPermission.__table__.c["metadata"]

        conflict_update: dict = {
            "enabled":    enabled,
            "granted_by": granted_by,
            "updated_at": func.now(),
        }
        # Only overwrite metadata on conflict when the caller explicitly provides
        # it.  Passing metadata=None (the default for grant/revoke calls) must
        # NOT erase a previously stored account_id from identity resolution —
        # doing so breaks ACL user-ID lookups on the next ingestion run.
        if metadata is not None:
            conflict_update[_meta_col] = metadata

        stmt = (
            pg_insert(ConnectorPermission)
            .values(
                subject_type   = subject_type,
                subject_id     = subject_id,
                connector_name = connector_name,
                enabled        = enabled,
                granted_by     = granted_by,
                metadata_      = metadata,
            )
            .on_conflict_do_update(
                constraint="uq_subject_connector",
                set_=conflict_update,
            )
            .returning(ConnectorPermission)
        )
        result = await self._db.execute(stmt)
        await self._db.commit()
        row: ConnectorPermission = result.scalar_one()
        await self._db.refresh(row)
        return row

    async def delete(
        self,
        subject_id:     str,
        connector_name: str,
        subject_type:   SubjectType = SubjectType.USER,
    ) -> bool:
        """
        Hard-delete a permission row.

        Prefer upsert(enabled=False) for auditable revokes.
        Use delete() only when the row itself should not exist
        (e.g. removing a user from the system entirely).

        Returns True if a row was deleted, False if none was found.
        """
        row = await self.get_one(subject_id, connector_name, subject_type)
        if row is None:
            return False
        await self._db.delete(row)
        await self._db.commit()
        return True
