"""
UserConnectorCredentialsRepository — async ORM access for user_connector_credentials.

Follows the same SQLAlchemy pattern as ConnectorPermissionRepository:
  - pg_insert for upserts
  - select() for reads
  - No raw SQL

Used by:
  - Atlassian OAuth callback  (upsert after OAuth flow)
  - JiraAgent                 (get to fetch token per request)
  - ConnectorIdentityService  (upsert external_id for Confluence accountId)
  - Token refresh service     (update_tokens on silent refresh)
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import and_, func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.permissions.models.user_connector_credentials_model import UserConnectorCredentials
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class UserConnectorCredentialsRepository:
    """
    Data-access layer for user_connector_credentials.

    All writes use PostgreSQL upsert (INSERT … ON CONFLICT DO UPDATE) so
    the caller never needs to distinguish between create and update.
    The unique constraint on (user_id, connector_name) is the conflict target.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    async def get(
        self,
        user_id: str,
        connector_name: str,
    ) -> Optional[UserConnectorCredentials]:
        """Fetch credential row for a specific user + connector. Returns None if not found."""
        query = select(UserConnectorCredentials).where(
            and_(
                UserConnectorCredentials.user_id        == uuid.UUID(user_id),
                UserConnectorCredentials.connector_name == connector_name,
            )
        )
        result = await self._db.execute(query)
        return result.scalar_one_or_none()

    async def get_by_external_id(
        self,
        connector_name: str,
        external_id: str,
    ) -> Optional[UserConnectorCredentials]:
        """
        Look up a credential by external connector identity.
        Used during ingestion to map Atlassian accountId → internal user_id.
        """
        query = select(UserConnectorCredentials).where(
            and_(
                UserConnectorCredentials.connector_name == connector_name,
                UserConnectorCredentials.external_id    == external_id,
                UserConnectorCredentials.status         == "active",
            )
        )
        result = await self._db.execute(query)
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # Writes (upsert pattern throughout)
    # ------------------------------------------------------------------

    async def upsert(
        self,
        *,
        user_id: str,
        connector_name: str,
        external_id: Optional[str] = None,
        external_email: Optional[str] = None,
        access_token_enc: Optional[str] = None,
        refresh_token_enc: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        token_scope: Optional[str] = None,
        status: str = "active",
        metadata: Optional[dict] = None,
    ) -> UserConnectorCredentials:
        """
        Insert or update a credential row.

        Uses PostgreSQL INSERT … ON CONFLICT DO UPDATE.
        None values do NOT overwrite existing data — only provided
        fields are updated. This matches the pattern in
        ConnectorPermissionRepository.upsert().
        """
        _table = UserConnectorCredentials.__table__

        insert_values: dict = {
            "credential_id":    uuid.uuid4(),
            "user_id":          uuid.UUID(user_id),
            "connector_name":   connector_name,
            "status":           status,
            "created_at":       datetime.now(timezone.utc),
            "updated_at":       datetime.now(timezone.utc),
        }
        if external_id       is not None: insert_values["external_id"]       = external_id
        if external_email    is not None: insert_values["external_email"]    = external_email
        if access_token_enc  is not None: insert_values["access_token_enc"]  = access_token_enc
        if refresh_token_enc is not None: insert_values["refresh_token_enc"] = refresh_token_enc
        if expires_at        is not None: insert_values["expires_at"]        = expires_at
        if token_scope       is not None: insert_values["token_scope"]       = token_scope
        if metadata          is not None: insert_values["metadata"]          = metadata

        conflict_update: dict = {
            "status":     status,
            "updated_at": func.now(),
        }
        if external_id       is not None: conflict_update["external_id"]       = external_id
        if external_email    is not None: conflict_update["external_email"]    = external_email
        if access_token_enc  is not None: conflict_update["access_token_enc"]  = access_token_enc
        if refresh_token_enc is not None: conflict_update["refresh_token_enc"] = refresh_token_enc
        if expires_at        is not None: conflict_update["expires_at"]        = expires_at
        if token_scope       is not None: conflict_update["token_scope"]       = token_scope
        if metadata          is not None: conflict_update["metadata"]          = metadata

        stmt = (
            pg_insert(UserConnectorCredentials)
            .values(**insert_values)
            .on_conflict_do_update(
                constraint="uq_user_connector",
                set_=conflict_update,
            )
            .returning(UserConnectorCredentials)
        )

        result = await self._db.execute(stmt)
        await self._db.commit()
        row: UserConnectorCredentials = result.scalar_one()
        await self._db.refresh(row)

        logger.info(
            "upsert credential",
            connector=connector_name,
            user_id=user_id,
            external_id=external_id,
            status=status,
        )
        return row

    async def update_tokens(
        self,
        *,
        user_id: str,
        connector_name: str,
        access_token_enc: str,
        refresh_token_enc: str,
        expires_at: datetime,
    ) -> None:
        """
        Update only token fields — called by the token refresh service.
        Never touches external_id or external_email.
        """
        row = await self.get(user_id, connector_name)
        if row is None:
            logger.warn(
                "update_tokens: no credential row found",
                connector=connector_name,
                user_id=user_id,
            )
            return

        row.access_token_enc  = access_token_enc
        row.refresh_token_enc = refresh_token_enc
        row.expires_at        = expires_at
        row.status            = "active"
        row.updated_at        = datetime.now(timezone.utc)

        await self._db.commit()
        await self._db.refresh(row)

        logger.info(
            "tokens refreshed",
            connector=connector_name,
            user_id=user_id,
            expires_at=expires_at.isoformat(),
        )

    async def revoke(
        self,
        *,
        user_id: str,
        connector_name: str,
    ) -> None:
        """
        Mark credential as revoked.
        Called when the user disconnects their Atlassian account or when
        a refresh token exchange returns 401 (user revoked app access).
        Soft delete — row is retained for audit purposes.
        """
        row = await self.get(user_id, connector_name)
        if row is None:
            return

        row.status     = "revoked"
        row.updated_at = datetime.now(timezone.utc)
        await self._db.commit()

        logger.info(
            "credential revoked",
            connector=connector_name,
            user_id=user_id,
        )
