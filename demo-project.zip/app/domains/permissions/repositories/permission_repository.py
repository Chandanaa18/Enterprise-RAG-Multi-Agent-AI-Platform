"""
PermissionRepository — database-only operations for permission data.

Responsibilities
----------------
* get_user_roles()             — read roles stored in the users table
* get_user_groups()            — read group memberships stored in users.metadata
* get_connector_permissions()  — read user-level connector grants from
                                  connector_permissions (subject_type='user')

No business logic lives here.  All permission decisions belong in
PermissionService.  This class only translates SQL results into plain Python
types so that callers never need to understand the schema layout.

Connection strategy
-------------------
Uses a psycopg2 ThreadedConnectionPool (identical to PgVectorStore) so that
this class can be called synchronously from LangGraph nodes without asyncio
complexity.  The pool is opened lazily on first construction.
"""
from __future__ import annotations

import logging
from typing import Any

from psycopg2.extras import RealDictCursor
from psycopg2.pool import ThreadedConnectionPool

from app.core.config import settings
from app.core.constants import (
    DOCUMENT_INDEX_TABLE,
    USER_METADATA_GROUPS_KEY,
    USERS_TABLE,
)

logger = logging.getLogger(__name__)
class PermissionRepository:
    """
    Raw database access layer for user permission and document ACL data.

    Uses the same psycopg2 ThreadedConnectionPool pattern as PgVectorStore so
    that connection lifecycle and error handling are consistent across the
    retrieval layer.

    This class is thread-safe: the pool handles concurrent access internally.
    """

    _POOL_MIN_CONNECTIONS = 1
    _POOL_MAX_CONNECTIONS = 5

    def __init__(self) -> None:
        database_config = settings.db
        self._pool = ThreadedConnectionPool(
            self._POOL_MIN_CONNECTIONS,
            self._POOL_MAX_CONNECTIONS,
            host=database_config.host,
            port=database_config.port,
            user=database_config.username,
            password=database_config.password,
            dbname=database_config.database,
        )
        logger.info(
            "PermissionRepository connection pool ready host=%s db=%s",
            database_config.host,
            database_config.database,
        )

    # ------------------------------------------------------------------
    # Connection helper
    # ------------------------------------------------------------------

    class _ConnectionContext:
        """Context manager that borrows a connection from the pool and
        commits or rolls back on exit."""

        def __init__(self, pool: ThreadedConnectionPool) -> None:
            self._pool = pool
            self._connection: Any = None

        def __enter__(self):
            self._connection = self._pool.getconn()
            return self._connection

        def __exit__(self, exc_type, exc, traceback):
            if exc_type is None:
                self._connection.commit()
            else:
                self._connection.rollback()
            self._pool.putconn(self._connection)

    def _borrow_connection(self) -> "_ConnectionContext":
        return PermissionRepository._ConnectionContext(self._pool)

    # ------------------------------------------------------------------
    # Public query methods — no business logic
    # ------------------------------------------------------------------

    def get_user_roles(self, user_id: str) -> list[str]:
        """
        Return the roles list stored in the users table for the given user.

        The roles column is a JSONB array (list of role-name strings).
        Returns an empty list if the user is not found or has no roles assigned.

        Parameters
        ----------
        user_id
            UUID string identifying the user in the local users table.
        """
        sql = f"SELECT roles FROM {USERS_TABLE} WHERE user_id = %s::uuid"

        with self._borrow_connection() as connection:
            with connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(sql, (user_id,))
                row = cursor.fetchone()

        if row is None:
            logger.warning(
                "get_user_roles: user_id=%s not found in the users table", user_id
            )
            return []

        raw_roles = row.get("roles") or []
        return [str(role) for role in raw_roles]

    def get_user_groups(self, user_id: str) -> list[str]:
        """
        Return the group memberships stored in users.metadata for the given user.

        Groups are stored as a list under the key defined by USER_METADATA_GROUPS_KEY
        inside the JSONB metadata column.  Example stored value:
            {"groups": ["engineering", "developers"]}

        Returns an empty list if no groups are defined or the user is not found.

        Parameters
        ----------
        user_id
            UUID string identifying the user in the local users table.
        """
        sql = f"SELECT metadata FROM {USERS_TABLE} WHERE user_id = %s::uuid"

        with self._borrow_connection() as connection:
            with connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(sql, (user_id,))
                row = cursor.fetchone()

        if row is None:
            logger.warning(
                "get_user_groups: user_id=%s not found in the users table", user_id
            )
            return []

        metadata = row.get("metadata") or {}
        raw_groups = metadata.get(USER_METADATA_GROUPS_KEY, [])
        return [str(group) for group in raw_groups]

    def get_user_id_by_connector_account(
        self,
        connector_id: str,
        account_id: str,
    ) -> str | None:
        """
        Look up the internal user_id for a given external connector account ID.

        Reads connector_permissions.metadata_ using the JSONB path:
            metadata ->> 'account_id' = <account_id>

        The identity mapping is stored in connector_permissions.metadata_ by
        ConnectorIdentityService after login. This query returns the subject_id
        (internal user UUID) of the matching enabled permission row.

        Example stored value in connector_permissions.metadata_::

            {
                "account_id":   "712020:abc...",
                "account_type": "atlassian",
                "display_name": "Apoorva SB",
                "resolved_at":  "2026-06-01T..."
            }

        Parameters
        ----------
        connector_id
            Connector name (e.g. "confluence") — matches connector_name column.
        account_id
            External account ID (e.g. Atlassian accountId).

        Returns
        -------
        str | None
            Internal user_id UUID string, or None if not found.
        """
        # Join to users so we always return the internal user_id UUID,
        # even when connector_permissions.subject_id stores azure_ad_oid.
        sql = """
            SELECT u.user_id::text
            FROM enterprise_rag_system.connector_permissions cp
            JOIN enterprise_rag_system.users u
              ON u.user_id::text = cp.subject_id
              OR u.azure_ad_oid  = cp.subject_id
            WHERE cp.subject_type  = 'user'
              AND cp.connector_name = %s
              AND cp.enabled        = TRUE
              AND cp.metadata      ->> 'account_id' = %s
            LIMIT 1
        """

        with self._borrow_connection() as connection:
            with connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(sql, (connector_id, account_id))
                row = cursor.fetchone()

        if row is None:
            logger.debug(
                "get_user_id_by_connector_account: no match for "
                "connector=%s account_id=%s",
                connector_id,
                account_id,
            )
            return None

        return row["user_id"]


    def get_connector_permissions(self, user_id: str) -> list[dict]:
        """
        Return connector permission rows for a given user.

        Queries connector_permissions WHERE subject_type='user' so that only
        explicit user-level grants are returned.  Group-subject rows are
        intentionally excluded here; V2 group resolution will be a separate
        method added when Azure group sync is implemented.

        Returns a list of dicts, each with keys:
            connector_name : str
            enabled        : bool

        An empty list means the user has no explicit connector permissions
        (deny-all default — PermissionService will return [] allowed_connectors).

        Parameters
        ----------
        user_id
            UUID string identifying the user in the local users table.
        """
        # The UI/API previously permitted granting by Azure AD OID or PostgreSQL PK.
        # To handle both gracefully, we left-join the users table to resolve the
        # user's azure_ad_oid, and accept a match on either ID.
        # LOWER() on both sides guards against any UUID case mismatch between
        # the stored subject_id and the queried user_id.
        sql = f"""
            SELECT c.connector_name, c.enabled
            FROM   enterprise_rag_system.connector_permissions c
            LEFT JOIN {USERS_TABLE} u ON u.user_id = %s::uuid
            WHERE  c.subject_type = 'user'
            AND    (
                LOWER(c.subject_id) = LOWER(%s)
                OR (u.azure_ad_oid IS NOT NULL AND LOWER(c.subject_id) = LOWER(u.azure_ad_oid))
            )
        """
        with self._borrow_connection() as connection:
            with connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(sql, (user_id, user_id))
                rows = cursor.fetchall()

        logger.debug(
            "get_connector_permissions user_id=%s found=%d rows=%s",
            user_id,
            len(rows),
            [(r["connector_name"], r["enabled"]) for r in rows],
        )

        return [
            {"connector_name": row["connector_name"], "enabled": bool(row["enabled"])}
            for row in rows
        ]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Return all connections to the pool and close it."""
        self._pool.closeall()
        logger.info("PermissionRepository connection pool closed")
