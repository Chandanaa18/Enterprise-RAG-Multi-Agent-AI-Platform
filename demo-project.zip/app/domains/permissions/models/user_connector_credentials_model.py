"""
UserConnectorCredentials ORM model.

Maps to enterprise_rag_system.user_connector_credentials.

One row per (user_id, connector_name) — stores per-user identity and
OAuth tokens for each external connector.

Connector-specific usage
------------------------
  Confluence  : external_id = Atlassian accountId, no token needed
                (service account handles ingestion; identity used for ACL)
  Jira        : external_id = Atlassian accountId, OAuth access + refresh tokens
  Teams       : external_id = Azure AD OID, no separate token (reuses Azure AD)
  M365        : external_id = Azure AD OID, no separate token (reuses Azure AD)
  SharePoint  : external_id = Azure AD OID, no separate token (reuses Azure AD)

Token fields are nullable so the table serves both identity-only connectors
(Confluence) and token-bearing connectors (Jira) without separate tables.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.infrastructure.database.database import Base


class UserConnectorCredentials(Base):
    """
    One row = one connector identity / credential set for a specific user.

    The UNIQUE constraint on (user_id, connector_name) means each user has
    exactly one authoritative row per connector. Upsert is the correct write
    pattern — never insert/update separately.
    """

    __tablename__  = "user_connector_credentials"
    __table_args__ = (
        UniqueConstraint(
            "user_id", "connector_name",
            name="uq_user_connector",
        ),
        {"schema": "enterprise_rag_system"},
    )

    credential_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_rag_system.users.user_id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )
    connector_name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="ConnectorType value e.g. 'jira', 'confluence', 'teams'",
    )
    external_id: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="User identity in external system e.g. Atlassian accountId",
    )
    external_email: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="User email in external system — may differ from Azure AD email",
    )
    access_token_enc: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Fernet-encrypted OAuth access token",
    )
    refresh_token_enc: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="Fernet-encrypted OAuth refresh token",
    )
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="When the access token expires",
    )
    token_scope: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True,
        comment="OAuth scopes granted e.g. 'read:jira-work write:jira-work'",
    )
    status: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        default="active",
        comment="'active' or 'revoked'",
    )
    metadata_: Mapped[Optional[dict]] = mapped_column(
        "metadata",
        JSONB,
        nullable=True,
        default=None,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
