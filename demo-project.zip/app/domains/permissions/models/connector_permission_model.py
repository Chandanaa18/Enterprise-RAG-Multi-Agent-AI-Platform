"""
ConnectorPermission ORM model.

Maps to enterprise_rag_system.connector_permissions.

Subject-based design
--------------------
A single model handles both V1 (user-level) and V2 (group-level) grants:

    subject_type = 'user'   → subject_id = users.user_id as a UUID string
    subject_type = 'group'  → subject_id = Azure AD / local group name string

V1 only creates 'user' rows.  V2 adds 'group' rows without any migration.

The SubjectType enum is the single source of truth for allowed values;
the database CHECK constraint mirrors it for defence-in-depth.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import StrEnum
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.infrastructure.database.database import Base


class SubjectType(StrEnum):
    """
    Discriminator for the subject of a connector permission grant.

    USER  — the grant applies to a single, specific user (V1 scope).
    GROUP — the grant applies to every member of the named group (V2 scope).

    Resolution priority: a USER row always overrides a GROUP row for the same
    connector.  This lets admins make per-user exceptions in both directions
    (explicit allow or explicit deny) on top of a group-level baseline.
    """
    USER  = "user"
    GROUP = "group"


class ConnectorPermission(Base):
    """
    One row = one access decision for (subject, connector) pair.

    The UNIQUE constraint on (subject_type, subject_id, connector_name) means
    every subject/connector combination has exactly one authoritative row.
    Upsert (INSERT … ON CONFLICT DO UPDATE) is the correct write pattern.

    Columns
    -------
    permission_id   Surrogate PK — stable external identifier for Admin APIs.
    subject_type    'user' or 'group' — controls how subject_id is interpreted.
    subject_id      UUID string for users; group-name string for groups.
    connector_name  Matches ConnectorType enum values (e.g. 'confluence').
    enabled         True = access granted; False = access explicitly denied.
                    Absent row = deny (deny-all default).
    granted_by      Which admin created / last modified this row. Nullable
                    because the first rows may be created by a migration or
                    seed script before any admin user exists.
    metadata        Reserved for future use (e.g. connector-specific scope
                    restrictions, rate limits, expiry timestamps).
    created_at      Immutable creation timestamp.
    updated_at      Kept current by a DB trigger on every UPDATE.
    """

    __tablename__  = "connector_permissions"
    __table_args__ = (
        UniqueConstraint(
            "subject_type", "subject_id", "connector_name",
            name="uq_subject_connector",
        ),
        {"schema": "enterprise_rag_system"},
    )

    permission_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )
    subject_type: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="'user' or 'group' — discriminator for subject_id interpretation",
    )
    subject_id: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        index=True,
        comment="UUID string for users; group-name string for groups",
    )
    connector_name: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="ConnectorType value, e.g. 'confluence', 'sharepoint'",
    )
    enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        comment="True = access granted; False = explicitly denied",
    )
    granted_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey(
            "enterprise_rag_system.users.user_id",
            ondelete="SET NULL",
        ),
        nullable=True,
        comment="Admin user_id who last modified this row",
    )
    metadata_: Mapped[Optional[dict]] = mapped_column(
        "metadata",
        JSONB,
        nullable=True,
        default=None,
        comment="Reserved: connector-specific scope, rate-limit, expiry data",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
