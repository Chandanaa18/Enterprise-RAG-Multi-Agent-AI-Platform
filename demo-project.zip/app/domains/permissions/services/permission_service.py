"""
PermissionService — resolves a user's full permission set into a PermissionContext.

Responsibilities
----------------
* Load application roles from the local database (set during Azure AD sync).
* Load group memberships from users.metadata (used for chunk-level ACL matching).
* Merge database roles with roles carried in the Azure AD JWT token.
* Load connector permissions from the connector_permissions table.
* Build and return a single, immutable PermissionContext.

Connector permission resolution (V1 — user-level only)
-------------------------------------------------------
V1 queries connector_permissions WHERE subject_type='user' AND subject_id=user_id.
Absent row = denied (deny-all default).

Connector permission resolution (V2 — group-level, future work)
----------------------------------------------------------------
When Azure group membership is available, also query rows WHERE
subject_type='group' AND subject_id IN (user_groups).
User-explicit rows override group rows (user wins on conflict).
No schema change is required — _resolve_connector_permissions() is the only
function that needs to be extended.
"""
from __future__ import annotations

import logging

from app.domains.permissions.schemas.permission_context import PermissionContext
from app.domains.permissions.repositories.permission_repository import PermissionRepository

logger = logging.getLogger(__name__)


class PermissionService:
    """
    Builds a PermissionContext for a given user by loading and combining role,
    group, and connector-permission information from the database.

    Designed to be constructed once and reused across requests — both this
    class and PermissionRepository are stateless after construction.

    Parameters
    ----------
    permission_repository
        Repository instance used for all database reads.  Injected to allow
        testing without a real database connection.
    """

    def __init__(self, permission_repository: PermissionRepository) -> None:
        self._repository = permission_repository

    def get_user_permissions(
        self,
        user_id: str,
        token_roles: list[str] | None = None,
    ) -> PermissionContext:
        """
        Load all permission data for a user and return a PermissionContext.

        Parameters
        ----------
        user_id
            Stable UUID string identifying the user (from the JWT oid claim or
            the local users table primary key).
        token_roles
            Roles extracted from the Azure AD JWT at request time.  These are
            merged with database-stored roles so that fresh role grants take
            effect immediately without waiting for the next database sync.

        Returns
        -------
        PermissionContext
            An immutable snapshot of the user's permissions at this moment.
        """
        database_roles = self._load_user_roles_from_database(user_id)
        user_groups    = self._load_user_groups_from_database(user_id)

        merged_roles = _merge_roles_deduplicating(
            token_roles=token_roles or [],
            database_roles=database_roles,
        )

        # V1: query only user-subject rows from connector_permissions.
        connector_permissions = self._resolve_connector_permissions(
            user_id=user_id,
            user_groups=user_groups,
        )
        allowed_connectors = [
            connector for connector, enabled in connector_permissions.items()
            if enabled
        ]

        logger.info(
            "event=permissions_resolved user=%s "
            "token_roles=%d db_roles=%d groups=%d "
            "allowed_connectors=%s",
            user_id,
            len(token_roles or []),
            len(database_roles),
            len(user_groups),
            allowed_connectors,
        )

        return PermissionContext(
            user_id=user_id,
            user_roles=merged_roles,
            user_groups=user_groups,
            connector_permissions=connector_permissions,
            allowed_connectors=allowed_connectors,
        )

    # ------------------------------------------------------------------
    # Private helpers — each does exactly one thing
    # ------------------------------------------------------------------

    def _load_user_roles_from_database(self, user_id: str) -> list[str]:
        """
        Retrieve the roles list from the local users table.

        Returns an empty list if the user is not yet provisioned or if the
        database query fails (token roles are still used via the merge step).
        """
        try:
            return self._repository.get_user_roles(user_id)
        except Exception as exc:
            logger.warning(
                "Failed to load roles for user_id=%s from database. "
                "Falling back to empty database-role list. error=%s",
                user_id, exc,
            )
            return []

    def _load_user_groups_from_database(self, user_id: str) -> list[str]:
        """
        Retrieve group memberships from users.metadata["groups"].

        Returns an empty list if no groups are defined or the query fails.
        Groups are used for chunk-level ACL matching (acl_roles column) and
        for V2 group-connector permission resolution.
        """
        try:
            return self._repository.get_user_groups(user_id)
        except Exception as exc:
            logger.warning(
                "Failed to load groups for user_id=%s from database. "
                "Falling back to empty groups list. error=%s",
                user_id, exc,
            )
            return []

    def _resolve_connector_permissions(
        self,
        user_id: str,
        user_groups: list[str],  # noqa: ARG002 — reserved for V2
    ) -> dict[str, bool]:
        """
        Build a connector_name → enabled map for the given user.

        V1 (current): queries only user-subject rows.
        Absent row = denied (deny-all default).

        V2 (future — no schema change needed):
            1. Load group-subject rows for each name in user_groups.
            2. Start with the group map as baseline.
            3. Overwrite with user-subject rows (user-explicit always wins).

        Parameters
        ----------
        user_id
            UUID string of the requesting user.
        user_groups
            Group names from users.metadata — passed in now so V2 can use
            them without changing this method's signature.

        Returns
        -------
        dict[str, bool]
            {connector_name: enabled} for every row that exists for this user.
            Keys not present in the dict = no explicit grant = denied.
        """
        try:
            rows = self._repository.get_connector_permissions(user_id)
        except Exception as exc:
            logger.warning(
                "Failed to load connector permissions for user_id=%s. "
                "Defaulting to deny-all. error=%s",
                user_id, exc,
            )
            return {}

        # V2 group resolution goes here — extend without changing the signature.
        # Example (do not implement until Azure group sync is available):
        #
        #   group_map: dict[str, bool] = {}
        #   for group_name in user_groups:
        #       for row in self._repository.get_connector_permissions_for_group(group_name):
        #           group_map[row["connector_name"]] = row["enabled"]
        #
        #   # User-explicit rows override group rows
        #   user_map = {row["connector_name"]: row["enabled"] for row in rows}
        #   return {**group_map, **user_map}

        return {row["connector_name"]: row["enabled"] for row in rows}


# ---------------------------------------------------------------------------
# Module-level pure functions (no side effects — easy to unit-test)
# ---------------------------------------------------------------------------

def _merge_roles_deduplicating(
    token_roles: list[str],
    database_roles: list[str],
) -> list[str]:
    """
    Combine JWT token roles and database roles into a single deduplicated list.

    Token roles are placed first because they represent the authoritative
    runtime grants from Azure AD.  Database roles follow, providing grants
    that were assigned outside of the token lifecycle.

    Examples
    --------
    >>> _merge_roles_deduplicating(["admin"], ["admin", "agent.knowledge_rag"])
    ['admin', 'agent.knowledge_rag']
    """
    seen_roles: set[str] = set(token_roles)
    merged: list[str] = list(token_roles)

    for role in database_roles:
        if role not in seen_roles:
            merged.append(role)
            seen_roles.add(role)

    return merged
