"""
ConnectorPermissionService — Admin API surface for connector permission management.

Responsibilities
----------------
* Grant / revoke connector access for a user or group.
* List all permissions for a given subject.
* Check whether a specific subject has access to a specific connector.

This service is the only layer that writes to connector_permissions.
The PermissionService (read path) has its own direct dependency on
ConnectorPermissionRepository to avoid coupling the hot request path to
this admin service.

V1 / V2 note
-----------
All public methods accept an optional subject_type parameter defaulting to
SubjectType.USER.  When group-based grants are enabled (V2), call with
subject_type=SubjectType.GROUP and subject_id=<group_name>.  No new methods
are required — the interface is already group-aware.
"""
from __future__ import annotations

import logging
import uuid
from typing import Optional

from app.shared.enums import ConnectorType
from app.domains.permissions.models.connector_permission_model import ConnectorPermission, SubjectType
from app.domains.permissions.repositories.connector_permission_repository import ConnectorPermissionRepository

logger = logging.getLogger(__name__)

# All connector names the system currently recognises.
# Used to validate connector_name on writes so invalid names are caught early.
_KNOWN_CONNECTORS: frozenset[str] = frozenset(c.value for c in ConnectorType)


class ConnectorPermissionService:
    """
    Admin-facing service for managing connector permissions.

    Designed to be constructed per-request via FastAPI Depends, with the
    repository receiving the injected AsyncSession.

    Usage example (FastAPI route)
    -----------------------------
    @router.post("/admin/users/{user_id}/connectors/{connector}/grant")
    async def grant(
        user_id: UUID,
        connector: str,
        admin: User = Depends(require_role(UserRole.ADMIN)),
        db: AsyncSession = Depends(get_db),
    ):
        svc = ConnectorPermissionService(ConnectorPermissionRepository(db))
        return await svc.grant_to_user(user_id, connector, granted_by=admin.user_id)
    """

    def __init__(self, repository: ConnectorPermissionRepository) -> None:
        self._repo = repository

    # ------------------------------------------------------------------
    # User-level grant/revoke  (V1 primary API)
    # ------------------------------------------------------------------

    async def grant_to_user(
        self,
        user_id:        uuid.UUID,
        connector_name: str,
        granted_by:     Optional[uuid.UUID] = None,
        metadata:       Optional[dict]      = None,
    ) -> ConnectorPermission:
        """
        Grant a specific user access to a connector.

        Idempotent — safe to call multiple times; each call sets enabled=True.
        An explicit user grant overrides any group-level deny for the same
        connector during PermissionService resolution.
        """
        self._validate_connector(connector_name)
        logger.info(
            "event=connector_grant subject_type=user subject_id=%s connector=%s granted_by=%s",
            user_id, connector_name, granted_by,
        )
        row = await self._repo.upsert(
            subject_id     = str(user_id),
            connector_name = connector_name,
            enabled        = True,
            subject_type   = SubjectType.USER,
            granted_by     = granted_by,
            metadata       = metadata,
        )

        # Re-resolve identity immediately if metadata is missing.
        # This handles the case where a connector was deleted and re-granted —
        # the new row has no metadata, so we enqueue resolution now instead of
        # waiting for the user's next login.
        if not (row.metadata_ or {}).get("account_id"):
            try:
                from app.infrastructure.database.database import AsyncSessionLocal
                from app.domains.users.repositories.user_repository import UserRepository
                from app.ingestion.tasks import resolve_user_identities

                async with AsyncSessionLocal() as db:
                    user_repo = UserRepository(db)
                    user = await user_repo.get_by_id(str(user_id))

                if user and user.email:
                    resolve_user_identities.delay(str(user_id), user.email)
                    logger.info(
                        "event=identity_resolution_enqueued user_id=%s connector=%s "
                        "reason=grant_without_metadata",
                        user_id, connector_name,
                    )
            except Exception as exc:
                # Never block the grant — identity resolution is best-effort.
                logger.warning(
                    "event=identity_resolution_enqueue_failed user_id=%s error=%s",
                    user_id, exc,
                )

        return row

    async def revoke_from_user(
        self,
        user_id:        uuid.UUID,
        connector_name: str,
        granted_by:     Optional[uuid.UUID] = None,
    ) -> ConnectorPermission:
        """
        Explicitly deny a user access to a connector.

        Sets enabled=False (soft revoke) rather than deleting the row so that
        the audit trail (granted_by, updated_at) is preserved.
        An explicit user deny overrides any group-level grant.
        """
        self._validate_connector(connector_name)
        logger.info(
            "event=connector_revoke subject_type=user subject_id=%s connector=%s revoked_by=%s",
            user_id, connector_name, granted_by,
        )
        return await self._repo.upsert(
            subject_id     = str(user_id),
            connector_name = connector_name,
            enabled        = False,
            subject_type   = SubjectType.USER,
            granted_by     = granted_by,
        )

    # ------------------------------------------------------------------
    # Group-level grant/revoke  (V2 API — same interface, group subject)
    # ------------------------------------------------------------------

    async def grant_to_group(
        self,
        group_name:     str,
        connector_name: str,
        granted_by:     Optional[uuid.UUID] = None,
        metadata:       Optional[dict]      = None,
    ) -> ConnectorPermission:
        """
        Grant all members of an Azure AD / local group access to a connector.

        V2 method. At resolution time, PermissionService checks group rows
        for each group in the user's user_groups list.
        """
        self._validate_connector(connector_name)
        logger.info(
            "event=connector_grant subject_type=group subject_id=%s connector=%s granted_by=%s",
            group_name, connector_name, granted_by,
        )
        return await self._repo.upsert(
            subject_id     = group_name,
            connector_name = connector_name,
            enabled        = True,
            subject_type   = SubjectType.GROUP,
            granted_by     = granted_by,
            metadata       = metadata,
        )

    async def revoke_from_group(
        self,
        group_name:     str,
        connector_name: str,
        granted_by:     Optional[uuid.UUID] = None,
    ) -> ConnectorPermission:
        """Explicitly deny all members of a group access to a connector."""
        self._validate_connector(connector_name)
        logger.info(
            "event=connector_revoke subject_type=group subject_id=%s connector=%s revoked_by=%s",
            group_name, connector_name, granted_by,
        )
        return await self._repo.upsert(
            subject_id     = group_name,
            connector_name = connector_name,
            enabled        = False,
            subject_type   = SubjectType.GROUP,
            granted_by     = granted_by,
        )

    # ------------------------------------------------------------------
    # Queries (used by Admin read endpoints)
    # ------------------------------------------------------------------

    async def get_user_permissions(
        self,
        user_id: uuid.UUID,
    ) -> list[ConnectorPermission]:
        """Return all connector permission rows for a specific user."""
        return await self._repo.get_all_for_subject(
            subject_id   = str(user_id),
            subject_type = SubjectType.USER,
        )

    async def get_group_permissions(
        self,
        group_name: str,
    ) -> list[ConnectorPermission]:
        """Return all connector permission rows for a specific group (V2)."""
        return await self._repo.get_all_for_subject(
            subject_id   = group_name,
            subject_type = SubjectType.GROUP,
        )

    async def is_user_allowed(
        self,
        user_id:        uuid.UUID,
        connector_name: str,
    ) -> bool:
        """
        Check whether a specific user has explicit access to a connector.

        Returns False if no row exists (deny-all default).
        Does NOT factor in group-level grants — use PermissionService for
        the full resolution including group inheritance.
        """
        row = await self._repo.get_one(
            subject_id     = str(user_id),
            connector_name = connector_name,
            subject_type   = SubjectType.USER,
        )
        return row is not None and row.enabled

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_connector(connector_name: str) -> None:
        """Raise ValueError if connector_name is not a known ConnectorType value."""
        if connector_name not in _KNOWN_CONNECTORS:
            raise ValueError(
                f"Unknown connector: {connector_name!r}. "
                f"Known connectors: {sorted(_KNOWN_CONNECTORS)}"
            )
