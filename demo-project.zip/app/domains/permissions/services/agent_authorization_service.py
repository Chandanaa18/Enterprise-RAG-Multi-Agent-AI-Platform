"""
AgentAuthorizationService — centralized execution-level authorization gate.

Position in the execution flow
-------------------------------
    API layer (JWT + any-agent-role check)
        │
        ▼
    Supervisor Planner (selects agent)
        │
        ▼
    ► AgentAuthorizationService.authorize()  ◄  — THIS SERVICE
        │
        ▼
    Agent Execution (handle)

Security policy
---------------
TEMPORARY:
    Admin currently bypasses execution authorization.
    Future implementation will enforce connector restrictions for admin.

    Current formula:
        ALLOW = has_admin_role
                OR
                (has_exact_agent_role AND connector_enabled)

    Target formula (future):
        ALLOW = (has_admin_role OR has_exact_agent_role) AND connector_enabled

Non-admin users:
    ALLOW = has_exact_agent_role AND connector_enabled

Failure strategy
----------------
If the authorization check itself fails (e.g. database unreachable), the
service fails closed — execution is denied.  This is the safe default for
an enterprise system.

Design
------
This is a pure domain service:
  - No FastAPI dependencies
  - No Supervisor logic
  - No agent implementation details
  - Reuses existing PermissionService and AGENT_ROLE_MAP
"""
from __future__ import annotations

from app.core.config import settings
from app.domains.permissions.schemas.authorization_context import AuthorizationContext
from app.domains.permissions.schemas.permission_context import PermissionContext
from app.domains.permissions.services.permission_service import PermissionService
from app.shared.enums import AGENT_ROLE_MAP, AgentName, UserRole
from app.shared.utils.logger.logger import Logger

logger = Logger(__file__)

# ---------------------------------------------------------------------------
# Agent name → connector name mapping
# ---------------------------------------------------------------------------
# By convention, the agent name matches the connector name exactly
# (e.g. agent "knowledge_rag" queries connector "confluence").
# Override this map when the relationship is not 1:1.

_AGENT_TO_CONNECTOR: dict[str, str] = {
    AgentName.KNOWLEDGE_RAG: "confluence",   # knowledge_rag reads from Confluence
    AgentName.JIRA:          "jira",
    AgentName.TEAMS:         "teams",
    AgentName.M365:          "m365",
}


class AgentAuthorizationService:
    """
    Single entry point for evaluating agent execution authorization.

    Constructed once at startup and reused across all requests.
    Thread-safe: all state is read-only after construction.

    Parameters
    ----------
    permission_service
        Existing PermissionService instance used to load connector
        permissions from the database.
    """

    def __init__(self, permission_service: PermissionService) -> None:
        self._permission_service = permission_service

    def authorize(
        self,
        *,
        user_id: str,
        user_roles: list[str],
        agent_name: str,
    ) -> AuthorizationContext:
        """
        Evaluate whether a user may execute a specific agent.

        Parameters
        ----------
        user_id
            Stable UUID string of the requesting user.
        user_roles
            Roles extracted from the Azure AD JWT token (merged with DB roles).
        agent_name
            The agent selected by the Supervisor planner (e.g. "jira").

        Returns
        -------
        AuthorizationContext
            Immutable decision object with allow/deny and evidence fields.
        """
        # ------------------------------------------------------------------
        # TEMPORARY: Admin currently bypasses execution authorization.
        # Future implementation will enforce connector restrictions for admin.
        # ------------------------------------------------------------------
        is_admin = UserRole.ADMIN.value in user_roles

        if settings.security.admin_bypass_enabled and is_admin:
            logger.info(
                "Agent authorization granted via admin bypass",
                event="agent_authorization",
                agent_name=agent_name,
                user_id=user_id,
                outcome="ALLOW",
                reason="admin_bypass",
            )
            return AuthorizationContext(
                allowed=True,
                agent_name=agent_name,
                user_id=user_id,
                required_role=self._resolve_required_role(agent_name),
                has_required_role=True,
                connector_enabled=True,
                reason="Authorized: admin bypass (temporary policy)",
            )

        # 1. Resolve the required Azure App Role for this agent
        required_role = self._resolve_required_role(agent_name)

        if required_role is None:
            # Unknown agent — fail closed
            logger.warn(
                "Agent authorization denied — no role mapping exists",
                event="agent_authorization",
                agent_name=agent_name,
                user_id=user_id,
                outcome="DENIED",
                reason="unknown_agent",
            )
            return AuthorizationContext(
                allowed=False,
                agent_name=agent_name,
                user_id=user_id,
                required_role=None,
                has_required_role=False,
                connector_enabled=False,
                reason=f"Agent '{agent_name}' has no role mapping — execution denied",
            )

        # 2. Check Azure App Role (exact match, no admin bypass for non-admins)
        has_role = required_role in user_roles

        # 3. Check connector permission from database
        connector_name = _AGENT_TO_CONNECTOR.get(agent_name, agent_name)
        connector_enabled = self._check_connector_enabled(
            user_id=user_id,
            user_roles=user_roles,
            connector_name=connector_name,
        )

        # 4. Evaluate policy for non-admin users:
        #    ALLOW = has_exact_agent_role AND connector_enabled
        allowed = has_role and connector_enabled

        # 5. Build reason string
        reason = self._build_reason(
            agent_name=agent_name,
            required_role=required_role,
            has_role=has_role,
            connector_name=connector_name,
            connector_enabled=connector_enabled,
            allowed=allowed,
        )

        logger.info(
            "Agent authorization evaluated",
            event="agent_authorization",
            agent_name=agent_name,
            user_id=user_id,
            connector_id=connector_name,
            required_role=required_role,
            has_required_role=has_role,
            connector_enabled=connector_enabled,
            outcome="ALLOW" if allowed else "DENIED",
        )

        return AuthorizationContext(
            allowed=allowed,
            agent_name=agent_name,
            user_id=user_id,
            required_role=required_role,
            has_required_role=has_role,
            connector_enabled=connector_enabled,
            reason=reason,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_required_role(agent_name: str) -> str | None:
        """
        Look up the Azure App Role required to execute the named agent.

        Uses the existing AGENT_ROLE_MAP defined in shared/enums.
        Returns None if the agent is not registered.
        """
        try:
            agent_enum = AgentName(agent_name)
        except ValueError:
            return None

        role: UserRole | None = AGENT_ROLE_MAP.get(agent_enum)
        return role.value if role is not None else None

    def _check_connector_enabled(
        self,
        *,
        user_id: str,
        user_roles: list[str],
        connector_name: str,
    ) -> bool:
        """
        Query the database for the user's connector permission.

        Reuses PermissionService.get_user_permissions() which loads the
        full PermissionContext including connector_permissions.

        Returns False if the connector is not in allowed_connectors
        (absent row = deny-all default).
        """
        try:
            permission_context: PermissionContext = (
                self._permission_service.get_user_permissions(
                    user_id=user_id,
                    token_roles=user_roles,
                )
            )
            return connector_name in permission_context.allowed_connectors
        except Exception as exc:
            # Fail closed: if we cannot verify, deny
            logger.error(
                "Connector permission check failed — defaulting to DENY",
                event="connector_health",
                connector_id=connector_name,
                user_id=user_id,
                outcome="DENIED",
                error=str(exc),
            )
            return False

    @staticmethod
    def _build_reason(
        *,
        agent_name: str,
        required_role: str,
        has_role: bool,
        connector_name: str,
        connector_enabled: bool,
        allowed: bool,
    ) -> str:
        """Build a human-readable reason string for audit logging."""
        if allowed:
            return (
                f"Authorized: user holds '{required_role}' and "
                f"connector '{connector_name}' is enabled"
            )

        parts: list[str] = []
        if not has_role:
            parts.append(
                f"missing required Azure role '{required_role}' "
                f"for agent '{agent_name}'"
            )
        if not connector_enabled:
            parts.append(
                f"connector '{connector_name}' is not enabled "
                f"for this user"
            )
        return "Denied: " + "; ".join(parts)
