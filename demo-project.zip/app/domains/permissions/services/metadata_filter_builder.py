"""
MetadataFilterBuilder — converts a PermissionContext into vector-store filters.

Responsibilities
----------------
* Accept a PermissionContext (user's roles, groups, allowed connectors).
* Produce a RetrievalFilters object that the vector-store search method
  can consume directly.
* Keep all permission-to-filter translation in one place so that adding a
  new ACL column or a new connector type never requires touching retrieval
  logic elsewhere.

ACL column mapping
------------------
The knowledge_chunks table stores access control in three columns:

    acl_user_ids  TEXT[]   — individual user IDs who may read this chunk
    acl_roles     TEXT[]   — role/group names that grant read access
    acl_public    BOOLEAN  — True means everyone may read this chunk

Groups (e.g. "engineering") and roles (e.g. "admin") are both stored as plain
strings in acl_roles at ingestion time.  The MetadataFilterBuilder therefore
merges user_roles and user_groups into a single list before passing it to the
SQL layer — no schema change is needed to support group-based ACL.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from app.domains.permissions.schemas.permission_context import PermissionContext

logger = logging.getLogger(__name__)
@dataclass(frozen=True)
class RetrievalFilters:
    """
    All parameters needed by the vector store to apply permission-aware ACL
    filtering during a hybrid search.

    Fields
    ------
    user_id
        The requesting user's ID.  Matched against acl_user_ids in the DB.
        A chunk is accessible if the user_id is in its acl_user_ids array.
    combined_roles_and_groups
        The union of the user's application roles and group memberships.
        Matched against acl_roles in the DB.  Roles (e.g. "admin") and groups
        (e.g. "engineering") are both stored as plain strings in acl_roles, so
        they are combined into this single list before reaching the SQL layer.
    allowed_connector_ids
        Connector IDs the user may query.  An empty list means no connectors
        are permitted and retrieval should return nothing.
    acl_groups
        The user_groups subset, exposed separately so callers can log or audit
        the group-derived access grants without re-parsing the combined list.
    """

    user_id:                   str
    combined_roles_and_groups: list[str] = field(default_factory=list)
    allowed_connector_ids:     list[str] = field(default_factory=list)
    acl_groups:                list[str] = field(default_factory=list)


class MetadataFilterBuilder:
    """
    Stateless converter: PermissionContext → RetrievalFilters.

    Stateless means it is safe to construct once and reuse across all requests
    without any locking or per-request state.
    """

    def build_filters(self, permission_context: PermissionContext) -> RetrievalFilters:
        """
        Convert a PermissionContext into the RetrievalFilters object passed to
        the vector store's hybrid_search() method.

        The vector store WHERE-clause checks:
            acl_public = TRUE
            OR %(user_id)s = ANY(acl_user_ids)
            OR acl_roles && %(roles)s::text[]

        Roles and groups are both stored in acl_roles as plain strings, so this
        method merges them before handing off to the SQL layer.

        Parameters
        ----------
        permission_context
            Resolved permission snapshot for the requesting user.

        Returns
        -------
        RetrievalFilters
            Ready to be passed directly to PgVectorStore.hybrid_search().

        Example output
        --------------
        RetrievalFilters(
            user_id="abc-123",
            combined_roles_and_groups=["admin", "engineering", "developers"],
            allowed_connector_ids=["confluence", "sharepoint"],
            acl_groups=["engineering", "developers"],
        )
        """
        combined_roles_and_groups = _merge_roles_and_groups_deduplicating(
            roles=permission_context.user_roles,
            groups=permission_context.user_groups,
        )

        retrieval_filters = RetrievalFilters(
            user_id=permission_context.user_id,
            combined_roles_and_groups=combined_roles_and_groups,
            allowed_connector_ids=list(permission_context.allowed_connectors),
            acl_groups=list(permission_context.user_groups),
        )

        logger.debug(
            "event=filters_built user=%s roles=%d groups=%d "
            "combined=%d connectors=%s",
            permission_context.user_id,
            len(permission_context.user_roles),
            len(permission_context.user_groups),
            len(combined_roles_and_groups),
            permission_context.allowed_connectors,
        )

        return retrieval_filters


# ---------------------------------------------------------------------------
# Module-level pure function
# ---------------------------------------------------------------------------

def _merge_roles_and_groups_deduplicating(
    roles:  list[str],
    groups: list[str],
) -> list[str]:
    """
    Merge role names and group names into a single deduplicated list.

    Roles are placed first because they are typically more specific grants
    (e.g. "admin" overrides group restrictions).  Groups follow in their
    original order, skipping any that already appeared in the roles list.

    Parameters
    ----------
    roles
        Application-level role names (e.g. ["admin", "agent.knowledge_rag"]).
    groups
        Group membership names (e.g. ["engineering", "developers"]).

    Returns
    -------
    list[str]
        Ordered, deduplicated list with roles first then groups.

    Examples
    --------
    >>> _merge_roles_and_groups_deduplicating(["admin"], ["admin", "engineering"])
    ['admin', 'engineering']
    """
    merged:      list[str] = list(roles)
    already_seen: set[str] = set(roles)

    for group_name in groups:
        if group_name not in already_seen:
            merged.append(group_name)
            already_seen.add(group_name)

    return merged
