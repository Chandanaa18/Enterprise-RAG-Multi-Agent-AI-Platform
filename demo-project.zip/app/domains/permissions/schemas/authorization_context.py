"""
AuthorizationContext — immutable result of an agent-execution authorization check.

Produced by AgentAuthorizationService and consumed by the Supervisor dispatch
node.  Contains the allow/deny decision along with the evidence that led to it,
enabling structured logging and audit without leaking implementation details
into the Supervisor.

This is a pure data class with no database access and no business logic.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class AuthorizationContext(BaseModel):
    """
    Result of evaluating whether a user may execute a specific agent.

    Fields
    ------
    allowed
        True if and only if the authorization policy passed.
    agent_name
        The agent that was evaluated (e.g. "knowledge_rag", "jira").
    user_id
        The UUID string of the requesting user.
    required_role
        The Azure App Role that was required for this agent
        (e.g. "agent.jira").  None if the agent has no mapping in
        AGENT_ROLE_MAP.
    has_required_role
        Whether the user's token roles contain the required_role.
    connector_enabled
        Whether the admin has enabled the connector associated with this
        agent in the connector_permissions table.
    reason
        Human-readable explanation of the decision, suitable for logging
        and error messages.
    """

    allowed:           bool       = Field(description="Final allow/deny decision")
    agent_name:        str        = Field(description="Agent that was evaluated")
    user_id:           str        = Field(description="UUID of the requesting user")
    required_role:     str | None = Field(default=None, description="Azure role required")
    has_required_role: bool       = Field(default=False, description="User holds required role")
    connector_enabled: bool       = Field(default=False, description="Admin enabled connector")
    reason:            str        = Field(default="", description="Human-readable decision reason")

    model_config = {"frozen": True}
