"""
PermissionContext — an immutable snapshot of a user's permissions at request time.

Built once per request in the resolve_permissions node and stored in agent state.
All downstream retrieval decisions are made against this object rather than
re-querying the database on every chunk.

Design note
-----------
Using a frozen Pydantic model (model_config frozen=True) makes it safe to pass
across LangGraph node boundaries without mutation risk.  The model is also JSON-
serialisable, so it can be stored in state without special handling.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class PermissionContext(BaseModel):
    """
    A complete, immutable view of a user's permissions for a single request.

    Fields
    ------
    user_id
        Stable UUID string identifying the requesting user.  Sourced from the
        Azure AD token sub claim or the local users table primary key.
    user_roles
        Application-level roles from the Azure AD token and the local users
        table (e.g. "agent.knowledge_rag", "admin").  Used to match against
        acl_roles in the knowledge_chunks table.
    user_groups
        Azure AD group memberships or database-stored groups that determine
        content-level ACL (e.g. "engineering", "developers").  Stored in
        users.metadata under the "groups" key.  Also matched against acl_roles
        in the knowledge_chunks table, since both roles and groups are stored
        there as plain strings during document ingestion.
    connector_permissions
        Raw permission map sourced from the connector_permissions DB table.
        Key = connector_name (e.g. "confluence"), value = enabled flag.
        Absent entry means the user has no explicit grant (deny-all default).
        V1: populated from user-subject rows only.
        V2: union of user-subject and group-subject rows, with user-explicit
            rows winning over group-level rows.
    allowed_connectors
        Derived flat list of connector names where enabled=True.
        This is the field consumed by MetadataFilterBuilder and the SQL
        retrieval layer — callers never need to inspect connector_permissions
        directly for access decisions.
    """

    user_id: str = Field(
        description="Stable UUID string identifying the requesting user",
    )
    user_roles: list[str] = Field(
        default_factory=list,
        description="Application-level roles from Azure AD token and users table",
    )
    user_groups: list[str] = Field(
        default_factory=list,
        description="Group memberships that determine content-level ACL",
    )
    connector_permissions: dict[str, bool] = Field(
        default_factory=dict,
        description=(
            "Map of connector_name → enabled flag, sourced from the "
            "connector_permissions table.  User-explicit rows override "
            "group-level rows.  Absent = denied."
        ),
    )
    allowed_connectors: list[str] = Field(
        default_factory=list,
        description=(
            "Derived list of connector names the user may query (enabled=True). "
            "Consumed by MetadataFilterBuilder and the SQL retrieval layer."
        ),
    )

    model_config = {"frozen": True}
