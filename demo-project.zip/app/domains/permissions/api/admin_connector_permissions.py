"""
Admin API — connector permission management.

Grants and revokes per-user and per-group access to connectors.
All writes are idempotent upserts; all reads are non-destructive.

Route layout
------------
POST   /admin/users/{user_id}/connectors/{connector}/grant
POST   /admin/users/{user_id}/connectors/{connector}/revoke
PATCH  /admin/users/{user_id}/connectors/{connector}/projects
GET    /admin/users/{user_id}/connectors
GET    /admin/users/{user_id}/connectors/{connector}

POST   /admin/groups/{group_name}/connectors/{connector}/grant   (V2)
POST   /admin/groups/{group_name}/connectors/{connector}/revoke  (V2)
GET    /admin/groups/{group_name}/connectors                     (V2)

Access control
--------------
Every route requires the 'admin' role.  require_role() already has a
built-in admin bypass, so users holding 'admin' pass all role checks.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, HTTPException, Path, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.bootstrap.auth_deps import require_role
from app.shared.enums import ConnectorType, UserRole
from app.infrastructure.database.database import get_db
from app.domains.users.models.user_model import User
from app.domains.users.repositories.user_repository import UserRepository
from app.domains.permissions.repositories.connector_permission_repository import ConnectorPermissionRepository
from app.domains.permissions.services.connector_permission_service import ConnectorPermissionService

admin_connector_permissions_router = APIRouter(
    prefix="/admin",
    tags=["Admin — Connector Permissions"],
)

_require_admin = require_role(UserRole.ADMIN)

# ---------------------------------------------------------------------------
# Request schemas  — defined FIRST so they can be used in route signatures
# ---------------------------------------------------------------------------

class GrantConnectorRequest(BaseModel):
    """Optional body for grant endpoint. Carries Jira project-level permissions."""
    allowed_projects: list[str] = Field(
        default_factory=list,
        description="Jira project keys this user can access e.g. ['ABC', 'DEVOPS']",
    )


class UpdateProjectsRequest(BaseModel):
    """Body for the PATCH /projects endpoint."""
    allowed_projects: list[str] = Field(
        ...,
        description="Updated list of Jira project keys e.g. ['ABC', 'DEVOPS', 'INFRA']",
    )


# ---------------------------------------------------------------------------
# Response schema
# ---------------------------------------------------------------------------

class ConnectorPermissionResponse(BaseModel):
    """API representation of a single connector_permissions row."""

    permission_id:    uuid.UUID
    subject_type:     str
    subject_id:       str
    connector_name:   str
    enabled:          bool
    granted_by:       Optional[uuid.UUID]
    allowed_projects: list[str] = []
    created_at:       datetime
    updated_at:       datetime

    model_config = {"from_attributes": True}


def _build_response(row) -> ConnectorPermissionResponse:
    """
    Build a ConnectorPermissionResponse from an ORM row.
    Pulls allowed_projects out of the metadata_ column.
    """
    resp = ConnectorPermissionResponse.model_validate(row)
    if hasattr(row, "metadata_") and row.metadata_:
        resp.allowed_projects = row.metadata_.get("allowed_projects", [])
    return resp


# ---------------------------------------------------------------------------
# Dependency: ConnectorPermissionService
# ---------------------------------------------------------------------------

def _get_permission_service(
    db: AsyncSession = Depends(get_db),
) -> ConnectorPermissionService:
    return ConnectorPermissionService(ConnectorPermissionRepository(db))


_ServiceDep = Annotated[ConnectorPermissionService, Depends(_get_permission_service)]
_AdminDep   = Annotated[User, Depends(_require_admin)]


# ---------------------------------------------------------------------------
# User listing — used by the Access Control UI search dropdown
# ---------------------------------------------------------------------------

class UserResponse(BaseModel):
    id: uuid.UUID
    display_name: Optional[str]
    email: Optional[str]

    model_config = {"from_attributes": True}


@admin_connector_permissions_router.get(
    "/users",
    response_model=list[UserResponse],
    status_code=status.HTTP_200_OK,
    summary="List all users (admin only)",
)
async def list_users(
    _admin: _AdminDep,
    db: AsyncSession = Depends(get_db),
) -> list[UserResponse]:
    rows = await UserRepository(db).list_all()
    return [UserResponse(id=u.user_id, display_name=u.display_name, email=u.email) for u in rows]

# ---------------------------------------------------------------------------
# Helper — validate connector name early so callers get a 422 not a 500
# ---------------------------------------------------------------------------

_KNOWN_CONNECTORS = frozenset(c.value for c in ConnectorType)


def _validated_connector(
    connector: str = Path(..., description="Connector name, e.g. 'confluence' or 'jira'"),
) -> str:
    if connector not in _KNOWN_CONNECTORS:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unknown connector {connector!r}. Known: {sorted(_KNOWN_CONNECTORS)}",
        )
    return connector


_ConnectorDep = Annotated[str, Depends(_validated_connector)]


# ---------------------------------------------------------------------------
# User-level routes  (V1)
# ---------------------------------------------------------------------------

@admin_connector_permissions_router.post(
    "/users/{user_id}/connectors/{connector}/grant",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Grant a user access to a connector",
)
async def grant_user_connector(
    user_id:   uuid.UUID,
    connector: _ConnectorDep,
    admin:     _AdminDep,
    svc:       _ServiceDep,
    db:        AsyncSession = Depends(get_db),
    body:      GrantConnectorRequest = GrantConnectorRequest(),
) -> ConnectorPermissionResponse:
    """
    Grant *user_id* access to *connector*. Idempotent — safe to call multiple times.

    For Jira, optionally pass `allowed_projects` to restrict which projects
    this user can interact with via the Jira agent.

    Example body (Jira with project restrictions):
        { "allowed_projects": ["ABC", "DEVOPS"] }

    Example body (Confluence or any connector with no project restrictions):
        {}
    """
    row = await svc.grant_to_user(
        user_id=user_id,
        connector_name=connector,
        granted_by=admin.user_id,
        metadata={
            "allowed_projects": [p.upper() for p in body.allowed_projects]
        } if body.allowed_projects else {},
    )

    # Immediately resolve connector identity + backfill acl_user_ids so the
    # user gets access to permitted chunks without waiting for next login.
    try:
        user = await UserRepository(db).get_by_id(user_id)
        if user and user.email:
            from app.ingestion.tasks import resolve_user_identities
            resolve_user_identities.delay(str(user_id), user.email)
    except Exception:
        pass  # non-fatal — user gets access on next login anyway

    return _build_response(row)


@admin_connector_permissions_router.post(
    "/users/{user_id}/connectors/{connector}/revoke",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Revoke a user's access to a connector",
)
async def revoke_user_connector(
    user_id:   uuid.UUID,
    connector: _ConnectorDep,
    admin:     _AdminDep,
    svc:       _ServiceDep,
    db:        AsyncSession = Depends(get_db),
) -> ConnectorPermissionResponse:
    """
    Explicitly deny *user_id* access to *connector*. Sets `enabled=False`.

    A soft revoke — the row is retained for audit purposes.
    """
    row = await svc.revoke_from_user(
        user_id=user_id,
        connector_name=connector,
        granted_by=admin.user_id,
    )

    # Remove user from acl_user_ids on all chunks for this connector immediately
    # so access is revoked without waiting for the next sync cycle.
    try:
        from app.core.config import settings
        import asyncpg
        conn = await asyncpg.connect(
            host=settings.db.host, port=settings.db.port,
            user=settings.db.username, password=settings.db.password,
            database=settings.db.database,
        )
        await conn.execute("""
            UPDATE enterprise_rag_system.knowledge_chunks
            SET acl_user_ids = array_remove(acl_user_ids, $1)
            WHERE connector_id = $2
              AND $1 = ANY(acl_user_ids)
        """, str(user_id), connector)
        await conn.close()
    except Exception:
        pass  # non-fatal — next sync will clean up

    return _build_response(row)


@admin_connector_permissions_router.patch(
    "/users/{user_id}/connectors/{connector}/projects",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Update allowed Jira projects for a user",
)
async def update_user_connector_projects(
    user_id:   uuid.UUID,
    connector: _ConnectorDep,
    admin:     _AdminDep,
    svc:       _ServiceDep,
    body:      UpdateProjectsRequest,
) -> ConnectorPermissionResponse:
    """
    Update which Jira projects a user can access without changing their
    overall connector enabled/disabled status.

    Requires the user to already have a grant row — call /grant first.

    Example:
        PATCH /admin/users/{user_id}/connectors/jira/projects
        { "allowed_projects": ["ABC", "DEVOPS", "INFRA"] }
    """
    # Reuse grant_to_user — it's an upsert so it only updates metadata
    # without touching enabled status if the row already exists
    row = await svc.grant_to_user(
        user_id=user_id,
        connector_name=connector,
        granted_by=admin.user_id,
        metadata={
            "allowed_projects": [p.upper() for p in body.allowed_projects]
        },
    )
    return _build_response(row)


@admin_connector_permissions_router.get(
    "/users/{user_id}/connectors",
    response_model=list[ConnectorPermissionResponse],
    status_code=status.HTTP_200_OK,
    summary="List all connector permissions for a user",
)
async def list_user_connectors(
    user_id: uuid.UUID,
    _admin:  _AdminDep,
    svc:     _ServiceDep,
) -> list[ConnectorPermissionResponse]:
    """
    Return all connector permission rows for *user_id*.

    An empty list means the user has no explicit grants — they are denied
    access to all connectors (deny-all default).
    """
    rows = await svc.get_user_permissions(user_id)
    return [_build_response(r) for r in rows]


@admin_connector_permissions_router.get(
    "/users/{user_id}/connectors/{connector}",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Get a user's permission for a specific connector",
)
async def get_user_connector(
    user_id:   uuid.UUID,
    connector: _ConnectorDep,
    _admin:    _AdminDep,
    svc:       _ServiceDep,
) -> ConnectorPermissionResponse:
    """
    Return the single permission row for (*user_id*, *connector*).

    Raises 404 if no row exists.
    """
    rows = await svc.get_user_permissions(user_id)
    match = next((r for r in rows if r.connector_name == connector), None)

    if match is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No permission row for user {user_id} / connector {connector!r}.",
        )
    return _build_response(match)


# ---------------------------------------------------------------------------
# Group-level routes  (V2 — same service, group subject_type)
# ---------------------------------------------------------------------------

@admin_connector_permissions_router.post(
    "/groups/{group_name}/connectors/{connector}/grant",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Grant all members of a group access to a connector (V2)",
)
async def grant_group_connector(
    group_name: str = Path(..., description="Azure AD or local group name"),
    connector:  str = Depends(_validated_connector),
    admin:      User = Depends(_require_admin),
    svc:        ConnectorPermissionService = Depends(_get_permission_service),
    body:       GrantConnectorRequest = GrantConnectorRequest(),
) -> ConnectorPermissionResponse:
    """
    Grant every member of *group_name* access to *connector*.

    At resolution time, PermissionService unions group-level rows with
    user-level rows (user-explicit rows win on conflict).
    """
    row = await svc.grant_to_group(
        group_name=group_name,
        connector_name=connector,
        granted_by=admin.user_id,
        metadata={
            "allowed_projects": [p.upper() for p in body.allowed_projects]
        } if body.allowed_projects else {},
    )
    return _build_response(row)


@admin_connector_permissions_router.post(
    "/groups/{group_name}/connectors/{connector}/revoke",
    response_model=ConnectorPermissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Revoke a group's access to a connector (V2)",
)
async def revoke_group_connector(
    group_name: str = Path(..., description="Azure AD or local group name"),
    connector:  str = Depends(_validated_connector),
    admin:      User = Depends(_require_admin),
    svc:        ConnectorPermissionService = Depends(_get_permission_service),
) -> ConnectorPermissionResponse:
    """Explicitly deny all members of *group_name* access to *connector*."""
    row = await svc.revoke_from_group(
        group_name=group_name,
        connector_name=connector,
        granted_by=admin.user_id,
    )
    return _build_response(row)


@admin_connector_permissions_router.get(
    "/groups/{group_name}/connectors",
    response_model=list[ConnectorPermissionResponse],
    status_code=status.HTTP_200_OK,
    summary="List all connector permissions for a group (V2)",
)
async def list_group_connectors(
    group_name: str = Path(..., description="Azure AD or local group name"),
    _admin:     User = Depends(_require_admin),
    svc:        ConnectorPermissionService = Depends(_get_permission_service),
) -> list[ConnectorPermissionResponse]:
    """Return all connector permission rows for *group_name*."""
    rows = await svc.get_group_permissions(group_name)
    return [_build_response(r) for r in rows]