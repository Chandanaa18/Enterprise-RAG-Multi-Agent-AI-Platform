"""
AuditService — writes tamper-evident audit records to the audit_logs table.

Two usage patterns:

1. In-request (awaited):
       service = AuditService(db)
       await service.log_action(user_id=..., session_id=..., action=...)

2. Fire-and-forget (exception handlers / middleware where there is no injected db):
       AuditService.fire_and_forget(user_id=..., session_id=..., action=...)
       # Non-blocking; creates its own DB session via AsyncSessionLocal.
"""

import asyncio
import uuid
from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.shared.enums import AuditOutcome
from app.infrastructure.database.database import AsyncSessionLocal
from app.domains.chat.models.audit_log_model import AuditLog
from app.domains.chat.repositories.audit_log_repository import AuditLogRepository
from app.shared.exceptions.error_enums import LogEvent
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class AuditService:

    def __init__(self, db: AsyncSession) -> None:
        self.repo = AuditLogRepository(db)

    # ── In-request write ─────────────────────────────────────────────────────

    async def log_action(
        self,
        user_id: uuid.UUID | str,
        session_id: uuid.UUID | str,
        action: str,
        *,
        agent_name: Optional[str] = None,
        target_system: Optional[str] = None,
        target_resource: Optional[str] = None,
        outcome: AuditOutcome = AuditOutcome.SUCCESS,
        metadata: Optional[dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ) -> AuditLog:
        if isinstance(user_id, str):
            user_id = uuid.UUID(user_id)
        if isinstance(session_id, str):
            session_id = uuid.UUID(session_id)

        extra: dict[str, Any] = metadata or {}
        if trace_id:
            extra["trace_id"] = trace_id

        entry = AuditLog(
            user_id=user_id,
            session_id=session_id,
            agent_name=agent_name,
            action=action,
            target_system=target_system,
            target_resource=target_resource,
            outcome=outcome.value if isinstance(outcome, AuditOutcome) else outcome,
            metadata_=extra or None,
        )

        saved = await self.repo.create(entry)

        logger.info(
            "Audit record written",
            event=LogEvent.AUDIT_LOG.value,
            log_id=str(saved.log_id),
            user_id=str(user_id),
            session_id=str(session_id),
            action=action,
            outcome=outcome,
            target_system=target_system,
            target_resource=target_resource,
            trace_id=trace_id,
        )

        return saved

    # ── Fire-and-forget (exception handlers / middleware) ────────────────────

    @staticmethod
    def fire_and_forget(
        user_id: uuid.UUID | str,
        session_id: uuid.UUID | str,
        action: str,
        *,
        agent_name: Optional[str] = None,
        target_system: Optional[str] = None,
        target_resource: Optional[str] = None,
        outcome: AuditOutcome = AuditOutcome.SUCCESS,
        metadata: Optional[dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ) -> None:
        async def _write() -> None:
            try:
                async with AsyncSessionLocal() as db:
                    await AuditService(db).log_action(
                        user_id=user_id,
                        session_id=session_id,
                        action=action,
                        agent_name=agent_name,
                        target_system=target_system,
                        target_resource=target_resource,
                        outcome=outcome,
                        metadata=metadata,
                        trace_id=trace_id,
                    )
            except Exception as exc:
                logger.error(
                    "fire_and_forget audit write failed",
                    event=LogEvent.AUDIT_LOG.value,
                    action=action,
                    outcome=outcome,
                    exc_info=exc,
                )

        try:
            asyncio.create_task(_write())
        except RuntimeError:
            logger.warn(
                "Audit write skipped — no running event loop",
                event=LogEvent.AUDIT_LOG.value,
                action=action,
                user_id=str(user_id),
            )
