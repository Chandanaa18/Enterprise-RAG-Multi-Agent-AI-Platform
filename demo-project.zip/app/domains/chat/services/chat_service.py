"""
ChatService — orchestrates an incoming chat message through the agent pipeline.

Responsibilities:
  - Inject DB session into agent state
  - Build the response payload
  - Write the top-level audit record for the interaction
"""
from __future__ import annotations
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.sessions.models.session_model import Session
from app.domains.users.models.user_model import User
from app.agents.knowledge_rag.agent import KnowledgeRAGAgent
from app.agents.knowledge_rag.state import ChatMessage
from app.shared.exceptions.base_exception import AppBaseException, AgentExecutionError
from app.shared.exceptions.error_enums import LogEvent
from app.shared.enums import AuditOutcome
from app.domains.chat.services.audit_service import AuditService
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class ChatService:
    def __init__(self, db: AsyncSession, knowledge_rag_agent: KnowledgeRAGAgent, session_store=None):
        self.agent         = knowledge_rag_agent
        self._db           = db
        self.audit_service = AuditService(db)
        self.session_store = session_store

    async def process_chat(
        self,
        message: str,
        session: Session,
        user: User,
        trace_id: Optional[str] = None,
    ) -> dict:
        result = None  # initialise so except block can safely reference it
        try:
            user_roles = list(user.roles) if user.roles else ["employee"]

            from app.agents.supervisor.supervisor_agent import _check_jira_permission_async
            jira_permission = await _check_jira_permission_async(
                user_roles=user_roles,
                db=self._db,
                user_id=str(user.user_id),
            )

            result = self.agent.handle(
                question=message,
                session_id=str(session.session_id),
                user_id=str(user.user_id),
                user_roles=user_roles,
                db=self._db,
                jira_permission=jira_permission,
            )

            if self.session_store:
                self.session_store.append_turn(
                    str(session.session_id),
                    ChatMessage(role="user", content=message),
                )
                self.session_store.append_turn(
                    str(session.session_id),
                    ChatMessage(role="assistant", content=result.text, mlflow_run_id=result.mlflow_run_id),
                )
                self.session_store.touch(str(session.session_id))

            trace_id = getattr(result, "mlflow_trace_id", None) or trace_id or ""

            citations_payload = [
                {
                    "doc_id":     getattr(c, "doc_id", ""),
                    "title":      getattr(c, "title", ""),
                    "source_uri": getattr(c, "source_uri", "") or getattr(c, "source_url", ""),
                    "page_no":    getattr(c, "page_no", None),
                    "score":      getattr(c, "score", 0.0),
                    "snippet":    getattr(c, "snippet", ""),
                }
                for c in result.citations
            ]

            # Use actual agent name from result — not hardcoded knowledge_rag
            agent_name = result.agent

            await self.audit_service.log_action(
                user_id=user.user_id,
                session_id=session.session_id,
                action=f"{agent_name.lower()}.query",
                agent_name=agent_name,
                target_system=agent_name.lower(),
                target_resource=message[:200],
                outcome=AuditOutcome.SUCCESS if result.can_answer else AuditOutcome.UNKNOWN,
                metadata={
                    "citation_count": len(result.citations),
                    "can_answer": result.can_answer,
                },
                trace_id=trace_id,
            )

            return {
                "response":      result.text,
                "session_id":    str(session.session_id),
                "can_answer":    result.can_answer,
                "agent":         agent_name,   # shows correct agent in UI badge
                "citations":     citations_payload,
                "mlflow_run_id": result.mlflow_run_id,
            }

        except AppBaseException:
            raise
        except Exception as e:
            logger.error(
                f"Chat processing failed for session: {session.session_id}",
                event=LogEvent.AGENT_FAILED.value,
                exc_info=e,
                session_id=str(session.session_id),
                user_id=str(user.user_id),
                trace_id=trace_id or "",
            )

            # result may be None if agent crashed before returning
            failed_agent = result.agent if result else "unknown"

            AuditService.fire_and_forget(
                user_id=user.user_id,
                session_id=session.session_id,
                action=f"{failed_agent.lower()}.query",
                agent_name=failed_agent,
                target_system=failed_agent.lower(),
                target_resource=message[:200],
                outcome=AuditOutcome.ERROR,
                metadata={"error": str(e)},
                trace_id=trace_id or "",
            )

            raise AgentExecutionError(
                agent_name=failed_agent,
                message=f"Chat processing failed: {str(e)}",
                details=str(e),
            )