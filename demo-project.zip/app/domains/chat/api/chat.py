from typing import Annotated
from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.database.database import get_db
from app.domains.chat.schemas.chat import ChatRequest, ChatResponse
from app.domains.sessions.api.session_deps import get_current_session
from app.bootstrap.auth_deps import require_role
from app.shared.enums import AGENT_ROLE_MAP
from app.domains.chat.services.chat_service import ChatService
from app.domains.sessions.models.session_model import Session
from app.domains.users.models.user_model import User
from app.shared.utils.logger.logger import Logger

chat_router = APIRouter(prefix="/api/v1/chat", tags=["Chat"])

SessionDep = Annotated[AsyncSession, Depends(get_db)]

_chat_access = require_role(*AGENT_ROLE_MAP.values())

logger = Logger(__file__)


@chat_router.post("", response_model=ChatResponse)
async def chat(
    body: ChatRequest,
    request: Request,
    db: SessionDep,
    session: Session = Depends(get_current_session),
    user: User = Depends(_chat_access),
):
    logger.info(
        "Chat request received",
        event="request_received",
        session_id=str(session.session_id),
        user_id=str(user.user_id),
    )

    agent = (
        getattr(request.app.state, "supervisor_agent", None)
        or request.app.state.knowledge_rag_agent
    )
    session_store = request.app.state.session_store
    service = ChatService(db, knowledge_rag_agent=agent, session_store=session_store)
    result = await service.process_chat(
        message=body.message,
        session=session,
        user=user,
        trace_id=getattr(request.state, "trace_id", None),
    )
    return ChatResponse(**result)
