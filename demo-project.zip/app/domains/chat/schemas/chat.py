from typing import Optional
from pydantic import BaseModel
from uuid import UUID


class ChatRequest(BaseModel):
    message: str


class CitationOut(BaseModel):
    doc_id:     Optional[str]   = None
    title:      Optional[str]   = None
    source_uri: Optional[str]   = None
    page_no:    Optional[int]   = None
    score:      Optional[float] = None
    snippet:    Optional[str]   = None
    # Legacy fields (backwards compat)
    source:     Optional[str]   = None
    url:        Optional[str]   = None


class ChatResponse(BaseModel):
    session_id:    UUID
    response:      str
    can_answer:    bool = False
    agent:         str = ""
    citations:     list[CitationOut] = []
    mlflow_run_id: Optional[str] = None
