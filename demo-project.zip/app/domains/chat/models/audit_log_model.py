import uuid
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column

from app.infrastructure.database.database import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = {'schema': 'audit'}

    log_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("enterprise_rag_system.users.user_id"), index=True)
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("enterprise_rag_system.sessions.session_id"), index=True)
    agent_name: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    action: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    target_system: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    target_resource: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    outcome: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    metadata_: Mapped[Optional[dict]] = mapped_column("metadata", JSONB, default=dict, nullable=True)

    user = relationship("User", back_populates="audit_logs")
    session = relationship("Session", back_populates="audit_logs")
