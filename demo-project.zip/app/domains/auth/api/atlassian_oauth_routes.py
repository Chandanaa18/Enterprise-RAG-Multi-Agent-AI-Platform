"""
Atlassian OAuth 2.0 (3LO) routes.

Two endpoints drive the OAuth flow:

  GET /auth/atlassian/connect   (requires Azure AD Bearer token)
      Redirects the authenticated user to Atlassian's consent page.
      Stores a CSRF state token in Redis with 10-minute TTL.

  GET /auth/atlassian/callback  (public — called by Atlassian)
      Receives the authorization code, exchanges for tokens,
      fetches the user's Atlassian accountId and email,
      encrypts both tokens, stores in user_connector_credentials.

Flow:
  User (logged in via Azure AD) clicks "Connect Atlassian"
        ↓
  GET /auth/atlassian/connect
        ↓
  State token → Redis (TTL 10 min, CSRF protection)
        ↓
  302 → Atlassian consent page
        ↓
  User approves
        ↓
  Atlassian → GET /auth/atlassian/callback?code=...&state=...
        ↓
  Verify state from Redis → fetch user_id
        ↓
  Exchange code → access_token + refresh_token
        ↓
  GET https://api.atlassian.com/me → accountId + email
        ↓
  Encrypt tokens → upsert user_connector_credentials
        ↓
  302 → frontend /settings/connections?jira=connected
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

import httpx
import redis.asyncio as aioredis
from fastapi import APIRouter, Depends, Query, status
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.bootstrap.auth_deps import get_current_user
from app.core.config import settings
from app.core.constants import (
    ATLASSIAN_AUTH_URL,
    ATLASSIAN_TOKEN_URL,
    ATLASSIAN_IDENTITY_URL,
    ATLASSIAN_OAUTH_SCOPES,
)
from app.domains.permissions.repositories.user_connector_credentials_repository import (
    UserConnectorCredentialsRepository,
)
from app.infrastructure.database.database import get_db
from app.shared.enums import AuthPath
from app.shared.utils.crypto import TokenEncryption
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

atlassian_oauth_router = APIRouter(tags=["Atlassian OAuth"])

# Redis key prefix and TTL for CSRF state tokens
_STATE_KEY_PREFIX = "atlassian_oauth_state:"
_STATE_TTL_SECONDS = 600  # 10 minutes


# ---------------------------------------------------------------------------
# Redis client — lazy singleton, reuses settings.redis.url
# ---------------------------------------------------------------------------

def _get_redis() -> aioredis.Redis:
    return aioredis.from_url(
        settings.redis.url,
        encoding="utf-8",
        decode_responses=True,
    )


# ---------------------------------------------------------------------------
# Step 1a — Return the Atlassian authorization URL (frontend fetches this)
# ---------------------------------------------------------------------------

@atlassian_oauth_router.get(
    "/auth/atlassian/connect-url",
    summary="Get Atlassian OAuth authorization URL",
    description=(
        "Returns the Atlassian consent page URL for the frontend to redirect to.\n\n"
        "The frontend calls this with the Bearer token, gets back the URL, "
        "then sets window.location.href to it.\n\n"
        "A CSRF state token is stored in Redis with a 10-minute TTL."
    ),
)
async def atlassian_connect_url(
    current_user=Depends(get_current_user),
) -> dict:
    """
    Returns { "url": "https://auth.atlassian.com/authorize?..." }
    Frontend redirects the browser to this URL.
    """
    state   = secrets.token_urlsafe(32)
    user_id = str(current_user.user_id)

    redis = _get_redis()
    try:
        await redis.setex(
            f"{_STATE_KEY_PREFIX}{state}",
            _STATE_TTL_SECONDS,
            user_id,
        )
    finally:
        await redis.aclose()

    params = {
        "audience":      "api.atlassian.com",
        "client_id":     settings.atlassian.client_id,
        "scope":         ATLASSIAN_OAUTH_SCOPES,
        "redirect_uri":  settings.atlassian.redirect_uri,
        "state":         state,
        "response_type": "code",
        "prompt":        "login",
    }

    auth_url = f"{ATLASSIAN_AUTH_URL}?{urlencode(params)}"
    logger.info("atlassian_connect_url: built for user=%s", user_id)
    return {"url": auth_url}


# ---------------------------------------------------------------------------
# Step 1b — Direct redirect (kept for backwards compatibility)
# ---------------------------------------------------------------------------

@atlassian_oauth_router.get(
    AuthPath.ATLASSIAN_CONNECT.value,
    summary="Initiate Atlassian OAuth 2.0 connection",
    description=(
        "Redirects the authenticated user to Atlassian's OAuth consent page.\n\n"
        "Requires a valid Azure AD Bearer token — user must be logged in first.\n\n"
        "A CSRF state token is stored in Redis with a 10-minute TTL."
    ),
    response_class=RedirectResponse,
    status_code=status.HTTP_302_FOUND,
)
async def atlassian_connect(
    current_user=Depends(get_current_user),
) -> RedirectResponse:
    """
    Build the Atlassian authorization URL and redirect the browser to it.
    State token stored in Redis maps state → user_id for CSRF protection.
    """
    state   = secrets.token_urlsafe(32)
    user_id = str(current_user.user_id)

    redis = _get_redis()
    try:
        await redis.setex(
            f"{_STATE_KEY_PREFIX}{state}",
            _STATE_TTL_SECONDS,
            user_id,
        )
    finally:
        await redis.aclose()

    params = {
        "audience":      "api.atlassian.com",
        "client_id":     settings.atlassian.client_id,
        "scope":         ATLASSIAN_OAUTH_SCOPES,
        "redirect_uri":  settings.atlassian.redirect_uri,
        "state":         state,
        "response_type": "code",
        "prompt":        "login",
    }

    auth_url = f"{ATLASSIAN_AUTH_URL}?{urlencode(params)}"
    logger.info("atlassian_connect: redirecting to consent page", user_id=user_id)
    return RedirectResponse(url=auth_url, status_code=status.HTTP_302_FOUND)


# ---------------------------------------------------------------------------
# Step 2 — Atlassian callback: exchange code → store tokens
# ---------------------------------------------------------------------------

@atlassian_oauth_router.get(
    AuthPath.ATLASSIAN_CALLBACK.value,
    summary="Atlassian OAuth 2.0 callback",
    description=(
        "Public endpoint — Atlassian redirects here after the user approves.\n\n"
        "Exchanges the authorization code for tokens, fetches the user's "
        "Atlassian identity, encrypts tokens, and stores them in "
        "user_connector_credentials."
    ),
    status_code=status.HTTP_302_FOUND,
    include_in_schema=True,
)
async def atlassian_callback(
    code:              str      = Query(...,        description="Authorization code from Atlassian"),
    state:             str      = Query(...,        description="CSRF state token"),
    error:             str|None = Query(default=None, description="Error code from Atlassian"),
    error_description: str|None = Query(default=None, description="Human-readable error from Atlassian"),
    db: AsyncSession = Depends(get_db),
) -> RedirectResponse:
    """
    OAuth2 callback handler for Atlassian.

    Steps:
    1. Handle Atlassian-side errors (user denied consent etc.)
    2. Verify CSRF state from Redis
    3. Exchange authorization code for access + refresh tokens
    4. Fetch Atlassian identity (accountId, email)
    5. Encrypt tokens and upsert into user_connector_credentials
    6. Redirect browser to frontend connections page
    """
    frontend_url    = settings.app.frontend_url.rstrip("/")
    connections_url = f"{frontend_url}/chat"

    def _redirect_error(reason: str) -> RedirectResponse:
        logger.warn("atlassian_callback: redirecting with error", reason=reason)
        return RedirectResponse(
            url=f"{connections_url}?jira=error&reason={reason}",
            status_code=status.HTTP_302_FOUND,
        )

    # ------------------------------------------------------------------
    # 1. Handle Atlassian-side errors
    # ------------------------------------------------------------------
    if error:
        logger.warn(
            "atlassian_callback: Atlassian returned error",
            error=error,
            description=error_description,
        )
        return _redirect_error(error)

    # ------------------------------------------------------------------
    # 2. Verify CSRF state from Redis
    # ------------------------------------------------------------------
    redis = _get_redis()
    try:
        redis_key = f"{_STATE_KEY_PREFIX}{state}"
        user_id   = await redis.get(redis_key)
        if user_id:
            await redis.delete(redis_key)  # one-time use
    finally:
        await redis.aclose()

    if not user_id:
        logger.warn("atlassian_callback: invalid or expired state token", state=state[:8])
        return _redirect_error("invalid_state")

    # ------------------------------------------------------------------
    # 3. Exchange code for tokens
    # ------------------------------------------------------------------
    try:
        token_data = await _exchange_code_for_tokens(code)
    except Exception as exc:
        logger.error(
            "atlassian_callback: token exchange failed",
            user_id=user_id,
            exc_info=exc,
        )
        return _redirect_error("token_exchange_failed")

    access_token  = token_data.get("access_token", "")
    refresh_token = token_data.get("refresh_token", "")
    expires_in    = int(token_data.get("expires_in", 3600))
    scope         = token_data.get("scope", "")
    expires_at    = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

    # ------------------------------------------------------------------
    # 4. Fetch Atlassian identity
    # ------------------------------------------------------------------
    try:
        identity = await _fetch_atlassian_identity(access_token)
    except Exception as exc:
        logger.error(
            "atlassian_callback: identity fetch failed",
            user_id=user_id,
            exc_info=exc,
        )
        return _redirect_error("identity_fetch_failed")

    account_id     = identity.get("account_id", "")
    external_email = identity.get("email", "")

    # ------------------------------------------------------------------
    # 5. Encrypt and store tokens
    # ------------------------------------------------------------------
    try:
        enc               = TokenEncryption()
        access_token_enc  = enc.encrypt(access_token)
        refresh_token_enc = enc.encrypt(refresh_token) if refresh_token else None

        repo = UserConnectorCredentialsRepository(db)
        await repo.upsert(
            user_id=user_id,
            connector_name="jira",
            external_id=account_id,
            external_email=external_email,
            access_token_enc=access_token_enc,
            refresh_token_enc=refresh_token_enc,
            expires_at=expires_at,
            token_scope=scope,
            status="active",
        )
    except Exception as exc:
        logger.error(
            "atlassian_callback: failed to store credentials",
            user_id=user_id,
            exc_info=exc,
        )
        return _redirect_error("storage_failed")

    logger.info(
        "atlassian_callback: Jira connected successfully",
        user_id=user_id,
        account_id=account_id,
        external_email=external_email,
    )

    # ------------------------------------------------------------------
    # 6. Pre-warm the user's mcp-atlassian process in the background
    #    so their first Jira query is instant (no 4-second startup wait).
    # ------------------------------------------------------------------
    try:
        from app.main import app as _app
        _pool = getattr(_app.state, "mcp_pool", None)
        if _pool is not None:
            await _pool.prewarm(user_id, access_token)
    except Exception as _exc:
        logger.warn("atlassian_callback: pool prewarm failed (non-fatal)", exc_info=_exc)

    # ------------------------------------------------------------------
    # 7. Redirect to frontend
    # ------------------------------------------------------------------
    return RedirectResponse(
        url=f"{connections_url}?jira=connected",
        status_code=status.HTTP_302_FOUND,
    )


# ---------------------------------------------------------------------------
# Step 3 — Status endpoint
# ---------------------------------------------------------------------------

@atlassian_oauth_router.get(
    "/auth/atlassian/status",
    summary="Get the current user's Atlassian connection status",
)
async def atlassian_status(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Returns whether the current user has connected their Atlassian account,
    along with the external email and account ID stored at OAuth time.
    """
    repo  = UserConnectorCredentialsRepository(db)
    creds = await repo.get(str(current_user.user_id), "jira")

    if (
        creds is None
        or creds.status == "revoked"
        or not creds.refresh_token_enc  # incomplete OAuth — no usable session
    ):
        return {"connected": False, "atlassian_email": None, "atlassian_account_id": None}

    return {
        "connected":             True,
        "atlassian_email":       creds.external_email,
        "atlassian_account_id":  creds.external_id,
    }


@atlassian_oauth_router.delete(
    "/auth/atlassian/disconnect",
    summary="Revoke the current user's Atlassian connection",
)
async def atlassian_disconnect(
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Marks the user's Atlassian credential row as revoked and kills their mcp process."""
    user_id = str(current_user.user_id)
    repo = UserConnectorCredentialsRepository(db)
    await repo.revoke(user_id=user_id, connector_name="jira")

    try:
        from app.main import app as _app
        _pool = getattr(_app.state, "mcp_pool", None)
        if _pool is not None:
            _pool.shutdown_user(user_id)
    except Exception as _exc:
        logger.warn("atlassian_disconnect: pool shutdown failed (non-fatal)", exc_info=_exc)

    logger.info("atlassian_disconnect: revoked user_id=%s", user_id)
    return {"disconnected": True}


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

async def _exchange_code_for_tokens(code: str) -> dict:
    """
    POST to Atlassian token endpoint.
    Returns the full token response dict including access_token, refresh_token,
    expires_in, and scope.
    Raises httpx.HTTPStatusError on non-2xx responses.
    """
    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(
            ATLASSIAN_TOKEN_URL,
            json={
                "grant_type":    "authorization_code",
                "client_id":     settings.atlassian.client_id,
                "client_secret": settings.atlassian.client_secret,
                "code":          code,
                "redirect_uri":  settings.atlassian.redirect_uri,
            },
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()
        return response.json()


async def _fetch_atlassian_identity(access_token: str) -> dict:
    """
    GET https://api.atlassian.com/me
    Returns dict with account_id, email, and display name.
    Raises httpx.HTTPStatusError on non-2xx responses.
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(
            ATLASSIAN_IDENTITY_URL,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        response.raise_for_status()
        data = response.json()

    return {
        "account_id": data.get("account_id", ""),
        "email":      data.get("email", ""),
        "name":       data.get("name", ""),
    }
