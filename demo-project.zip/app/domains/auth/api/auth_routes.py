"""
Authentication routes — the two public endpoints that drive the browser-based
OAuth2 Authorization Code Flow.

  GET /login          → redirect browser to Azure AD login page
  GET /auth/callback  → receive auth code, exchange for tokens, return them

These routes are listed in AuthMiddleware's public-path allowlist and therefore
receive no Bearer token requirement — they are the entry points into the auth
flow itself.

Flow diagram:
  Browser → GET /login
         → 302 to Azure AD (authorization URL with state JWT)
         → user authenticates on Azure
         → Azure → 302 to /auth/callback?code=...&state=...
         → exchange code for tokens (server-to-server, never in browser)
         → upsert user in PostgreSQL
         → return JSON { access_token, id_token, user }

  Subsequent API calls:
    Authorization: Bearer <access_token>
    → AuthMiddleware validates token
    → request.state.user = UserContext(...)
    → route handler / LangGraph agent runs
"""

from urllib.parse import urlencode, quote

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.auth.services.azure_auth_service import AuthServiceError, azure_auth_service
from app.ingestion.tasks import resolve_user_identities
from app.core.config import settings
from app.shared.exceptions.error_enums import LogEvent
from app.shared.enums import AuthPath
from app.infrastructure.database.database import get_db
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

auth_router = APIRouter(tags=["Authentication"])


# ---------------------------------------------------------------------------
# Response schema
# ---------------------------------------------------------------------------

class TokenResponse(BaseModel):
    """Returned after a successful authorization-code exchange."""

    access_token: str
    id_token: str
    token_type: str
    expires_in: int
    scope: str
    user: dict


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@auth_router.get(
    AuthPath.LOGIN.value,
    summary="Initiate Azure AD login",
    description=(
        "Redirects the browser to the Azure Entra ID authorization endpoint.\n\n"
        "**Flow**: `GET /login` → 302 to Azure → user authenticates → "
        "Azure redirects to `/auth/callback`.\n\n"
        "A signed, short-lived state JWT is embedded in the redirect URL "
        "to prevent CSRF attacks on the callback."
    ),
    response_class=RedirectResponse,
    status_code=status.HTTP_302_FOUND,
    include_in_schema=True,
)
async def login() -> RedirectResponse:
    """
    Build the Azure AD authorization URL and redirect the browser to it.

    The state token embedded in the URL is a HS256-signed JWT that expires
    in 10 minutes.  The callback verifies it before trusting the code.
    """
    try:
        authorization_url, _state = azure_auth_service.build_authorization_url()
        response = RedirectResponse(url=authorization_url, status_code=status.HTTP_302_FOUND)
        response.headers["ngrok-skip-browser-warning"] = "true"
        return response

    except Exception as exc:
        logger.error(
            "Failed to build Azure AD authorization URL",
            event=LogEvent.USER_AUTH_FAILED.value,
            exc_info=exc,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Authentication service is temporarily unavailable. "
                "Check AZURE_CLIENT_ID and AZURE_TENANT_ID in your environment."
            ),
        )


@auth_router.get(
    AuthPath.CALLBACK.value,
    summary="Azure AD authorization callback",
    description=(
        "Receives the authorization code from Azure AD after the user "
        "authenticates.\n\n"
        "**Steps executed server-side**:\n"
        "1. Verify the `state` JWT for CSRF protection\n"
        "2. Exchange `code` for `access_token` + `id_token`\n"
        "3. Decode `id_token` to extract user identity\n"
        "4. Upsert the user in PostgreSQL\n"
        "5. Return tokens\n\n"
        "Store the returned `access_token` and include it as "
        "`Authorization: Bearer <access_token>` on subsequent API calls."
    ),
    response_model=TokenResponse,
)
async def auth_callback(
    # Required parameters sent by Azure AD on successful authentication
    code: str = Query(..., description="Authorization code from Azure AD"),
    state: str = Query(..., description="State JWT for CSRF verification"),
    # Optional: Azure sends these when the user denies consent or an error occurs
    error: str | None = Query(
        default=None, description="Error code from Azure AD (on failure)"
    ),
    error_description: str | None = Query(
        default=None, description="Human-readable error description from Azure"
    ),
    db: AsyncSession = Depends(get_db),
) -> JSONResponse:
    """
    OAuth2 callback handler.

    The `access_token` returned here is what clients MUST include on every
    subsequent API request as `Authorization: Bearer <access_token>`.

    The `id_token` is provided for informational purposes (e.g., the frontend
    may display the user's name without an extra API call); it is not validated
    by AuthMiddleware.
    """
    def _login_redirect(msg: str) -> RedirectResponse:
        """Redirect browser back to chat.html with an error message."""
        frontend_url = settings.app.frontend_url.rstrip("/")
        return RedirectResponse(
            url=f"{frontend_url}/?auth_error={quote(msg)}",
            status_code=status.HTTP_302_FOUND,
        )

    # ------------------------------------------------------------------
    # Handle Azure-side errors (user denied consent, tenant policy, etc.)
    # ------------------------------------------------------------------
    if error:
        logger.warn(
            "Azure AD returned an authorization error",
            event=LogEvent.USER_AUTH_FAILED.value,
            azure_error=error,
            azure_error_description=error_description,
        )
        return _login_redirect(error_description or error)

    # ------------------------------------------------------------------
    # Exchange code → tokens → provision user
    # ------------------------------------------------------------------
    try:
        token_response = await azure_auth_service.exchange_code_for_tokens(
            code=code,
            state=state,
        )
        
        user = await azure_auth_service.provision_user_from_token_response(
            token_response=token_response,
            db=db,
        )

    except AuthServiceError as exc:
        logger.warn(
            "Auth callback failed",
            event=LogEvent.USER_AUTH_FAILED.value,
            reason=exc.message,
        )
        return _login_redirect(exc.message)

    except Exception as exc:
        logger.error(
            "Unexpected error in auth callback",
            event=LogEvent.USER_AUTH_FAILED.value,
            exc_info=exc,
        )
        return _login_redirect("Authentication failed — please try again.")

    # ------------------------------------------------------------------
    # Build response
    # ------------------------------------------------------------------
    logger.info(
        "User successfully authenticated and provisioned",
        event=LogEvent.USER_PROVISIONED.value,
        user_id=str(user.user_id),
        email=user.email,
    )

    # Enqueue identity resolution (non-blocking, fire-and-forget)
    try:
        resolve_user_identities.delay(str(user.user_id), user.email)
        logger.info(
            "Identity resolution enqueued",
            user_id=str(user.user_id),
            email=user.email,
        )
    except Exception as exc:
        # Enqueue failure must never block login — log and continue.
        logger.error(
            "Failed to enqueue identity resolution — login proceeds anyway",
            user_id=str(user.user_id),
            email=user.email,
            exc_info=exc,
        )

    # Redirect the browser back to chat.html with the token in the URL
    # fragment (#).  Fragments are never sent to the server, so the token
    # stays client-side only.  chat.html reads it, stores it in localStorage,
    # then clears the hash from the address bar.
    fragment = urlencode({
        "access_token": token_response.get("access_token", ""),
        "expires_in":   str(token_response.get("expires_in", 3600)),
        "user_email":   user.email,
        "display_name": user.display_name or "",
        "user_id":      str(user.user_id),
        "roles":        ",".join(user.roles or []),
    })
    frontend_url = settings.app.frontend_url.rstrip("/")
    return RedirectResponse(
        url=f"{frontend_url}/#{fragment}",
        status_code=status.HTTP_302_FOUND,
    )
