"""
UserContext — immutable representation of an authenticated caller.

Populated by AuthMiddleware after validating the Bearer JWT.  Intentionally
decoupled from the SQLAlchemy User ORM model so that the hot-path (every
protected request) carries zero database dependency beyond the initial
token-validation step.

Routes and LangGraph agents that need the full ORM User object can do a
single DB lookup via azure_ad_oid; everything else only needs UserContext.
"""

from pydantic import BaseModel, Field
from app.shared.enums import UserRole


class UserContext(BaseModel):
    """
    Lightweight, frozen snapshot of the authenticated user.

    Fields map directly to Azure AD JWT claims extracted during
    Bearer token validation in AuthMiddleware.

    Frozen (immutable) so it can be safely shared across async boundaries
    without risk of accidental mutation.
    """

    model_config = {"frozen": True}

    # Stable Azure AD object-ID — use this as the cross-system user key.
    # The OID is a UUID-format string assigned by Entra ID and never changes
    # even if the user's UPN / email changes.
    user_id: str = Field(..., description="Azure AD OID — stable user identity")

    # Redundant with user_id; kept separate so call-sites can be explicit
    # about whether they mean the platform identity (user_id) or the
    # directory object reference (azure_ad_oid).
    azure_ad_oid: str = Field(..., description="Entra ID object identifier (oid claim)")

    email: str = Field(..., description="preferred_username / upn claim")
    display_name: str = Field(default="", description="name claim")

    # Entra ID app-role assignments propagated through the roles claim.
    # Values match UserRole enum strings defined in app/core/enums/enum.py.
    roles: list[str] = Field(default_factory=list, description="Entra ID app roles")

    # -----------------------------------------------------------------------
    # Convenience helpers — keep route handlers clean
    # -----------------------------------------------------------------------

    def has_role(self, role: str) -> bool:
        """Return True if the user holds *role* or the admin super-role."""
        return UserRole.ADMIN.value in self.roles or role in self.roles

    def has_any_role(self, *roles: str) -> bool:
        """Return True if the user holds at least one of *roles* (or admin)."""
        if UserRole.ADMIN.value in self.roles:
            return True
        return bool(set(self.roles) & set(roles))
