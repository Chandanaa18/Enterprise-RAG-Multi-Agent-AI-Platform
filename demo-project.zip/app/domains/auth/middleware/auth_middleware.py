"""
AuthMiddleware — Starlette middleware that enforces Bearer token authentication
on every protected route and populates request.state.user with a UserContext.

Architecture decisions:

1. Middleware over FastAPI Security dependency:
   A FastAPI dependency could be accidentally omitted from a new route.
   Middleware runs unconditionally for ALL matching paths — there is no way
   to add a protected route and forget auth.

2. Public path allowlist (not a denylist):
   Opting routes OUT of auth (denylist) is risky; opting them IN is even
   riskier.  We use an explicit allowlist of paths that bypass auth so that
   any new route is protected by default.

3. UserContext carries no ORM objects:
   The middleware validates the token cryptographically and builds a
   lightweight frozen Pydantic model.  No database call happens here.
   Routes that need the full ORM User do a single lookup using azure_ad_oid.
   This keeps middleware latency to a JWT decode + JWKS lookup (cached).

4. OPTIONS requests are always passed through:
   CORS preflight requests do not carry Authorization headers.  Blocking them
   here would break cross-origin access before CORS middleware gets a chance
   to handle them.

5. Structured error responses:
   On auth failure we return JSON (not HTML) with a consistent shape so API
   clients can parse errors reliably.
"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

from fastapi import status
from app.domains.auth.services.token_validator import TokenValidator, TokenValidationError
from app.domains.auth.schemas.user_context import UserContext
from app.shared.enums import AuthPath
from app.shared.exceptions.error_enums import LogEvent
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

# ---------------------------------------------------------------------------
# Public-path allowlist
# ---------------------------------------------------------------------------
# These exact paths (and any path that startswith a prefix listed in
# _PUBLIC_PREFIXES) bypass token validation entirely.
_PUBLIC_PATHS: frozenset[str] = frozenset(
    {
        AuthPath.LOGIN.value,
        AuthPath.CALLBACK.value,
        AuthPath.HEALTH.value,
        AuthPath.DOCS.value,
        AuthPath.REDOC.value,
        AuthPath.OPENAPI.value,
        AuthPath.OAUTH2_REDIRECT.value,
        AuthPath.ATLASSIAN_CONNECT.value,
        AuthPath.ATLASSIAN_CALLBACK.value,
    }
)

# Prefix-based allowlist for paths that have sub-routes we want fully public
_PUBLIC_PREFIXES: tuple[str, ...] = (
    "/docs",
    "/redoc",
    "/static",
)


def _is_public(path: str) -> bool:
    """Return True if *path* should bypass authentication."""
    if path in _PUBLIC_PATHS:
        return True
    return any(path.startswith(prefix) for prefix in _PUBLIC_PREFIXES)


class AuthMiddleware(BaseHTTPMiddleware):
    """
    Validates Azure AD Bearer tokens on inbound requests.

    On success  → sets request.state.user = UserContext(...)
    On failure  → returns 401 JSON immediately, route handler never runs
    Public paths → passed through without any auth check
    """

    def __init__(
        self,
        app: ASGIApp,
        validator: TokenValidator,
    ) -> None:
        super().__init__(app)
        self._validator = validator

    async def dispatch(self, request: Request, call_next) -> Response:
        path: str = request.url.path

        # 1. CORS preflight — must pass through before we inspect headers
        if request.method == "OPTIONS":
            return await call_next(request)

        # 2. Public routes — no auth required
        if _is_public(path):
            return await call_next(request)

        # 3. Extract Bearer token
        auth_header: str = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return self._unauthorized(
                "Authorization header is missing or does not use the Bearer scheme. "
                "Expected: Authorization: Bearer <access_token>"
            )

        token: str = auth_header[len("Bearer "):]

        # 4. Validate token via JWKS
        try:
            claims = await self._validator.validate(token)

        except TokenValidationError as exc:
            logger.warn(
                "Bearer token validation failed",
                event=LogEvent.USER_AUTH_FAILED.value,
                reason=exc.message,
                path=path,
                method=request.method,
            )
            return self._unauthorized(exc.message)

        except Exception as exc:
            # Catch unexpected errors (network issue fetching JWKS, etc.)
            # and return a generic 401 so we don't leak internals.
            logger.error(
                "Unexpected error during token validation",
                event=LogEvent.USER_AUTH_FAILED.value,
                exc_info=exc,
                path=path,
            )
            return self._unauthorized(
                "Token validation could not be completed"
            )

        # 5. Build UserContext from validated claims and attach to request state.
        #
        # oid   = Azure AD object ID — stable unique identifier for the user
        # We use oid for BOTH user_id and azure_ad_oid.
        # If a route needs the PostgreSQL UUID it looks up by azure_ad_oid.
        #
        # Written to request.state.user_context (NOT .user) because
        # fastapi-azure-auth's __call__ also sets request.state.user with its
        # own internal user model, which would overwrite ours.
        oid: str = claims.get("oid", "")
        request.state.user_context = UserContext(
            user_id=oid,
            azure_ad_oid=oid,
            email=(
                claims.get("preferred_username")
                or claims.get("upn")
                or claims.get("email")
                or ""
            ),
            display_name=claims.get("name", ""),
            roles=claims.get("roles") or [],
        )

        logger.info(
            "Request authenticated",
            event=LogEvent.USER_AUTH_INITIATED.value,
            azure_ad_oid=oid,
            path=path,
            method=request.method,
        )

        return await call_next(request)

    @staticmethod
    def _unauthorized(detail: str) -> JSONResponse:
        """
        Return a structured 401 response.

        Using JSONResponse (not raise HTTPException) because middleware cannot
        rely on FastAPI's exception handlers — those run inside the app layer
        which we're blocking at the middleware level.
        """
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={
                "error": "UNAUTHORIZED",
                "detail": detail,
            },
        )
