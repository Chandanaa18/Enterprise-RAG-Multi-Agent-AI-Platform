"""
AzureAuthService — OAuth2 Authorization Code Flow against Azure Entra ID.

Responsibilities:
  1. Build the authorization URL that sends the browser to Azure login.
  2. Validate the state parameter (CSRF protection) on the callback.
  3. Exchange the authorization code for access / ID / refresh tokens.
  4. Decode the ID token to extract user identity claims.
  5. Upsert the user in the database (first login → create; repeat → sync roles).

Why no MSAL?
  Microsoft's MSAL Python library has limited async support and adds a large
  dependency tree. python-jose + httpx gives identical capability with full
  async/await and a much lighter footprint.

Why a signed-JWT state token (not a random UUID stored server-side)?
  The state parameter prevents CSRF on the callback. Storing it server-side
  requires shared state (Redis, DB) which we want to avoid for a stateless
  service. A short-lived HS256-signed JWT signed with the client secret is
  tamper-proof, self-contained, and expires automatically after 10 minutes.
"""

import secrets
import time
from typing import Any
from urllib.parse import urlencode

from fastapi import status

import httpx
from jose import jwt, JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import AzureADConfig
from app.shared.exceptions.error_enums import LogEvent
from app.domains.users.models.user_model import User
from app.domains.users.services.user_service import UserService
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

# ---------------------------------------------------------------------------
# Configuration Constants
# ---------------------------------------------------------------------------
_STATE_TOKEN_EXPIRY_SECONDS: int = 600  # 10-minute login window
_HTTP_TIMEOUT_SECONDS: float = 15.0     # Timeout for HTTP calls to Azure
_JWT_ALGORITHM_HS256: str = "HS256"
_JWT_ALGORITHM_RS256: str = "RS256"


class AuthServiceError(Exception):
    """Raised when the auth code flow cannot be completed successfully."""

    def __init__(self, message: str, status_code: int = status.HTTP_400_BAD_REQUEST) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AzureAuthService:
    """
    Stateless service that drives the OAuth2 Authorization Code Flow.

    All configuration is read lazily via a private helper method from `envSettings`
    to ensure instantiation is safe at import time without a loaded `.env`.
    """

    # ------------------------------------------------------------------
    # Configuration / Endpoint helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_azure_config() -> AzureADConfig:
        """Lazily retrieve Azure AD configuration from application settings."""
        from app.core.config import settings as envSettings
        return envSettings.azure_ad

    @staticmethod
    def _authorize_endpoint(tenant_id: str) -> str:
        return f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/authorize"

    @staticmethod
    def _token_endpoint(tenant_id: str) -> str:
        return f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

    @staticmethod
    def _scopes(client_id: str) -> str:
        """
        Define scopes requested from Azure AD.

        openid + profile + email → id_token with name / upn / email claims
        offline_access           → refresh_token

        Tokens returned with this scope have aud=api://{client_id} and can be
        validated by AuthMiddleware via the tenant JWKS.
        """
        return f"openid profile email offline_access api://{client_id}/access_as_user"

    # ------------------------------------------------------------------
    # State token (CSRF protection)
    # ------------------------------------------------------------------

    @staticmethod
    def _create_state_token(client_secret: str) -> str:
        """
        Create a short-lived HS256-signed JWT used as the OAuth2 state parameter.
        The nonce ensures every state token is unique, blocking replay attacks.
        """
        now = int(time.time())
        payload = {
            "iat": now,
            "exp": now + _STATE_TOKEN_EXPIRY_SECONDS,
            "nonce": secrets.token_hex(16),
        }
        return jwt.encode(payload, client_secret, algorithm=_JWT_ALGORITHM_HS256)

    @staticmethod
    def _verify_state_token(state: str, client_secret: str) -> None:
        """
        Verify the state JWT from the callback query string.
        Raises AuthServiceError if the token is missing, forged, or expired.
        """
        try:
            jwt.decode(
                state,
                client_secret,
                algorithms=[_JWT_ALGORITHM_HS256],
                options={"verify_exp": True},
            )
        except JWTError as exc:
            raise AuthServiceError(
                f"Invalid or expired state parameter — possible CSRF attempt: {exc}",
                status_code=status.HTTP_400_BAD_REQUEST,
            ) from exc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_authorization_url(self) -> tuple[str, str]:
        """
        Build the Azure AD authorization redirect URL.

        Returns:
            tuple[str, str]: A tuple containing (authorization_url, state_token).
                - authorization_url: URL to redirect the user's browser to.
                - state_token: Included in the URL, verified on callback to prevent CSRF.
        """
        azure_config = self._get_azure_config()
        state = self._create_state_token(azure_config.client_secret or "")

        params: dict[str, str] = {
            "client_id": azure_config.client_id or "",
            "response_type": "code",
            "redirect_uri": azure_config.redirect_uri or "",
            "scope": self._scopes(azure_config.client_id or ""),
            "response_mode": "query",
            "state": state,
            "prompt": "select_account",
        }

        url = f"{self._authorize_endpoint(azure_config.tenant_id or '')}?{urlencode(params)}"

        logger.info(
            "Built Azure AD authorization URL",
            event=LogEvent.USER_AUTH_INITIATED.value,
            redirect_uri=azure_config.redirect_uri,
        )
        return url, state

    async def exchange_code_for_tokens(self, code: str, state: str) -> dict[str, Any]:
        """
        Verify the state token then POST to Azure's token endpoint.
        Returns the parsed token response payload (access_token, id_token, refresh_token).

        Raises AuthServiceError on CSRF failure or token endpoint errors.
        """
        azure_config = self._get_azure_config()

        # CSRF check — must happen before we trust the code
        self._verify_state_token(state, azure_config.client_secret or "")

        form_data: dict[str, str] = {
            "grant_type": "authorization_code",
            "client_id": azure_config.client_id or "",
            "client_secret": azure_config.client_secret or "",
            "code": code,
            "redirect_uri": azure_config.redirect_uri or "",
            "scope": self._scopes(azure_config.client_id or ""),
        }

        logger.info(
            "Exchanging authorization code for tokens",
            event=LogEvent.USER_AUTH_INITIATED.value,
        )

        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT_SECONDS) as client:
            resp = await client.post(
                self._token_endpoint(azure_config.tenant_id or ""),
                data=form_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

        if resp.status_code != status.HTTP_200_OK:
            azure_error = resp.json().get("error_description", resp.text)
            logger.error(
                "Azure AD token exchange failed",
                event=LogEvent.USER_AUTH_FAILED.value,
                status_code=resp.status_code,
                azure_error=azure_error,
            )
            raise AuthServiceError(
                "Token exchange with Azure AD failed. "
                "The authorization code may have expired or been reused.",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

    
        tokens: dict[str, Any] = resp.json()

        logger.info(
            "Token exchange successful",
            event=LogEvent.USER_PROVISIONED.value,
            token_type=tokens.get("token_type"),
            expires_in=tokens.get("expires_in"),
        )
        return tokens

    @staticmethod
    def decode_id_token_claims(id_token: str) -> dict[str, Any]:
        """
        Decode the id_token WITHOUT verifying its signature to extract user info.

        Security Note: We skip signature verification because the id_token was
        received directly from Azure's token endpoint over TLS, not via the client.
        The access_token is validated independently on API calls.
        """
        try:
            claims: dict[str, Any] = jwt.decode(
                id_token,
                key="",  # Not used since verify_signature is False
                algorithms=[_JWT_ALGORITHM_RS256],
                options={
                    "verify_signature": False,
                    "verify_exp": False,
                    "verify_aud": False,
                },
            )
        except JWTError as exc:
            raise AuthServiceError(
                f"Failed to decode id_token: {exc}",
                status_code=status.HTTP_400_BAD_REQUEST
            ) from exc

        return claims

    async def provision_user_from_token_response(
        self,
        token_response: dict[str, Any],
        db: AsyncSession,
    ) -> User:
        """
        Extract identity from the token response and upsert the user in the database.

        Reads the id_token for identity because it guarantees claims like
        name, preferred_username, and roles.

        Returns:
            User: The SQLAlchemy User ORM instance (created or updated).

        Raises:
            AuthServiceError: If required claims are missing.
        """
        id_token: str = token_response.get("id_token", "")
        if not id_token:
            raise AuthServiceError(
                "Azure token response did not include an id_token",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        claims = self.decode_id_token_claims(id_token)

        oid: str = claims.get("oid", "")
        email: str = (
            claims.get("preferred_username")
            or claims.get("upn")
            or claims.get("email")
            or ""
        )
        display_name: str = claims.get("name", "")
        roles: list[str] = claims.get("roles") or []

        if not oid:
            raise AuthServiceError(
                "id_token is missing the 'oid' (object ID) claim — "
                "cannot identify the user",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        logger.info(
            "Provisioning user from Azure AD id_token",
            event=LogEvent.USER_PROVISIONED.value,
            azure_ad_oid=oid,
            email=email,
            roles=roles,
        )

        user_service = UserService(db)
        return await user_service.get_or_provision_user(
            azure_ad_oid=oid,
            email=email,
            display_name=display_name,
            roles=roles,
        )


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
# AzureAuthService carries no mutable state — all config is read lazily
# on each call, so the singleton is safe to reuse across requests.
azure_auth_service = AzureAuthService()
