"""
TokenValidator — validates Azure AD JWT access tokens via the tenant's JWKS.

Architecture decisions:

1. JWKS caching with 15-minute TTL:
   Azure rotates signing keys infrequently, but fetching them on every request
   would add ~100-200ms of latency.  We cache the key-set and only re-fetch
   when the TTL expires OR when we receive a kid that isn't in the cache
   (handles rare mid-TTL rotations gracefully).

2. asyncio.Lock for thundering-herd protection:
   When the cache expires under high concurrency, only ONE coroutine fetches
   new keys; all others wait on the lock and then read the refreshed cache.

3. python-jose for validation:
   python-jose is already in the project and handles RSA256 verification
   natively.  It also lets us decode the header before selecting the key,
   which avoids trying every key in the JWKS set.

4. Audience validation uses BOTH forms Azure may emit:
   - "api://{client_id}" — standard for custom API scopes (v2.0 access tokens)
   - "{client_id}"        — emitted when no api:// URI is registered
   Accepting both avoids silent failures when app registrations vary.
"""

import asyncio
import time
from typing import Any

import httpx
from jose import jwt, JWTError

from app.shared.utils.logger.logger import Logger
from app.shared.exceptions.error_enums import LogEvent

logger = Logger(__name__)

_JWKS_CACHE_TTL_SECONDS: int = 900  # 15 minutes


class TokenValidationError(Exception):
    """Raised when a JWT cannot be decoded or fails any validation check."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class TokenValidator:
    """
    Singleton validator that verifies Azure AD RS256 access tokens.

    Usage (injected into AuthMiddleware at startup):
        claims = await token_validator.validate(raw_bearer_token)
    """

    def __init__(self) -> None:
        self._jwks: dict[str, Any] | None = None
        self._jwks_fetched_at: float = 0.0
        self._lock: asyncio.Lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _jwks_url(self, tenant_id: str) -> str:
        return (
            f"https://login.microsoftonline.com/{tenant_id}"
            "/discovery/v2.0/keys"
        )

    def _issuer(self, tenant_id: str) -> str:
        # Primary issuer for v2.0 tokens (accessTokenAcceptedVersion=2 in manifest).
        return f"https://login.microsoftonline.com/{tenant_id}/v2.0"

    def _accepted_issuers(self, tenant_id: str) -> tuple[str, ...]:
        # Accept both v2 and v1 issuers so the app works regardless of the
        # App Registration manifest's accessTokenAcceptedVersion setting.
        #
        # v2 issuer: https://login.microsoftonline.com/{tenant_id}/v2.0
        #   → requires accessTokenAcceptedVersion=2 in the App Registration manifest
        # v1 issuer: https://sts.windows.net/{tenant_id}/
        #   → default when accessTokenAcceptedVersion is null (older registrations)
        #

        return (
            f"https://login.microsoftonline.com/{tenant_id}/v2.0",
            f"https://sts.windows.net/{tenant_id}/",
        )

    def _expected_audiences(self, client_id: str) -> tuple[str, ...]:
        # python-jose only accepts audience as a single string (not a list),
        # so we store candidates and try them in order in validate().
        # Priority: api://{client_id} (access_token from custom API scope)
        #       then {client_id}       (id_token, or fallback access_token)
        return (f"api://{client_id}", client_id)

    async def _fetch_jwks(self, tenant_id: str) -> dict[str, Any]:
        """Fetch the JWKS from Azure, respecting the in-memory TTL cache."""
        now = time.monotonic()

        # Fast path — cache is warm
        cached_jwks = self._jwks
        if cached_jwks is not None and (now - self._jwks_fetched_at) < _JWKS_CACHE_TTL_SECONDS:
            return cached_jwks

        # Slow path — acquire lock so only one coroutine does the HTTP call
        async with self._lock:
            # Re-check after acquiring the lock in case another coroutine
            # already refreshed while we were waiting.
            cached_jwks = self._jwks
            if cached_jwks is not None and (now - self._jwks_fetched_at) < _JWKS_CACHE_TTL_SECONDS:
                return cached_jwks

            url = self._jwks_url(tenant_id)
            logger.info(
                "Fetching Azure AD JWKS",
                event=LogEvent.USER_AUTH_INITIATED.value,
                jwks_url=url,
            )

            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    resp = await client.get(url)
                    resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise TokenValidationError(
                    f"Failed to fetch Azure AD JWKS: {exc}"
                ) from exc

            self._jwks = resp.json()
            self._jwks_fetched_at = time.monotonic()
            key_count = len(self._jwks.get("keys", []))
            logger.info(
                "Azure AD JWKS refreshed",
                event=LogEvent.USER_AUTH_INITIATED.value,
                key_count=key_count,
            )
            return self._jwks

    async def _resolve_signing_key(
        self, kid: str, tenant_id: str
    ) -> dict[str, Any]:
        """
        Find the JWK matching *kid*.

        If not found in the warm cache, force a single JWKS refresh to handle
        mid-TTL key rotations.  Raise TokenValidationError if still absent.
        """
        jwks = await self._fetch_jwks(tenant_id)
        keys = [k for k in jwks.get("keys", []) if k.get("kid") == kid]

        if not keys:
            # Key not in cache — Azure may have rotated; force one refresh
            self._jwks_fetched_at = 0.0
            jwks = await self._fetch_jwks(tenant_id)
            keys = [k for k in jwks.get("keys", []) if k.get("kid") == kid]

        if not keys:
            raise TokenValidationError(
                f"No Azure AD signing key found for kid={kid!r}. "
                "JWKS was refreshed — key may have been revoked."
            )

        return keys[0]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def validate(self, token: str) -> dict[str, Any]:
        """
        Fully validate a raw Bearer token string.

        Checks:
          - RS256 signature against current Azure JWKS
          - Expiry (exp), not-before (nbf), issued-at (iat)
          - Issuer matches tenant OIDC issuer
          - Audience is our client_id or api://<client_id>

        Returns the decoded claims dict on success.
        Raises TokenValidationError on any failure.
        """
        # Import here to avoid circular import at module level
        from app.core.config import settings as envSettings

        tenant_id: str = envSettings.azure_ad.tenant_id or ""
        client_id: str = envSettings.azure_ad.client_id or ""

        # Decode header WITHOUT verifying the signature just to read kid.
        # python-jose requires the algorithm list even for unverified decode.
        try:
            header = jwt.get_unverified_header(token)
        except JWTError as exc:
            raise TokenValidationError(f"Malformed token header: {exc}") from exc

        kid: str | None = header.get("kid") #key id
        alg: str = header.get("alg", "RS256") # alg = algorithm

        if not kid:
            raise TokenValidationError("Token header is missing the 'kid' claim")

        if alg != "RS256":
            # Only accept RS256 — symmetric algorithms are never valid for
            # tokens issued by Azure AD.
            raise TokenValidationError(
                f"Unsupported signing algorithm: {alg!r} (expected RS256)"
            )

        signing_key = await self._resolve_signing_key(kid, tenant_id)

        # Peek at unverified payload to surface the actual aud/iss in error
        # messages — makes misconfiguration much easier to diagnose.
        try:
            _unverified = jwt.decode(
                token,
                key="",
                algorithms=["RS256"],
                options={
                    "verify_signature": False,
                    "verify_exp": False,
                    "verify_aud": False,
                    "verify_iss": False,
                },
            )
            actual_aud = _unverified.get("aud", "MISSING")
            actual_iss = _unverified.get("iss", "MISSING")
        except Exception:
            actual_aud = "undecodable"
            actual_iss = "undecodable"

        logger.info(
            "Token claims peek",
            actual_aud=actual_aud,
            actual_iss=actual_iss,
            expected_audiences=list(self._expected_audiences(client_id)),
            expected_issuer=self._issuer(tenant_id),
        )

        # python-jose only accepts audience and issuer as single strings, but
        # we need to accept multiple valid values for each.
        #
        # Strategy: disable python-jose's issuer check (verify_iss=False) and
        # do our own multi-value issuer check after signature + audience pass.
        # We still try each audience candidate in order so both access_tokens
        # (aud=api://client_id) and id_tokens (aud=client_id) are accepted.
        aud_candidates = self._expected_audiences(client_id)
        accepted_issuers = self._accepted_issuers(tenant_id)
        last_exc: JWTError | None = None
        claims: dict[str, Any] | None = None

        for audience in aud_candidates:
            try:
                claims = jwt.decode(
                    token,
                    signing_key,
                    algorithms=["RS256"],
                    audience=audience,
                    options={
                        "verify_exp": True,
                        "verify_nbf": True,
                        "verify_iat": True,
                        "verify_aud": True,
                        "verify_iss": False,   # checked manually below
                    },
                )
                break  # audience + signature passed — stop trying
            except JWTError as exc:
                last_exc = exc
                continue

        if claims is None:
            raise TokenValidationError(
                f"Token validation failed: {last_exc}. "
                f"Token aud={actual_aud!r}, iss={actual_iss!r}. "
                f"Expected aud one of {list(aud_candidates)}, "
                f"iss one of {list(accepted_issuers)}"
            ) from last_exc

        # Manual issuer check against all accepted issuers.
        token_iss: str = claims.get("iss", "")
        if token_iss not in accepted_issuers:
            raise TokenValidationError(
                f"Invalid token issuer {token_iss!r}. "
                f"Accepted: {list(accepted_issuers)}"
            )

        # Belt-and-suspenders: ensure the OID claim is present.
        # Every Azure AD token MUST contain oid; absence signals token tampering.
        if not claims.get("oid"):
            raise TokenValidationError(
                "Token is missing the required 'oid' (object ID) claim"
            )

        return claims

    def invalidate_cache(self) -> None:
        """Force JWKS refresh on the next validate() call (useful in tests)."""
        self._jwks_fetched_at = 0.0


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------
# Shared across all requests; thread-safe because the only mutable state
# (JWKS cache) is guarded by an asyncio.Lock.
token_validator = TokenValidator()
