"""
AtlassianTokenService — get a valid Atlassian access token for a user.

This is the single entry point the JiraAgent calls before every MCP request.
It handles three cases transparently:

  1. Token is valid            → decrypt and return immediately
  2. Token is expiring soon    → silent refresh → update DB → return new token
  3. Refresh fails (revoked)   → mark credential revoked → raise clear error

The caller (JiraAgent) never needs to know which case occurred — it always
receives a plaintext access token ready to use, or a clear exception.

Silent refresh uses the OAuth 2.0 Refresh Token Grant Flow with the
offline_access scope. The refresh_token is rotated by Atlassian on every
exchange — both tokens are re-encrypted and stored after every refresh.

A Redis distributed lock prevents race conditions when multiple concurrent
requests for the same user all see an expired token simultaneously.
Only one coroutine performs the refresh; all others wait and then read
the freshly stored token.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

import httpx
import redis.asyncio as aioredis
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.constants import ATLASSIAN_TOKEN_URL
from app.domains.permissions.repositories.user_connector_credentials_repository import (
    UserConnectorCredentialsRepository,
)
from app.shared.exceptions.connector_exceptions import (
    AtlassianNotConnectedError,
    AtlassianTokenError,
    AtlassianTokenRefreshError,
    AtlassianTokenRevokedError,
)
from app.shared.utils.crypto import TokenEncryption
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

# Refresh the token if it expires within this window
_REFRESH_BUFFER_MINUTES = 5

# Redis lock settings
_LOCK_KEY_PREFIX   = "atlassian_token_refresh_lock:"
_LOCK_TTL_SECONDS  = 30
_LOCK_WAIT_SECONDS = 35


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------

class AtlassianTokenService:
    """
    Retrieves a valid Atlassian access token for a given user.

    Constructed once and reused — all state is in the DB and Redis,
    not in this object. Thread-safe and async-safe.
    """

    def __init__(self) -> None:
        self._enc = TokenEncryption()

    async def get_valid_token(
        self,
        user_id: str,
        db: AsyncSession,
    ) -> str:
        """
        Return a valid plaintext Atlassian access token for the user.

        Transparently handles token refresh when the access token is
        expiring within the next 5 minutes.

        Parameters
        ----------
        user_id
            Internal user UUID string.
        db
            Active async SQLAlchemy session.

        Returns
        -------
        str
            Decrypted plaintext access token ready to use in Authorization header.

        Raises
        ------
        AtlassianNotConnectedError
            User has no credential row — they need to connect Atlassian first.
        AtlassianTokenRevokedError
            Credential exists but is revoked — user needs to reconnect.
        AtlassianTokenRefreshError
            Refresh attempt failed for an unexpected reason.
        """
        repo = UserConnectorCredentialsRepository(db)
        creds = await repo.get(user_id, "jira")

        # ------------------------------------------------------------------
        # 1. No credential row — user has never connected
        # ------------------------------------------------------------------
        if creds is None:
            logger.info(
                "atlassian_token: no credential found",
                user_id=user_id,
            )
            raise AtlassianNotConnectedError(
                "Your Atlassian account is not connected. "
                "Go to Settings → Connections → Connect Atlassian."
            )

        # ------------------------------------------------------------------
        # 2. Credential is revoked
        # ------------------------------------------------------------------
        if creds.status == "revoked":
            logger.warn(
                "atlassian_token: credential is revoked",
                user_id=user_id,
            )
            raise AtlassianTokenRevokedError(
                "Your Atlassian connection was disconnected. "
                "Go to Settings → Connections to reconnect."
            )

        # ------------------------------------------------------------------
        # 3. Token is still valid — decrypt and return
        # ------------------------------------------------------------------
        if not self._is_expiring_soon(creds.expires_at):
            logger.info(
                "atlassian_token: token valid, returning",
                user_id=user_id,
                expires_at=creds.expires_at.isoformat() if creds.expires_at else "unknown",
            )
            return self._enc.decrypt(creds.access_token_enc)

        # ------------------------------------------------------------------
        # 4. Token is expiring — silent refresh with distributed lock
        # ------------------------------------------------------------------
        logger.info(
            "atlassian_token: token expiring, refreshing",
            user_id=user_id,
        )
        return await self._refresh_with_lock(user_id=user_id, db=db, repo=repo)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _refresh_with_lock(
        self,
        *,
        user_id: str,
        db: AsyncSession,
        repo: UserConnectorCredentialsRepository,
    ) -> str:
        """
        Acquire a Redis distributed lock then refresh the token.

        If another coroutine is already refreshing for this user,
        wait for it to finish then read the freshly stored token
        instead of making a duplicate refresh call.
        """
        lock_key = f"{_LOCK_KEY_PREFIX}{user_id}"
        redis    = aioredis.from_url(
            settings.redis.url,
            encoding="utf-8",
            decode_responses=True,
        )

        try:
            acquired = await redis.set(
                lock_key,
                "1",
                nx=True,           # only set if not exists
                ex=_LOCK_TTL_SECONDS,
            )

            if not acquired:
                # Another coroutine holds the lock — wait then re-read
                logger.info(
                    "atlassian_token: lock held by another worker, waiting",
                    user_id=user_id,
                )
                await self._wait_for_lock_release(redis, lock_key)

                # Re-fetch after waiting — should now be fresh
                creds = await repo.get(user_id, "jira")
                if creds and creds.access_token_enc:
                    return self._enc.decrypt(creds.access_token_enc)
                raise AtlassianTokenRefreshError(
                    "Token refresh by concurrent worker failed."
                )

            # We hold the lock — perform the refresh
            return await self._do_refresh(user_id=user_id, db=db, repo=repo)

        finally:
            await redis.delete(lock_key)
            await redis.aclose()

    async def _do_refresh(
        self,
        *,
        user_id: str,
        db: AsyncSession,
        repo: UserConnectorCredentialsRepository,
    ) -> str:
        """
        Exchange the refresh token for new tokens and update the DB.
        Called only when holding the distributed lock.
        """
        creds = await repo.get(user_id, "jira")

        if not creds or not creds.refresh_token_enc:
            raise AtlassianTokenRefreshError(
                "No refresh token stored. User must reconnect Atlassian."
            )

        refresh_token = self._enc.decrypt(creds.refresh_token_enc)

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    ATLASSIAN_TOKEN_URL,
                    json={
                        "grant_type":    "refresh_token",
                        "client_id":     settings.atlassian.client_id,
                        "client_secret": settings.atlassian.client_secret,
                        "refresh_token": refresh_token,
                    },
                    headers={"Content-Type": "application/json"},
                )
                response.raise_for_status()
                token_data = response.json()

        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in (400, 401):
                # Refresh token is invalid or revoked by user
                await repo.revoke(user_id=user_id, connector_name="jira")
                logger.warn(
                    "atlassian_token: refresh token rejected — marking revoked",
                    user_id=user_id,
                    status_code=exc.response.status_code,
                )
                raise AtlassianTokenRevokedError(
                    "Your Atlassian connection was revoked. "
                    "Go to Settings → Connections to reconnect."
                ) from exc
            raise AtlassianTokenRefreshError(
                f"Atlassian token refresh failed: {exc}"
            ) from exc

        except Exception as exc:
            raise AtlassianTokenRefreshError(
                f"Unexpected error during token refresh: {exc}"
            ) from exc

        # Encrypt and store new tokens
        new_access_token  = token_data["access_token"]
        new_refresh_token = token_data.get("refresh_token", refresh_token)
        expires_in        = int(token_data.get("expires_in", 3600))
        expires_at        = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

        await repo.update_tokens(
            user_id=user_id,
            connector_name="jira",
            access_token_enc=self._enc.encrypt(new_access_token),
            refresh_token_enc=self._enc.encrypt(new_refresh_token),
            expires_at=expires_at,
        )

        # Kill the running mcp process so the next request respawns it
        # with the new token. Without this the hot path in JiraAgent.run()
        # keeps reusing the old expired process.
        try:
            from app.main import app as _app
            _pool = getattr(_app.state, "mcp_pool", None)
            if _pool is not None:
                _pool.shutdown_user(user_id)
                logger.info(
                    "atlassian_token: mcp process killed for respawn",
                    user_id=user_id,
                )
        except Exception as _exc:
            logger.warn(
                "atlassian_token: pool shutdown failed (non-fatal)",
                user_id=user_id,
                error=str(_exc),
            )

        logger.info(
            "atlassian_token: token refreshed successfully",
            user_id=user_id,
            expires_at=expires_at.isoformat(),
        )
        return new_access_token

    @staticmethod
    def _is_expiring_soon(expires_at: datetime | None) -> bool:
        """Return True if the token expires within the refresh buffer window."""
        if expires_at is None:
            return True
        now    = datetime.now(timezone.utc)
        buffer = timedelta(minutes=_REFRESH_BUFFER_MINUTES)
        return expires_at <= (now + buffer)

    @staticmethod
    async def _wait_for_lock_release(
        redis: aioredis.Redis,
        lock_key: str,
    ) -> None:
        """
        Poll until the lock is released or timeout is reached.
        Uses short sleep intervals to avoid busy-waiting.
        """
        waited = 0
        while waited < _LOCK_WAIT_SECONDS:
            await asyncio.sleep(0.5)
            waited += 0.5
            exists = await redis.exists(lock_key)
            if not exists:
                return
        logger.warn("atlassian_token: lock wait timeout", lock_key=lock_key)
