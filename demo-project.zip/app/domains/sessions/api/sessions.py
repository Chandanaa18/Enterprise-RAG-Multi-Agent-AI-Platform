"""
Sessions API — spec §11.3

GET /api/v1/sessions                       — list active sessions for current user
GET /api/v1/sessions/{session_id}/messages — conversation history for a session
"""
from __future__ import annotations
from typing import Annotated, List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.database.database import get_db
from app.bootstrap.auth_deps import require_role
from app.shared.enums import AGENT_ROLE_MAP
from app.domains.sessions.models.session_model import Session
from app.domains.sessions.models.message_model import Message
from app.domains.users.models.user_model import User

sessions_router = APIRouter(prefix="/api/v1/sessions", tags=["Sessions"])

SessionDep = Annotated[AsyncSession, Depends(get_db)]
_auth = require_role(*AGENT_ROLE_MAP.values())


# ── Response schemas ───────────────────────────────────────────────────────────

class SessionItem(BaseModel):
    session_id: UUID
    created_at: str
    last_active_at: str | None
    agent_last_used: str | None
    is_active: bool


class SessionListResponse(BaseModel):
    items: List[SessionItem]


class SessionCreateResponse(BaseModel):
    session_id: UUID
    created_at: str


class MessageItem(BaseModel):
    message_id: UUID
    role: str | None
    content: str | None
    agent_name: str | None
    created_at: str
    token_usage: dict | None
    mlflow_run_id: str | None


class MessageListResponse(BaseModel):
    session_id: UUID
    items: List[MessageItem]


# ── Endpoints ──────────────────────────────────────────────────────────────────

@sessions_router.post("", response_model=SessionCreateResponse, status_code=201)
async def create_session(db: SessionDep, user: User = Depends(_auth)):
    session = Session(user_id=user.user_id)
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return SessionCreateResponse(
        session_id=session.session_id,
        created_at=session.created_at.isoformat(),
    )


@sessions_router.get("", response_model=SessionListResponse)
async def list_sessions(db: SessionDep, user: User = Depends(_auth)):
    result = await db.execute(
        select(Session)
        .where(Session.user_id == user.user_id)
        .where(Session.is_active == True)
        .order_by(Session.last_active_at.desc())
    )
    sessions = result.scalars().all()
    return SessionListResponse(items=[
        SessionItem(
            session_id=s.session_id,
            created_at=s.created_at.isoformat() if s.created_at else "",
            last_active_at=s.last_active_at.isoformat() if s.last_active_at else None,
            agent_last_used=s.agent_last_used,
            is_active=s.is_active,
        )
        for s in sessions
    ])


@sessions_router.get("/{session_id}/messages", response_model=MessageListResponse)
async def get_session_messages(
    session_id: UUID,
    db: SessionDep,
    user: User = Depends(_auth),
):
    session_result = await db.execute(
        select(Session).where(
            Session.session_id == session_id,
            Session.user_id == user.user_id,
        )
    )
    if not session_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Session not found")

    messages_result = await db.execute(
        select(Message)
        .where(Message.session_id == session_id)
        .order_by(Message.created_at.asc())
    )
    messages = messages_result.scalars().all()
    return MessageListResponse(
        session_id=session_id,
        items=[
            MessageItem(
                message_id=m.message_id,
                role=m.role,
                content=m.content,
                agent_name=m.agent_name,
                created_at=m.created_at.isoformat() if m.created_at else "",
                token_usage=m.token_usage,
                mlflow_run_id=m.mlflow_run_id,
            )
            for m in messages
        ],
    )
