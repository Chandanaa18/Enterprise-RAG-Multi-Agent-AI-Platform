from fastapi import Header, Depends, Response
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from uuid import UUID

from app.infrastructure.database.database import get_db
from app.domains.sessions.services.session_service import SessionService
from app.bootstrap.auth_deps import get_current_user
from app.domains.sessions.models.session_model import Session
from app.domains.users.models.user_model import User


async def get_current_session(
    response: Response,
    current_user: User = Depends(get_current_user),
    x_session_id: Optional[UUID] = Header(None, alias="X-Session-ID"),
    db: AsyncSession = Depends(get_db)
) -> Session:
    """
    FastAPI Dependency to handle Session Lifecycle.
    Delegates all business logic to SessionService.
    """
    session_service = SessionService(db)

    session = await session_service.get_or_create_session(
        user_id=current_user.user_id,
        session_id=x_session_id,
    )

    response.headers["X-Session-ID"] = str(session.session_id)
    return session
