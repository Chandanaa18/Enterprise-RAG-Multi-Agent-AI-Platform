import uuid
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column

from app.infrastructure.database.database import Base

class Message(Base):
    __tablename__ = "messages"
    __table_args__ = {'schema': 'enterprise_rag_system'}

    message_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("enterprise_rag_system.sessions.session_id"), index=True)
    role: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    agent_name: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    token_usage: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict, nullable=True)
    mlflow_run_id: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    session = relationship("Session", back_populates="messages")
