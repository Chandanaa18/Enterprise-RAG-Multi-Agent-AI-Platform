from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.sessions.models.session_model import Session


class SessionRepository:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, session_id):
        query = select(Session).where(Session.session_id == session_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def create(self, session: Session):
        self.db.add(session)
        await self.db.flush()    # assign PK / defaults without closing the tx
        await self.db.refresh(session)
        await self.db.commit()
        return session

    async def update(self, session: Session):
        await self.db.flush()
        await self.db.refresh(session)
        await self.db.commit()
        return session