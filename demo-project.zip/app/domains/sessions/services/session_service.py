from uuid import UUID, uuid4
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.sessions.repositories.session_repository import SessionRepository
from app.domains.sessions.models.session_model import Session
from app.shared.exceptions.base_exception import AppBaseException, SessionExpiredError, PermissionDeniedError
from app.shared.exceptions.error_enums import LogEvent
from app.shared.enums import SessionStatus
from app.core.config import settings
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class SessionService:

    def __init__(self, db: AsyncSession):
        self.session_repo = SessionRepository(db)
        self.inactivity_timeout_hours: int = settings.session.inactivity_timeout_hours

    async def create_session(self, user_id: UUID) -> Session:
        try:
            new_session = Session(
                session_id=uuid4(),
                user_id=user_id,
                created_at=datetime.now(timezone.utc),
                last_active_at=datetime.now(timezone.utc),
                is_active=True,
            )
            session = await self.session_repo.create(new_session)
            logger.info(
                "New session created",
                event=SessionStatus.CREATED.value,
                session_id=str(session.session_id),
                user_id=str(user_id),
            )
            return session
        except AppBaseException:
            raise
        except Exception as e:
            logger.error(
                f"Failed to create session for user: {user_id}",
                event=LogEvent.SESSION_CREATED.value,
                exc_info=e,
                user_id=str(user_id),
            )
            raise AppBaseException(
                message=f"Failed to create session for user: {user_id}",
                details=str(e),
            )

    async def validate_and_refresh(self, session_id: UUID, user_id: UUID) -> Optional[Session]:
        try:
            session = await self.session_repo.get_by_id(session_id)
            if not session:
                return None

            if session.user_id != user_id:
                logger.info(
                    "Session ownership mismatch",
                    event=LogEvent.RETRIEVAL_DENIED.value,
                    session_id=str(session_id),
                    requested_by=str(user_id),
                )
                raise PermissionDeniedError(
                    message="Session does not belong to the authenticated user",
                    user_id=str(user_id),
                    resource=str(session_id),
                )

            if not session.is_active:
                logger.info(
                    "Attempted to access an inactive session",
                    event=LogEvent.SESSION_INACTIVE.value,
                    session_id=str(session_id),
                    status=SessionStatus.INACTIVE.value,
                )
                return None

            elapsed = datetime.now(timezone.utc) - session.last_active_at.replace(tzinfo=timezone.utc)
            if elapsed > timedelta(hours=self.inactivity_timeout_hours):
                session.is_active = False
                await self.session_repo.update(session)
                logger.info(
                    f"Session expired after {self.inactivity_timeout_hours}h of inactivity",
                    event=LogEvent.SESSION_EXPIRED.value,
                    session_id=str(session_id),
                    status=SessionStatus.EXPIRED.value,
                    inactivity_hours=self.inactivity_timeout_hours,
                )
                raise SessionExpiredError(session_id=str(session_id))

            session.last_active_at = datetime.now(timezone.utc)
            await self.session_repo.update(session)
            return session

        except (AppBaseException, SessionExpiredError):
            raise
        except Exception as e:
            logger.error(
                f"Failed to validate session: {session_id}",
                event=LogEvent.SESSION_EXPIRED.value,
                exc_info=e,
                session_id=str(session_id),
            )
            raise AppBaseException(
                message=f"Failed to validate session: {session_id}",
                details=str(e),
            )

    async def get_or_create_session(self, user_id: UUID, session_id: Optional[UUID] = None) -> Session:
        try:
            if session_id:
                try:
                    session = await self.validate_and_refresh(session_id, user_id)
                    if session:
                        return session
                except SessionExpiredError:
                    logger.info(
                        "Expired session replaced with new session",
                        event=LogEvent.SESSION_CREATED.value,
                        old_session_id=str(session_id),
                        user_id=str(user_id),
                    )

            return await self.create_session(user_id)

        except AppBaseException:
            raise
        except Exception as e:
            logger.error(
                f"Failed to resolve session for user: {user_id}",
                event=LogEvent.SESSION_EXPIRED.value,
                exc_info=e,
                user_id=str(user_id),
            )
            raise AppBaseException(
                message=f"Failed to resolve session for user: {user_id}",
                details=str(e),
            )
