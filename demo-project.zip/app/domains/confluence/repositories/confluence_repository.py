from __future__ import annotations

from typing import List, Optional

from app.domains.confluence.connector.confluence_connector import ConfluenceConnector
from app.domains.confluence.schemas.schemas import ConfluenceSearchResultSchema
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)
class ConfluenceAdapter:

    def __init__(self, connector: ConfluenceConnector) -> None:
        self._connector = connector

    @property
    def base_url(self) -> str:
        return self._connector.base_url

    async def search_pages(
        self,
        cql: str,
        *,
        limit: Optional[int] = None,
    ) -> List[ConfluenceSearchResultSchema]:
        results = await self._connector.search_pages(cql, limit=limit)
        logger.info("ConfluenceAdapter.search_pages → %d results", len(results))
        return results
