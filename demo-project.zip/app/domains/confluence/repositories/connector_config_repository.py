"""
Repository for the connector_configs table.

Provides read/write access to connector configuration and sync state.
Used by sync services to track incremental synchronization timestamps
via the existing connector_configs.last_sync_at column.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.confluence.models.connector_config_model import ConnectorConfig


class ConnectorConfigRepository:

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def get_all_enabled(self) -> list[ConnectorConfig]:
        """Return all connector_config rows where enabled=True."""
        result = await self.db.execute(
            select(ConnectorConfig).where(ConnectorConfig.enabled == True)  # noqa: E712
        )
        return list(result.scalars().all())

    # Get by id
    async def get_by_id(self, connector_id: str) -> Optional[ConnectorConfig]:
        result = await self.db.execute(
            select(ConnectorConfig).where(ConnectorConfig.connector_id == connector_id)
        )
        return result.scalar_one_or_none()

    # Get last sync
    async def get_last_sync_at(self, connector_id: str) -> Optional[datetime]:
        """Return the last successful sync timestamp, or None if never synced."""
        record = await self.get_by_id(connector_id)
        return record.last_sync_at if record else None

    # Upsert
    async def upsert(
        self,
        connector_id: str,
        *,
        connector_name: Optional[str] = None,
        enabled: bool = True,
        config: Optional[dict] = None,
    ) -> ConnectorConfig:
        """Create the connector_config row if it doesn't exist yet."""
        record = await self.get_by_id(connector_id)
        if record is None:
            record = ConnectorConfig(
                connector_id=connector_id,
                connector_name=connector_name or connector_id,
                enabled=enabled,
                config=config or {},
            )
            self.db.add(record)
            await self.db.commit()
            await self.db.refresh(record)
        return record


    async def update_last_sync_at(
        self,
        connector_id: str,
        sync_time: datetime,
    ) -> ConnectorConfig:
        """
        Persist the sync completion timestamp.
        Creates the connector_config row if it doesn't exist.
        """
        record = await self.get_by_id(connector_id)
        if record is None:
            record = ConnectorConfig(
                connector_id=connector_id,
                connector_name=connector_id,
                enabled=True,
                config={},
            )
            self.db.add(record)

        record.last_sync_at = sync_time
        await self.db.commit()
        await self.db.refresh(record)
        return record
