from __future__ import annotations
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional

import psycopg2
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.confluence.connector.confluence_connector import ConfluenceConnector
from app.domains.confluence.models.document_index_model import DocumentIndex
from app.shared.exceptions.error_enums import SyncStatus
from app.shared.enums import ConnectorType
from app.ingestion.pipeline import IngestionPipeline
from app.domains.confluence.repositories.connector_config_repository import ConnectorConfigRepository
from app.domains.confluence.schemas.schemas import NormalizedDocument, SyncStatusResponse
from app.shared.utils.logger.logger import Logger
from app.core.config import settings

# Regex to extract the numeric Confluence page ID from a stored source_url.
# Example URL: https://company.atlassian.net/wiki/spaces/HR/pages/11075585/Title
_CONFLUENCE_PAGE_ID_RE = re.compile(r"/pages/(\d+)")

_BAR_WIDTH = 30

def _progress_bar(current: int, total: int) -> str:
    """Return a simple ASCII progress bar: [████████░░░░░░] 8/20"""
    filled = int(_BAR_WIDTH * current / total) if total else _BAR_WIDTH
    bar    = "█" * filled + "░" * (_BAR_WIDTH - filled)
    return f"[{bar}] {current}/{total}"

logger = Logger(__name__)
_CONNECTOR_ID = ConnectorType.CONFLUENCE.value


class ConfluenceSyncService:

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._config_repo = ConnectorConfigRepository(db)

    async def run_sync(
        self,
        *,
        space_keys: Optional[List[str]] = None,
        limit: Optional[int] = None,
        force_full: bool = False,
    ) -> SyncStatusResponse:
        start_time = time.monotonic()
        synced_at  = datetime.now(timezone.utc)

        # Ensure the connector_config row exists so document_index FK works.
        logger.info("Ensuring connector_config exists for %s", _CONNECTOR_ID)
        await self._config_repo.upsert(_CONNECTOR_ID, connector_name="Confluence")

        last_sync_at: Optional[datetime] = None
        if not force_full:
            last_sync_at = await self._config_repo.get_last_sync_at(_CONNECTOR_ID)
            logger.info(
                "ConfluenceSyncService: last_sync_at=%s force_full=%s",
                last_sync_at, force_full,
            )
        else:
            logger.info("ConfluenceSyncService: force_full=True — skipping last_sync_at")

        try:
            async with ConfluenceConnector() as connector:
                await connector.connect()
                documents: List[NormalizedDocument] = await connector.sync(
                    last_sync_at,
                    space_keys=space_keys,
                    limit=limit,
                )

            # ── Ingest each document through the pipeline ────────────────────
            if documents:
                pipeline     = IngestionPipeline()
                total_chunks = 0
                failed_docs  = 0
                total        = len(documents)

                logger.info("──────────────────────────────────────────────────────")
                logger.info("INGESTION START  total_docs=%d", total)
                logger.info("──────────────────────────────────────────────────────")

                for idx, doc in enumerate(documents, start=1):
                    doc_start = time.monotonic()
                    logger.info(
                        "%s  doc=%d/%d  title=%r",
                        _progress_bar(idx - 1, total), idx, total, doc.title,
                    )
                    try:
                        n = await pipeline.run(
                            doc,
                            db=self._db,
                            connector_id=_CONNECTOR_ID,
                        )
                        total_chunks += n
                        elapsed = round(time.monotonic() - doc_start, 2)
                        logger.info(
                            "%s  [done]   doc=%d/%d  chunks=%d  time=%.2fs  title=%r",
                            _progress_bar(idx, total), idx, total, n, elapsed, doc.title,
                        )
                    except Exception as exc:
                        failed_docs += 1
                        elapsed = round(time.monotonic() - doc_start, 2)
                        logger.error(
                            "%s  [failed]  doc=%d/%d  time=%.2fs  title=%r  error=%s",
                            _progress_bar(idx, total), idx, total, elapsed, doc.title, exc,
                        )

                logger.info("──────────────────────────────────────────────────────")
                logger.info(
                    "INGESTION DONE  docs=%d  chunks=%d  failed=%d",
                    total, total_chunks, failed_docs,
                )
                logger.info("──────────────────────────────────────────────────────")

            await self._config_repo.update_last_sync_at(_CONNECTOR_ID, synced_at)

            duration    = round(time.monotonic() - start_time, 2)
            sync_status = SyncStatus.NO_CHANGES if not documents else SyncStatus.COMPLETED

            logger.info(
                "ConfluenceSyncService: %s — %d documents synced in %.2fs",
                sync_status, len(documents), duration,
            )
            return SyncStatusResponse(
                connector=ConnectorType.CONFLUENCE,
                status=sync_status,
                pages_synced=len(documents),
                last_sync_time=synced_at,
                duration_seconds=duration,
            )

        except Exception as exc:
            duration = round(time.monotonic() - start_time, 2)
            logger.error(
                "ConfluenceSyncService: sync failed after %.2fs — %s",
                duration, exc,
                exc_info=exc,
            )
            return SyncStatusResponse(
                connector=ConnectorType.CONFLUENCE,
                status=SyncStatus.FAILED,
                pages_synced=0,
                duration_seconds=duration,
                error=str(exc),
            )

    async def get_last_sync_time(self) -> Optional[datetime]:
        return await self._config_repo.get_last_sync_at(_CONNECTOR_ID)

    # ──────────────────────────────────────────────────────────────────────────
    # Permission-only sync
    # ──────────────────────────────────────────────────────────────────────────

    async def run_permission_sync(self) -> "PermissionSyncResult":
        """
        Lightweight permission-only sync. No re-chunking, no embedding API calls.

        For every Confluence page currently in document_index:
          1. Fetch the latest page-level restrictions from the Confluence REST API.
          2. Compare against the stored permissions_acl.
          3. If the restrictions have changed:
               a. Update permissions_acl on the document_index row.
               b. Clear acl_user_ids on all knowledge_chunks for that document
                  so the ACL backfill (resolve_user_identities) can rebuild it.

        The caller is responsible for triggering resolve_user_identities for all
        users after this method returns, so that acl_user_ids is repopulated from
        the freshly updated permissions_acl.

        Returns
        -------
        PermissionSyncResult
            pages_checked  — total documents inspected
            pages_changed  — documents whose permissions actually changed
            pages_failed   — documents that raised an error during processing
        """
        indexed_docs: list[DocumentIndex] = await self._fetch_all_confluence_docs()

        if not indexed_docs:
            logger.info("permission_sync: status=skipped reason='no Confluence documents indexed'")
            return PermissionSyncResult(pages_checked=0, pages_changed=0, pages_failed=0)

        total_docs:    int = len(indexed_docs)
        total_changed: int = 0
        total_failed:  int = 0

        logger.info("permission_sync: status=started pages_to_check=%d", total_docs)

        async with ConfluenceConnector() as confluence:
            await confluence.connect()

            for doc in indexed_docs:
                page_id: Optional[str] = self._extract_page_id_from_url(doc.source_url or "")

                if not page_id:
                    logger.warn(
                        "permission_sync: status=skipped_page reason='page_id not found in URL' "
                        "doc_id=%s source_url=%r",
                        doc.doc_id, doc.source_url,
                    )
                    continue

                try:
                    fresh_permissions: dict = await confluence.get_permissions(page_id)
                    fresh_user_ids:    list[str] = fresh_permissions["user_ids"]
                    fresh_groups:      list[str] = fresh_permissions["groups"]
                    stored_acl:        dict      = doc.permissions_acl or {}

                    if not self._has_permissions_changed(stored_acl, fresh_user_ids, fresh_groups):
                        continue

                    updated_acl: dict = self._build_permissions_acl(fresh_user_ids, fresh_groups)

                    await self._update_document_acl(doc_id=doc.doc_id, new_acl=updated_acl)
                    self._clear_chunk_acl_users(doc_id=str(doc.doc_id))

                    logger.info(
                        "permission_sync: status=permission_updated "
                        "doc_id=%s page_id=%s previous_acl=%s updated_acl=%s",
                        doc.doc_id, page_id, stored_acl, updated_acl,
                    )
                    total_changed += 1

                except Exception as exc:
                    total_failed += 1
                    logger.error(
                        "permission_sync: status=page_failed "
                        "doc_id=%s page_id=%s error='%s'",
                        doc.doc_id, page_id, exc,
                    )

        logger.info(
            "permission_sync: status=completed "
            "pages_checked=%d pages_changed=%d pages_failed=%d",
            total_docs, total_changed, total_failed,
        )
        return PermissionSyncResult(
            pages_checked=total_docs,
            pages_changed=total_changed,
            pages_failed=total_failed,
        )

    # ── Private helpers ────────────────────────────────────────────────────────

    async def _fetch_all_confluence_docs(self) -> list[DocumentIndex]:
        """Return all document_index rows for the Confluence connector."""
        query_result = await self._db.execute(
            select(DocumentIndex).where(DocumentIndex.connector_id == _CONNECTOR_ID)
        )
        return list(query_result.scalars().all())

    async def _update_document_acl(self, doc_id, new_acl: dict) -> None:
        """Persist the updated permissions_acl on the document_index row."""
        await self._db.execute(
            update(DocumentIndex)
            .where(DocumentIndex.doc_id == doc_id)
            .values(permissions_acl=new_acl)
        )
        await self._db.commit()

    @staticmethod
    def _extract_page_id_from_url(source_url: str) -> Optional[str]:
        """Extract the numeric Confluence page ID from a source URL.

        Returns None if the URL does not contain a recognisable page ID segment.
        """
        match = _CONFLUENCE_PAGE_ID_RE.search(source_url)
        return match.group(1) if match else None

    @staticmethod
    def _has_permissions_changed(
        stored_acl:    dict,
        fresh_user_ids: list[str],
        fresh_groups:   list[str],
    ) -> bool:
        """Return True if the fresh Confluence restrictions differ from stored_acl."""
        stored_user_ids: set[str] = set(stored_acl.get("connector_account_ids", []))
        stored_groups:   set[str] = set(stored_acl.get("roles", []))
        stored_is_public: bool    = stored_acl.get("public", False)

        fresh_is_restricted: bool = bool(fresh_user_ids or fresh_groups)

        # Public → restricted  or  restricted → public
        if stored_is_public != (not fresh_is_restricted):
            return True

        # Explicit user list changed
        if stored_user_ids != set(fresh_user_ids):
            return True

        # Group list changed
        if stored_groups != set(fresh_groups):
            return True

        return False

    @staticmethod
    def _build_permissions_acl(user_ids: list[str], groups: list[str]) -> dict:
        """Build a permissions_acl dict from fresh Confluence restrictions.

        An empty user_ids and groups means the page is unrestricted (public).
        """
        if not user_ids and not groups:
            return {"public": True}

        acl: dict = {}
        if groups:
            acl["roles"] = groups
        if user_ids:
            acl["connector_account_ids"] = user_ids
        return acl

    @staticmethod
    def _clear_chunk_acl_users(doc_id: str) -> None:
        """Reset acl_user_ids to empty on all knowledge_chunks for this document.

        Uses psycopg2 (sync) — same pattern as _acl_backfill in tasks.py to
        avoid asyncpg uuid[] array-cast issues. After clearing, the subsequent
        resolve_user_identities backfill will repopulate acl_user_ids from the
        freshly updated permissions_acl.
        """
        db_cfg = settings.db
        conn = psycopg2.connect(
            host=db_cfg.host,
            port=db_cfg.port,
            user=db_cfg.username,
            password=db_cfg.password,
            dbname=db_cfg.database,
        )
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE enterprise_rag_system.knowledge_chunks
                    SET    acl_user_ids = '{}'
                    WHERE  doc_id = %s::uuid
                """, (doc_id,))
                rows_cleared: int = cur.rowcount

            conn.commit()
            logger.info(
                "permission_sync: cleared acl_user_ids on %d chunks doc_id=%s",
                rows_cleared, doc_id,
            )
        finally:
            conn.close()


# ──────────────────────────────────────────────────────────────────────────────
# Result type
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PermissionSyncResult:
    """Outcome of a single run_permission_sync() call."""
    pages_checked: int
    pages_changed: int
    pages_failed:  int
