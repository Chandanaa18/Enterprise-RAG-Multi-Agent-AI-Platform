from __future__ import annotations

import re
import uuid
from typing import List, Optional

from app.shared.exceptions.connector_exceptions import ConfluenceAPIError
from app.shared.enums import ConnectorType
from app.shared.exceptions.base_exception import ConnectorUnavailableError
from app.domains.confluence.repositories.confluence_repository import ConfluenceAdapter
from app.domains.confluence.schemas.schemas import ConfluenceSearchResultSchema
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)
_STOP_WORDS = frozenset(
    "how do i a an the to is in of and or what where when why can my for be "
    "are was were has have had will would could should".split()
)

# Simple chunk type used by the Confluence service for RAG retrieval
from dataclasses import dataclass, field as dc_field


@dataclass(frozen=True)
class Chunk:
    id: str
    text: str
    source: str
    score: float
    metadata: dict = dc_field(default_factory=dict)


class ConfluenceService:

    name = ConnectorType.CONFLUENCE.value
    enabled = True

    def __init__(self, adapter: ConfluenceAdapter) -> None:
        self._adapter = adapter

    async def search(
        self,
        query: str,
        *,
        space_keys: Optional[List[str]] = None,
        limit: Optional[int] = 25,
    ) -> List[ConfluenceSearchResultSchema]:
        cql = _build_cql(query, space_keys=space_keys)
        logger.info("ConfluenceService.search cql=%r limit=%s", cql, limit)

        try:
            results = await self._adapter.search_pages(cql, limit=limit)
        except ConfluenceAPIError as exc:
            raise ConnectorUnavailableError(ConnectorType.CONFLUENCE.value, details=str(exc)) from exc

        keywords = _extract_keywords(query)
        for result in results:
            result.score = _overlap_score(keywords, f"{result.title} {result.excerpt or ''}")

        return sorted(results, key=lambda r: r.score, reverse=True)



def _build_cql(query: str, *, space_keys: Optional[List[str]] = None) -> str:
    keywords = _extract_keywords(query)
    search_term = " ".join(keywords[:4]) if keywords else query.strip()
    search_term = search_term.replace('"', '\\"')

    space_clause = ""
    if space_keys:
        quoted = ", ".join(f'"{k}"' for k in space_keys)
        space_clause = f" AND space IN ({quoted})"

    return f'type = "page" AND text ~ "{search_term}"{space_clause}'


def _extract_keywords(query: str) -> List[str]:
    tokens = re.findall(r"[a-zA-Z0-9]+", query.lower())
    return [t for t in tokens if t not in _STOP_WORDS and len(t) > 2]


def _overlap_score(keywords: List[str], text: str) -> float:
    if not keywords:
        return 0.0
    word_set = set(re.findall(r"[a-zA-Z0-9]+", text.lower()))
    return round(len(set(keywords) & word_set) / len(keywords), 4)


def _extract_roles(labels: List[str]) -> List[str]:
    return [lbl[len("role:"):] for lbl in labels if lbl.startswith("role:")]


def _role_permitted(page_roles: List[str], caller_roles: List[str]) -> bool:
    if not page_roles:
        return True
    return bool(set(page_roles) & set(caller_roles))
