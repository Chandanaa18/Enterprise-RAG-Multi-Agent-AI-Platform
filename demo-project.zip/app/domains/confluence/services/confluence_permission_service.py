"""
ConfluencePermissionService — fetches and normalises Confluence ACL data.

Responsibilities
----------------
* Call the Confluence REST API to retrieve space-level and page-level permissions.
* Extract which groups are allowed to read a given Confluence space.
* Extract which users are explicitly allowed to read a given page.
* Normalise the raw Confluence API response into the standard permission format
  used by the rest of the permission-aware retrieval pipeline.

Design notes
------------
This service is Confluence-specific.  Adding SharePoint, Jira, or Teams
permission fetching means creating a parallel service (e.g.
SharePointPermissionService) with the same public interface — the retrieval
pipeline never needs to change.

The service is fully async (httpx.AsyncClient) so it does not block the
event loop when called from async sync methods in ConfluenceConnector.
"""
from __future__ import annotations

import logging

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)
# ---------------------------------------------------------------------------
# Confluence Cloud REST API path templates
# ---------------------------------------------------------------------------

# Returns a list of space permissions (requires space-admin or Confluence-admin).
_SPACE_PERMISSIONS_PATH = "/wiki/rest/api/space/{space_key}/permission"



class ConfluencePermissionService:
    """
    Fetches access-control data from the Confluence REST API and converts it
    into the standard format consumed by the MetadataFilterBuilder.

    Parameters
    ----------
    base_url
        Root URL of the Confluence instance (e.g. "https://yourco.atlassian.net").
        Defaults to settings.confluence.base_url.
    email
        Atlassian account email used for Basic Auth.
        Defaults to settings.confluence.email.
    api_token
        Atlassian API token used for Basic Auth.
        Defaults to settings.confluence.api_token.
    """

    def __init__(
        self,
        base_url:  str | None = None,
        email:     str | None = None,
        api_token: str | None = None,
    ) -> None:
        self._base_url  = (base_url  or settings.confluence.base_url).rstrip("/")
        self._email     = email      or settings.confluence.email
        self._api_token = api_token  or settings.confluence.api_token

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    async def get_allowed_groups_for_space(self, space_key: str) -> list[str]:
        """
        Return the names of all groups that have 'read' permission on the space.

        Parameters
        ----------
        space_key
            The Confluence space key (e.g. "ENGINEERING", "HR").

        Returns
        -------
        list[str]
            Normalised group names with read access to this space.
            Returns an empty list if the API call fails (fail-open — content-
            level ACL in the database remains the authoritative guard).
        """
        raw_permission_entries = await self._fetch_space_permissions(space_key)
        return _extract_groups_with_read_access(raw_permission_entries)

    # ------------------------------------------------------------------
    # Private API callers
    # ------------------------------------------------------------------

    async def _fetch_space_permissions(self, space_key: str) -> list[dict]:
        """
        Call the Confluence space permissions endpoint and return the results list.

        Returns an empty list on any HTTP or network error.  Permission
        enforcement at the vector-store ACL layer is not bypassed by this
        failing — it is an enhancement layer, not the primary guard.
        """
        url = self._base_url + _SPACE_PERMISSIONS_PATH.format(space_key=space_key)

        try:
            async with httpx.AsyncClient(
                auth=(self._email, self._api_token),
                timeout=10.0,
            ) as client:
                response = await client.get(url)
                response.raise_for_status()
                payload = response.json()
                return payload.get("results", [])

        except httpx.HTTPStatusError as exc:
            logger.warning(
                "Confluence space permissions API returned HTTP %s "
                "for space_key=%s — returning empty permissions",
                exc.response.status_code,
                space_key,
            )
            return []

        except Exception as exc:
            logger.warning(
                "Failed to fetch Confluence space permissions for space_key=%s: %s",
                space_key,
                exc,
            )
            return []



# ---------------------------------------------------------------------------
# Module-level pure functions (no side effects — straightforward to unit-test)
# ---------------------------------------------------------------------------

def _extract_groups_with_read_access(
    permission_entries: list[dict],
) -> list[str]:
    """
    Walk a list of Confluence space permission entries and return the names of
    all groups that have a 'read' or 'view' type operation.

    Confluence Cloud v1 space permission entry shape:
        {
          "id": "...",
          "operation": {"key": "read", "target": "space"},
          "subjects": {
            "group": {"results": [{"name": "engineering", ...}]},
            "user":  {"results": []}
          }
        }

    Parameters
    ----------
    permission_entries
        Raw list of permission entries returned by the Confluence API.

    Returns
    -------
    list[str]
        Group names that have read/view access to the space.
    """
    allowed_groups: list[str] = []
    read_operation_keys = {"read", "view"}

    for entry in permission_entries:
        operation_key = entry.get("operation", {}).get("key", "").lower()
        if operation_key not in read_operation_keys:
            continue

        group_results = (
            entry.get("subjects", {}).get("group", {}).get("results", [])
        )
        for group_entry in group_results:
            group_name = group_entry.get("name") or ""
            if group_name:
                allowed_groups.append(group_name)

    return allowed_groups


