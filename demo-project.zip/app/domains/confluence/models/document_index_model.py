"""DocumentIndex ORM model — strict to spec §4."""
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Integer, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.infrastructure.database.database import Base


class DocumentIndex(Base):
    __tablename__ = "document_index"
    __table_args__ = {"schema": "enterprise_rag_system"}

    doc_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    connector_id: Mapped[Optional[str]] = mapped_column(
        Text,
        ForeignKey("enterprise_rag_system.connector_configs.connector_id"),
        nullable=True,
        index=True,
    )
    source_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True, index=True)
    title: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    last_synced_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    permissions_acl: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict, nullable=True)
    chunk_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    # Python attr is metadata_ to avoid clash with SQLAlchemy's reserved .metadata
    metadata_: Mapped[Optional[dict]] = mapped_column("metadata", JSONB, default=dict, nullable=True)

    connector = relationship("ConnectorConfig", back_populates="documents")
