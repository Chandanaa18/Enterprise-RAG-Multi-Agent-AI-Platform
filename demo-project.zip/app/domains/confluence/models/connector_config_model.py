from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import Boolean, DateTime, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column

from app.infrastructure.database.database import Base

class ConnectorConfig(Base):
    __tablename__ = "connector_configs"
    __table_args__ = {'schema': 'enterprise_rag_system'}

    connector_id: Mapped[str] = mapped_column(Text, primary_key=True)
    connector_name: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    config: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict, nullable=True)
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    documents = relationship("DocumentIndex", back_populates="connector")
