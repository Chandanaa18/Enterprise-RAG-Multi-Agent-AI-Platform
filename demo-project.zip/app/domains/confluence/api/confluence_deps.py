from __future__ import annotations

from typing import AsyncIterator

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.domains.confluence.connector.confluence_connector import ConfluenceConnector
from app.infrastructure.database.database import get_db
from app.domains.confluence.repositories.confluence_repository import ConfluenceAdapter
from app.domains.confluence.services.confluence_service import ConfluenceService
from app.domains.confluence.services.confluence_sync_service import ConfluenceSyncService


async def _get_connector() -> AsyncIterator[ConfluenceConnector]:
    async with ConfluenceConnector() as connector:
        yield connector


async def get_confluence_service(
    connector: ConfluenceConnector = Depends(_get_connector),
) -> ConfluenceService:
    return ConfluenceService(ConfluenceAdapter(connector))


async def get_confluence_sync_service(
    db: AsyncSession = Depends(get_db),
) -> ConfluenceSyncService:
    return ConfluenceSyncService(db)
