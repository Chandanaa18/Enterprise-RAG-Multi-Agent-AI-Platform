from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query

from app.domains.confluence.api.confluence_deps import get_confluence_sync_service
from app.domains.confluence.schemas.schemas import SyncStatusResponse
from app.domains.confluence.services.confluence_sync_service import ConfluenceSyncService
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)

confluence_router = APIRouter(prefix="/confluence", tags=["Confluence"])


@confluence_router.post(
    "/sync",
    response_model=SyncStatusResponse,
    summary="Trigger incremental Confluence sync",
)
async def trigger_sync(
    space_keys: Optional[str] = Query(
        None, description="Comma-separated space keys to sync (None = all)"
    ),
    limit: Optional[int] = Query(
        None, ge=1, le=5000, description="Cap total pages fetched"
    ),
    force_full: bool = Query(
        False, description="Ignore last_sync_at and re-fetch all pages"
    ),
    sync_service: ConfluenceSyncService = Depends(get_confluence_sync_service),
) -> SyncStatusResponse:
    logger.info(
        "POST /confluence/sync space_keys=%s limit=%s force_full=%s",
        space_keys, limit, force_full,
    )
    keys = [k.strip() for k in space_keys.split(",") if k.strip()] if space_keys else None
    return await sync_service.run_sync(space_keys=keys, limit=limit, force_full=force_full)
