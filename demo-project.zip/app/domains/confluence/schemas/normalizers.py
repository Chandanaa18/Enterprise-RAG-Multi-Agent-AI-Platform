from __future__ import annotations

from typing import Optional

from app.domains.confluence.schemas.schemas import (
    ConfluenceAttachmentSchema,
    ConfluencePageSchema,
    ConfluenceSearchResultSchema,
    ConfluenceSpaceSchema,
    ConfluenceVersionSchema,
)
from app.shared.helpers.date_utils import parse_datetime
from app.shared.helpers.html_utils import clean_html


def normalize_space(raw: dict) -> ConfluenceSpaceSchema:
    desc_obj = raw.get("description") or {}
    description: Optional[str] = None
    if isinstance(desc_obj, dict):
        description = desc_obj.get("plain", {}).get("value") or None
    elif isinstance(desc_obj, str):
        description = desc_obj or None

    return ConfluenceSpaceSchema(
        id=str(raw.get("id", "")),
        key=raw.get("key", ""),
        name=raw.get("name", ""),
        type=raw.get("type", "global"),
        status=raw.get("status", "current"),
        description=description,
        homepage_id=str(raw["homepageId"]) if raw.get("homepageId") else None,
    )


def normalize_page(raw: dict) -> ConfluencePageSchema:
    label_list = (
        raw.get("metadata", {}).get("labels", {}).get("results", [])
        or raw.get("labels", {}).get("results", [])
    )
    labels = [
        lbl["name"]
        for lbl in label_list
        if isinstance(lbl, dict) and lbl.get("name")
    ]

    body_text: Optional[str] = None
    body = raw.get("body", {}) or {}
    for fmt in ("view", "storage", "export_view"):
        section = body.get(fmt)
        if isinstance(section, dict):
            html = section.get("value", "")
            if html:
                body_text = clean_html(html)
                break

    version_raw = raw.get("version") or {}
    version: Optional[ConfluenceVersionSchema] = None
    if version_raw:
        version = ConfluenceVersionSchema(
            number=version_raw.get("number", 1),
            created_at=parse_datetime(version_raw.get("when")),
            author_display_name=(
                version_raw.get("by", {}).get("displayName")
                if isinstance(version_raw.get("by"), dict)
                else None
            ),
        )

    space = raw.get("space") or {}
    space_key: Optional[str] = space.get("key") or raw.get("spaceKey") or None
    space_id_raw = space.get("id") or raw.get("spaceId")
    space_id: Optional[str] = str(space_id_raw) if space_id_raw else None

    web_url: Optional[str] = raw.get("_links", {}).get("webui") or None

    return ConfluencePageSchema(
        id=str(raw.get("id", "")),
        title=raw.get("title", ""),
        space_id=space_id,
        space_key=space_key,
        status=raw.get("status", "current"),
        body_text=body_text,
        web_url=web_url,
        labels=labels,
        version=version,
        parent_id=str(raw["parentId"]) if raw.get("parentId") else None,
        created_at=parse_datetime(
            raw.get("createdAt")
            or (raw.get("history") or {}).get("createdDate")
        ),
        updated_at=parse_datetime(version_raw.get("when") if version_raw else None),
    )


def normalize_search_result(raw: dict) -> ConfluenceSearchResultSchema:
    label_list = raw.get("metadata", {}).get("labels", {}).get("results", [])
    labels = [
        lbl["name"]
        for lbl in label_list
        if isinstance(lbl, dict) and lbl.get("name")
    ]

    space = raw.get("space") or {}
    space_key: Optional[str] = space.get("key") or raw.get("spaceKey") or None
    web_url: Optional[str] = raw.get("_links", {}).get("webui") or None

    return ConfluenceSearchResultSchema(
        id=str(raw.get("id", "")),
        title=raw.get("title", ""),
        space_key=space_key,
        excerpt=raw.get("excerpt") or None,
        web_url=web_url,
        score=0.0,
        labels=labels,
    )


def normalize_attachment(raw: dict) -> ConfluenceAttachmentSchema:
    extensions = raw.get("extensions") or {}
    links = raw.get("_links") or {}
    return ConfluenceAttachmentSchema(
        id=str(raw.get("id", "")),
        title=raw.get("title", ""),
        file_size=extensions.get("fileSize"),
        media_type=extensions.get("mediaType"),
        download_url=links.get("download"),
        created_at=parse_datetime(raw.get("createdAt")),
    )
