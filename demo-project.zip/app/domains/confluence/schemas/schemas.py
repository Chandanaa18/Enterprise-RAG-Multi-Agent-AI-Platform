from datetime import datetime
from typing import Any, Dict, Generic, List, Optional, TypeVar
from pydantic import BaseModel, Field
from app.shared.exceptions.error_enums import HealthStatus, SyncStatus
from app.shared.enums import ConnectorType

T = TypeVar("T")



# Canonical normalized document — shared across all connectors
class NormalizedDocument(BaseModel):
    document_id: str
    title: str
    content: str
    source: str                                    # e.g. "Confluence"
    author: Optional[str] = None
    space: Optional[str] = None
    url: Optional[str] = None
    last_modified: Optional[datetime] = None
    permissions: List[str] = Field(default_factory=list)         # role/group names → acl_roles
    allowed_user_ids: List[str] = Field(default_factory=list)    # specific user IDs → acl_user_ids
    metadata: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"from_attributes": True}



class ConfluenceSpaceSchema(BaseModel):
    id: str
    key: str
    name: str
    type: str = "global"
    status: str = "current"
    description: Optional[str] = None
    homepage_id: Optional[str] = None

    model_config = {"from_attributes": True}


class ConfluenceVersionSchema(BaseModel):
    number: int
    created_at: Optional[datetime] = None
    author_display_name: Optional[str] = None


class ConfluencePageSchema(BaseModel):
    id: str
    title: str
    space_id: Optional[str] = None
    space_key: Optional[str] = None
    status: str = "current"
    body_text: Optional[str] = None
    web_url: Optional[str] = None
    labels: List[str] = Field(default_factory=list)
    version: Optional[ConfluenceVersionSchema] = None
    parent_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ConfluenceSearchResultSchema(BaseModel):
    id: str
    title: str
    space_key: Optional[str] = None
    excerpt: Optional[str] = None
    web_url: Optional[str] = None
    score: float = 0.0
    labels: List[str] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class ConfluenceAttachmentSchema(BaseModel):
    id: str
    title: str
    file_size: Optional[int] = None
    media_type: Optional[str] = None
    download_url: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


# Sync and health response schemas (used by routes)
class SyncStatusResponse(BaseModel):
    connector: ConnectorType
    status: SyncStatus
    pages_synced: int = 0
    last_sync_time: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    error: Optional[str] = None


class HealthResponse(BaseModel):
    connector: ConnectorType
    status: HealthStatus
    latency_ms: Optional[float] = None
    error: Optional[str] = None



# Generic paginated envelope
class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    limit: int
    page: int = 1

    model_config = {"from_attributes": True}
