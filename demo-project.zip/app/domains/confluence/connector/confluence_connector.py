from __future__ import annotations

import base64
import logging
import time
from datetime import datetime
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from app.connectors.base.base_connector import BaseConnector
from app.domains.confluence.schemas.normalizers import (
    normalize_attachment,
    normalize_page,
    normalize_search_result,
    normalize_space,
)
from app.domains.confluence.schemas.schemas import (
    ConfluenceAttachmentSchema,
    ConfluencePageSchema,
    ConfluenceSearchResultSchema,
    ConfluenceSpaceSchema,
    NormalizedDocument,
)
from app.shared.helpers.html_utils import clean_html
from app.shared.exceptions.connector_exceptions import (
    ConfluenceAPIError,
    ConfluenceAuthError,
    ConfluenceNotFoundError,
    ConfluenceRateLimitError,
    ConfluenceServerError,
    with_confluence_retry,
)
from app.shared.exceptions.error_enums import HealthStatus
from app.shared.enums import ConnectorType
from app.core.config import settings as envSettings
from app.domains.confluence.services.confluence_permission_service import ConfluencePermissionService
logger = logging.getLogger(__name__)


class ConfluenceConnector(BaseConnector):
    """
    API versions used:
      - v1 (/wiki/rest/api)  — search, content restrictions
      - v2 (/wiki/api/v2)    — spaces, pages, attachments

    """

    name = ConnectorType.CONFLUENCE.value

    _V1 = "/wiki/rest/api"
    _V2 = "/wiki/api/v2"

    def __init__(self) -> None:
        self._settings = envSettings.confluence
        self._base_url = (self._settings.base_url or "").rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def base_url(self) -> str:
        return self._base_url


    async def __aenter__(self) -> "ConfluenceConnector":
        self._client = self._build_client()
        logger.info("Confluence: HTTP client opened → %s", self._base_url)
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None
            logger.info("Confluence: HTTP client closed")

    def _build_client(self) -> httpx.AsyncClient:
        raw = f"{self._settings.email}:{self._settings.api_token}"
        token = base64.b64encode(raw.encode()).decode()
        return httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Basic {token}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-Atlassian-Token": "no-check",
            },
            timeout=self._settings.timeout_seconds,
            follow_redirects=True,
        )

    @property
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError(
                "ConfluenceConnector is not open. "
                "Use 'async with ConfluenceConnector(settings) as conn'."
            )
        return self._client


    # Confluence connect
    async def connect(self) -> bool:
        
        if self._client is None:
            self._client = self._build_client()

        logger.info(
            "Confluence: authenticating — user=%s base=%s",
            self._settings.email, self._base_url,
        )
        await self._get(f"{self._V1}/space", {"limit": 1})
        logger.info("Confluence: authentication successful")
        return True



    async def _get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        async def request() -> Dict[str, Any]:
            
            logger.debug("Confluence GET %s params=%s", path, params)
            
            response = await self._http.get(path, params=params)
            self._raise_for_status(response)
            return response.json()

        return await with_confluence_retry(
            request,
            max_retries=self._settings.max_retries,
            backoff=self._settings.retry_backoff,
        )

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.is_success:
            return
        
        url = str(response.url)
        body = response.text[:400]
        
        status_code = response.status_code
        if status_code in (401, 403):
            raise ConfluenceAuthError(status_code, body, url)
        if status_code == 404:
            raise ConfluenceNotFoundError(status_code, body, url)
        if status_code == 429:
            retry_after = response.headers.get("Retry-After", "unknown")
            raise ConfluenceRateLimitError(status_code, f"retry-after={retry_after}s", url)
        if status_code >= 500:
            raise ConfluenceServerError(status_code, body, url)
        raise ConfluenceAPIError(status_code, body, url)


    # Paginated Result
    async def fetch_paginated_results(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        limit: Optional[int] = None,
        use_cursor: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Collect all items from a paginated endpoint into a flat list.

        use_cursor=True  → Confluence v2 cursor pagination  (_links.next)
        use_cursor=False → Confluence v1 offset pagination  (start / totalSize)
        """
        if use_cursor:
            return [item async for item in self._paginate_cursor(path, params, limit=limit)]
        return await self._paginate_offset(path, params, limit=limit)

    async def _paginate_cursor(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        limit: Optional[int] = None,
        max_pages: int = 200,
    ) -> AsyncIterator[Dict[str, Any]]:
        """Yield items following Confluence v2 cursor (_links.next) pagination."""
        active_params: Dict[str, Any] = {**(params or {})}
        if limit:
            active_params["limit"] = limit
        active_path = path
        pages_fetched = 0

        while pages_fetched < max_pages:
            data = await self._get(active_path, active_params)
            for item in data.get("results", []):
                yield item

            pages_fetched += 1
            next_link: Optional[str] = data.get("_links", {}).get("next")
            if not next_link:
                break

            if "?" in next_link:
                active_path, qs = next_link.split("?", 1)
                active_params = {
                    k: v
                    for pair in qs.split("&")
                    if "=" in pair
                    for k, v in [pair.split("=", 1)]
                }
            else:
                active_path = next_link
                active_params = {}

    async def _paginate_offset(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Collect items using Confluence v1 start/totalSize offset pagination."""
        page_size = 50  # Confluence API max per request
        active_params: Dict[str, Any] = {
            **(params or {}),
            "limit": page_size,
            "start": 0,
        }
        results: List[Dict[str, Any]] = []

        while True:
            data = await self._get(path, active_params)
            batch: List[Dict[str, Any]] = data.get("results", [])
            results.extend(batch)
            total = data.get("totalSize")
            active_params["start"] = len(results)

            logger.debug(
                "Confluence offset page: fetched=%d total=%s path=%s",
                len(results), total, path,
            )
            if not batch or len(batch) < page_size:
                break
            if total is not None and len(results) >= total:
                break
            if limit and len(results) >= limit:
                break

        return results[:limit] if limit else results


    async def get_spaces(
        self,
        *,
        limit: Optional[int] = None,
        status: str = "current",
    ) -> List[ConfluenceSpaceSchema]:
        logger.info("Confluence: fetching spaces")
        raw = await self.fetch_paginated_results(
            f"{self._V2}/spaces",
            {"status": status},
            limit=limit,
            use_cursor=True,
        )
        spaces = [normalize_space(s) for s in raw]
        logger.info("Confluence: fetched %d spaces", len(spaces))
        return spaces

    async def get_pages(
        self,
        *,
        space_id: Optional[str] = None,
        space_key: Optional[str] = None,
        limit: Optional[int] = None,
        status: str = "current",
    ) -> List[ConfluencePageSchema]:
        logger.info("Confluence: fetching pages space_id=%s space_key=%s", space_id, space_key)
        if space_id:
            raw = await self.fetch_paginated_results(
                f"{self._V2}/spaces/{space_id}/pages",
                {"status": status, "body-format": "storage"},
                limit=limit,
                use_cursor=True,
            )
        else:
            space_clause = f' AND space = "{space_key}"' if space_key else ""
            cql = f'type = "page"{space_clause}'
            raw = await self.fetch_paginated_results(
                f"{self._V1}/content/search",
                {"cql": cql, "expand": "body.storage,space,version,metadata.labels"},
                limit=limit,
                use_cursor=False,
            )
        pages = [normalize_page(p) for p in raw]
        logger.info("Confluence: fetched %d pages", len(pages))
        return pages

    async def get_page_by_id(
        self,
        page_id: str,
        *,
        body_format: str = "storage",
        include_labels: bool = True,
        include_version: bool = True,
    ) -> ConfluencePageSchema:
        logger.info("Confluence: fetching page id=%s", page_id)
        params: Dict[str, Any] = {"body-format": body_format}
        if include_labels:
            params["include-labels"] = "true"
        if include_version:
            params["include-version"] = "true"
        raw = await self._get(f"{self._V2}/pages/{page_id}", params)
        logger.info("Confluence: fetched page id=%s title=%r", page_id, raw.get("title"))
        return normalize_page(raw)

    async def search_pages(
        self,
        cql: str,
        *,
        limit: Optional[int] = None,
    ) -> List[ConfluenceSearchResultSchema]:
        logger.info("Confluence: searching pages cql=%r", cql)
        raw = await self.fetch_paginated_results(
            f"{self._V1}/content/search",
            {"cql": cql, "expand": "body.storage,space,version,metadata.labels"},
            limit=limit,
            use_cursor=False,
        )
        results = [normalize_search_result(r) for r in raw]
        logger.info("Confluence: search returned %d results", len(results))
        return results

    async def get_attachments(
        self,
        page_id: str,
        *,
        limit: Optional[int] = None,
    ) -> List[ConfluenceAttachmentSchema]:
        logger.info("Confluence: fetching attachments page_id=%s", page_id)
        raw = await self.fetch_paginated_results(
            f"{self._V2}/pages/{page_id}/attachments",
            limit=limit,
            use_cursor=True,
        )
        attachments = [normalize_attachment(a) for a in raw]
        logger.info("Confluence: fetched %d attachments page_id=%s", len(attachments), page_id)
        return attachments

    async def get_updated_pages(
        self,
        last_sync: Optional[datetime] = None,
        *,
        space_keys: Optional[List[str]] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Incremental fetch — return only pages modified after `last_sync`.

        Uses CQL  `lastModified > "YYYY-MM-DD HH:MM"` for efficiency.
        last_sync=None triggers a full fetch (no date filter).
        Results are ordered oldest-first so the sync service can resume safely.
        """
        cql_parts = ['type = "page"']

        if last_sync:
            ts = last_sync.strftime("%Y-%m-%d %H:%M")
            cql_parts.append(f'lastModified > "{ts}"')

        if space_keys:
            quoted = ", ".join(f'"{k}"' for k in space_keys)
            cql_parts.append(f"space IN ({quoted})")

        cql = " AND ".join(cql_parts) + " ORDER BY lastModified ASC"
        logger.info(
            "Confluence: get_updated_pages last_sync=%s space_keys=%s cql=%r",
            last_sync, space_keys, cql,
        )

        results = await self.fetch_paginated_results(
            f"{self._V1}/content/search",
            {
                "cql": cql,
                "expand": "body.storage,space,version,metadata.labels,history",
            },
            limit=limit,   # None = no cap, paginate until all results exhausted
            use_cursor=False,
        )
        logger.info("Confluence: get_updated_pages → %d pages", len(results))
        return results

    async def fetch(self, **kwargs: Any) -> List[Any]:
        """Generic fetch — delegates to get_pages() with keyword args."""
        return await self.get_pages(**kwargs)


    async def get_permissions(self, page_id: str) -> Dict[str, List[str]]:
        """
        Fetch read restrictions for a page from the Confluence v1 restrictions API.

        Returns a dict with two keys:
            "user_ids"  — list of accountId strings who have explicit read access
            "groups"    — list of group names that have explicit read access

        An empty result (both lists empty) means no restrictions are set — the
        page is accessible to everyone (public within the space).

        Confluence API: GET /wiki/rest/api/content/{id}/restriction/byOperation/read
        """
        try:
            data = await self._get(
                f"{self._V1}/content/{page_id}/restriction/byOperation/read",
            )
        except (ConfluenceNotFoundError, ConfluenceAuthError):
            # 404 = no restrictions set (page is public), 403 = no permission to read restrictions
            return {"user_ids": [], "groups": []}

        restrictions = data.get("restrictions", {})

        user_ids: List[str] = [
            u.get("accountId", "")
            for u in restrictions.get("user", {}).get("results", [])
            if u.get("accountId")
        ]
        groups: List[str] = [
            g.get("name", "")
            for g in restrictions.get("group", {}).get("results", [])
            if g.get("name")
        ]

        return {"user_ids": user_ids, "groups": groups}

    async def _fetch_full_page_body(self, page_id: str, search_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fetch a page's complete body from the v2 API.

        The v1 content/search API silently truncates ``body.storage`` for large
        pages.  This method re-fetches the page individually via the v2 API,
        which always returns the full untruncated content.

        v1-only metadata fields (space, version, history, labels) are not
        returned by the v2 pages endpoint, so they are copied from the original
        v1 search result so that ``_normalize`` can still access them.

        Returns the enriched v2 page dict, or the original search result dict
        if the v2 fetch fails (with a warning logged).
        """
        V1_ONLY_FIELDS = ("space", "spaceKey", "version", "history", "metadata")
        try:
            full_page = await self._get(
                f"{self._V2}/pages/{page_id}",
                {"body-format": "storage"},
            )
            for field in V1_ONLY_FIELDS:
                if field in search_result and field not in full_page:
                    full_page[field] = search_result[field]
            return full_page

        except Exception as exc:
            logger.warning(
                "Confluence: failed to fetch full page body for page_id=%s "
                "— falling back to (possibly truncated) search result. error=%s",
                page_id,
                exc,
            )
            return search_result

    async def sync(
        self,
        last_sync: Optional[datetime] = None,
        *,
        space_keys: Optional[List[str]] = None,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> List[NormalizedDocument]:
        """
        Incremental synchronization.

        1. Fetch pages modified after `last_sync` (full sync if None).
        2. Re-fetch each page individually via the v2 API to get the full,
           untruncated body — the v1 search API silently truncates large pages.
        3. Normalize each page to NormalizedDocument.
        4. Fetch per-page restrictions and populate allowed_user_ids / permissions.
           If a page has no page-level restrictions, fall back to space-level group
           permissions so the page is not incorrectly marked as public.
        5. Return the list — DB bookkeeping is the caller's responsibility.
        """
        logger.info(
            "Confluence: sync started last_sync=%s space_keys=%s", last_sync, space_keys
        )
        search_results = await self.get_updated_pages(
            last_sync, space_keys=space_keys, limit=limit
        )

        # Build one ConfluencePermissionService instance for space-level lookups.
        # Cache space group results so we don't re-fetch the same space repeatedly.
        perm_service = ConfluencePermissionService()
        space_groups_cache: dict[str, list[str]] = {}

        docs: List[NormalizedDocument] = []
        for search_result in search_results:
            page_id = str(search_result.get("id", ""))

            # Re-fetch the full page body via v2 API to avoid v1 search truncation.
            if page_id:
                raw_page = await self._fetch_full_page_body(page_id, search_result)
            else:
                raw_page = search_result

            doc = self._normalize(raw_page)

            if page_id:
                perms = await self.get_permissions(page_id)
                page_user_ids: list[str] = perms["user_ids"]
                page_groups:   list[str] = perms["groups"]

                # No page-level restrictions → fall back to space-level groups.
                # This prevents private-space pages from being stored as public.
                if not page_user_ids and not page_groups:
                    space_key: str = (
                        raw_page.get("space", {}).get("key")
                        or raw_page.get("spaceKey")
                        or ""
                    )
                    if space_key:
                        if space_key not in space_groups_cache:
                            space_groups_cache[space_key] = (
                                await perm_service.get_allowed_groups_for_space(space_key)
                            )
                        page_groups = space_groups_cache[space_key]
                        if page_groups:
                            logger.debug(
                                "page_id=%s has no page-level restrictions — "
                                "inheriting %d space groups from space=%s",
                                page_id, len(page_groups), space_key,
                            )

                doc = doc.model_copy(update={
                    "allowed_user_ids": page_user_ids,
                    "permissions":      page_groups,
                })
            docs.append(doc)

        logger.info("Confluence: sync produced %d normalized documents", len(docs))
        return docs



    async def health_check(self) -> Dict[str, Any]:
        """
        Verify connectivity by fetching one space.
        Always safe to call — opens/closes its own client if needed.
        """
        start = time.monotonic()
        own_client = False
        try:
            if self._client is None:
                self._client = self._build_client()
                own_client = True

            await self._get(f"{self._V1}/space", {"limit": 1})
            latency_ms = round((time.monotonic() - start) * 1000, 2)
            logger.info("Confluence health check: healthy (%.1f ms)", latency_ms)
            return {"connector": self.name, "status": HealthStatus.HEALTHY.value, "latency_ms": latency_ms}

        except Exception as exc:
            latency_ms = round((time.monotonic() - start) * 1000, 2)
            logger.error("Confluence health check: unhealthy — %s", exc)
            return {
                "connector": self.name,
                "status": HealthStatus.UNHEALTHY.value,
                "latency_ms": latency_ms,
                "error": str(exc),
            }
        finally:
            if own_client:
                await self.close()


    # Normalization — raw Confluence page → NormalizedDocument


    def _normalize(self, raw: Dict[str, Any]) -> NormalizedDocument:
        """
        Convert a raw Confluence page dict to NormalizedDocument.

        Handles field layout differences between API v1 and v2 responses.
        Permissions are not fetched here for performance; callers that need
        ACL data should call get_permissions(page_id) separately.
        """
        page_id = str(raw.get("id", ""))
        title = raw.get("title", "")

        # -- Body (try storage → view → export_view) --
        body = raw.get("body") or {}
        html_content = ""
        for fmt in ("storage", "view", "export_view"):
            section = body.get(fmt)
            if isinstance(section, dict):
                html_content = section.get("value", "")
                if html_content:
                    break
        content = clean_html(html_content) or title

        # -- Space --
        space = raw.get("space") or {}
        space_key: str = space.get("key") or raw.get("spaceKey") or ""

        # -- Author (version.by → history.createdBy fallback) --
        version = raw.get("version") or {}
        author: Optional[str] = None
        version_by = version.get("by") or {}
        if isinstance(version_by, dict):
            author = (
                version_by.get("displayName")
                or version_by.get("publicName")
                or version_by.get("username")
            )
        if not author:
            created_by = (raw.get("history") or {}).get("createdBy") or {}
            if isinstance(created_by, dict):
                author = created_by.get("displayName")

        # -- URL --
        links = raw.get("_links") or {}
        web_ui = links.get("webui", "")
        if web_ui:
            url = (
                web_ui
                if web_ui.startswith("http")
                else f"{self._base_url}/wiki{web_ui}"
            )
        else:
            url = f"{self._base_url}/wiki/spaces/{space_key}/pages/{page_id}"

        # -- Last modified --
        last_modified: Optional[datetime] = None
        version_when = version.get("when")
        if version_when:
            try:
                last_modified = datetime.fromisoformat(
                    version_when.replace("Z", "+00:00")
                )
            except (ValueError, AttributeError):
                pass

        # -- Labels --
        label_list = (
            (raw.get("metadata") or {}).get("labels", {}).get("results", [])
            or (raw.get("labels") or {}).get("results", [])
        )
        labels = [
            lbl["name"]
            for lbl in label_list
            if isinstance(lbl, dict) and lbl.get("name")
        ]

        return NormalizedDocument(
            document_id=page_id,
            title=title,
            content=content,
            source=ConnectorType.CONFLUENCE.value,
            author=author,
            space=space_key or None,
            url=url,
            last_modified=last_modified,
            permissions=[],     # populated on demand via get_permissions()
            metadata={
                "page_type": "documentation",
                "space_key": space_key,
                "version_number": version.get("number"),
                "labels": labels,
                "status": raw.get("status", "current"),
            },
        )
