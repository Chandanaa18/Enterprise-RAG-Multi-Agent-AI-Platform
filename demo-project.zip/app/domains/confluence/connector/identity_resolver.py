"""
Confluence Identity Resolver.

Maps an Azure AD email to an Atlassian accountId via the Confluence REST API.

Endpoint strategy (tried in order):
  1. GET /wiki/rest/api/user/search?query={email}  — Cloud standard
  2. GET /wiki/rest/api/user/picker?query={email}  — Cloud fallback
  3. return None — login proceeds unblocked; ingestion auto-resolves at sync time
     via the reverse path: accountId → user profile → email → internal user_id.
"""
from __future__ import annotations

import logging
from typing import Any

from app.domains.confluence.connector.confluence_connector import ConfluenceConnector
from app.infrastructure.identity.resolver_interface import ConnectorIdentityResolver
from app.shared.enums import ConnectorType

logger = logging.getLogger(__name__)


class ConfluenceIdentityResolver(ConnectorIdentityResolver):
    """
    Resolves an Azure AD email to an Atlassian accountId.

    Two endpoint strategies are tried in order. Returning None is safe:
    IngestionPipeline.auto_resolve handles the mapping at sync time via
    the reverse path (accountId → Confluence user profile → email → user).
    """

    @property
    def connector_name(self) -> str:
        return ConnectorType.CONFLUENCE.value

    async def resolve_identity(self, email: str) -> dict[str, Any] | None:
        """
        Resolve Atlassian accountId for an Azure AD email address.

        Tries /user/search then /user/picker. If both return 404 or no match,
        returns None. Login is never blocked regardless of outcome.
        """
        async with ConfluenceConnector() as connector:
            for strategy_name, fetch_fn in [
                ("jira/v3/user/search/full",       _fetch_via_jira_v3),            # full email query
                ("jira/v3/user/search/local",      _fetch_via_jira_v3_localpart),  # email local-part e.g. "chandana.r"
                ("jira/v3/user/search/firstname",  _fetch_via_jira_v3_firstname),  # first name e.g. "chandana"
                ("user/search",                    _fetch_via_search),             # Confluence Cloud standard
                ("user/picker",                    _fetch_via_picker),             # Confluence Cloud fallback
            ]:
                try:
                    results = await fetch_fn(connector, email)
                except Exception as exc:
                    logger.warning(
                        "confluence_identity strategy=%s email=%s — request failed: %s",
                        strategy_name, email, exc,
                    )
                    continue

                if not results:
                    logger.info(
                        "confluence_identity strategy=%s email=%s — no results",
                        strategy_name, email,
                    )
                    continue

                logger.debug(
                    "confluence_identity strategy=%s email=%s — %d candidates",
                    strategy_name, email, len(results),
                )
                user_node = _match_user(results, email)
                if user_node is None:
                    continue

                account_id = user_node.get("accountId")
                if not account_id:
                    logger.warning(
                        "confluence_identity strategy=%s email=%s — "
                        "matched node has no accountId: %s",
                        strategy_name, email, user_node,
                    )
                    continue

                logger.info(
                    "confluence_identity strategy=%s email=%s "
                    "accountId=%s displayName=%r",
                    strategy_name, email, account_id,
                    user_node.get("displayName"),
                )
                groups = await _fetch_user_groups(connector, account_id)
                return {
                    "account_id":   account_id,
                    "account_type": user_node.get("accountType", "atlassian"),
                    "display_name": (
                        user_node.get("displayName") or user_node.get("publicName")
                    ),
                    "groups": groups,
                }

        logger.warning(
            "confluence_identity email=%s — all strategies exhausted. "
            "Identity will be resolved automatically at next Confluence sync.",
            email,
        )
        return None


# ---------------------------------------------------------------------------
# Module-level helpers (stateless, no self needed)
# ---------------------------------------------------------------------------

async def _fetch_via_jira_v3(
    connector: ConfluenceConnector,
    email: str,
) -> list[dict]:
    """
    GET /rest/api/3/user/search?query={email}

    Jira REST API v3 — available on all Atlassian Cloud instances that host
    both Confluence and Jira on the same domain. Returns a bare list.

    Note: emailAddress is hidden ("") due to Atlassian Cloud privacy policy.
    Match falls through to Priority 3 (single unambiguous result).
    """
    data = await connector._get(
        "/rest/api/3/user/search",
        params={"query": email, "maxResults": 10},
    )
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("values") or data.get("results", [])
    return []


async def _fetch_via_jira_v3_firstname(
    connector: ConfluenceConnector,
    email: str,
) -> list[dict]:
    """
    GET /rest/api/3/user/search?query={first_name}

    Searches by the first segment of the email local-part before the dot.
    e.g. "chandana" from "chandana.r@sigmoidanalytics.com".

    Atlassian displayName is typically the user's first name only when
    email privacy is on, so this matches when the full-email and local-part
    searches return 0 results (e.g. Confluence-only users with no Jira seat).
    """
    first_name = email.split("@")[0].split(".")[0]
    data = await connector._get(
        "/rest/api/3/user/search",
        params={"query": first_name, "maxResults": 10},
    )
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("values") or data.get("results", [])
    return []


async def _fetch_via_jira_v3_localpart(
    connector: ConfluenceConnector,
    email: str,
) -> list[dict]:
    """
    GET /rest/api/3/user/search?query={local_part}

    Searches by the email local-part (e.g. "chandana.r" from "chandana.r@sigmoidanalytics.com").
    Atlassian usernames often match the email local-part, so this succeeds even
    when the full email is hidden by Cloud privacy policy.
    """
    local_part = email.split("@")[0]
    data = await connector._get(
        "/rest/api/3/user/search",
        params={"query": local_part, "maxResults": 10},
    )
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("values") or data.get("results", [])
    return []


async def _fetch_via_search(
    connector: ConfluenceConnector,
    email: str,
) -> list[dict]:
    """GET /wiki/rest/api/user/search?query={email}"""
    data = await connector._get(
        f"{connector._V1}/user/search",
        params={"query": email, "limit": 10},
    )
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("results", [])
    return []


async def _fetch_via_picker(
    connector: ConfluenceConnector,
    email: str,
) -> list[dict]:
    """GET /wiki/rest/api/user/picker?query={email}"""
    data = await connector._get(
        f"{connector._V1}/user/picker",
        params={"query": email, "limit": 10},
    )
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        # picker wraps results in {"users": [...]}
        return data.get("users") or data.get("results", [])
    return []


async def _fetch_user_groups(connector: ConfluenceConnector, account_id: str) -> list[str]:
    """
    Fetch all Atlassian group names the user belongs to.

    Uses GET /wiki/rest/api/user/memberof?accountId={account_id}.
    Returns an empty list on any error — group ACL matching degrades gracefully.
    """
    try:
        data = await connector._get(
            f"{connector._V1}/user/memberof",
            params={"accountId": account_id, "limit": 200},
        )
        results = data.get("results", [])
        groups = [g.get("name") for g in results if g.get("name")]
        logger.info(
            "confluence_identity accountId=%s groups=%s",
            account_id, groups,
        )
        return groups
    except Exception as exc:
        logger.warning(
            "confluence_identity accountId=%s — failed to fetch groups: %s",
            account_id, exc,
        )
        return []


def _match_user(results: list[dict], email: str) -> dict | None:
    """
    Select the best-matching user from a result list.

    Priority:
      1. Exact emailAddress field match  (admin token — email visible)
      2. Exact email field match         (some API variants)
      3. emailAddress local-part == email local-part  (partial email visible)
      4. displayName local-part == email local-part   (Cloud privacy fallback)
      5. publicName == email local-part               (username fallback)

    Priority 3 "single result" is intentionally removed — it caused wrong
    account_ids to be stored when Atlassian Cloud hides emails, because the
    search could return a different user that happened to be the only result.
    """
    email_lower = email.lower()
    email_local = email_lower.split("@")[0]

    # Priority 1 — emailAddress field (Jira v3)
    match = next(
        (r for r in results if (r.get("emailAddress") or "").lower() == email_lower),
        None,
    )
    if match:
        return match

    # Priority 2 — email field (Confluence v1/v2 variants)
    match = next(
        (r for r in results if (r.get("email") or "").lower() == email_lower),
        None,
    )
    if match:
        return match

    # Priority 3 — partial email match (emailAddress local-part, privacy mode)
    match = next(
        (
            r for r in results
            if (r.get("emailAddress") or "").lower().split("@")[0] == email_local
            and (r.get("emailAddress") or "") != ""
        ),
        None,
    )
    if match:
        return match

    # Priority 4 — displayName normalised == email local-part
    # e.g. displayName "Chandana R" → normalised "chandana.r" == email local "chandana.r"
    def _normalise(name: str) -> str:
        return name.lower().replace(" ", ".").replace("_", ".")

    match = next(
        (
            r for r in results
            if _normalise(r.get("displayName") or "") == email_local
        ),
        None,
    )
    if match:
        return match

    # Priority 5 — publicName == email local-part (Atlassian username)
    match = next(
        (r for r in results if (r.get("publicName") or "").lower() == email_local),
        None,
    )
    if match:
        return match

    # Priority 6 — first word of displayName matches email first segment, single result only.
    # Handles both "Chandana" and "YOGESHWARAN D" (first word = "yogeshwaran").
    # Safe only when there is exactly 1 candidate — avoids wrong mapping
    # when multiple users share the same first name.
    email_firstname = email_local.split(".")[0]
    firstname_matches = [
        r for r in results
        if (r.get("displayName") or "").lower().split()[0] == email_firstname
        if (r.get("displayName") or "").split()
    ]
    if len(firstname_matches) == 1:
        logger.info(
            "confluence_identity _match_user: matched via first-name+single-result "
            "email=%s displayName=%r accountId=%s",
            email, firstname_matches[0].get("displayName"), firstname_matches[0].get("accountId"),
        )
        return firstname_matches[0]

    # No safe match — reject all to prevent wrong account_id being stored.
    logger.warning(
        "confluence_identity _match_user: %d candidates for email=%s "
        "— no safe match found (rejecting to prevent wrong account_id mapping). "
        "candidates=%s",
        len(results), email,
        [
            {
                "accountId":    r.get("accountId", "?")[:12],
                "displayName":  r.get("displayName"),
                "publicName":   r.get("publicName"),
                "emailAddress": (r.get("emailAddress") or "")[:6] + "…" if r.get("emailAddress") else "",
            }
            for r in results[:5]
        ],
    )
    return None
