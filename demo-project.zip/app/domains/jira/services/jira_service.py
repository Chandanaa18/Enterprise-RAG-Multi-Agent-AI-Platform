"""
Jira Service — business layer.

Executes Jira operations via the local mcp-atlassian MCP server (SSE transport).
The server pre-normalises responses, so fields are flat (not nested under 'fields').
"""
from __future__ import annotations

import json
import logging
from typing import Any

from app.domains.jira.connector.mcp_client import JiraMCPClient, MCPTool
import httpx

from app.domains.jira.schemas.schemas import (
    AddCommentRequest,
    AddProjectMemberRequest,
    AddProjectMemberResponse,
    CommentResponse,
    CreateIssueRequest,
    GetIssueRequest,
    IssueAssignee,
    IssuePriority,
    IssueResponse,
    IssueStatus,
    JiraActionResponse,
    SearchIssueRequest,
    SearchResultResponse,
    TransitionIssueRequest,
    TransitionResponse,
    UpdateIssueRequest,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Normaliser — mcp-atlassian returns flat pre-normalised dicts
# ---------------------------------------------------------------------------

def _normalise_issue(raw: dict[str, Any], jira_base_url: str = "") -> IssueResponse:
    """
    Convert a mcp-atlassian issue dict to IssueResponse.
    Response format is flat — no nested 'fields' key.
    """
    key          = raw.get("key", "")
    status_raw   = raw.get("status")   or {}
    assignee_raw = raw.get("assignee") or {}
    priority_raw = raw.get("priority") or {}
    issuetype    = (raw.get("issue_type") or {}).get("name")

    return IssueResponse(
        key=key,
        summary=raw.get("summary", ""),
        description=raw.get("description"),
        status=IssueStatus(
            id="",
            name=status_raw.get("name", ""),
            category=status_raw.get("category"),
        ) if status_raw else None,
        assignee=IssueAssignee(
            account_id=assignee_raw.get("account_id", ""),
            display_name=assignee_raw.get("display_name", ""),
            email=assignee_raw.get("email"),
        ) if assignee_raw.get("display_name") not in (None, "Unassigned") else None,
        priority=IssuePriority(
            id="",
            name=priority_raw.get("name", ""),
        ) if priority_raw else None,
        issue_type=issuetype,
        project_key=key.split("-")[0] if "-" in key else None,
        labels=raw.get("labels", []),
        url=f"{jira_base_url}/browse/{key}" if jira_base_url else None,
        created_at=raw.get("created"),
        updated_at=raw.get("updated"),
    )


# ---------------------------------------------------------------------------
# JiraService
# ---------------------------------------------------------------------------

class JiraService:
    def __init__(
        self,
        mcp_client: JiraMCPClient,
        session_service: Any,
        jira_base_url: str = "",
        cloud_id: str = "",
        **kwargs: Any,
    ) -> None:
        self._mcp = mcp_client
        self._session_service = session_service
        self._jira_base_url = jira_base_url.rstrip("/")
        self._cloud_id = cloud_id
        self._field_id_cache: dict[str, str] = {}  # display_name → field_key

    async def _find_start_date_field(self, issue_key: str) -> str | None:
        """Find the start date field key for a specific issue by inspecting its edit metadata.

        Strategy: fetch /rest/api/3/issue/{key}/editmeta, collect all fields whose
        schema type is "date" but are NOT the standard due-date field, then return
        the first one found.  This relies entirely on Jira's own type system — no
        field names or IDs are hardcoded here.
        Result is cached per project key."""
        project_key = issue_key.split("-")[0] if "-" in issue_key else issue_key
        cache_key = f"start_date_field:{project_key}"
        if cache_key in self._field_id_cache:
            return self._field_id_cache[cache_key] or None

        try:
            headers = await self._mcp.get_auth_headers()
            headers["Accept"] = "application/json"
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{self._jira_base_url}/rest/api/3/issue/{issue_key}",
                    params={"expand": "editmeta"},
                    headers=headers,
                )
                resp.raise_for_status()
                edit_fields: dict = resp.json().get("editmeta", {}).get("fields", {})

            # Collect all editable date-type fields that are not the due-date system field
            due_date_key = next(
                (fid for fid, m in edit_fields.items()
                 if m.get("schema", {}).get("system") == "duedate"),
                "duedate",
            )
            date_fields = {
                fid: meta
                for fid, meta in edit_fields.items()
                if meta.get("schema", {}).get("type") == "date" and fid != due_date_key
            }

            if date_fields:
                field_id = next(iter(date_fields))
                self._field_id_cache[cache_key] = field_id
                logger.info(
                    "start_date_field resolved issue=%s field=%s name=%r",
                    issue_key, field_id, date_fields[field_id].get("name"),
                )
                return field_id

            all_date = {fid: m.get("name") for fid, m in edit_fields.items()
                        if m.get("schema", {}).get("type") == "date"}
            logger.warning(
                "start_date_field: no non-duedate date field found for issue=%s. All date fields: %s",
                issue_key, all_date,
            )
            self._field_id_cache[cache_key] = ""

        except Exception as exc:
            logger.warning("start_date_field: editmeta lookup failed issue=%s error=%s", issue_key, exc)
        return None

    # ------------------------------------------------------------------
    # Tool discovery
    # ------------------------------------------------------------------

    async def discover_tools(self) -> list[MCPTool]:
        tools = await self._mcp.list_tools()
        logger.info("tool_discovery count=%d", len(tools))
        return tools

    # ------------------------------------------------------------------
    # Get issue
    # ------------------------------------------------------------------

    async def get_issue(self, session_id: str, request: GetIssueRequest) -> IssueResponse:
        result = await self._mcp.execute("jira_get_issue", {"issue_key": request.issue_key})
        raw    = result.result or {}
        issue  = _normalise_issue(raw, self._jira_base_url)
        logger.info("tool_executed tool=get_issue issue=%s session=%s", request.issue_key, session_id)
        return issue

    # ------------------------------------------------------------------
    # Search issues
    # ------------------------------------------------------------------

    async def search_issues(self, session_id: str, request: SearchIssueRequest) -> SearchResultResponse:
        result = await self._mcp.execute("jira_search", {
            "jql":   request.jql,
            "limit": request.max_results,
        })
        data   = result.result or {}
        issues = [_normalise_issue(r, self._jira_base_url) for r in data.get("issues", [])]
        total  = data.get("total", len(issues))
        logger.info("tool_executed tool=search_issues total=%d session=%s", total, session_id)
        return SearchResultResponse(total=total, issues=issues, jql=request.jql)

    # ------------------------------------------------------------------
    # Create issue
    # ------------------------------------------------------------------

    async def create_issue(self, session_id: str, request: CreateIssueRequest) -> JiraActionResponse:
        args: dict[str, Any] = {
            "project_key": request.project_key,
            "summary":     request.summary,
            "issue_type":  request.issue_type,
        }
        if request.description:
            args["description"] = request.description
        if request.assignee:
            args["assignee"] = request.assignee
        if request.priority:
            args["additional_fields"] = json.dumps({"priority": {"name": request.priority}})

        result = await self._mcp.execute("jira_create_issue", args)
        raw    = result.result or {}
        key    = raw.get("key", "")
        logger.info("tool_executed tool=create_issue created_key=%s session=%s", key, session_id)
        return JiraActionResponse(
            success=True,
            issue_key=key,
            message=f"Issue {key} created successfully",
            data=raw,
        )

    # ------------------------------------------------------------------
    # Update issue
    # ------------------------------------------------------------------

    async def _resolve_assignee(self, identifier: str) -> str:
        """
        Resolve a display name or email to an accountId string.
        mcp-atlassian expects a plain accountId string in the fields dict —
        it wraps it into {"accountId": "..."} before calling the Jira REST API.
        """
        try:
            result = await self._mcp.execute("jira_search_users", {"query": identifier})
            users = result.result or []
            if isinstance(users, list) and users:
                account_id = (
                    users[0].get("account_id")   # mcp-atlassian snake_case
                    or users[0].get("accountId") # Jira REST camelCase
                    or ""
                )
                if account_id:
                    logger.info("resolve_assignee: found account_id=%s for '%s'", account_id, identifier)
                    return account_id
        except Exception as exc:
            logger.warning("resolve_assignee: user search failed for '%s': %s", identifier, exc)
        return identifier

    async def update_issue(self, session_id: str, request: UpdateIssueRequest) -> JiraActionResponse:
        fields: dict[str, Any] = {}
        if request.summary:
            fields["summary"] = request.summary
        if request.description is not None:
            fields["description"] = request.description
        if request.priority:
            fields["priority"] = {"name": request.priority}
        if request.labels is not None:
            fields["labels"] = request.labels
        if request.assignee:
            fields["assignee"] = await self._resolve_assignee(request.assignee)
        if request.due_date:
            fields["duedate"] = request.due_date
        if request.start_date:
            start_field = await self._find_start_date_field(request.issue_key)
            if start_field:
                fields[start_field] = request.start_date
            else:
                logger.warning("update_issue: could not resolve start date field for %s — skipping", request.issue_key)

        if not fields:
            return JiraActionResponse(
                success=False, issue_key=request.issue_key, message="No fields to update"
            )

        # mcp-atlassian expects fields as a JSON string
        result = await self._mcp.execute("jira_update_issue", {
            "issue_key": request.issue_key,
            "fields":    json.dumps(fields),
        })
        logger.info("tool_executed tool=update_issue issue=%s session=%s", request.issue_key, session_id)
        return JiraActionResponse(
            success=True,
            issue_key=request.issue_key,
            message=f"Issue {request.issue_key} updated successfully",
            data=result.result,
        )

    # ------------------------------------------------------------------
    # Add comment
    # ------------------------------------------------------------------

    async def add_comment(self, session_id: str, request: AddCommentRequest) -> CommentResponse:
        result = await self._mcp.execute("jira_add_comment", {
            "issue_key": request.issue_key,
            "body":      request.body,
        })
        raw = result.result if isinstance(result.result, dict) else {}
        logger.info("tool_executed tool=add_comment issue=%s session=%s", request.issue_key, session_id)
        author_raw = raw.get("author")
        author = (
            author_raw if isinstance(author_raw, str)
            else author_raw.get("display_name") or author_raw.get("displayName")
            if isinstance(author_raw, dict)
            else None
        )
        return CommentResponse(
            comment_id=str(raw.get("id", "")),
            issue_key=request.issue_key,
            body=request.body,
            author=author,
            created_at=raw.get("created") if raw else None,
        )

    # ------------------------------------------------------------------
    # Transition issue
    # ------------------------------------------------------------------

    async def transition_issue(self, session_id: str, request: TransitionIssueRequest) -> TransitionResponse:
        # Step 1: get available transitions and find matching ID by name
        tr_result    = await self._mcp.execute("jira_get_transitions", {"issue_key": request.issue_key})
        transitions  = tr_result.result or []
        match        = next(
            (t for t in transitions if t["name"].lower() == request.transition_name.lower()),
            None,
        )
        if not match:
            available = [t["name"] for t in transitions]
            raise ValueError(
                f"Transition '{request.transition_name}' not found. Available: {available}"
            )

        # Step 2: perform transition using the ID (must be a string per schema)
        await self._mcp.execute("jira_transition_issue", {
            "issue_key":     request.issue_key,
            "transition_id": str(match["id"]),
        })
        logger.info("tool_executed tool=transition_issue issue=%s transition=%s session=%s",
                    request.issue_key, request.transition_name, session_id)
        return TransitionResponse(
            issue_key=request.issue_key,
            transition_applied=request.transition_name,
            new_status=request.transition_name,
        )

    # ------------------------------------------------------------------
    # Add project member
    # ------------------------------------------------------------------

    async def add_project_member(self, session_id: str, request: AddProjectMemberRequest) -> AddProjectMemberResponse:
        # 1. Resolve user identifier to an accountId
        account_id = await self._resolve_assignee(request.user)

        # 2. Get auth headers to make direct Jira REST API calls
        headers = await self._mcp.get_auth_headers()
        headers["Accept"] = "application/json"
        headers["Content-Type"] = "application/json"

        async with httpx.AsyncClient(timeout=30.0) as client:
            # 3. Fetch all roles for the project
            roles_resp = await client.get(
                f"{self._jira_base_url}/rest/api/3/project/{request.project_key}/role",
                headers=headers,
            )
            roles_resp.raise_for_status()
            roles: dict = roles_resp.json()

            # 4. Match the requested role (case-insensitive)
            role_url: str | None = None
            matched_role_name: str = request.role
            for name, url in roles.items():
                if request.role.lower() in name.lower():
                    role_url = url
                    matched_role_name = name
                    break

            if not role_url:
                available = list(roles.keys())
                raise ValueError(
                    f"Role '{request.role}' not found in project {request.project_key}. "
                    f"Available roles: {available}"
                )

            # 5. Extract role ID from the URL and add user
            role_id = role_url.rstrip("/").split("/")[-1]
            add_resp = await client.post(
                f"{self._jira_base_url}/rest/api/3/project/{request.project_key}/role/{role_id}",
                headers=headers,
                json={"user": [account_id]},
            )
            add_resp.raise_for_status()

        logger.info(
            "tool_executed tool=add_project_member project=%s user=%s role=%s session=%s",
            request.project_key, request.user, matched_role_name, session_id,
        )
        return AddProjectMemberResponse(
            success=True,
            project_key=request.project_key,
            user=request.user,
            role=matched_role_name,
            message=f"Successfully added {request.user} as {matched_role_name} in {request.project_key}",
        )
