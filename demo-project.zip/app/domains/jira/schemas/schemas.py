"""
Jira domain schemas — Phase 3
No raw Jira payload leakage. All MCP responses are normalised here.
"""

from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------

class GetIssueRequest(BaseModel):
    issue_key: str = Field(..., description="Jira issue key, e.g. ABC-123")


class SearchIssueRequest(BaseModel):
    jql: str = Field(..., description="JQL query string")
    max_results: int = Field(default=20, ge=1, le=100)
    fields: list[str] = Field(
        default_factory=lambda: ["summary", "status", "assignee", "priority"],
        description="Fields to include in the results",
    )


class CreateIssueRequest(BaseModel):
    project_key: str = Field(..., description="Project key, e.g. ABC")
    summary: str
    description: Optional[str] = None
    issue_type: str = Field(default="Task")
    priority: Optional[str] = None
    assignee: Optional[str] = None
    labels: list[str] = Field(default_factory=list)


class UpdateIssueRequest(BaseModel):
    issue_key: str
    summary: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    assignee: Optional[str] = None
    labels: Optional[list[str]] = None
    due_date: Optional[str] = None   # ISO format: YYYY-MM-DD
    start_date: Optional[str] = None  # ISO format: YYYY-MM-DD


class AddCommentRequest(BaseModel):
    issue_key: str
    body: str


class TransitionIssueRequest(BaseModel):
    issue_key: str
    transition_name: str = Field(
        ...,
        description="Human-readable transition name, e.g. 'In Progress', 'Done'",
    )


class AddProjectMemberRequest(BaseModel):
    project_key: str = Field(..., description="Project key, e.g. ADP")
    user: str = Field(..., description="Email, display name, or account ID of the user to add")
    role: str = Field(default="Administrator", description="Role to assign, e.g. Administrator, Developer, Viewer")


# ---------------------------------------------------------------------------
# Tool selection
# ---------------------------------------------------------------------------

class ToolSelection(BaseModel):
    tool_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    reasoning: Optional[str] = None


# ---------------------------------------------------------------------------
# Normalised response schemas
# ---------------------------------------------------------------------------

class IssueStatus(BaseModel):
    id: str
    name: str
    category: Optional[str] = None


class IssueAssignee(BaseModel):
    account_id: str
    display_name: str
    email: Optional[str] = None


class IssuePriority(BaseModel):
    id: str
    name: str


class IssueResponse(BaseModel):
    """Normalised single Jira issue. No raw payload fields."""
    key: str
    summary: str
    description: Optional[str] = None
    status: Optional[IssueStatus] = None
    assignee: Optional[IssueAssignee] = None
    priority: Optional[IssuePriority] = None
    issue_type: Optional[str] = None
    project_key: Optional[str] = None
    labels: list[str] = Field(default_factory=list)
    url: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class SearchResultResponse(BaseModel):
    total: int
    issues: list[IssueResponse]
    jql: str


class CommentResponse(BaseModel):
    comment_id: str
    issue_key: str
    body: str
    author: Optional[str] = None
    created_at: Optional[str] = None


class TransitionResponse(BaseModel):
    issue_key: str
    transition_applied: str
    new_status: Optional[str] = None


class JiraActionResponse(BaseModel):
    """Generic action result (create / update / transition)."""
    success: bool
    issue_key: Optional[str] = None
    message: str
    data: Optional[dict[str, Any]] = None


class AddProjectMemberResponse(BaseModel):
    success: bool
    project_key: str
    user: str
    role: str
    message: str