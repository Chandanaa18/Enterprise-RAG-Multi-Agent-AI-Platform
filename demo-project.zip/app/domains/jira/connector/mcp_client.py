"""
JiraMCPClient — Atlassian Rovo MCP Server via HTTP/SSE transport.

Transport:  HTTP + Server-Sent Events (MCP spec)
Server:     Atlassian Rovo MCP  (https://mcp.atlassian.com)
Auth now:   APITokenAuth — HTTP Basic (email:api_token)
Auth later: drop-in any MCPAuth implementation (e.g. OAuthAuth) without
            touching JiraService, LangGraph nodes, or FastAPI routes.

Each MCP operation opens its own short-lived SSE session so stale
connections can never block a request.

Constructor signature is unchanged so main.py needs no edits:

    JiraMCPClient(
        base_url=settings.atlassian.mcp_url,   # https://mcp.atlassian.com
        email=settings.atlassian.email,
        api_token=settings.atlassian.api_token,
        timeout_seconds=settings.jira.mcp_timeout_seconds,
    )

To introduce OAuth later, pass auth=OAuthAuth(...).
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from app.shared.exceptions.connector_exceptions import (
    JiraMCPConnectionError,
    JiraMCPExecutionError,
    JiraMCPInvalidToolError,
    JiraMCPTimeoutError,
)

logger = logging.getLogger(__name__)


# ── Response objects ──────────────────────────────────────────────────────

@dataclass
class MCPTool:
    name: str
    description: str
    input_schema: dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPToolResult:
    tool_name: str
    result: Any
    duration_ms: float
    raw_response: dict[str, Any] = field(default_factory=dict)


# ── Auth abstraction ──────────────────────────────────────────────────────

@runtime_checkable
class MCPAuth(Protocol):
    """
    Auth provider protocol — swap API token for OAuth without touching
    JiraService, LangGraph nodes, or FastAPI routes.
    """
    async def get_headers(self) -> dict[str, str]: ...


class APITokenAuth:
    """HTTP Basic Auth using Atlassian email + API token."""

    def __init__(self, email: str, api_token: str) -> None:
        credentials = f"{email}:{api_token}"
        encoded = base64.b64encode(credentials.encode()).decode()
        self._header_value = f"Basic {encoded}"

    async def get_headers(self) -> dict[str, str]:
        return {"Authorization": self._header_value}


class OAuthAuth:
    """Bearer token auth using an Atlassian OAuth 2.0 access token."""

    def __init__(self, access_token: str) -> None:
        self._token = access_token

    async def get_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}


class NoAuth:
    """No-op auth — for local mcp-atlassian processes that handle their own credentials."""

    async def get_headers(self) -> dict[str, str]:
        return {}


# ── Client ────────────────────────────────────────────────────────────────

class JiraMCPClient:
    """
    MCP client for Atlassian Rovo MCP Server using HTTP/SSE transport.

    Each operation (list_tools, execute) opens a fresh SSE session to
    avoid stale-connection hangs when the server closes an idle stream.
    """

    _SSE_PATH = "/sse"

    def __init__(
        self,
        base_url: str,
        email: str = "",
        api_token: str = "",
        timeout_seconds: float = 30.0,
        *,
        auth: MCPAuth | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout_seconds
        self._auth: MCPAuth = auth if auth is not None else APITokenAuth(email, api_token)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Probe the MCP server to verify credentials."""
        sse_url = f"{self._base_url}{self._SSE_PATH}"
        headers = await self._auth.get_headers()
        try:
            async with self._open_session(sse_url, headers) as session:
                await session.initialize()
                logger.info("JiraMCPClient probe OK url=%s", sse_url)
        except Exception as exc:
            raise JiraMCPConnectionError(
                f"Cannot connect to MCP server at {sse_url}: {exc}"
            ) from exc

    async def close(self) -> None:
        logger.info("JiraMCPClient closed")

    async def __aenter__(self) -> "JiraMCPClient":
        await self.connect()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ── Public API ────────────────────────────────────────────────────────

    async def get_auth_headers(self) -> dict[str, str]:
        """Return auth headers for direct Jira REST API calls."""
        return await self._auth.get_headers()

    async def list_tools(self) -> list[MCPTool]:
        """Discover tools from the MCP server using a fresh session."""
        sse_url = f"{self._base_url}{self._SSE_PATH}"
        headers = await self._auth.get_headers()
        try:
            async with self._open_session(sse_url, headers) as session:
                await session.initialize()
                result = await session.list_tools()
                return [
                    MCPTool(
                        name=t.name,
                        description=t.description or "",
                        input_schema=(
                            t.inputSchema
                            if isinstance(t.inputSchema, dict)
                            else t.inputSchema.model_dump()
                        ),
                    )
                    for t in result.tools
                ]
        except Exception as exc:
            raise JiraMCPExecutionError(f"list_tools failed: {exc}") from exc

    async def execute(self, tool_name: str, args: dict[str, Any]) -> MCPToolResult:
        """Call an MCP tool using a fresh session per call.

        Retries once on connection errors (TaskGroup / connection refused) —
        these happen on first use after a server restart while mcp-atlassian
        is still starting up.
        """
        sse_url = f"{self._base_url}{self._SSE_PATH}"
        t0 = time.monotonic()
        raw_result = None

        for attempt in range(2):
            headers = await self._auth.get_headers()
            try:
                async with self._open_session(sse_url, headers) as session:
                    await session.initialize()
                    raw_result = await session.call_tool(tool_name, args)
                break  # success
            except JiraMCPExecutionError:
                raise
            except Exception as exc:
                err_str = str(exc).lower()
                is_transient = any(k in err_str for k in (
                    "taskgroup", "connection refused", "connection reset",
                    "connectionrefused", "connectionreset", "connect call failed",
                    "errno 111", "errno 61",
                ))
                if is_transient and attempt == 0:
                    logger.warning(
                        "MCP process not ready yet (attempt 1), retrying in 4s. "
                        "tool=%s url=%s error=%s", tool_name, sse_url, exc
                    )
                    await asyncio.sleep(4)
                    continue
                raise JiraMCPExecutionError(
                    f"tool={tool_name} RPC failed: {exc}"
                ) from exc

        duration_ms = (time.monotonic() - t0) * 1000

        if raw_result.isError:
            raise JiraMCPExecutionError(
                f"tool={tool_name} returned error: "
                f"{self._flatten_content(raw_result.content)}"
            )

        return MCPToolResult(
            tool_name=tool_name,
            result=self._flatten_content(raw_result.content),
            duration_ms=duration_ms,
            raw_response={
                "content": [str(c) for c in raw_result.content],
                "isError": raw_result.isError,
            },
        )

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _open_session(sse_url: str, headers: dict):
        from contextlib import asynccontextmanager
        from mcp.client.sse import sse_client
        from mcp.client.session import ClientSession

        @asynccontextmanager
        async def _ctx():
            async with AsyncExitStack() as stack:
                read, write = await stack.enter_async_context(
                    sse_client(url=sse_url, headers=headers)
                )
                session = await stack.enter_async_context(
                    ClientSession(read, write)
                )
                yield session

        return _ctx()

    @staticmethod
    def _flatten_content(content: list) -> Any:
        """Flatten MCP content blocks into a Python object."""
        if not content:
            return None
        parsed: list[Any] = []
        for block in content:
            text = getattr(block, "text", None)
            if text is not None:
                try:
                    parsed.append(json.loads(text))
                except (json.JSONDecodeError, TypeError):
                    parsed.append(text)
            else:
                data = getattr(block, "data", None)
                parsed.append(data if data is not None else str(block))
        return parsed[0] if len(parsed) == 1 else parsed
