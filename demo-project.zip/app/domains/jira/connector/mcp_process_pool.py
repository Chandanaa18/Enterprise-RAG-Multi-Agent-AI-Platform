"""
Per-user mcp-atlassian process pool.

One mcp-atlassian SSE server process runs per active user, each
configured with that user's Atlassian OAuth access token. Jira
operations execute as that user — not a shared service account —
so Jira's own project permissions are fully respected.

Port range: 7801–7899 (up to 99 concurrent active users).
Idle timeout: 30 minutes — processes are killed after inactivity.

Thread-safety: uses threading.Lock so it works correctly from both
the FastAPI event loop and ThreadPoolExecutor worker threads.
"""
from __future__ import annotations

import asyncio
import logging
import subprocess
import threading
import time
import signal

from app.core.config import settings as _app_settings

logger = logging.getLogger(__name__)


class _UserProcess:
    def __init__(self, user_id: str, port: int, proc: subprocess.Popen) -> None:
        self.user_id   = user_id
        self.port      = port
        self._proc     = proc
        self.last_used = time.monotonic()

    def touch(self) -> None:
        self.last_used = time.monotonic()

    def is_alive(self) -> bool:
        return self._proc.poll() is None

    def kill(self) -> None:
        try:
            self._proc.terminate()
            self._proc.wait(timeout=5)
        except Exception as exc:
            logger.warning("MCPProcessPool: terminate failed user=%s, forcing kill: %s", self.user_id, exc)
            try:
                self._proc.kill()
            except Exception as kill_exc:
                logger.error("MCPProcessPool: force kill also failed user=%s: %s", self.user_id, kill_exc)


class MCPProcessPool:
    """
    One mcp-atlassian process per active user, each using that user's
    Atlassian OAuth access token.
    """

    def __init__(
        self,
        jira_url: str,
        cloud_id: str,
        startup_wait_seconds: float | None = None,
        idle_timeout_seconds: float | None = None,
    ) -> None:
        pool_cfg = _app_settings.mcp_pool
        self._jira_url     = jira_url.rstrip("/")
        self._cloud_id     = cloud_id
        self._base_port    = pool_cfg.base_port
        self._max_users    = pool_cfg.max_users
        self._startup_wait = startup_wait_seconds if startup_wait_seconds is not None else pool_cfg.startup_wait_secs
        self._idle_timeout = idle_timeout_seconds if idle_timeout_seconds is not None else pool_cfg.idle_timeout_secs
        self._pool: dict[str, _UserProcess] = {}
        self._lock         = threading.Lock()
        self._kill_orphans()
        self._cleanup_task: asyncio.Task | None = None

    # ------------------------------------------------------------------
    # Lifecycle — called from main.py lifespan
    # ------------------------------------------------------------------

    async def start(self) -> None:
        self._cleanup_task = asyncio.create_task(
            self._cleanup_loop(), name="mcp-pool-cleanup"
        )
        logger.info(
            "MCPProcessPool: started (ports %d–%d)", self._base_port, self._base_port + self._max_users - 1
        )

    async def stop(self) -> None:
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        with self._lock:
            for entry in list(self._pool.values()):
                entry.kill()
            self._pool.clear()
        logger.info("MCPProcessPool: stopped — all user processes killed")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def get_or_spawn(self, user_id: str, access_token: str) -> int:
        """
        Return the SSE port for this user's mcp-atlassian process.
        Spawns a new process if none exists or the existing one died.
        Blocks (async sleep) until the process is ready to accept connections.
        """
        spawned = False
        port: int = 0

        with self._lock:
            entry = self._pool.get(user_id)

            if entry and entry.is_alive():
                entry.touch()
                logger.info(
                    "MCPProcessPool: reusing process user=%s port=%d", user_id, entry.port
                )
                return entry.port

            # Dead entry — clean up before spawning fresh
            if entry:
                entry.kill()
                del self._pool[user_id]

            port = self._next_free_port()
            proc = self._spawn(user_id=user_id, port=port, access_token=access_token)
            self._pool[user_id] = _UserProcess(user_id=user_id, port=port, proc=proc)
            spawned = True

        if spawned:
            # Wait outside the lock so other users aren't blocked during startup
            logger.info(
                "MCPProcessPool: waiting for startup user=%s port=%d", user_id, port
            )
            await asyncio.sleep(self._startup_wait)

        return port

    def get_running_port(self, user_id: str) -> int | None:
        """
        Return the port if this user's process is already alive, else None.
        Synchronous and lock-safe — callable from any thread/event loop.
        """
        with self._lock:
            entry = self._pool.get(user_id)
            if entry and entry.is_alive():
                entry.touch()
                return entry.port
        return None

    async def prewarm(self, user_id: str, access_token: str) -> None:
        """
        Spawn the user's process in the background.
        Call this after OAuth connect so the first Jira query is instant.
        """
        asyncio.create_task(
            self.get_or_spawn(user_id, access_token),
            name=f"mcp-prewarm-{user_id[:8]}",
        )
        logger.info("MCPProcessPool: prewarm scheduled user=%s", user_id)

    def shutdown_user(self, user_id: str) -> None:
        """Kill a specific user's process (e.g. on Atlassian disconnect)."""
        with self._lock:
            entry = self._pool.pop(user_id, None)
        if entry:
            entry.kill()
            logger.info(
                "MCPProcessPool: killed process user=%s port=%d", user_id, entry.port
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _kill_orphans(self) -> None:
        """Kill any leftover mcp-atlassian processes from a previous server run."""
        for port in range(self._base_port, self._base_port + self._max_users):
            try:
                result = subprocess.run(
                    ["fuser", f"{port}/tcp"],
                    capture_output=True, text=True,
                )
                for pid_str in result.stdout.split():
                    try:
                        subprocess.run(["kill", "-9", pid_str.strip()], check=False)
                        logger.info("MCPProcessPool: killed orphan pid=%s on port=%d", pid_str.strip(), port)
                    except Exception:
                        pass
            except Exception:
                pass

    def _next_free_port(self) -> int:
        used = {e.port for e in self._pool.values()}
        for i in range(self._max_users):
            port = self._base_port + i
            if port not in used:
                return port
        raise RuntimeError(
            f"MCPProcessPool: all {self._max_users} ports in use — cannot spawn more processes"
        )

    def _spawn(self, *, user_id: str, port: int, access_token: str) -> subprocess.Popen:
        cmd = [
            "uvx", "mcp-atlassian",
            "--transport", "sse",
            "--port", str(port),
            "--jira-url", self._jira_url,
            "--oauth-access-token", access_token,
            "--oauth-cloud-id", self._cloud_id,
        ]
        logger.info("MCPProcessPool: spawning user=%s port=%d", user_id, port)
        return subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    async def _cleanup_loop(self) -> None:
        """Background task: kill processes idle longer than idle_timeout."""
        while True:
            await asyncio.sleep(60)   # check every minute
            now = time.monotonic()
            with self._lock:
                stale = [
                    uid for uid, entry in self._pool.items()
                    if not entry.is_alive()
                    or (now - entry.last_used) > self._idle_timeout
                ]
                for uid in stale:
                    logger.info(
                        "MCPProcessPool: reaping idle/dead process user=%s", uid
                    )
                    self._pool[uid].kill()
                    del self._pool[uid]
