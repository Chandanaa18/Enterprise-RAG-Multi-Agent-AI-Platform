"""
Jira API routes.
POST /jira/query — accepts a natural-language message and returns an answer via the JiraAgent.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.jira.agent import JiraAgent
from app.bootstrap.auth_deps import get_current_user
from app.infrastructure.database.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/jira", tags=["jira"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class JiraQueryRequest(BaseModel):
    message: str = Field(..., min_length=1, description="Natural-language Jira query")
    session_id: str = Field(..., description="Active session ID")


class JiraQueryResponse(BaseModel):
    answer: str


# ---------------------------------------------------------------------------
# Dependency provider
# (Replace with your real DI mechanism — e.g. bootstrap/auth_deps pattern)
# ---------------------------------------------------------------------------

def get_jira_agent() -> JiraAgent:
    """Returns the singleton JiraAgent from app.state, set during startup."""
    from app.main import app  # avoid circular import at module level
    agent: JiraAgent | None = getattr(app.state, "jira_agent", None)
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Jira agent is not initialised",
        )
    return agent


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------

@router.post("/query", response_model=JiraQueryResponse)
async def jira_query(
    body: JiraQueryRequest,
    jira_agent: JiraAgent = Depends(get_jira_agent),
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> JiraQueryResponse:
    """
    Accepts a natural-language message about Jira and returns an answer.

    Example:
        POST /jira/query
        { "message": "show ticket ABC-123", "session_id": "..." }
    """
    logger.info(
        "jira_query: session=%s user=%s message_preview=%s",
        body.session_id,
        current_user.user_id,
        body.message[:80],
    )

    try:
        answer = await jira_agent.run(
            message=body.message,
            session_id=body.session_id,
            user_id=str(current_user.user_id),
            db=db,
        )
        return JiraQueryResponse(answer=answer)
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "jira_failure route=jira_query session=%s error=%s",
            body.session_id, exc,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Jira agent encountered an error. Please try again.",
        ) from exc