from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified
from typing import Optional

from app.domains.users.models.user_model import User


class UserRepository:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_email(self, email: str) -> Optional[User]:
        query = select(User).where(User.email == email)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_by_id(self, user_id) -> Optional[User]:
        query = select(User).where(User.user_id == user_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_by_azure_oid(self, oid: str) -> Optional[User]:
        query = select(User).where(User.azure_ad_oid == oid)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def create(self, user: User) -> User:
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user

    async def list_all(self) -> list[User]:
        result = await self.db.execute(select(User).order_by(User.display_name))
        return list(result.scalars().all())

    async def update(self, user: User) -> User:
        # JSONB columns require an explicit dirty flag for SQLAlchemy to detect the change.
        flag_modified(user, "roles")
        await self.db.commit()
        await self.db.refresh(user)
        return user