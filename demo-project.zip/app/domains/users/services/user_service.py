from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from app.domains.users.repositories.user_repository import UserRepository
from app.domains.users.models.user_model import User
from app.shared.exceptions.base_exception import AppBaseException
from app.shared.exceptions.error_enums import LogEvent
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)


class UserService:

    def __init__(self, db: AsyncSession):
        self.user_repo = UserRepository(db)

    async def get_user_by_email(self, email: str) -> Optional[User]:
        try:
            return await self.user_repo.get_by_email(email)
        except Exception as e:
            logger.error(
                f"Failed to fetch user by email: {email}",
                event=LogEvent.ERROR_UNKNOWN.value,
                exc_info=e,
                email=email,
            )
            raise AppBaseException(
                message=f"Failed to fetch user by email: {email}",
                details=str(e),
            )

    async def get_or_provision_user(
        self,
        azure_ad_oid: str,
        email: str,
        display_name: str,
        roles: list[str],
    ) -> User:
        """
        Upserts a user from Azure AD JWT claims.
        On first login the user is created. On subsequent logins, roles, email,
        and display_name are always overwritten from the token so that changes
        made in Entra ID take effect immediately on the next request.
        """
        try:
            # Look up by OID first (most reliable — stable across email changes)
            user = await self.user_repo.get_by_azure_oid(azure_ad_oid)

            # Fallback: same email exists but under a different / missing OID
            # (e.g. created via dev-mode X-User-Email stub before Azure login)
            if not user:
                user = await self.user_repo.get_by_email(email)

            if user:
                user.azure_ad_oid = azure_ad_oid
                user.roles        = roles
                user.email        = email
                user.display_name = display_name
                return await self.user_repo.update(user)

            new_user = User(
                azure_ad_oid=azure_ad_oid,
                email=email,
                display_name=display_name,
                roles=roles,
            )
            logger.info(
                f"Provisioning new user from Azure AD: {email}",
                event=LogEvent.USER_PROVISIONED.value,
                azure_ad_oid=azure_ad_oid,
                email=email,
            )
            return await self.user_repo.create(new_user)

        except AppBaseException:
            raise
        except Exception as e:
            logger.error(
                f"Failed to provision user: {email}",
                event=LogEvent.USER_AUTH_FAILED.value,
                exc_info=e,
                azure_ad_oid=azure_ad_oid,
                email=email,
            )
            raise AppBaseException(
                message=f"Failed to provision user: {email}",
                details=str(e),
            )

