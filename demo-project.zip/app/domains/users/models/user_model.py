import uuid
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import DateTime, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship, Mapped, mapped_column

from app.infrastructure.database.database import Base

class User(Base):
    __tablename__ = "users"
    __table_args__ = {'schema': 'enterprise_rag_system'}

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    azure_ad_oid: Mapped[Optional[str]] = mapped_column(Text, unique=True, index=True, nullable=True)
    display_name: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    email: Mapped[Optional[str]] = mapped_column(Text, unique=True, index=True, nullable=True)
    roles: Mapped[Optional[list]] = mapped_column(JSONB, default=list, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    metadata_: Mapped[Optional[dict]] = mapped_column("metadata", JSONB, default=dict, nullable=True)

    sessions = relationship("Session", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")
