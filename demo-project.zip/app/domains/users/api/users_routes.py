from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from app.infrastructure.database.database import get_db
from app.domains.users.repositories.user_repository import UserRepository

users_router = APIRouter(prefix="/api/v1/users", tags=["Users"])


class UserSummary(BaseModel):
    user_id: str
    display_name: str | None
    email: str | None
    roles: list[str]


@users_router.get("", response_model=list[UserSummary])
async def list_users(db: AsyncSession = Depends(get_db)):
    """Return all provisioned Azure AD users. Used by the dev user-switcher."""
    repo = UserRepository(db)
    users = await repo.list_all()
    return [
        UserSummary(
            user_id=str(u.user_id),
            display_name=u.display_name,
            email=u.email,
            roles=u.roles or [],
        )
        for u in users
    ]
