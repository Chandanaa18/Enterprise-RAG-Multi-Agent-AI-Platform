"""
Embedder implementations.

Only backend: Google Gemini — models/gemini-embedding-001 (3072-d).
Requires GOOGLE_API_KEY to be set in the environment.

IMPORTANT: embedding dimension is fixed per pgvector table.
Switching to a different model/dimension requires creating a new collection
and re-ingesting all documents.
"""
from __future__ import annotations

import logging
import time
from typing import Protocol, runtime_checkable

from app.core.config import settings
from app.shared.enums import EmbedderProvider, GoogleEmbedTaskType

logger = logging.getLogger(__name__)


# ── Protocol ──────────────────────────────────────────────────────────────────

@runtime_checkable
class EmbedderProtocol(Protocol):
    """Interface every embedder must satisfy."""
    dim: int
    model_name: str
    provider: EmbedderProvider

    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...
    def embed_query(self, text: str) -> list[float]: ...


# ── Google Gemini ─────────────────────────────────────────────────────────────

class _GeminiEmbedder:
    """Google Gemini embedding model via langchain-google-genai."""

    dim = 3072
    model_name = "models/gemini-embedding-001"
    provider = EmbedderProvider.GOOGLE

    def __init__(self) -> None:
        try:
            from langchain_google_genai import GoogleGenerativeAIEmbeddings
        except ImportError as exc:
            raise RuntimeError(
                "langchain-google-genai is not installed. "
                "Run: pip install langchain-google-genai"
            ) from exc

        if not settings.llm_keys.effective_google_key:
            raise RuntimeError(
                "No Google API key found. "
                "Set GOOGLE_API_KEY or GEMINI_API_KEY in your .env file."
            )

        self._model = GoogleGenerativeAIEmbeddings(
            model=self.model_name,
            task_type=GoogleEmbedTaskType.RETRIEVAL_DOCUMENT,
        )
        logger.info(
            "Initialized embedder provider=%s model=%s dim=%d",
            self.provider.value, self.model_name, self.dim,
        )

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        return self._embed_with_retry(lambda: self._model.embed_documents(texts))

    def embed_query(self, text: str) -> list[float]:
        return self._embed_with_retry(lambda: self._model.embed_query(text))

    def _embed_with_retry(self, fn, max_retries: int = 3, base_delay: float = 60.0):
        """Retry on Gemini 429 rate-limit errors with exponential backoff."""
        delay = base_delay
        for attempt in range(1, max_retries + 1):
            try:
                return fn()
            except Exception as exc:
                is_rate_limit = "RESOURCE_EXHAUSTED" in str(exc) or "429" in str(exc)
                if is_rate_limit and attempt < max_retries:
                    logger.warning(
                        "Gemini embedding rate limit hit (attempt %d/%d) — "
                        "waiting %.0fs before retry.",
                        attempt, max_retries, delay,
                    )
                    time.sleep(delay)
                    delay = min(delay * 2, 120.0)
                else:
                    raise


# ── Singleton factory ─────────────────────────────────────────────────────────

_embedder_singleton: EmbedderProtocol | None = None


def build_embedder() -> EmbedderProtocol:
    """Return the process-wide Gemini embedder, initialising it on first call.

    Raises RuntimeError if GOOGLE_API_KEY is not set or the package is missing.
    """
    global _embedder_singleton
    if _embedder_singleton is not None:
        return _embedder_singleton

    _embedder_singleton = _GeminiEmbedder()
    return _embedder_singleton
