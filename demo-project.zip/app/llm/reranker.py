"""
Cross-encoder reranker.

Uses flashrank (ONNX Runtime) to keep
the memory footprint small. Model ms-marco-MiniLM-L-12-v2 is ~50 MB on disk and
runs entirely on CPU with no GPU/CUDA dependency.

flashrank uses
ONNX Runtime, which provides the same cross-encoder quality at a fraction of the
memory cost and startup time.
"""
from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)
# ONNX cross-encoder model shipped by flashrank — ~50 MB, no GPU needed.
_MODEL_NAME = "ms-marco-MiniLM-L-12-v2"


# ──────────────────────────────────────────────────────────────────────────────
# Protocol
# ──────────────────────────────────────────────────────────────────────────────

@runtime_checkable
class RerankerProtocol(Protocol):
    def rerank(self, query: str, passages: list[str]) -> list[float]:
        """Return a relevance score for each (query, passage) pair, in input order."""
        ...


# ──────────────────────────────────────────────────────────────────────────────
# Reranker implementations
# ──────────────────────────────────────────────────────────────────────────────

class FlashRankReranker:
    """
    Cross-encoder reranker backed by flashrank (ONNX Runtime).

    Lazy-loads the model on first instantiation — the ONNX file is downloaded
    from HuggingFace Hub on first use and cached in the default HF cache directory.
    """

    model_name = _MODEL_NAME

    def __init__(self) -> None:
        from flashrank import Ranker
        logger.info("event=reranker_load model=%s backend=flashrank_onnx", self.model_name)
        self._ranker = Ranker(model_name=self.model_name)

    def rerank(self, query: str, passages: list[str]) -> list[float]:
        """
        Score each (query, passage) pair.

        flashrank returns results sorted by score — we restore the original
        passage order so callers can zip(chunks, scores) safely.
        """
        if not passages:
            return []

        from flashrank import RerankRequest

        request = RerankRequest(
            query=query,
            passages=[{"id": i, "text": p} for i, p in enumerate(passages)],
        )
        results = self._ranker.rerank(request)

        # Restore original order — results arrive sorted by score descending.
        scores_by_id: dict[int, float] = {
            int(r["id"]): float(r["score"]) for r in results
        }
        return [scores_by_id.get(i, 0.0) for i in range(len(passages))]


class _FakeReranker:
    """
    Identity reranker for dev / offline environments.

    Preserves the original retrieval order by assigning linearly decreasing
    scores — no model download required.
    """

    model_name = "fake"

    def rerank(self, query: str, passages: list[str]) -> list[float]:
        return [1.0 - (i * 0.01) for i in range(len(passages))]


# ──────────────────────────────────────────────────────────────────────────────
# Singleton factory
# ──────────────────────────────────────────────────────────────────────────────

_reranker_singleton: RerankerProtocol | None = None


def build_reranker() -> RerankerProtocol:
    """
    Return the shared reranker instance (built once on first call).

    Falls back to _FakeReranker if flashrank is unavailable so the retrieval
    pipeline keeps running in environments without the ONNX model.
    """
    global _reranker_singleton
    if _reranker_singleton is not None:
        return _reranker_singleton

    try:
        _reranker_singleton = FlashRankReranker()
    except Exception as exc:
        logger.warning(
            "event=reranker_fallback reason=%s — using identity reranker", exc,
        )
        _reranker_singleton = _FakeReranker()

    return _reranker_singleton
