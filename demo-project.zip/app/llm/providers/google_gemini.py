"""Google Gemini provider via langchain-google-genai."""
from __future__ import annotations
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.language_models import BaseChatModel

from app.core.config import settings


def build_gemini_chat(model: str, **kwargs) -> BaseChatModel:
    if not settings.llm_keys.effective_google_key:
        raise RuntimeError(
            "No Google API key found. Set GOOGLE_API_KEY or GEMINI_API_KEY in your .env file."
        )
    # langchain-google-genai 4.x reads GOOGLE_API_KEY / GEMINI_API_KEY from env automatically.
    return ChatGoogleGenerativeAI(
        model=model,
        temperature=kwargs.get("temperature", 0.0),
        max_retries=0,
    )
