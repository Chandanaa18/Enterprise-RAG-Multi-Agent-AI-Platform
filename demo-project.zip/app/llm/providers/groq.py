"""Groq provider via langchain-groq."""
from __future__ import annotations

from langchain_core.language_models import BaseChatModel
from langchain_groq import ChatGroq

from app.core.config import settings


def build_groq_chat(model: str, **kwargs) -> BaseChatModel:
    api_key = settings.llm_keys.groq_api_key
    if not api_key:
        raise RuntimeError("GROQ_API_KEY is not set. Add it to your .env file.")
    return ChatGroq(
        model=model,
        api_key=api_key,
        temperature=kwargs.get("temperature", 0.0),
        max_retries=0,
        request_timeout=30.0,
    )
