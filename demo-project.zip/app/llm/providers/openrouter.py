"""OpenRouter provider — uses OpenAI-compatible API via langchain-openai."""
from __future__ import annotations
from langchain_openai import ChatOpenAI
from langchain_core.language_models import BaseChatModel

from app.core.config import settings
from app.core.constants import OPENROUTER_BASE_URL


def build_openrouter_chat(model: str, base_url: str | None = None, **kwargs) -> BaseChatModel:
    api_key = settings.llm_keys.openrouter_api_key
    if not api_key:
        raise RuntimeError("OPENROUTER_API_KEY not set")
    return ChatOpenAI(
        model=model,
        openai_api_key=api_key,
        openai_api_base=base_url or OPENROUTER_BASE_URL,
        temperature=kwargs.get("temperature", 0.0),
        max_retries=2,
    )
