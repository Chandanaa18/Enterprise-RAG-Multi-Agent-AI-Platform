"""
ProviderFactory — builds LangChain chat models from logical model ids.

Falls through the provider chain on RateLimitError / connection errors.
Provider + model used are recorded as span attributes in MLflow.
"""
from __future__ import annotations
import logging
from typing import Optional

from langchain_core.language_models import BaseChatModel

from app.llm.registry import get_logical_model_config, ProviderDeployment, ensure_loaded

logger = logging.getLogger(__name__)
class _ChainedChatModel:
    """
    Wraps a list of LangChain chat models in a priority chain.
    Falls through to the next on any provider error.
    """

    def __init__(self, deployments: list[ProviderDeployment]) -> None:
        self._deployments = []
        self._models: list[BaseChatModel] = []
        self.provider_used: Optional[str] = None
        self.model_used:    Optional[str] = None
        for dep in deployments:
            try:
                self._models.append(_build_chat(dep))
                self._deployments.append(dep)
            except Exception as exc:
                logger.warning(
                    "provider_init_skip provider=%s model=%s error=%s",
                    dep.provider, dep.model, str(exc)[:120],
                )
        if not self._models:
            raise RuntimeError("No providers could be initialised — check installed packages and API keys.")

    def _try_invoke(self, messages, **kwargs):
        last_err = None
        for idx, (model, dep) in enumerate(zip(self._models, self._deployments)):
            try:
                result = model.invoke(messages, **kwargs)
                self.provider_used = dep.provider
                self.model_used    = dep.model
                if idx > 0:
                    logger.info("provider_fallback provider=%s model=%s attempt=%d",
                                dep.provider, dep.model, idx)
                return result
            except Exception as exc:
                logger.warning("provider_error provider=%s model=%s error=%s",
                               dep.provider, dep.model, str(exc)[:120])
                last_err = exc
        raise RuntimeError(f"All providers failed. Last: {last_err}") from last_err

    async def _try_ainvoke(self, messages, **kwargs):
        last_err = None
        for idx, (model, dep) in enumerate(zip(self._models, self._deployments)):
            try:
                result = await model.ainvoke(messages, **kwargs)
                self.provider_used = dep.provider
                self.model_used    = dep.model
                return result
            except Exception as exc:
                logger.warning("provider_error provider=%s model=%s error=%s",
                               dep.provider, dep.model, str(exc)[:120])
                last_err = exc
        raise RuntimeError(f"All providers failed. Last: {last_err}") from last_err

    def invoke(self, messages, **kwargs):
        return self._try_invoke(messages, **kwargs)

    async def ainvoke(self, messages, **kwargs):
        return await self._try_ainvoke(messages, **kwargs)


def _build_chat(dep: ProviderDeployment) -> BaseChatModel:
    if dep.provider == "google":
        from app.llm.providers.google_gemini import build_gemini_chat
        return build_gemini_chat(dep.model)
    if dep.provider == "openrouter":
        from app.llm.providers.openrouter import build_openrouter_chat
        return build_openrouter_chat(dep.model, base_url=dep.base_url)
    if dep.provider == "groq":
        from app.llm.providers.groq import build_groq_chat
        return build_groq_chat(dep.model)
    raise ValueError(f"Unknown provider: {dep.provider!r}")


class ProviderFactory:
    def __init__(self) -> None:
        ensure_loaded()

    def get_chat_model(self, logical_id: str) -> _ChainedChatModel:
        cfg = get_logical_model_config(logical_id)
        available = cfg.available_deployments()
        if not available:
            logger.warning("No real provider for %s — using FakeChatModel", logical_id)
            return _FakeChatModel(logical_id)  # type: ignore[return-value]
        return _ChainedChatModel(available)


class _FakeChatModel:
    """Deterministic dev fallback when no API key is present."""

    def __init__(self, logical_id: str = "FAKE") -> None:
        self.provider_used = "fake"
        self.model_used    = "fake"
        self._logical_id   = logical_id

    def _respond(self, messages) -> object:
        from langchain_core.messages import AIMessage
        text = str(messages).lower()
        if "intent" in text or "classify" in text:
            content = '{"intent": "knowledge_qa", "confidence": 0.9}'
        elif "rewrite" in text or "expand" in text:
            content = '["What is the onboarding process?", "How do I get started?"]'
        elif ("answer with a single word" in text or "yes or no" in text
              or ("sufficient" in text and "relevance" in text)):
            content = "yes"
        else:
            content = (
                "This is a simulated answer. No LLM provider is configured. "
                "Set GOOGLE_API_KEY or OPENROUTER_API_KEY to enable real responses."
            )
        return AIMessage(content=content)

    def invoke(self, messages, **_):
        return self._respond(messages)

    async def ainvoke(self, messages, **_):
        return self._respond(messages)


_factory: Optional[ProviderFactory] = None


def get_provider_factory() -> ProviderFactory:
    global _factory
    if _factory is None:
        _factory = ProviderFactory()
    return _factory
