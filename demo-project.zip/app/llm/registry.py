"""
LLM Registry — inline logical model configuration.

Each logical_model id is referenced by agent code; never provider names directly.
The chain is tried in order; providers whose required API-key env var is absent
are skipped silently.  Switching/adding a provider means editing _LLM_CONFIG below.

Usage:
    from app.llm.registry import get_logical_model_config
    cfg = get_logical_model_config("KNOWLEDGE_DEFAULT")
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from app.core.constants import OPENROUTER_BASE_URL

# ──────────────────────────────────────────────────────────────────────────────
# Inline configuration  (replaces config/llm.yaml)
# ──────────────────────────────────────────────────────────────────────────────

_LLM_CONFIG: dict = {
    "logical_models": [
        {
            "id": "KNOWLEDGE_DEFAULT",
            "description": "Answer generation — use most capable available model",
            "active_prompt": "rag_answer:2",
            "chain": [
                {
                    "provider": "groq",
                    "model": "llama-3.3-70b-versatile",
                    "requires_key_env": "GROQ_API_KEY",
                    "rpm_limit": 30,
                },
                {
                    "provider": "groq",
                    "model": "llama-3.1-8b-instant",
                    "requires_key_env": "GROQ_API_KEY",
                    "rpm_limit": 30,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.5-flash",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 10,
                    "rpd_limit": 500,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.0-flash",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 15,
                    "rpd_limit": 200,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.5-flash-lite",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 30,
                    "rpd_limit": 1500,
                },
                {
                    "provider": "openrouter",
                    "model": "openai/gpt-oss-120b:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                },
                {
                    "provider": "openrouter",
                    "model": "nvidia/nemotron-3-super-120b-a12b:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                },
                {
                    "provider": "openrouter",
                    "model": "nvidia/nemotron-nano-9b-v2:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                }
            ],
        },
        {
            "id": "GENERAL_LLM",
            "description": "Direct LLM answers for general/world knowledge — optimise for low cost",
            "chain": [
                {
                    "provider": "groq",
                    "model": "llama-3.1-8b-instant",
                    "requires_key_env": "GROQ_API_KEY",
                    "rpm_limit": 30,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.5-flash-lite",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 30,
                    "rpd_limit": 1500,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.0-flash",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 15,
                    "rpd_limit": 200,
                },
                {
                    "provider": "openrouter",
                    "model": "nvidia/nemotron-nano-9b-v2:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                },
            ],
        },
        {
            "id": "KNOWLEDGE_FAST",
            "description": "Intent classification and query rewriting — speed > quality",
            "active_prompt": "intent_classify:1",
            "chain": [
                {
                    "provider": "groq",
                    "model": "llama-3.1-8b-instant",
                    "requires_key_env": "GROQ_API_KEY",
                    "rpm_limit": 30,
                },
                {
                    "provider": "groq",
                    "model": "llama-3.3-70b-versatile",
                    "requires_key_env": "GROQ_API_KEY",
                    "rpm_limit": 30,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.5-flash",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 10,
                    "rpd_limit": 500,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.0-flash",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 15,
                    "rpd_limit": 200,
                },
                {
                    "provider": "google",
                    "model": "gemini-2.5-flash-lite",
                    "requires_key_env": "GOOGLE_API_KEY",
                    "rpm_limit": 30,
                    "rpd_limit": 1500,
                },
                {
                    "provider": "openrouter",
                    "model": "openai/gpt-oss-20b:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                },
                {
                    "provider": "openrouter",
                    "model": "nvidia/nemotron-nano-9b-v2:free",
                    "requires_key_env": "OPENROUTER_API_KEY",
                    "base_url": OPENROUTER_BASE_URL,
                    "rpm_limit": 20,
                }
            ],
        }
    ]
}


# ──────────────────────────────────────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ProviderDeployment:
    provider: str           # google | openrouter  
    model: str
    requires_key_env: Optional[str] = None
    base_url: Optional[str] = None
    rpm_limit: int = 60
    rpd_limit: int = 0      # 0 = unlimited

    def is_available(self) -> bool:
        """Return True if the required API key is present (or none required)."""
        if self.requires_key_env:
            from app.core.config import settings
            return bool(settings.llm_keys.get(self.requires_key_env))
        return True


@dataclass
class LogicalModelConfig:
    id: str
    description: str = ""
    active_prompt: Optional[str] = None
    chain: list[ProviderDeployment] = field(default_factory=list)

    def available_deployments(self) -> list[ProviderDeployment]:
        return [d for d in self.chain if d.is_available()]


# ──────────────────────────────────────────────────────────────────────────────
# Registry
# ──────────────────────────────────────────────────────────────────────────────

_registry: dict[str, LogicalModelConfig] = {}


def _load() -> None:
    global _registry
    for lm in _LLM_CONFIG.get("logical_models", []):
        deployments = [
            ProviderDeployment(
                provider=d["provider"],
                model=d["model"],
                requires_key_env=d.get("requires_key_env"),
                base_url=d.get("base_url"),
                rpm_limit=d.get("rpm_limit", 60),
                rpd_limit=d.get("rpd_limit", 0),
            )
            for d in lm.get("chain", [])
        ]
        _registry[lm["id"]] = LogicalModelConfig(
            id=lm["id"],
            description=lm.get("description", ""),
            active_prompt=lm.get("active_prompt"),
            chain=deployments,
        )


def get_logical_model_config(logical_id: str) -> LogicalModelConfig:
    if not _registry:
        _load()
    if logical_id not in _registry:
        raise KeyError(
            f"Unknown logical model id: {logical_id!r}. "
            "Check _LLM_CONFIG in app/llm/registry.py."
        )
    return _registry[logical_id]


def ensure_loaded() -> None:
    """Called at startup to eagerly load and validate the registry."""
    _load()
    for logical_id, cfg in _registry.items():
        available = cfg.available_deployments()
        if not available:
            import warnings
            warnings.warn(
                f"No usable provider for logical model {logical_id!r}. "
                "The system will fall back to FakeLLM if called.",
                RuntimeWarning,
                stacklevel=2,
            )
