"""
RetrievalService — orchestrates embed → hybrid-search → rerank → diversify.

Called from the KnowledgeRAGAgent retrieval subgraph.
All operations are deterministic (no LLM calls).
"""
from __future__ import annotations
import logging
from typing import Optional

from app.core.config import settings
from app.llm.embeddings import build_embedder
from app.retrieval.vector_store import RetrievedChunk, get_vector_store
from app.retrieval.rerank import rerank_chunks, diversify_chunks

logger = logging.getLogger(__name__)


class RetrievalService:
    """Stateless service. Thread-safe: models are loaded once on first call."""

    def retrieve(
        self,
        *,
        query: str,
        user_id: str,
        user_roles: list[str],
        allowed_connector_ids: list[str],
        top_k_dense: Optional[int] = None,
        top_k_final: Optional[int] = None,
    ) -> list[RetrievedChunk]:
        """
        Full retrieval pipeline:
        1. Embed the query
        2. Hybrid search pgvector (ACL + connector filtered inside the query)
        3. Rerank with cross-encoder
        4. Diversify (max 3 chunks per doc)
        """
        _top_k_dense = top_k_dense or settings.rag.top_k_dense
        _top_k_final = top_k_final or settings.rag.top_k_after_rerank

        try:
            query_vec = build_embedder().embed_query(query)
        except Exception as exc:
            logger.error(
                "embed_query failed — check API key quota. query=%r error=%s",
                query[:80], exc,
            )
            return []

        raw_chunks  = get_vector_store().hybrid_search(
            query_text=query,
            query_vector=query_vec,
            user_id=user_id,
            user_roles=user_roles,
            allowed_connector_ids=allowed_connector_ids,
            top_k=_top_k_dense,
        )

        logger.info("retrieval_raw query=%r user=%s raw=%d", query[:60], user_id, len(raw_chunks))

        if not raw_chunks:
            return []

        diversified = diversify_chunks(rerank_chunks(query, raw_chunks, top_k=_top_k_final), max_per_doc=3)
        logger.info("retrieval_final query=%r user=%s final=%d", query[:60], user_id, len(diversified))
        return diversified


_retrieval_service: Optional[RetrievalService] = None


def get_retrieval_service() -> RetrievalService:
    global _retrieval_service
    if _retrieval_service is None:
        _retrieval_service = RetrievalService()
    return _retrieval_service
