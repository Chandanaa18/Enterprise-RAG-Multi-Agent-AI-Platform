"""
pgvector-backed vector store.

Embeddings are stored in `enterprise_rag_system.knowledge_chunks`
as halfvec(3072) with an HNSW cosine index; full-text search uses a tsvector
generated column. ACL is enforced inside the SQL where-clause so unauthorized
chunks never leave the database (spec §3.6, §13).

Hybrid search blends BM25-equivalent (ts_rank_cd) and vector distance via
weighted Reciprocal Rank Fusion (RRF). The `alpha` parameter preserves the
existing API semantics:
    alpha = 0.0  → pure BM25
    alpha = 1.0  → pure vector
    alpha = 0.5  → equal weighting

Connection lifecycle is a sync psycopg2 pool so the existing sync callers
(IngestionPipeline, RetrievalService) don't need to be rewritten.
"""
from __future__ import annotations

import logging
import threading
import uuid as _uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from pgvector.psycopg2 import register_vector
from psycopg2.extras import RealDictCursor, execute_values
from psycopg2.pool import ThreadedConnectionPool

from app.core.config import settings
from app.shared.enums import ChunkType

logger = logging.getLogger(__name__)
# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class RetrievedChunk:
    """A single chunk returned by a vector or hybrid search query."""

    chunk_id: str
    doc_id: str
    version_id: str
    connector_id: str
    title: str
    source_uri: str
    content: str
    chunk_type: ChunkType
    score: float
    page_no: Optional[int] = None
    section_path: list[str] = field(default_factory=list)
    # ACL fields — carried through so permission_recheck can verify them
    # as a defence-in-depth layer independent of the SQL WHERE-clause.
    acl_user_ids: list[str] = field(default_factory=list)
    acl_roles:    list[str] = field(default_factory=list)
    acl_public:   bool      = False


# ---------------------------------------------------------------------------
# Vector store
# ---------------------------------------------------------------------------

_RRF_K = 60                  # standard RRF damping constant
_OVER_FETCH_MULTIPLIER = 4   # fetch 4x top_k from each ranker before fusion
_SCHEMA = "enterprise_rag_system"
_TABLE = f"{_SCHEMA}.knowledge_chunks"


class PgVectorStore:
    """
    pgvector + tsvector wrapper providing insert / hybrid-search / delete
    with built-in ACL filtering.
    """

    _POOL_MIN = 1
    _POOL_MAX = 10

    def __init__(self) -> None:
        db = settings.db
        logger.info(
            "Connecting to Postgres for pgvector store host=%s db=%s",
            db.host, db.database,
        )
        self._pool = ThreadedConnectionPool(
            self._POOL_MIN, self._POOL_MAX,
            host=db.host, port=db.port,
            user=db.username, password=db.password,
            dbname=db.database,
        )
        # Register vector type with every connection lent by the pool.
        with self._connection() as conn:
            register_vector(conn)
        logger.info("PgVectorStore ready table=%s", _TABLE)

    # ------------------------------------------------------------------
    # Connection helpers
    # ------------------------------------------------------------------

    class _ConnContext:
        def __init__(self, pool: ThreadedConnectionPool) -> None:
            self._pool = pool
            self._conn: Any = None

        def __enter__(self):
            self._conn = self._pool.getconn()
            register_vector(self._conn)
            return self._conn

        def __exit__(self, exc_type, exc, tb):
            if exc_type is None:
                self._conn.commit()
            else:
                self._conn.rollback()
            self._pool.putconn(self._conn)

    def _connection(self) -> "PgVectorStore._ConnContext":
        return PgVectorStore._ConnContext(self._pool)

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def insert_chunks(
        self,
        chunks: list,
        vectors: list[list[float]],
    ) -> None:
        """
        Bulk-insert chunks with pre-computed embedding vectors.

        ACL is stored as flat columns (acl_user_ids[], acl_roles[], acl_public)
        so the hybrid_search where-clause can prune unauthorized chunks inside
        the SQL query — before results surface to application code.
        """
        if len(chunks) != len(vectors):
            raise ValueError(
                f"chunks/vectors length mismatch: {len(chunks)} chunks vs {len(vectors)} vectors"
            )
        if not chunks:
            return

        rows = []
        for chunk, vector in zip(chunks, vectors):
            acl = chunk.acl
            chunk_type_value = (
                chunk.chunk_type.value
                if isinstance(chunk.chunk_type, Enum)
                else str(chunk.chunk_type)
            )
            rows.append((
                str(self._parse_or_generate_uuid(chunk.chunk_id)),
                chunk.doc_id,
                chunk.version_id,
                chunk.connector_id,
                chunk.source_uri,
                chunk_type_value,
                chunk.title,
                chunk.content,
                chunk.section_path or [],
                chunk.page_no,
                list(acl.users),
                list(acl.roles),
                bool(acl.public),
                vector,
            ))

        # ON CONFLICT (chunk_id) DO UPDATE makes re-ingest idempotent if a
        # previous run partially completed without the delete_chunks_by_doc step.
        sql = f"""
            INSERT INTO {_TABLE} (
                chunk_id, doc_id, version_id, connector_id, source_uri,
                chunk_type, title, content, section_path, page_no,
                acl_user_ids, acl_roles, acl_public, embedding
            )
            VALUES %s
            ON CONFLICT (chunk_id) DO UPDATE SET
                doc_id        = EXCLUDED.doc_id,
                version_id    = EXCLUDED.version_id,
                connector_id  = EXCLUDED.connector_id,
                source_uri    = EXCLUDED.source_uri,
                chunk_type    = EXCLUDED.chunk_type,
                title         = EXCLUDED.title,
                content       = EXCLUDED.content,
                section_path  = EXCLUDED.section_path,
                page_no       = EXCLUDED.page_no,
                acl_user_ids  = EXCLUDED.acl_user_ids,
                acl_roles     = EXCLUDED.acl_roles,
                acl_public    = EXCLUDED.acl_public,
                embedding     = EXCLUDED.embedding
        """
        template = (
            "(%s::uuid, %s::uuid, %s::uuid, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
            "%s::halfvec)"
        )
        with self._connection() as conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, rows, template=template, page_size=200)

        logger.info("insert_chunks inserted=%d", len(rows))

    # ------------------------------------------------------------------
    # Read / search operations
    # ------------------------------------------------------------------

    def hybrid_search(
        self,
        query_text: str,
        query_vector: list[float],
        *,
        user_id: str,
        user_roles: list[str],
        allowed_connector_ids: list[str],
        top_k: int = 20,
        alpha: float = 0.5,
    ) -> list[RetrievedChunk]:
        """
        Weighted-RRF hybrid search (BM25 + vector) with ACL and connector
        filtering applied inside SQL.

            score = alpha * 1/(K + rank_vec) + (1 - alpha) * 1/(K + rank_bm25)

        Chunks missing from one ranker contribute only the other ranker's term
        (FULL OUTER JOIN). The ACL where-clause is identical in both CTEs so
        unauthorized chunks never enter either ranking.

        Connector enforcement
        ---------------------
        The ``allowed_connector_ids`` parameter restricts which connectors may
        contribute chunks.  This is enforced via
        ``AND connector_id = ANY(%(allowed_connectors)s)`` inside the
        ``acl_filtered`` CTE — unauthorized connector chunks never leave the
        database.

        If ``allowed_connector_ids`` is empty, **zero chunks** are returned
        immediately without executing the query (deny-all default).
        """
        # ── Edge-case guard: empty connector list = deny-all ──────────
        if not allowed_connector_ids:
            logger.info(
                "hybrid_search short-circuit: allowed_connector_ids is empty "
                "— returning 0 chunks (deny-all). user=%s",
                user_id,
            )
            return []

        over_fetch = top_k * _OVER_FETCH_MULTIPLIER
        # Empty roles array means "no role-based grants" — handled in WHERE via array_length.
        roles_param = list(user_roles) if user_roles else []

        sql = f"""
        WITH acl_filtered AS (
            SELECT *
            FROM {_TABLE}
            WHERE connector_id = ANY(%(allowed_connectors)s)
              AND (
                  acl_public = TRUE
                  OR %(user_id)s = ANY(acl_user_ids)
                  OR (
                      COALESCE(array_length(%(roles)s::text[], 1), 0) > 0
                      AND acl_roles && %(roles)s::text[]
                  )
              )
        ),
        vec AS (
            SELECT chunk_id,
                   ROW_NUMBER() OVER (ORDER BY embedding <=> %(qvec)s::halfvec) AS rnk
            FROM acl_filtered
            ORDER BY embedding <=> %(qvec)s::halfvec
            LIMIT %(over_fetch)s
        ),
        bm25 AS (
            SELECT chunk_id,
                   ROW_NUMBER() OVER (
                       ORDER BY ts_rank_cd(content_tsv, plainto_tsquery('english', %(qtext)s)) DESC
                   ) AS rnk
            FROM acl_filtered
            WHERE content_tsv @@ plainto_tsquery('english', %(qtext)s)
            LIMIT %(over_fetch)s
        ),
        fused AS (
            SELECT
                COALESCE(v.chunk_id, b.chunk_id) AS chunk_id,
                (
                    %(alpha)s       * COALESCE(1.0 / (%(rrf_k)s + v.rnk), 0)
                    + (1 - %(alpha)s) * COALESCE(1.0 / (%(rrf_k)s + b.rnk), 0)
                ) AS score
            FROM vec v
            FULL OUTER JOIN bm25 b USING (chunk_id)
        )
        SELECT
            c.chunk_id::text     AS chunk_id,
            c.doc_id::text       AS doc_id,
            c.version_id::text   AS version_id,
            c.connector_id,
            c.source_uri,
            c.chunk_type,
            c.title,
            c.content,
            c.section_path,
            c.page_no,
            c.acl_user_ids,
            c.acl_roles,
            c.acl_public,
            f.score
        FROM fused f
        JOIN {_TABLE} c ON c.chunk_id = f.chunk_id
        ORDER BY f.score DESC
        LIMIT %(top_k)s
        """

        params = {
            "user_id":              user_id,
            "roles":                roles_param,
            "allowed_connectors":   list(allowed_connector_ids),
            "qvec":                 query_vector,
            "qtext":                query_text,
            "alpha":                float(alpha),
            "rrf_k":                _RRF_K,
            "over_fetch":           over_fetch,
            "top_k":                top_k,
        }

        with self._connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(sql, params)
                rows = cur.fetchall()

        retrieved = [self._row_to_chunk(row) for row in rows]
        logger.debug(
            "hybrid_search user=%s roles=%s connectors=%s alpha=%.2f "
            "top_k=%d returned=%d query=%r",
            user_id, user_roles, allowed_connector_ids, alpha,
            top_k, len(retrieved), query_text[:80],
        )
        return retrieved

    # ------------------------------------------------------------------
    # Delete operations
    # ------------------------------------------------------------------

    def delete_chunks_by_doc(self, doc_id: str) -> None:
        """Delete every chunk belonging to a document (all versions)."""
        with self._connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"DELETE FROM {_TABLE} WHERE doc_id = %s::uuid",
                    (doc_id,),
                )
        logger.info("Deleted all chunks for doc_id=%s", doc_id)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying connection pool."""
        self._pool.closeall()
        logger.info("PgVectorStore connection pool closed")

    def __enter__(self) -> "PgVectorStore":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_or_generate_uuid(chunk_id: str) -> _uuid.UUID:
        """Return a UUID parsed from chunk_id if valid, otherwise generate a new one."""
        try:
            return _uuid.UUID(chunk_id)
        except (ValueError, TypeError):
            return _uuid.uuid4()

    @staticmethod
    def _row_to_chunk(row: dict[str, Any]) -> RetrievedChunk:
        raw_chunk_type = row.get("chunk_type") or ChunkType.TEXT.value
        try:
            chunk_type = ChunkType(raw_chunk_type)
        except ValueError:
            logger.warning(
                "Unrecognised chunk_type=%r received from DB, defaulting to TEXT",
                raw_chunk_type,
            )
            chunk_type = ChunkType.TEXT

        return RetrievedChunk(
            chunk_id=row.get("chunk_id") or "",
            doc_id=row.get("doc_id") or "",
            version_id=row.get("version_id") or "",
            connector_id=row.get("connector_id") or "",
            title=row.get("title") or "",
            source_uri=row.get("source_uri") or "",
            content=row.get("content") or "",
            chunk_type=chunk_type,
            page_no=row.get("page_no"),
            section_path=row.get("section_path") or [],
            score=float(row.get("score") or 0.0),
            acl_user_ids=list(row.get("acl_user_ids") or []),
            acl_roles=list(row.get("acl_roles") or []),
            acl_public=bool(row.get("acl_public") or False),
        )




# ---------------------------------------------------------------------------
# Thread-safe module-level singleton
# ---------------------------------------------------------------------------

_vector_store: PgVectorStore | None = None
_vector_store_lock = threading.Lock()


def get_vector_store() -> PgVectorStore:
    """Return the shared PgVectorStore instance, creating it on first call."""
    global _vector_store
    if _vector_store is None:
        with _vector_store_lock:
            if _vector_store is None:  # double-checked locking
                _vector_store = PgVectorStore()
    return _vector_store
