"""Reranking step — cross-encoder over (query, chunk.content) pairs."""
from __future__ import annotations
import logging

from app.core.config import settings
from app.retrieval.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)
def rerank_chunks(
    query: str,
    chunks: list[RetrievedChunk],
    top_k: int | None = None,
) -> list[RetrievedChunk]:
    """
    Rerank retrieved chunks using the cross-encoder.
    Returns top_k chunks sorted by reranker score descending.
    """
    if not chunks:
        return []

    _top_k = top_k or settings.rag.top_k_after_rerank

    try:
        from app.llm.reranker import build_reranker
        reranker = build_reranker()
        passages = [c.content for c in chunks]
        scores = reranker.rerank(query, passages)

        # Attach reranker scores
        scored = [
            RetrievedChunk(
                chunk_id=c.chunk_id, doc_id=c.doc_id, version_id=c.version_id,
                connector_id=c.connector_id, title=c.title, source_uri=c.source_uri,
                content=c.content, chunk_type=c.chunk_type, page_no=c.page_no,
                section_path=c.section_path, score=float(s),
            )
            for c, s in zip(chunks, scores)
        ]
        scored.sort(key=lambda x: x.score, reverse=True)
        return scored[:_top_k]

    except Exception as exc:
        logger.warning("Reranker failed: %s — returning original order", exc)
        return chunks[:_top_k]


def diversify_chunks(
    chunks: list[RetrievedChunk],
    max_per_doc: int = 3,
) -> list[RetrievedChunk]:
    """
    Simple diversification: drop chunks from the same doc_id beyond max_per_doc.
    Preserves rank order.
    """
    seen: dict[str, int] = {}
    result: list[RetrievedChunk] = []
    for chunk in chunks:
        count = seen.get(chunk.doc_id, 0)
        if count < max_per_doc:
            result.append(chunk)
            seen[chunk.doc_id] = count + 1
    return result
