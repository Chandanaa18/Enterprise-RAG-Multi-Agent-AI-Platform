"""
Connector Loader  —  the only file that needs to change when adding a connector.

This module registers every connector and always-on agent with the registry.
It is imported once at application startup (in _bootstrap_agents, main.py).

To add a new connector
----------------------
1. Build the connector under  app/connectors/<name>/
2. Build the agent under      app/agents/<name>/agent.py
3. Add the import and registry.add() call in the section below.
   Nothing else in the platform needs to change.
"""
from __future__ import annotations

from app.connectors.registry import registry
from app.shared.enums import ConnectorType


def load_all() -> None:
    """
    Register all connectors and always-on agents.

    Called once from _bootstrap_agents in main.py before the factory builds
    the live agents dict. Safe to call multiple times — duplicate registrations
    log a warning and overwrite the previous entry.
    """

    # ── Always-on agents ──────────────────────────────────────────────────────
    # Active regardless of connector_configs. These agents do not depend on a
    # specific external data source being enabled.

    from app.agents.knowledge_rag.agent import KnowledgeRAGAgent
    from app.agents.general_llm.agent  import GeneralLLMAgent

    registry.add_always_on(
        agent_key="knowledge_rag",
        agent_cls=KnowledgeRAGAgent,
        requires_llm=True,   # needs llm_fast, llm_default, session_store
    )
    registry.add_always_on(
        agent_key="general_llm",
        agent_cls=GeneralLLMAgent,
        requires_llm=False,
    )

    # ── Connector-driven agents ───────────────────────────────────────────────
    # Active only when the connector row in connector_configs has enabled=True.
    # The agent_key must match what the planner uses in AGENT_REGISTRY.

    from app.agents.jira.agent import JiraAgent

    registry.add(
        connector_id=ConnectorType.JIRA.value,
        agent_key="jira",
        agent_cls=JiraAgent,
        requires_llm=False,
    )

    # ── Pending connectors ────────────────────────────────────────────────────
    # Uncomment each block when the connector and agent are implemented.

    # from app.agents.sharepoint.agent import SharePointAgent
    # registry.add(
    #     connector_id=ConnectorType.SHAREPOINT.value,
    #     agent_key="knowledge_rag",   # shares the same RAG agent as Confluence
    #     agent_cls=SharePointAgent,
    #     requires_llm=True,
    # )

    # from app.agents.teams.agent import TeamsAgent
    # registry.add(
    #     connector_id=ConnectorType.TEAMS.value,
    #     agent_key="teams",
    #     agent_cls=TeamsAgent,
    #     requires_llm=False,
    # )

    # from app.agents.m365.agent import M365Agent
    # registry.add(
    #     connector_id=ConnectorType.M365.value,
    #     agent_key="m365",
    #     agent_cls=M365Agent,
    #     requires_llm=False,
    # )
