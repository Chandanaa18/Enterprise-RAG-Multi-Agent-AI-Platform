"""
Abstract base connector interface.

Every enterprise data-source connector (Confluence, SharePoint, Jira, Teams, M365)
must inherit BaseConnector and implement all abstract methods. This contract ensures:
  - plug-and-play integration: new connectors slot in without changing platform code
  - uniform lifecycle: connect → fetch/sync → close
  - uniform health-check interface for the ops dashboard
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional


class BaseConnector(ABC):
    """
    Contract for all enterprise data-source connectors.

    Lifecycle
    ---------
    Option A — explicit:
        connector = ConcreteConnector(settings)
        await connector.connect()
        docs = await connector.sync(last_sync=some_dt)
        await connector.close()

    Option B — context manager (preferred):
        async with ConcreteConnector(settings) as conn:
            await conn.connect()
            docs = await conn.sync(last_sync=some_dt)
    """

    name: str  # unique connector identifier, e.g. "confluence", "sharepoint"


    # Connect
    @abstractmethod
    async def connect(self) -> bool:
        """
        Authenticate and open transport connections.
        Must be called before any data-fetching method.
        Returns True on success; raises a connector-specific exception on failure.
        """

    # Close
    @abstractmethod
    async def close(self) -> None:
        """Release HTTP clients and any other held resources."""

    async def __aenter__(self) -> "BaseConnector":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # Fetch
    @abstractmethod
    async def fetch(self, **kwargs: Any) -> List[Any]:
        """
        Generic document fetch.
        Implementations accept source-specific keyword filters
        (e.g. space_key=, folder_id=).
        Returns raw documents before normalization.
        """

    # Sync
    @abstractmethod
    async def sync(
        self,
        last_sync: Optional[datetime] = None,
        **kwargs: Any,
    ) -> List[Any]:
        """
        Incremental synchronization.
        Fetch only documents modified after `last_sync`.
        `last_sync=None` triggers a full sync.
        Returns normalized document objects (type defined by each connector).
        """

    # Health
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """
        Connectivity and authentication probe.
        Always returns a dict with at minimum:
            {"connector": <name>, "status": "healthy" | "unhealthy"}
        May add "latency_ms" and "error" keys.
        """
