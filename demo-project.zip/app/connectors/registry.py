"""
Connector Registry  (spec §3.7 — Plug-and-Play Connector Architecture)

Purpose
-------
Central place that maps connector IDs to their agents.
The SupervisorAgent uses this at startup to know which agents to activate.

How to add a new connector
--------------------------
1. Create the connector under  app/connectors/<name>/
2. Create the agent under      app/agents/<name>/agent.py
3. Open  app/connectors/loader.py  and add two lines:
       from app.agents.<name>.agent import <Name>Agent
       registry.add(connector_id="<name>", agent_key="<name>", agent_cls=<Name>Agent)
   That is all.  No changes to main.py, the supervisor, or any router.

How to disable a connector
--------------------------
Set  connector_configs.enabled = False  via the admin panel.
The connector's agent is excluded from the next startup.
Users receive a clean message — the platform does not crash.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.agents.knowledge_rag.agent import AgentResult
from app.shared.utils.logger.logger import Logger

logger = Logger(__file__)


# ──────────────────────────────────────────────────────────────────────────────
# Entry types
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ConnectorEntry:
    """
    Describes one connector and the agent that handles it.

    connector_id : value stored in connector_configs.connector_id
    agent_key    : key the SupervisorAgent uses to route queries
    agent_cls    : agent class to instantiate when this connector is enabled
    requires_llm : True when the agent constructor needs llm_fast,
                   llm_default, and session_store (e.g. KnowledgeRAGAgent)
    """
    connector_id: str
    agent_key:    str
    agent_cls:    type
    requires_llm: bool = False


@dataclass(frozen=True)
class AlwaysOnEntry:
    """
    An agent that is always active regardless of which connectors are enabled.

    Use this for agents that do not depend on an external data source
    (e.g. general_llm, which answers entirely from LLM knowledge).
    """
    agent_key:    str
    agent_cls:    type
    requires_llm: bool = False


# ──────────────────────────────────────────────────────────────────────────────
# Registry
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ConnectorRegistry:
    """
    Holds all registered connectors and always-on agents.

    One instance is created at module level below and imported everywhere.
    All registration happens in app/connectors/loader.py before startup.
    """

    _connectors:  dict[str, ConnectorEntry] = field(default_factory=dict)
    _always_on:   list[AlwaysOnEntry]       = field(default_factory=list)

    def add(
        self,
        *,
        connector_id: str,
        agent_key:    str,
        agent_cls:    type,
        requires_llm: bool = False,
    ) -> None:
        """
        Register a connector.

        Parameters
        ----------
        connector_id : must match the connector_configs.connector_id in the DB
        agent_key    : how the supervisor identifies this agent (e.g. "jira")
        agent_cls    : the agent class to activate when this connector is enabled
        requires_llm : set True when the agent needs llm_fast / llm_default /
                       session_store (e.g. KnowledgeRAGAgent)
        """
        if connector_id in self._connectors:
            previous_agent = self._connectors[connector_id].agent_cls.__name__
            logger.warn(
                "Overwriting already-registered connector",
                connector_id=connector_id,
                previous_agent=previous_agent,
                new_agent=agent_cls.__name__,
            )

        self._connectors[connector_id] = ConnectorEntry(
            connector_id=connector_id,
            agent_key=agent_key,
            agent_cls=agent_cls,
            requires_llm=requires_llm,
        )
        logger.info(
            "Connector registered",
            connector_id=connector_id,
            agent_key=agent_key,
            agent_cls=agent_cls.__name__,
        )

    def add_always_on(
        self,
        *,
        agent_key:    str,
        agent_cls:    type,
        requires_llm: bool = False,
    ) -> None:
        """
        Register an agent that is always active regardless of connector_configs.

        Parameters
        ----------
        agent_key    : how the supervisor identifies this agent
        agent_cls    : the agent class to activate at startup
        requires_llm : set True when the agent needs llm_fast / llm_default /
                       session_store injected at construction
        """
        self._always_on.append(
            AlwaysOnEntry(
                agent_key=agent_key,
                agent_cls=agent_cls,
                requires_llm=requires_llm,
            )
        )
        logger.info(
            "connector_registry.add_always_on: registered agent_key=%s "
            "agent_cls=%s requires_llm=%s",
            agent_key, agent_cls.__name__, requires_llm,
        )

    def build_agents(
        self,
        enabled_connector_ids: list[str],
        *,
        session_store: Any,
        llm_fast:      Any = None,
        llm_default:   Any = None,
    ) -> dict[str, Any]:
        """
        Build and return the agents dict for the SupervisorAgent.

        Called once at startup from _bootstrap_agents in main.py.

        Parameters
        ----------
        enabled_connector_ids : connector_id values where enabled=True in DB
        session_store         : passed to agents that need LLM infrastructure
        llm_fast              : fast LLM for classification / query rewriting
        llm_default           : capable LLM for answer generation

        Returns
        -------
        dict[str, agent_instance]  — ready to pass to SupervisorAgent(agents=...)
        """
        active_agents: dict[str, Any] = {}

        # Step 1 — Always-on agents (active regardless of connector_configs)
        for entry in self._always_on:
            try:
                agent_instance = self._create_agent(
                    entry.agent_cls,
                    requires_llm=entry.requires_llm,
                    llm_fast=llm_fast,
                    llm_default=llm_default,
                    session_store=session_store,
                )
                active_agents[entry.agent_key] = agent_instance
                logger.info(
                    "Always-on agent activated",
                    agent_key=entry.agent_key,
                )
            except Exception as exc:
                logger.error(
                    "Failed to activate always-on agent",
                    event="connector_health",
                    agent_key=entry.agent_key,
                    connector_id="always_on",
                    error=str(exc),
                )

        # Step 2 — Connector-driven agents (active only when enabled in DB)
        for connector_id in enabled_connector_ids:
            connector_entry = self._connectors.get(connector_id)

            if connector_entry is None:
                logger.warn(
                    "No registry entry found for connector — add registry.add() in app/connectors/loader.py",
                    connector_id=connector_id,
                )
                continue

            agent_key = connector_entry.agent_key

            # Skip if already active — multiple connectors can share one agent
            # (e.g. Confluence + SharePoint both use knowledge_rag)
            if agent_key in active_agents:
                continue

            try:
                agent_instance = self._create_agent(
                    connector_entry.agent_cls,
                    requires_llm=connector_entry.requires_llm,
                    llm_fast=llm_fast,
                    llm_default=llm_default,
                    session_store=session_store,
                )
                active_agents[agent_key] = agent_instance
                logger.info(
                    "Connector agent activated",
                    connector_id=connector_id,
                    agent_key=agent_key,
                )
            except Exception as exc:
                logger.error(
                    "Failed to activate connector agent",
                    event="connector_health",
                    connector_id=connector_id,
                    agent_key=agent_key,
                    error=str(exc),
                )

        logger.info(
            "connector_registry.build: complete active_agents=%s",
            sorted(active_agents.keys()),
        )
        return active_agents

    @staticmethod
    def disabled_agent_response(agent_key: str, session_id: str) -> AgentResult:
        """
        Graceful fallback when the supervisor routes to a disabled agent.

        Returns a clean user message instead of crashing — satisfies spec §3.7.
        """
        return AgentResult(
            text=(
                f"The '{agent_key}' integration is not currently enabled. "
                "Please contact your administrator to activate it."
            ),
            agent="supervisor",
            session_id=session_id,
            can_answer=False,
        )

    @staticmethod
    def _create_agent(
        agent_cls:     type,
        *,
        requires_llm:  bool,
        llm_fast:      Any,
        llm_default:   Any,
        session_store: Any,
    ) -> Any:
        """Instantiate an agent with the right constructor arguments."""
        if requires_llm:
            return agent_cls(
                llm_fast=llm_fast,
                llm_default=llm_default,
                session_store=session_store,
            )
        return agent_cls()


# ──────────────────────────────────────────────────────────────────────────────
# Module-level singleton  — import this everywhere
# ──────────────────────────────────────────────────────────────────────────────

registry = ConnectorRegistry()
