"""
FastAPI application entry point.

Startup sequence (lifespan):
  1. Azure AD — load OpenID config, pre-warm JWKS cache
  2. MLflow   — initialise tracing + LangChain autolog
  3. Prompts  — seed MLflow prompt registry
  4. LLM      — eager-load LLM provider registry
  5. Agents   — load connector registry, build SupervisorAgent
  6. Sync     — queue Confluence background sync if connector is enabled
"""
from __future__ import annotations
import os

# .env must load before any other import so env vars are present when
# MLflow tracing auto-instrumentation initialises.
from dotenv import load_dotenv
load_dotenv(override=False)

# Fail fast when MLflow server is unreachable — prevents startup from blocking
# for minutes due to urllib3's exponential-backoff retry loop.
os.environ.setdefault("MLFLOW_HTTP_REQUEST_TIMEOUT", "5")
os.environ.setdefault("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "1")
os.environ.setdefault("MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", "0")

# Register all ORM models with the shared Base before any mapper configuration.
# Ensures string-based relationship() references resolve correctly regardless
# of module import order.
from app.infrastructure.database import model_registry  # noqa: F401

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from starlette.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.bootstrap.auth_deps import azure_scheme
from app.domains.auth.middleware.auth_middleware import AuthMiddleware
from app.domains.auth.api.auth_routes import auth_router
from app.domains.auth.services.token_validator import token_validator
from app.observability.logging import configure_logging
from app.observability.tracing import init_mlflow
from app.shared.utils.exception_handlers import setup_exception_handlers
from app.shared.utils.logger.logger import Logger

configure_logging()
logger = Logger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Bootstrap helpers
# One function per startup step. Called in order from lifespan().
# Each helper is independently non-fatal unless stated otherwise.
# ──────────────────────────────────────────────────────────────────────────────

async def _bootstrap_azure_ad() -> None:
    """Load Azure AD OpenID configuration and pre-warm the JWKS key cache."""
    if not settings.azure_ad.auth_enabled:
        logger.warn(
            "bootstrap.azure_ad status=skipped "
            "reason='AZURE_AUTH_ENABLED=false' "
            "fallback='X-User-Email header used as identity stub' "
            "action_required='Enable Azure AD auth before deploying to production'"
        )
        return

    if azure_scheme is None:
        raise RuntimeError(
            "bootstrap.azure_ad status=failed "
            "reason='azure_scheme did not initialise' "
            "hint='Verify AZURE_CLIENT_ID and AZURE_TENANT_ID env vars are set'"
        )

    await azure_scheme.openid_config.load_config()
    logger.info("bootstrap.azure_ad step=openid_config status=ok provider=azure_ad")

    try:
        await token_validator._fetch_jwks(settings.azure_ad.tenant_id or "")
        logger.info(
            "bootstrap.azure_ad step=jwks_cache status=ok "
            "effect='first authenticated request will not incur key-fetch latency'"
        )
    except Exception as exc:
        # Non-fatal — the validator retries lazily on the first real request.
        logger.warn(
            "bootstrap.azure_ad step=jwks_cache status=failed error='%s' "
            "impact='non-fatal — validator will retry on first authenticated request'",
            exc,
        )


def _bootstrap_mlflow() -> None:
    """Initialise MLflow tracing and enable LangChain autolog."""
    try:
        init_mlflow()
        logger.info("bootstrap.mlflow step=init status=ok")
    except Exception as exc:
        logger.warn(
            "bootstrap.mlflow step=init status=failed error='%s' "
            "impact='LLM tracing and LangChain autolog unavailable — requests will still be served'",
            exc,
        )


def _bootstrap_prompts() -> None:
    """Seed the MLflow prompt registry with default prompt templates."""
    try:
        from app.observability.prompts import seed_prompt_registry
        seed_prompt_registry()
        logger.info("bootstrap.prompts step=seed_registry status=ok")
    except Exception as exc:
        logger.warn(
            "bootstrap.prompts step=seed_registry status=failed error='%s' "
            "impact='non-fatal — agents will use embedded default prompts'",
            exc,
        )


def _bootstrap_llm_registry() -> None:
    """Eager-load the LLM provider registry and validate API key availability."""
    try:
        from app.llm.registry import ensure_loaded
        ensure_loaded()
        logger.info("bootstrap.llm step=registry_loaded status=ok")
    except Exception as exc:
        logger.warn(
            "bootstrap.llm step=registry_loaded status=failed error='%s' "
            "impact='LLM provider chain unavailable — agents will fall back to FakeChatModel'",
            exc,
        )


async def _bootstrap_agents(app: FastAPI) -> None:
    """
    Build the SupervisorAgent with all active connector agents.

    Steps:
      1. Initialise the session store (Postgres-backed).
      2. Load LLM providers (fast + default).
      3. Load connector + agent registrations from loader.py.
      4. Query connector_configs for enabled connectors.
      5. Build the active agents dict via the connector registry.
      6. Instantiate the SupervisorAgent (fatal — platform cannot serve without it).
    """
    from app.infrastructure.database.session_store import PostgresSessionStore
    from app.agents.supervisor.supervisor_agent import SupervisorAgent
    from app.domains.permissions.repositories.permission_repository import PermissionRepository
    from app.domains.permissions.services.permission_service import PermissionService
    from app.domains.permissions.services.agent_authorization_service import AgentAuthorizationService
    from app.domains.confluence.repositories.connector_config_repository import ConnectorConfigRepository
    from app.infrastructure.database.database import AsyncSessionLocal
    from app.connectors.loader import load_all
    from app.connectors.registry import registry

    # ── Step 1: Session store ─────────────────────────────────────────────────
    session_store = PostgresSessionStore()
    app.state.session_store = session_store
    logger.info("bootstrap.agents step=session_store status=ok backend=postgres")

    # ── Step 2: LLM providers ─────────────────────────────────────────────────
    llm_fast         = None
    llm_default      = None
    provider_factory = None
    try:
        from app.llm.provider_factory import get_provider_factory
        provider_factory = get_provider_factory()
        llm_fast         = provider_factory.get_chat_model("KNOWLEDGE_FAST")
        llm_default      = provider_factory.get_chat_model("KNOWLEDGE_DEFAULT")
        logger.info(
            "bootstrap.agents step=llm_providers status=ok "
            "llm_fast=KNOWLEDGE_FAST llm_default=KNOWLEDGE_DEFAULT"
        )
    except Exception as exc:
        logger.warn(
            "bootstrap.agents step=llm_providers status=degraded error='%s' "
            "impact='FakeChatModel active — set API keys to enable real LLM responses'",
            exc,
        )

    # ── Step 3: Connector + agent registrations ───────────────────────────────
    # Load all connector and agent registrations defined in loader.py so that
    # the registry knows which agents are available before we query the DB.
    load_all()
    logger.info("bootstrap.agents step=connector_loader status=ok")

    # ── Step 4: Fetch enabled connectors from DB ──────────────────────────────
    # Query connector_configs to determine which connectors are active.
    # Only agents whose connector is enabled will be included in the active set.
    enabled_connector_ids: list[str] = []
    try:
        async with AsyncSessionLocal() as db:
            enabled_connector_rows = await ConnectorConfigRepository(db).get_all_enabled()
            enabled_connector_ids  = [row.connector_id for row in enabled_connector_rows]
        logger.info(
            "bootstrap.agents step=enabled_connectors status=ok connectors=%s",
            enabled_connector_ids,
        )
    except Exception as exc:
        logger.warn(
            "bootstrap.agents step=enabled_connectors status=failed error='%s' "
            "impact='falling back to always-on agents only — connector-specific agents inactive'",
            exc,
        )

    # ── Step 5: Build active agents dict via the connector registry ───────────
    # The registry instantiates each agent whose connector_id is in the enabled
    # list, injecting shared dependencies (session_store, LLM handles).
    active_agents: dict = registry.build_agents(
        enabled_connector_ids,
        session_store=session_store,
        llm_fast=llm_fast,
        llm_default=llm_default,
    )

    # ── Step 5b: JiraAgent — per-user OAuth via MCPProcessPool ────────────────
    # The JiraAgent uses a long-lived MCP process pool (one worker process per
    # authenticated user) to forward Jira tool calls.  We start the pool here
    # and pre-warm a worker for every user who already has an active Jira token,
    # so the first query after a backend restart is served without cold-start
    # latency.  All errors here are non-fatal: the platform continues without
    # Jira if the pool or the Jira credentials are unavailable.
    try:
        from app.agents.jira.agent import JiraAgent
        from app.domains.auth.services.atlassian_token_service import AtlassianTokenService
        from app.domains.jira.connector.mcp_process_pool import MCPProcessPool
        from app.shared.utils.crypto import TokenEncryption
        from sqlalchemy import select
        from app.domains.permissions.models.user_connector_credentials_model import UserConnectorCredentials

        # Initialise and start the MCP process pool that backs the JiraAgent.
        mcp_process_pool = MCPProcessPool(
            jira_url=settings.jira.base_url,
            cloud_id=settings.atlassian.cloud_id,
        )
        await mcp_process_pool.start()
        app.state.mcp_pool = mcp_process_pool

        # Build the JiraAgent, wiring it to the shared session store and pool.
        jira_agent = JiraAgent(
            token_service=AtlassianTokenService(),
            session_service=session_store,
            llm=provider_factory.get_chat_model("KNOWLEDGE_DEFAULT") if provider_factory else llm_default,
            mcp_base_url=settings.atlassian.mcp_url,
            jira_base_url=settings.jira.base_url,
            mcp_timeout_seconds=settings.jira.mcp_timeout_seconds,
            pool=mcp_process_pool,
        )
        app.state.jira_agent = jira_agent

        # Add (or override) the jira agent in the active agents dict so the
        # SupervisorAgent below receives the pool-backed instance.
        active_agents["jira"] = jira_agent
        logger.info("bootstrap.agents step=jira_agent status=ok mode=per_user_oauth_pool")

        # Pre-warm: spin up a worker process for each user who already has an
        # active Jira token stored in the DB.
        try:
            token_encryption = TokenEncryption()
            async with AsyncSessionLocal() as prewarm_db:
                prewarm_result = await prewarm_db.execute(
                    select(UserConnectorCredentials).where(
                        UserConnectorCredentials.connector_name == "jira",
                        UserConnectorCredentials.status          == "active",
                    )
                )
                active_jira_credentials = prewarm_result.scalars().all()

            for credential_row in active_jira_credentials:
                try:
                    if not credential_row.access_token_enc:
                        continue
                    decrypted_access_token = token_encryption.decrypt(str(credential_row.access_token_enc))
                    await mcp_process_pool.prewarm(str(credential_row.user_id), decrypted_access_token)
                except Exception as prewarm_user_exc:
                    logger.warn(
                        "bootstrap.agents step=jira_prewarm user_id=%s status=skipped error='%s'",
                        credential_row.user_id,
                        prewarm_user_exc,
                    )

            logger.info(
                "bootstrap.agents step=jira_prewarm status=ok prewarmed_users=%d",
                len(active_jira_credentials),
            )
        except Exception as prewarm_exc:
            logger.warn(
                "bootstrap.agents step=jira_prewarm status=failed error='%s' "
                "impact='non-fatal — first Jira query per user will incur pool cold-start latency'",
                prewarm_exc,
            )

    except Exception as jira_init_exc:
        logger.warn(
            "bootstrap.agents step=jira_agent status=unavailable error='%s' "
            "impact='Jira queries will not be available in this session'",
            jira_init_exc,
        )

    # ── Step 6: SupervisorAgent (fatal — platform cannot serve without it) ────
    # Build the central authorization gate that sits in front of all agents.
    # This step is intentionally not wrapped in a try/except: if the
    # SupervisorAgent cannot be constructed the platform must not start.
    authorization_service = AgentAuthorizationService(
        PermissionService(PermissionRepository())
    )
    app.state.supervisor_agent = SupervisorAgent(
        agents=active_agents,
        session_store=session_store,
        auth_service=authorization_service,
    )
    logger.info(
        "bootstrap.agents step=supervisor_agent status=ok active_agents=%s",
        sorted(active_agents.keys()),
    )


async def _bootstrap_confluence_sync() -> None:
    """Queue a Confluence incremental sync task if the connector is enabled."""
    try:
        from app.infrastructure.database.database import AsyncSessionLocal
        from app.domains.confluence.repositories.connector_config_repository import ConnectorConfigRepository
        from app.shared.enums import ConnectorType
        from app.ingestion.tasks import sync_confluence_space

        async with AsyncSessionLocal() as db:
            confluence_config = await ConnectorConfigRepository(db).get_by_id(
                ConnectorType.CONFLUENCE.value
            )

        if confluence_config and confluence_config.enabled:
            sync_confluence_space.delay()
            logger.info(
                "bootstrap.confluence step=sync_queued status=ok "
                "connector=confluence trigger=startup"
            )
        else:
            logger.info(
                "bootstrap.confluence step=sync_queued status=skipped "
                "reason='connector not configured or disabled in DB'"
            )
    except Exception as exc:
        logger.warn(
            "bootstrap.confluence step=sync_queued status=failed error='%s' "
            "impact='non-fatal — Confluence sync will not run until triggered manually or on next restart'",
            exc,
        )


# ──────────────────────────────────────────────────────────────────────────────
# Lifespan
# ──────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("startup service='enterprise-rag-platform' version='1.0.0'")

    await _bootstrap_azure_ad()
    _bootstrap_mlflow()
    _bootstrap_prompts()
    _bootstrap_llm_registry()
    await _bootstrap_agents(app)
    await _bootstrap_confluence_sync()

    logger.info("startup complete service='enterprise-rag-platform' status=ready")
    yield

    logger.info("shutdown service='enterprise-rag-platform'")

    # Gracefully shut down the JiraAgent MCP process pool so all worker
    # processes are terminated cleanly before the event loop closes.
    mcp_pool = getattr(app.state, "mcp_pool", None)
    if mcp_pool is not None:
        await mcp_pool.stop()
        logger.info("shutdown step=mcp_pool status=stopped")


# ──────────────────────────────────────────────────────────────────────────────
# Application
# ──────────────────────────────────────────────────────────────────────────────

_swagger_oauth_config: dict = {}
if settings.azure_ad.auth_enabled and settings.azure_ad.client_id:
    _swagger_oauth_config = {
        "usePkceWithAuthorizationCodeGrant": True,
        "clientId": settings.azure_ad.client_id,
        "scopes": f"api://{settings.azure_ad.client_id}/access_as_user",
    }

app = FastAPI(
    title="Secure Enterprise RAG + Agent Platform",
    version="1.0.0",
    description=(
        "Production-ready multi-agent RAG platform with pluggable connectors, "
        "permission-aware retrieval, and MLflow observability.\n\n"
        "**Auth:** Click the Authorize button and paste your `access_token` "
        "in the **BearerAuth (http, Bearer)** field."
    ),
    lifespan=lifespan,
    swagger_ui_oauth2_redirect_url="/oauth2-redirect",
    swagger_ui_init_oauth=_swagger_oauth_config or None,
)

setup_exception_handlers(app)


# ──────────────────────────────────────────────────────────────────────────────
# OpenAPI schema — adds BearerAuth security scheme for Swagger UI
# ──────────────────────────────────────────────────────────────────────────────

def _build_openapi_schema():
    if app.openapi_schema:
        return app.openapi_schema

    schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )

    schema.setdefault("components", {}).setdefault("securitySchemes", {})
    schema["components"]["securitySchemes"]["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
        "description": (
            "Paste the access_token from the /login Azure AD flow. "
            "Retrieve it from: DevTools → Application → Local Storage → access_token"
        ),
    }
    schema["security"] = [{"BearerAuth": []}]

    app.openapi_schema = schema
    return schema


app.openapi = _build_openapi_schema


# ──────────────────────────────────────────────────────────────────────────────
# Middleware
#
# Starlette applies middleware as a stack — the last registered runs first
# on inbound requests. Registration order here is intentionally reversed:
#
#   Inbound:  CORSMiddleware → AuthMiddleware → route handler
#   Outbound: route handler  → AuthMiddleware → CORSMiddleware
#
# AuthMiddleware passes OPTIONS requests through so CORSMiddleware can
# handle preflight without the request being blocked by auth.
# ──────────────────────────────────────────────────────────────────────────────

# Inner (registered first, runs second) — validates JWT, populates request.state.user_context
if settings.azure_ad.auth_enabled:
    app.add_middleware(AuthMiddleware, validator=token_validator)
else:
    logger.warn(
        "middleware.auth status=disabled "
        "reason='AZURE_AUTH_ENABLED=false' "
        "impact='all routes are unprotected — do not use in production'"
    )

# Outer (registered second, runs first) — handles CORS preflight and response headers
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["DELETE", "GET", "OPTIONS", "POST", "PUT", "PATCH"],
    allow_headers=["*"],
    expose_headers=["X-Session-ID"],
)


# ──────────────────────────────────────────────────────────────────────────────
# Routers
# ──────────────────────────────────────────────────────────────────────────────

from app.api.health import ping_router
from app.domains.chat.api.chat import chat_router
from app.domains.sessions.api.sessions import sessions_router
from app.domains.confluence.api.confluence import confluence_router
from app.domains.permissions.api.admin_connector_permissions import admin_connector_permissions_router
from app.domains.users.api.users_routes import users_router
from app.domains.jira.api.jira import router as jira_router
from app.domains.auth.api.atlassian_oauth_routes import atlassian_oauth_router

app.include_router(auth_router)               # /login, /auth/callback — Azure AD, public
app.include_router(atlassian_oauth_router)    # /auth/atlassian/* — Atlassian OAuth
app.include_router(ping_router)
app.include_router(chat_router)
app.include_router(sessions_router)
app.include_router(confluence_router)
app.include_router(admin_connector_permissions_router)
app.include_router(users_router)
app.include_router(jira_router)
