import time
from typing import Optional, Annotated
from dataclasses import dataclass

from fastapi import APIRouter, HTTPException, Request, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
import httpx

from app.infrastructure.database.database import get_db
from app.schemas.health import (
    HealthDetailSchema,
    HealthDetailsSchema,
    HealthCheckResponseSchema,
)
from app.shared.utils.logger.logger import Logger

logger = Logger(__name__)
ping_router = APIRouter(prefix="/health_check", tags=["Health Check"])

SessionDep = Annotated[AsyncSession, Depends(get_db)]


@dataclass
class HealthCheckResult:
    name: str
    status: str
    error: Optional[str] = None
    duration_ms: Optional[float] = None


class HealthChecker:

    @staticmethod
    async def check_database(session: AsyncSession) -> HealthCheckResult:
        start = time.time()
        try:
            await session.execute(text("SELECT 1"))
            return HealthCheckResult("database", "up", duration_ms=(time.time() - start) * 1000)
        except Exception as e:
            return HealthCheckResult("database", "down", str(e), (time.time() - start) * 1000)

    @staticmethod
    async def check_docs(base_url: str) -> HealthCheckResult:
        start = time.time()
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(f"{base_url}/docs", timeout=5.0)
            status = "up" if 200 <= response.status_code < 400 else "down"
            error  = None if status == "up" else f"HTTP {response.status_code}"
            return HealthCheckResult("docs", status, error, (time.time() - start) * 1000)
        except Exception as e:
            return HealthCheckResult("docs", "down", str(e), (time.time() - start) * 1000)


@ping_router.get("", response_model=HealthCheckResponseSchema)
async def health_check(request: Request, session: SessionDep) -> HealthCheckResponseSchema:
    try:
        base_url = str(request.base_url).rstrip("/")

        db_result   = await HealthChecker.check_database(session)
        docs_result = await HealthChecker.check_docs(base_url)
        api_result  = HealthCheckResult("api", "up")

        checks      = [db_result, docs_result, api_result]
        has_failure = any(c.status == "down" for c in checks)

        return HealthCheckResponseSchema(
            status="error" if has_failure else "ok",
            details=HealthDetailsSchema(
                database=HealthDetailSchema(
                    status=db_result.status,
                    duration_ms=db_result.duration_ms,
                    error=db_result.error,
                ),
                docs=HealthDetailSchema(
                    status=docs_result.status,
                    duration_ms=docs_result.duration_ms,
                    error=docs_result.error,
                ),
                api=HealthDetailSchema(
                    status=api_result.status,
                    duration_ms=api_result.duration_ms,
                    error=api_result.error,
                ),
            ),
        )

    except HTTPException as error:
        detail = HealthDetailSchema(status="down", error=str(error))
        return HealthCheckResponseSchema(
            status="error",
            details=HealthDetailsSchema(database=detail, docs=detail, api=detail),
        )
