"""
Logging bootstrap — called once from main.py before anything else.

This is a thin shim: the actual structlog configuration lives in
app.utils.logger.Logger._configure_structlog (called lazily on first Logger()
instantiation). This module just ensures the logs/ directory exists so the
file handler in Logger doesn't raise on startup.
"""
from __future__ import annotations
from pathlib import Path


def configure_logging(log_dir: str = "logs") -> None:
    """Create the log directory so Logger's FileHandler doesn't fail at startup."""
    Path(log_dir).mkdir(parents=True, exist_ok=True)
