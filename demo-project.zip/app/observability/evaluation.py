"""
MLflow evaluation harness.

Usage:
    python -m app.observability.evaluation            # dataset-based judges
    python -m app.observability.evaluation --traces   # trace-based judges on recent traces

Loads the eval dataset from tests/fixtures/eval_dataset.jsonl, runs the live
agent for each query, then scores with MLflow's native LLM judges backed by
the project's Groq model (configurable via MLFLOW_JUDGE_MODEL env var).

Dataset-based judges (run against a manually constructed DataFrame):
  - RelevanceToQuery   : is the answer on-topic for the question?
  - Correctness        : does the answer match the expected response?
  - Safety             : does the answer contain harmful content?
  - Fluency            : is the answer grammatically correct and well-written?
  - Completeness       : does the answer fully address all parts of the question?
  - groundedness       : is every fact in the answer present in the retrieved context?
  - conciseness        : is the answer free from unnecessary padding?
  - citation_quality   : does the answer cite specific source material when available?

Trace-based judges (run against live MLflow traces already in the experiment):
  - RetrievalGroundedness : is the answer aligned with what was retrieved?
  - RetrievalRelevance    : is the retrieved context relevant to the query?
  - RetrievalSufficiency  : is the retrieved context sufficient to answer?

Results are logged to the MLflow run and visible in the MLflow Evaluation UI.
"""
from __future__ import annotations

import json
import logging
import os
import pathlib
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)

# Stable UUID so permission DB queries don't error on type mismatch.
# This user has no connector access — retrieved_context falls back to
# expected_contexts from the dataset for scoring purposes.
EVAL_USER_ID = "00000000-0000-0000-0000-000000000001"


def load_eval_dataset() -> list[dict]:
    path = pathlib.Path(settings.rag.eval_dataset_path)
    if not path.exists():
        logger.warning("Eval dataset not found at %s", path)
        return []
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _build_scorers(judge_model: str) -> list:
    """Return all dataset-based judges configured with the given judge model.

    All scorers read from inputs/outputs only — no expectations column in the
    DataFrame. This avoids a crash in mlflow.genai.evaluate where Correctness
    tries to link expectations to a trace object that is None when tracing is
    disabled during the agent-call phase.

    The expected answer is embedded in inputs['expected_answer'] instead so
    the correctness Guidelines scorer can access it.
    """
    from mlflow.genai.scorers import Guidelines, RelevanceToQuery, Safety

    # max_tokens keeps judge responses short; temperature=0 makes scoring deterministic.
    # These also reduce token spend on Groq's free tier.
    params = {"max_tokens": 256, "temperature": 0}

    return [
        # ── Answer quality ────────────────────────────────────────────────────
        RelevanceToQuery(model=judge_model, inference_params=params),
        Safety(model=judge_model, inference_params=params),

        # Correctness via Guidelines — reads expected_answer from inputs so we
        # avoid the Correctness built-in which needs a live trace to store expectations.
        Guidelines(
            name="correctness",
            guidelines=[
                "The response must be semantically equivalent to the 'expected_answer' "
                "field in the inputs. Minor wording differences are fine; core facts must match.",
                "If 'expected_answer' is empty, skip this check and score as 'yes'.",
            ],
            model=judge_model,
            inference_params=params,
        ),

        # ── Retrieval-grounding ───────────────────────────────────────────────
        Guidelines(
            name="groundedness",
            guidelines=[
                "The response must only contain facts present in the 'context' field of the inputs.",
                "If the context is empty or missing, score as 'no'.",
            ],
            model=judge_model,
            inference_params=params,
        ),

        # ── Style ─────────────────────────────────────────────────────────────
        Guidelines(
            name="conciseness",
            guidelines=[
                "The response should answer the question directly without unnecessary padding, "
                "filler phrases, or repetition.",
                "Bullet points and headers are acceptable when the answer is complex.",
            ],
            model=judge_model,
            inference_params=params,
        ),

        Guidelines(
            name="citation_quality",
            guidelines=[
                "If the inputs contain a non-empty 'context', the response should reference "
                "or acknowledge the source material rather than presenting facts as self-evident.",
                "Numeric citations such as [1] or [2] are preferred over vague phrases like "
                "'according to documents'.",
                "If context is empty, this check should pass without penalising the response.",
            ],
            model=judge_model,
            inference_params=params,
        ),
    ]


def run_evaluation(
    session_id: str = "eval_session",
    user_id:    str = EVAL_USER_ID,
    user_roles: Optional[list[str]] = None,
    experiment_name: Optional[str] = None,
) -> dict:
    """
    Run all dataset-based judges against the eval dataset.
    Calls the live RAG agent for each row, then scores outputs with LLM judges.
    """
    import mlflow
    import mlflow.genai
    import pandas as pd

    # Ensure litellm (used by native judges) can find the Groq key.
    if settings.llm_keys.groq_api_key:
        os.environ.setdefault("GROQ_API_KEY", settings.llm_keys.groq_api_key)

    # Set tracking URI in both the env var AND the Python client.
    # The async trace exporter reads os.environ; the Python client controls runs.
    os.environ["MLFLOW_TRACKING_URI"] = settings.mlflow.tracking_uri
    mlflow.set_tracking_uri(settings.mlflow.tracking_uri)

    # Disable tracing for the agent-call phase — the async trace exporter can
    # race against our URI config and try to write to /mlruns.
    # mlflow.genai.evaluate re-enables tracing internally for scoring.
    mlflow.tracing.disable()

    rows = load_eval_dataset()
    if not rows:
        logger.error("No eval data — aborting evaluation")
        return {}

    from app.agents.knowledge_rag.agent import KnowledgeRAGAgent
    from app.infrastructure.database.session_store import InMemorySessionStore
    from app.llm.provider_factory import get_provider_factory

    factory       = get_provider_factory()
    session_store = InMemorySessionStore()
    agent         = KnowledgeRAGAgent(
        llm_fast=factory.get_chat_model("KNOWLEDGE_FAST"),
        llm_default=factory.get_chat_model("KNOWLEDGE_DEFAULT"),
        session_store=session_store,
    )

    results = []
    for i, row in enumerate(rows):
        query    = row["query"]
        expected = row.get("expected_answer", "")
        contexts = row.get("expected_contexts", [])
        sid      = f"{session_id}_{i}"

        try:
            result = agent.handle(
                question=query,
                session_id=sid,
                user_id=user_id,
                user_roles=user_roles or [],
            )
            actual_answer      = result.text
            retrieved_contexts = [c.snippet for c in result.citations] if result.citations else []
        except Exception as exc:
            logger.error("Agent failed for query %r: %s", query, exc)
            actual_answer      = ""
            retrieved_contexts = []

        # Fall back to expected_contexts when eval user has no connector access.
        context_for_scoring = retrieved_contexts or contexts

        # All judge inputs are embedded in the inputs dict.
        # No separate expectations column — Correctness built-in crashes when
        # trace is None (tracing is disabled during agent calls).
        results.append({
            "inputs": {
                "question":        query,
                "expected_answer": expected,
                "context": "\n".join(
                    c.get("content", str(c)) if isinstance(c, dict) else str(c)
                    for c in context_for_scoring
                ),
            },
            "outputs": actual_answer,
        })

    df          = pd.DataFrame(results)
    judge_model = settings.mlflow.judge_model
    scorers     = _build_scorers(judge_model)

    # Re-enable tracing before evaluate — the harness stores scorer assessments
    # onto trace objects; if tracing is disabled, eval_item.trace is None and
    # _get_new_expectations crashes after every successful scorer invocation.
    mlflow.tracing.enable()

    exp = experiment_name or settings.mlflow.experiment_name
    mlflow.end_run()
    with mlflow.start_run(
        experiment_id=mlflow.set_experiment(exp).experiment_id,
        run_name="rag_evaluation",
    ) as run:
        eval_result = mlflow.genai.evaluate(data=df, scorers=scorers)

        scores = eval_result.metrics
        logged = {k.replace("/", "_"): v for k, v in scores.items() if isinstance(v, (int, float))}
        logged["eval_row_count"] = len(results)
        mlflow.log_metrics(logged)

        logger.info(
            "Evaluation complete run_id=%s judge=%s rows=%d metrics=%s",
            run.info.run_id, judge_model, len(results),
            {k: round(v, 3) for k, v in logged.items()},
        )
        return scores


def run_trace_evaluation(
    experiment_name: Optional[str] = None,
    max_traces: int = 50,
) -> dict:
    """
    Run retrieval-specific judges against existing MLflow traces.

    RetrievalGroundedness, RetrievalRelevance, and RetrievalSufficiency pull
    retrieved context directly from trace spans — they don't need a manual dataset.

    Args:
        experiment_name: MLflow experiment to search for traces (defaults to config value).
        max_traces: Maximum number of recent traces to evaluate.
    """
    import mlflow
    import mlflow.genai
    from mlflow.genai.scorers import (
        RetrievalGroundedness,
        RetrievalRelevance,
        RetrievalSufficiency,
    )

    if settings.llm_keys.groq_api_key:
        os.environ.setdefault("GROQ_API_KEY", settings.llm_keys.groq_api_key)

    os.environ["MLFLOW_TRACKING_URI"] = settings.mlflow.tracking_uri
    mlflow.set_tracking_uri(settings.mlflow.tracking_uri)

    exp         = experiment_name or settings.mlflow.experiment_name
    judge_model = settings.mlflow.judge_model

    experiment = mlflow.get_experiment_by_name(exp)
    if experiment is None:
        logger.error("Experiment %r not found — run the app first to generate traces", exp)
        return {}

    traces = mlflow.search_traces(
        experiment_ids=[experiment.experiment_id],
        max_results=max_traces,
    )

    if traces.empty:
        logger.warning("No traces found in experiment %r", exp)
        return {}

    logger.info("Scoring %d traces from experiment %r", len(traces), exp)

    scorers = [
        RetrievalGroundedness(model=judge_model),
        RetrievalRelevance(model=judge_model),
        RetrievalSufficiency(model=judge_model),
    ]

    mlflow.end_run()
    with mlflow.start_run(
        experiment_id=experiment.experiment_id,
        run_name="rag_trace_evaluation",
    ) as run:
        eval_result = mlflow.genai.evaluate(data=traces, scorers=scorers)

        scores = eval_result.metrics
        logged = {k.replace("/", "_"): v for k, v in scores.items() if isinstance(v, (int, float))}
        logged["trace_count"] = len(traces)
        mlflow.log_metrics(logged)

        logger.info(
            "Trace evaluation complete run_id=%s judge=%s traces=%d metrics=%s",
            run.info.run_id, judge_model, len(traces),
            {k: round(v, 3) for k, v in logged.items()},
        )
        return scores


if __name__ == "__main__":
    import argparse
    from app.observability.tracing import init_mlflow

    parser = argparse.ArgumentParser(description="Run MLflow evaluation")
    parser.add_argument(
        "--traces",
        action="store_true",
        help="Score existing traces instead of running the agent on the eval dataset",
    )
    parser.add_argument(
        "--max-traces",
        type=int,
        default=50,
        help="Maximum number of traces to evaluate (only used with --traces)",
    )
    args = parser.parse_args()

    init_mlflow()

    if args.traces:
        scores = run_trace_evaluation(max_traces=args.max_traces)
        print("Trace evaluation scores:", scores)
    else:
        scores = run_evaluation()
        print("Dataset evaluation scores:", scores)
