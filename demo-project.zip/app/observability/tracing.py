"""
MLflow tracing setup.

- Initializes the MLflow tracking server connection
- Sets up experiment
- Enables mlflow.langchain.autolog() for automatic node-level child spans
  in every LangGraph pipeline (parent span opened per-request by the route handler)

Parent-child span nesting:
  request (root span)
  └── rewrite_query_llm      ← auto-traced by autolog
  └── grade_context          ← auto-traced by autolog
  └── generate_answer_llm    ← auto-traced by autolog
      └── generate_answer_result  ← manual child span inside the node
"""
from __future__ import annotations
import logging
import os

import mlflow

from app.core.config import settings

logger = logging.getLogger(__name__)


def _mlflow_reachable(tracking_uri: str, timeout: int = 3) -> bool:
    """Return True if the MLflow server responds within `timeout` seconds."""
    if not tracking_uri.startswith("http"):
        return True  # local sqlite / file URI — always reachable
    try:
        import urllib.request
        urllib.request.urlopen(tracking_uri, timeout=timeout)
        return True
    except Exception:
        return False


def init_mlflow() -> None:
    """Initialize MLflow — called once at application startup."""
    tracking_uri = settings.mlflow.tracking_uri
    experiment   = settings.mlflow.experiment_name

    os.environ["MLFLOW_TRACKING_URI"] = tracking_uri
    mlflow.set_tracking_uri(tracking_uri)

    if not _mlflow_reachable(tracking_uri):
        logger.warning(
            "MLflow server at %s is unreachable — tracing and experiment tracking disabled",
            tracking_uri,
        )
        mlflow.tracing.disable()
        return

    # MLflow 3.x tracing backend
    try:
        mlflow.tracing.disable()
        mlflow.tracing.enable()
    except Exception:
        pass

    try:
        exp = mlflow.set_experiment(experiment)
        logger.info(
            "MLflow initialized tracking_uri=%s experiment=%s id=%s",
            tracking_uri, experiment, exp.experiment_id,
        )
    except Exception as exc:
        logger.warning(
            "MLflow experiment setup failed: %s — continuing without MLflow", exc
        )


