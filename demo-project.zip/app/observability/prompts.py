"""
MLflow Prompt Registry — seed and load prompts.

Two prompts are managed via the registry:
  1. intent_classify  (version 1)
  2. rag_answer       (versions 1 and 2)

Run `python -m app.observability.prompts` to seed the registry.
Nodes load prompts at runtime via load_prompt().

MLflow 3.x notes
----------------
- register_prompt() no longer accepts `version` or `description`; versions
  auto-increment on each call.  Use `commit_message` for human notes.
- Templates can use plain {var} syntax; load_prompt() returns the raw string
  which we pass to Python's str.format().
- load_prompt(name, version=n) still works for targeted version lookup.
"""
from __future__ import annotations
import logging
from app.core.config import settings

logger = logging.getLogger(__name__)
# ──────────────────────────────────────────────────────────────────────────────
# Prompt templates (authoritative source)
# ──────────────────────────────────────────────────────────────────────────────

INTENT_CLASSIFY_V1 = """\
You are an intent classifier for an enterprise knowledge assistant.

Classify the user's message into exactly one of:
- knowledge_qa  — they are asking a question whose answer should come from internal documents
- smalltalk     — greetings, thanks, chit-chat
- out_of_scope  — they are asking the assistant to take an action (create ticket, send message, etc.)

Return JSON: {{ "intent": "<one of above>", "confidence": 0..1 }}

User message:
{user_input}"""

RAG_ANSWER_V1 = """\
You are an enterprise knowledge assistant. Answer the user's question using ONLY the provided context.
If the context does not contain the answer, say so explicitly — do not invent.

Cite every factual claim with [n] where n is the 1-based index of the source chunk.

Context:
{context}

Conversation so far:
{history}

User: {user_input}
Assistant:"""

RAG_ANSWER_V2 = """\
You are a precise enterprise knowledge assistant.
Answer the question using ONLY the numbered context chunks below.
- Be concise and direct. Use bullet points or numbered lists when listing multiple items.
- Place [n] immediately after EACH sentence or item that uses that source, not just at the end.
- Every single point or sentence must have a citation [n]. No uncited claims allowed.
- Do not add information beyond what the context provides.
- If the context contains relevant information but cannot give a fully precise answer,
  share what the context does say and clarify what varies or is not specified.
- Only say "I don't know based on the indexed documents" when the topic is completely
  absent from the context — not when the context gives partial, range-based, or conditional information.

Context:
{context}

Conversation history:
{history}

Question: {user_input}
Answer:"""


# ──────────────────────────────────────────────────────────────────────────────
# Seed function
# ──────────────────────────────────────────────────────────────────────────────

def seed_prompt_registry() -> None:
    """
    Register all prompts in the MLflow prompt registry.
    Idempotent — checks whether each version already exists before registering.
    """
    _ensure_prompt_version("intent_classify", target_version=1,
                           template=INTENT_CLASSIFY_V1,
                           commit_message="Intent classification: knowledge_qa / smalltalk / out_of_scope")

    _ensure_prompt_version("rag_answer", target_version=1,
                           template=RAG_ANSWER_V1,
                           commit_message="RAG answer v1 — verbose with conversation history")
    _ensure_prompt_version("rag_answer", target_version=2,
                           template=RAG_ANSWER_V2,
                           commit_message="RAG answer v2 — concise, no history")
    _ensure_prompt_version("rag_answer", target_version=3,
                           template=RAG_ANSWER_V2,
                           commit_message="RAG answer v3 — precise, structured, fully cited with history")
    _ensure_prompt_version("rag_answer", target_version=4,
                           template=RAG_ANSWER_V2,
                           commit_message="RAG answer v4 — strict per-item citation after every sentence")
    _ensure_prompt_version("rag_answer", target_version=5,
                           template=RAG_ANSWER_V2,
                           commit_message="RAG answer v5 — hedge on partial/range answers instead of refusing")

    logger.info("Seeded MLflow prompt registry: intent_classify v1, rag_answer v1+v2+v3")


def _ensure_prompt_version(
    name: str,
    target_version: int,
    template: str,
    commit_message: str = "",
) -> None:
    import mlflow.genai

    try:
        existing = mlflow.genai.load_prompt(name, version=target_version, allow_missing=True)
        if existing is not None:
            logger.debug("Prompt %s v%d already registered — skipping", name, target_version)
            return
    except Exception:
        pass

    try:
        result = mlflow.genai.register_prompt(
            name=name,
            template=template,
            commit_message=commit_message,
            tags={"stage": "production"},
        )
        logger.info("Registered prompt name=%s version=%s", name, result.version)
    except Exception as exc:
        logger.warning("Failed to register prompt %s v%d: %s", name, target_version, exc)


# ──────────────────────────────────────────────────────────────────────────────
# Runtime loading
# ──────────────────────────────────────────────────────────────────────────────

def load_prompt(name: str, version: int | None = None) -> str:
    """
    Load a prompt template from the registry.
    Returns the raw template string (use str.format(**kwargs) to fill vars).
    Falls back to the embedded default on any failure.
    """
    import mlflow.genai

    try:
        v = version or settings.rag.get_prompt_version(name)
        prompt_obj = mlflow.genai.load_prompt(name, version=v)
        template = prompt_obj.template

        # PromptVersion.template is `str | list[dict]` — normalise to str.
        if isinstance(template, str):
            return template
        # Chat-style list of {"role": ..., "content": ...} dicts — join content fields.
        return "\n".join(
            msg.get("content", "") for msg in template if isinstance(msg, dict)
        )
    except Exception as exc:
        logger.debug(
            "Could not load prompt %s v%s from registry: %s — using embedded default",
            name, version, exc,
        )

    defaults: dict[str, str] = {
        "intent_classify": INTENT_CLASSIFY_V1,
        "rag_answer": RAG_ANSWER_V2,
    }
    return defaults.get(name, "")


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    from app.observability.tracing import init_mlflow
    init_mlflow()
    seed_prompt_registry()
    print("Prompt registry seeded successfully.")
