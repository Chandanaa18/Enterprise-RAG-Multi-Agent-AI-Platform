"""
Application settings via pydantic-settings.

Every value the app reads from the environment lives here as a typed field.
No os.getenv() calls anywhere else in the codebase — import settings instead.

Usage:
    from app.core.config import settings
    db_url        = settings.db.url
    redis_url     = settings.redis.url
    mlflow_uri    = settings.mlflow.tracking_uri
    google_key    = settings.llm_keys.google_api_key
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)

from pydantic import AliasChoices, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# ──────────────────────────────────────────────────────────────────────────────
# Sub-configs  (one class per env-var namespace)
# ──────────────────────────────────────────────────────────────────────────────

class AppConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="APP_", extra="ignore")

    name: str = "RAG Platform"
    version: str = "1.0.0"
    description: str = "Enterprise RAG Platform"
    host: str = "localhost"
    port: int = Field(default=8000, validation_alias=AliasChoices("APP_PORT", "PORT"))
    enable_debug_mode: bool = False
    # Where chat.html is served — used to redirect back after OAuth2 callback.
    # Set FRONTEND_URL in .env (e.g. http://localhost:3000 for local dev).
    frontend_url: str = Field(
        default="http://localhost:3000",
        validation_alias=AliasChoices("APP_FRONTEND_URL", "FRONTEND_URL"),
    )


class DBConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DB_", populate_by_name=True, extra="ignore")

    type: str = Field(
        default="postgresql+asyncpg",
        validation_alias=AliasChoices("DB_CONNECTION", "DB_TYPE"),
    )
    host: Optional[str] = "localhost"
    port: int = 5432
    username: Optional[str] = "rag"
    password: Optional[str] = "rag"
    database: str = "rag"
    logging: str = "false"

    @property
    def url(self) -> str:
        return f"{self.type}://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"


class RedisConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="REDIS_", extra="ignore")

    url: str = "redis://localhost:6379/0"


class PgVectorConfig(BaseSettings):
    """pgvector store config — embedding dimension is fixed to 3072
    (Gemini gemini-embedding-001) by the knowledge_chunks table schema."""
    model_config = SettingsConfigDict(env_prefix="PGVECTOR_", extra="ignore")

    embedding_dim: int = 3072


class MLflowConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MLFLOW_", extra="ignore")

    tracking_uri: str = "http://localhost:5000"
    experiment_name: str = "knowledge_rag"
    # litellm model URI used as LLM judge in evaluation runs.
    # Supports any litellm provider: "groq/...", "openai/...", "anthropic/...", etc.
    judge_model: str = "groq:/llama-3.3-70b-versatile"


class LLMKeysConfig(BaseSettings):
    """API keys for external LLM providers.  No env_prefix — keys have distinct names."""
    model_config = SettingsConfigDict(extra="ignore", populate_by_name=True)

    google_api_key: Optional[str] = Field(default=None, alias="GOOGLE_API_KEY")
    # GEMINI_API_KEY is Google's newer alias — set this in .env when GOOGLE_API_KEY is exhausted.
    # langchain-google-genai 4.x reads both env vars automatically.
    gemini_api_key: Optional[str] = Field(default=None, alias="GEMINI_API_KEY")
    groq_api_key: Optional[str] = Field(default=None, alias="GROQ_API_KEY")
    openrouter_api_key: Optional[str] = Field(default=None, alias="OPENROUTER_API_KEY")
    @property
    def effective_google_key(self) -> Optional[str]:
        """Return the first available Google API key (GOOGLE_API_KEY, then GEMINI_API_KEY)."""
        return self.google_api_key or self.gemini_api_key

    def get(self, env_var_name: str) -> Optional[str]:
        """Look up a key by its environment variable name (used by the LLM registry)."""
        mapping: dict[str, Optional[str]] = {
            "GOOGLE_API_KEY": self.effective_google_key,
            "GEMINI_API_KEY": self.gemini_api_key,
            "GROQ_API_KEY": self.groq_api_key,
            "OPENROUTER_API_KEY": self.openrouter_api_key,
        }
        return mapping.get(env_var_name)


class SessionConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SESSION_", extra="ignore")

    inactivity_timeout_hours: int = 8


class AzureADConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AZURE_", extra="ignore")

    auth_enabled: bool = False
    client_id: Optional[str] = None
    tenant_id: Optional[str] = None

    # Required for Authorization Code Flow (server-side token exchange).
    # Never expose this value in logs, responses, or client-side code.
    client_secret: Optional[str] = None

    # Must exactly match a Redirect URI registered in the Entra ID App Registration.
    redirect_uri: Optional[str] = None

    # Auto-computed from tenant_id if not explicitly set via AZURE_AUTHORITY.
    authority: Optional[str] = None

    @model_validator(mode="after")
    def validate_azure_config(self) -> "AzureADConfig":
        if self.auth_enabled:
            if not self.client_id:
                raise ValueError("AZURE_CLIENT_ID must be set when AZURE_AUTH_ENABLED=true")
            if not self.tenant_id:
                raise ValueError("AZURE_TENANT_ID must be set when AZURE_AUTH_ENABLED=true")
        if not self.authority and self.tenant_id:
            self.authority = f"https://login.microsoftonline.com/{self.tenant_id}"
        return self


class RAGConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RAG_", extra="ignore")

    chunk_strategy: str = "recursive"
    chunk_size: int = 800
    chunk_overlap: int = 120
    top_k_dense: int = 20
    top_k_after_rerank: int = 6
    answer_prompt_version: int = Field(
        default=5,
        validation_alias=AliasChoices("RAG_ANSWER_PROMPT_VERSION", "ANSWER_PROMPT_VERSION"),
    )
    eval_dataset_path: str = Field(
        default="tests/fixtures/eval_dataset.jsonl",
        validation_alias=AliasChoices("EVAL_DATASET_PATH", "RAG_EVAL_DATASET_PATH"),
    )

    def get_prompt_version(self, prompt_name: str) -> int:
        """Return the configured version number for a named prompt (defaults to 1)."""
        mapping: dict[str, int] = {
            "rag_answer": self.answer_prompt_version,
        }
        return mapping.get(prompt_name.lower(), 1)


class ConfluenceConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CONFLUENCE_", extra="ignore")

    base_url: str = ""
    email: str = ""
    api_token: str = ""
    timeout_seconds: float = 15.0
    max_retries: int = 3
    retry_backoff: float = 1.0


class LoggingConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ERP_", extra="ignore")

    log_file: str = "logs/app.log"
    log_level: str = "INFO"


class AtlassianConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ATLASSIAN_", extra="ignore", populate_by_name=True)

    mcp_url: str = "https://mcp.atlassian.com"
    api_token: str = ""
    email: str = ""
    cloud_id: str = ""
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = ""


class JiraConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="JIRA_", extra="ignore")

    base_url: str = ""
    mcp_timeout_seconds: float = 30.0


class TokenConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TOKEN_", extra="ignore")

    encryption_key: str = ""


class SecurityConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SECURITY_", extra="ignore")

    # Temporarily grants admin users full agent access regardless of connector
    # permissions.  Set SECURITY_ADMIN_BYPASS_ENABLED=false to enforce
    # connector restrictions for admins (target behaviour).
    admin_bypass_enabled: bool = True


class LLMConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LLM_", extra="ignore")

    # Model used by the supervisor planner (LLM_PLANNER_MODEL)
    planner_model: str = "llama-3.3-70b-versatile"


class MCPPoolConfig(BaseSettings):
    """Port-pool and lifecycle settings for per-user mcp-atlassian processes."""
    model_config = SettingsConfigDict(env_prefix="MCP_POOL_", extra="ignore")

    base_port: int          = 7801   # MCP_POOL_BASE_PORT
    max_users: int          = 99     # MCP_POOL_MAX_USERS  (base_port + max_users - 1 = last port)
    idle_timeout_secs: int  = 1800   # MCP_POOL_IDLE_TIMEOUT_SECS  (30 min)
    startup_wait_secs: float = 4.0   # MCP_POOL_STARTUP_WAIT_SECS


class IngestionConfig(BaseSettings):
    """Celery task retry and timing settings for the ingestion pipeline."""
    model_config = SettingsConfigDict(env_prefix="INGESTION_", extra="ignore")

    max_retries: int           = 3   # INGESTION_MAX_RETRIES
    default_retry_delay: int   = 60  # INGESTION_DEFAULT_RETRY_DELAY  (seconds)
    permissions_retry_delay: int = 30  # INGESTION_PERMISSIONS_RETRY_DELAY


# ──────────────────────────────────────────────────────────────────────────────
# Root settings object
# ──────────────────────────────────────────────────────────────────────────────

class Settings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")

    app: AppConfig           = Field(default_factory=AppConfig)
    db: DBConfig             = Field(default_factory=DBConfig)
    redis: RedisConfig       = Field(default_factory=RedisConfig)
    pgvector: PgVectorConfig = Field(default_factory=PgVectorConfig)
    mlflow: MLflowConfig     = Field(default_factory=MLflowConfig)
    llm_keys: LLMKeysConfig  = Field(default_factory=LLMKeysConfig)
    session: SessionConfig   = Field(default_factory=SessionConfig)
    azure_ad: AzureADConfig  = Field(default_factory=AzureADConfig)
    rag: RAGConfig           = Field(default_factory=RAGConfig)
    confluence: ConfluenceConfig = Field(default_factory=ConfluenceConfig)
    logging: LoggingConfig       = Field(default_factory=LoggingConfig)
    atlassian: AtlassianConfig   = Field(default_factory=AtlassianConfig)
    jira: JiraConfig             = Field(default_factory=JiraConfig)
    token: TokenConfig           = Field(default_factory=TokenConfig)
    security: SecurityConfig     = Field(default_factory=SecurityConfig)
    llm: LLMConfig               = Field(default_factory=LLMConfig)
    mcp_pool: MCPPoolConfig      = Field(default_factory=MCPPoolConfig)
    ingestion: IngestionConfig   = Field(default_factory=IngestionConfig)
# Singleton — import this everywhere
settings = Settings()

# Backwards-compatibility alias
envSettings = settings


