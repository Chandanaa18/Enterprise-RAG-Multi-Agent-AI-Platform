"""
Application-wide constants.

Use this module for values that are:
  - Fixed by the external provider (e.g. OAuth endpoint URLs)
  - Shared across multiple modules (prevent duplication)
  - Not environment-specific (same in dev, staging, prod)

For environment-specific values use app/core/config.py instead.
"""
from __future__ import annotations

from app.shared.enums import ConnectorType

# ── Database ──────────────────────────────────────────────────────────────────
DB_SCHEMA = "enterprise_rag_system"

# Schema-qualified table paths — keep in sync with SQLAlchemy model __tablename__
USERS_TABLE            = f"{DB_SCHEMA}.users"
DOCUMENT_INDEX_TABLE   = f"{DB_SCHEMA}.document_index"
KNOWLEDGE_CHUNKS_TABLE = f"{DB_SCHEMA}.knowledge_chunks"

# ── Connectors ────────────────────────────────────────────────────────────────
# Ordered list of all connectors the system currently supports.
# connector_id values here must match knowledge_chunks.connector_id in the DB.
# Add new connectors here before they can appear in allowed_connectors.
ALL_SUPPORTED_CONNECTORS: list[str] = [
    ConnectorType.CONFLUENCE,
    ConnectorType.SHAREPOINT,
    ConnectorType.JIRA,
    ConnectorType.TEAMS,
    ConnectorType.M365,
]

# ── Metadata JSONB keys ───────────────────────────────────────────────────────
# Key inside users.metadata for group memberships — e.g. ["engineering", "devs"]
USER_METADATA_GROUPS_KEY = "groups"

# Key inside users.metadata for connector-specific external identities.
# Structure: {"connector_accounts": {"confluence": {"account_id": "..."}, ...}}
USER_METADATA_CONNECTOR_ACCOUNTS_KEY = "connector_accounts"

# ── Confluence permission label prefixes ──────────────────────────────────────
# Page labels use these prefixes to encode access rules.
# e.g. "role:engineering" means the "engineering" role is required.
CONFLUENCE_ROLE_PREFIX  = "role:"
CONFLUENCE_GROUP_PREFIX = "group:"

# ── Atlassian OAuth endpoints ─────────────────────────────────────────────────
# Fixed by Atlassian — do not override per-environment.
ATLASSIAN_AUTH_URL     = "https://auth.atlassian.com/authorize"
ATLASSIAN_TOKEN_URL    = "https://auth.atlassian.com/oauth/token"
ATLASSIAN_IDENTITY_URL = "https://api.atlassian.com/me"

# Scopes granted during the OAuth consent step.
# Must match what is configured in the Atlassian developer console.
ATLASSIAN_OAUTH_SCOPES = (
    "read:jira-work write:jira-work read:jira-user read:me offline_access"
)

# ── Provider API base URLs ────────────────────────────────────────────────────
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# ── Embedding ─────────────────────────────────────────────────────────────────
GEMINI_EMBEDDING_MODEL = "models/gemini-embedding-001"
GEMINI_EMBEDDING_DIM   = 3072
