"""
auth_deps.py — FastAPI dependencies that resolve the authenticated ORM User.

Design change (2026-05-24):
  Previously, get_current_user used fastapi-azure-auth's Security() dependency
  to validate the JWT on every request.  That caused double validation (once in
  AuthMiddleware, once here) and broke on v1 tokens because fastapi-azure-auth
  only accepts the v2 issuer.

  Now: AuthMiddleware owns JWT validation and writes a validated UserContext to
  request.state.user.  get_current_user reads that context and does a single DB
  lookup to return the full ORM User.  fastapi-azure-auth's azure_scheme is kept
  only for loading the OpenID config at startup (used by Swagger UI OAuth2).
"""

from typing import Any

from fastapi import Depends, Header, HTTPException, Request, Security
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.database.database import get_db
from app.domains.users.services.user_service import UserService
from app.domains.users.models.user_model import User
from app.shared.enums import UserRole
from app.shared.exceptions.base_exception import PermissionDeniedError
from app.shared.exceptions.error_enums import LogEvent
from app.core.config import settings as envSettings
from app.shared.utils.logger.logger import Logger
from fastapi_azure_auth import SingleTenantAzureAuthorizationCodeBearer

logger = Logger(__name__)

azure_scheme = None

if envSettings.azure_ad.auth_enabled:

    _client_id = envSettings.azure_ad.client_id
    _tenant_id = envSettings.azure_ad.tenant_id

    if not _client_id:
        raise EnvironmentError("AZURE_CLIENT_ID must be set when AZURE_AUTH_ENABLED=true")
    if not _tenant_id:
        raise EnvironmentError("AZURE_TENANT_ID must be set when AZURE_AUTH_ENABLED=true")

    # azure_scheme is kept for two purposes only:
    #   1. Loading OpenID config at startup (main.py lifespan)
    #   2. Powering the Swagger UI "Authorize" button
    # It is NO LONGER used as a per-request Security() dependency — that role
    # belongs to AuthMiddleware + get_current_user below.
    azure_scheme = SingleTenantAzureAuthorizationCodeBearer(
        app_client_id=_client_id,
        tenant_id=_tenant_id,
        scopes={f"api://{_client_id}/access_as_user": "Access as user"},
        # auto_error=False: let our AuthMiddleware own validation; azure_scheme
        # is declared here only so FastAPI emits the security scheme in OpenAPI
        # (Swagger lock icons + "Authorize" button).  If fastapi-azure-auth's
        # own token check fails (e.g., v1-format token), it returns None rather
        # than raising — request.state.user (set by AuthMiddleware) is the
        # authoritative source of truth.
        auto_error=False,
    )

    async def get_current_user(
        request: Request,
        db: AsyncSession = Depends(get_db),
        # Declaring Security(azure_scheme) here causes FastAPI to:
        #   1. Add AzureAD_PKCE_single_tenant to OpenAPI securitySchemes.
        #   2. Stamp a security requirement on every route that depends on
        #      get_current_user (directly or via require_role), giving Swagger
        #      the lock icon and "Authorize" button.
        # The resolved value (_azure_user) is intentionally ignored — auth is
        # enforced via request.state.user populated by AuthMiddleware.
        _azure_user: Any = Security(azure_scheme, scopes=["access_as_user"]),
    ) -> User:
        """
        Return the full ORM User for the authenticated caller.

        AuthMiddleware has already validated the JWT and populated
        request.state.user (UserContext) before this dependency runs.
        We read that context and upsert the user in the DB so that roles
        and display_name stay in sync with every request.
        """
        from app.domains.auth.schemas.user_context import UserContext

        user_ctx: UserContext | None = getattr(request.state, "user_context", None)
        if user_ctx is None:
            raise HTTPException(
                status_code=401,
                detail="Not authenticated. AuthMiddleware did not populate request.state.user_context.",
            )

        logger.info(
            "Resolving ORM user from validated UserContext",
            azure_ad_oid=user_ctx.azure_ad_oid,
            email=user_ctx.email,
        )

        user_service = UserService(db)
        user = await user_service.get_or_provision_user(
            azure_ad_oid=user_ctx.azure_ad_oid,
            email=user_ctx.email,
            display_name=user_ctx.display_name,
            roles=user_ctx.roles,
        )

        # Enqueue identity resolution if connector_accounts is not yet populated.
        # This is the primary trigger for users who already have a valid token in
        # localStorage and never re-hit /auth/callback after the task was wired.
        # The task is idempotent — ConnectorIdentityService skips connectors that
        # are already resolved, so duplicate enqueues on concurrent requests are
        # harmless. Once metadata is populated this branch never fires again.
        connector_accounts = (user.metadata_ or {}).get("connector_accounts", {})
        if not connector_accounts:
            try:
                from app.ingestion.tasks import resolve_user_identities
                resolve_user_identities.delay(str(user.user_id), user.email)
                logger.info(
                    "Identity resolution enqueued from request path",
                    user_id=str(user.user_id),
                    email=user.email,
                )
            except Exception as exc:
                # Never block the request — just log and continue.
                logger.error(
                    "Failed to enqueue identity resolution from request path",
                    user_id=str(user.user_id),
                    email=user.email,
                    exc_info=exc,
                )

        return user

else:
    logger.warn(
        "Azure AD authentication is DISABLED — using dev stub (X-User-Email header). "
        "Never run with AZURE_AUTH_ENABLED=false in production.",
        event=LogEvent.USER_AUTH_FAILED.value,
    )

    async def _get_current_user_stub(
        db: AsyncSession = Depends(get_db),
        x_user_email: str = Header(..., alias="X-User-Email"),
    ) -> User:
        """
        Dev-mode stub: auto-provisions any email on first use.
        No password, no pre-seeding needed — just pass X-User-Email.
        """
        user_service = UserService(db)
        user = await user_service.get_user_by_email(x_user_email)

        if not user:
            # Auto-create the user so any email works without manual seeding
            import uuid as _uuid
            logger.warn(
                f"Dev stub: auto-provisioning user '{x_user_email}' with employee+admin roles",
                event=LogEvent.USER_PROVISIONED.value,
                email=x_user_email,
            )
            user = await user_service.get_or_provision_user(
                azure_ad_oid=str(_uuid.uuid5(_uuid.NAMESPACE_URL, x_user_email)),
                email=x_user_email,
                display_name=x_user_email.split("@")[0],
                roles=["employee", "admin"],
            )

        return user

    get_current_user = _get_current_user_stub  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# RBAC dependency factory
# ---------------------------------------------------------------------------

def require_role(*roles: UserRole):
    """
    Gates a route to users holding at least one of the given roles.
    admin bypasses all role checks.

    Usage:
        @router.post("/chat")
        async def chat(user: User = Depends(require_role(UserRole.AGENT_JIRA))):
            ...
    """
    async def checker(current_user: User = Depends(get_current_user)) -> User:
        user_roles: set[str] = set(current_user.roles or [])

        if UserRole.ADMIN.value in user_roles:
            return current_user

        required = {role.value for role in roles}
        if not user_roles & required:
            logger.warn(
                "RBAC check failed — access denied",
                event=LogEvent.RBAC_DENIED.value,
                user_id=str(current_user.user_id),
                required_roles=sorted(required),
                user_roles=sorted(user_roles),
            )
            raise PermissionDeniedError(
                user_id=str(current_user.user_id),
                resource=", ".join(sorted(required)),
            )

        return current_user

    return checker
