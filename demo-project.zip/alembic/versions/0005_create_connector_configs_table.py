"""Create connector configs table

Revision ID: 0005
Revises: 0004
Create Date: 2024-05-19 12:04:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0005'
down_revision: Union[str, Sequence[str], None] = '0004'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.connector_configs (
        connector_id TEXT PRIMARY KEY,
        connector_name TEXT,
        enabled BOOLEAN,
        config JSONB,
        last_sync_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE
    );
    ''')

def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS enterprise_rag_system.connector_configs CASCADE;')
