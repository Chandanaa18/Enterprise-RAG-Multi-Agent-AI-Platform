"""Create schemas and extensions

Revision ID: 0000
Revises: 
Create Date: 2024-05-19 11:59:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0000'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    # create schemas
    op.execute("CREATE SCHEMA IF NOT EXISTS enterprise_rag_system;")
    op.execute("CREATE SCHEMA IF NOT EXISTS audit;")

    # pgvector stores knowledge chunk embeddings (halfvec for 3072-d Gemini vectors with HNSW).
    # uuid-ossp is useful for gen_random_uuid() in raw SQL scripts.
    op.execute("CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";")
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto;")
    op.execute("CREATE EXTENSION IF NOT EXISTS vector;")

def downgrade() -> None:
    op.execute('DROP SCHEMA IF EXISTS enterprise_rag_system CASCADE;')
    op.execute('DROP SCHEMA IF EXISTS audit CASCADE;')
