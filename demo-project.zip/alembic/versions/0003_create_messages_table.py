"""Create messages table

Revision ID: 0003
Revises: 0002
Create Date: 2024-05-19 12:02:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0003'
down_revision: Union[str, Sequence[str], None] = '0002'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.messages (
        message_id UUID PRIMARY KEY,
        session_id UUID REFERENCES enterprise_rag_system.sessions(session_id),
        role TEXT,
        content TEXT,
        agent_name TEXT,
        created_at TIMESTAMP WITH TIME ZONE,
        token_usage JSONB,
        mlflow_run_id TEXT
    );
    ''')

def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS enterprise_rag_system.messages CASCADE;')
