"""Create user_connector_credentials table

Revision ID: 0010
Revises: 0009
Create Date: 2026-06-05 00:00:00.000000

Purpose
-------
Stores per-user credentials for each connector (Jira, Confluence, Teams, M365).

Separates two concerns that were previously mixed in connector_permissions.metadata_:
  - connector_permissions  → access control (who can use which connector)
  - user_connector_credentials → identity + credentials (how to authenticate as that user)

One row per (user_id, connector_name) pair.

Connector-specific usage
------------------------
  Confluence  : external_id = Atlassian accountId, no token (service account handles ingestion)
  Jira        : external_id = Atlassian accountId, access_token + refresh_token (OAuth 2.0)
  Teams       : external_id = Azure AD OID, no separate token (reuses Azure AD session)
  M365        : external_id = Azure AD OID, no separate token (reuses Azure AD session)
  SharePoint  : external_id = Azure AD OID, no separate token (reuses Azure AD session)
"""
from typing import Sequence, Union
from alembic import op


revision: str = '0010'
down_revision: Union[str, Sequence[str], None] = '0009'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE IF NOT EXISTS enterprise_rag_system.user_connector_credentials (
            credential_id       UUID        NOT NULL DEFAULT gen_random_uuid(),
            user_id             UUID        NOT NULL
                                            REFERENCES enterprise_rag_system.users(user_id)
                                            ON DELETE CASCADE,
            connector_name      TEXT        NOT NULL,
            external_id         TEXT        NULL,
            external_email      TEXT        NULL,
            access_token_enc    TEXT        NULL,
            refresh_token_enc   TEXT        NULL,
            expires_at          TIMESTAMPTZ NULL,
            token_scope         TEXT        NULL,
            status              TEXT        NOT NULL DEFAULT 'active',
            metadata            JSONB       NULL,
            created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

            CONSTRAINT pk_user_connector_credentials
                PRIMARY KEY (credential_id),

            CONSTRAINT uq_user_connector
                UNIQUE (user_id, connector_name),

            CONSTRAINT chk_status
                CHECK (status IN ('active', 'revoked'))
        );
    """)

    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ucc_user_connector
            ON enterprise_rag_system.user_connector_credentials (user_id, connector_name);
    """)

    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ucc_external_id
            ON enterprise_rag_system.user_connector_credentials (connector_name, external_id);
    """)

    op.execute("""
        CREATE OR REPLACE FUNCTION enterprise_rag_system.update_ucc_updated_at()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    """)

    op.execute("""
        CREATE TRIGGER trg_ucc_updated_at
        BEFORE UPDATE ON enterprise_rag_system.user_connector_credentials
        FOR EACH ROW EXECUTE FUNCTION enterprise_rag_system.update_ucc_updated_at();
    """)


def downgrade() -> None:
    op.execute("""
        DROP TRIGGER IF EXISTS trg_ucc_updated_at
            ON enterprise_rag_system.user_connector_credentials;
    """)
    op.execute("""
        DROP FUNCTION IF EXISTS enterprise_rag_system.update_ucc_updated_at();
    """)
    op.execute("""
        DROP TABLE IF EXISTS enterprise_rag_system.user_connector_credentials CASCADE;
    """)
