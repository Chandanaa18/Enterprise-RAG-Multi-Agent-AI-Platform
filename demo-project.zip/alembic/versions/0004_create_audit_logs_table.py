"""Create audit logs table

Revision ID: 0004
Revises: 0003
Create Date: 2024-05-19 12:03:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0004'
down_revision: Union[str, Sequence[str], None] = '0003'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS audit.audit_logs (
        log_id UUID PRIMARY KEY,
        user_id UUID REFERENCES enterprise_rag_system.users(user_id),
        session_id UUID REFERENCES enterprise_rag_system.sessions(session_id),
        agent_name TEXT,
        action TEXT,
        target_system TEXT,
        target_resource TEXT,
        outcome TEXT,
        created_at TIMESTAMP WITH TIME ZONE,
        metadata JSONB
    );
    ''')

def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS audit.audit_logs CASCADE;')
