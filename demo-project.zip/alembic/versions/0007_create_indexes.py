"""Create indexes

Revision ID: 0007
Revises: 0006
Create Date: 2024-05-19 12:06:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0007'
down_revision: Union[str, Sequence[str], None] = '0006'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('CREATE INDEX IF NOT EXISTS ix_users_azure_ad_oid ON enterprise_rag_system.users (azure_ad_oid);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_users_email ON enterprise_rag_system.users (email);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_sessions_user_id ON enterprise_rag_system.sessions (user_id);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_messages_session_id ON enterprise_rag_system.messages (session_id);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_audit_logs_user_id ON audit.audit_logs (user_id);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_audit_logs_session_id ON audit.audit_logs (session_id);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_document_index_connector_id ON enterprise_rag_system.document_index (connector_id);')
    op.execute('CREATE INDEX IF NOT EXISTS ix_document_index_source_url ON enterprise_rag_system.document_index (source_url);')

def downgrade() -> None:
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_users_azure_ad_oid;')
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_users_email;')
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_sessions_user_id;')
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_messages_session_id;')
    op.execute('DROP INDEX IF EXISTS audit.ix_audit_logs_user_id;')
    op.execute('DROP INDEX IF EXISTS audit.ix_audit_logs_session_id;')
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_document_index_connector_id;')
    op.execute('DROP INDEX IF EXISTS enterprise_rag_system.ix_document_index_source_url;')
