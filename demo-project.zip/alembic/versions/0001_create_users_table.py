"""Create users table

Revision ID: 0001
Revises: 0000
Create Date: 2024-05-19 12:00:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0001'
down_revision: Union[str, Sequence[str], None] = '0000'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.users (
        user_id UUID PRIMARY KEY,
        azure_ad_oid TEXT UNIQUE,
        display_name TEXT,
        email TEXT UNIQUE,
        roles JSONB,
        created_at TIMESTAMP WITH TIME ZONE,
        metadata JSONB
    );
    ''')

def downgrade() -> None:
    op.execute('''
    DROP TABLE IF EXISTS enterprise_rag_system.users CASCADE;
    ''')
