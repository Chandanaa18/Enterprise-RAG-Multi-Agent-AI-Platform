"""Create connector_permissions table

Revision ID: 0009
Revises: 0008
Create Date: 2026-05-31 00:00:00.000000

Design: subject-based permission model
---------------------------------------
A single table handles both user-level (V1) and group-level (V2) connector
permissions via a (subject_type, subject_id) pair:

    subject_type = 'user'   → subject_id = users.user_id UUID string
    subject_type = 'group'  → subject_id = Azure AD group name string

V1 only writes 'user' rows.  V2 adds 'group' rows without any schema change.

Resolution:
    No row for a subject/connector pair = denied (deny-all default).
    Group-based resolution is future work (V2) — no schema change required.
"""
from typing import Sequence, Union
from alembic import op


revision: str = '0009'
down_revision: Union[str, Sequence[str], None] = '0008'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE IF NOT EXISTS enterprise_rag_system.connector_permissions (
            permission_id   UUID        NOT NULL DEFAULT gen_random_uuid(),
            subject_type    TEXT        NOT NULL,
            subject_id      TEXT        NOT NULL,
            connector_name  TEXT        NOT NULL,
            enabled         BOOLEAN     NOT NULL DEFAULT FALSE,
            granted_by      UUID        NULL
                                        REFERENCES enterprise_rag_system.users(user_id)
                                        ON DELETE SET NULL,
            metadata        JSONB       NULL,
            created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

            CONSTRAINT pk_connector_permissions
                PRIMARY KEY (permission_id),

            CONSTRAINT uq_subject_connector
                UNIQUE (subject_type, subject_id, connector_name),

            CONSTRAINT chk_subject_type
                CHECK (subject_type IN ('user', 'group'))
        );
    """)

    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_cp_subject_lookup
            ON enterprise_rag_system.connector_permissions (subject_type, subject_id);
    """)


def downgrade() -> None:
    op.execute("""
        DROP TABLE IF EXISTS enterprise_rag_system.connector_permissions CASCADE;
    """)
