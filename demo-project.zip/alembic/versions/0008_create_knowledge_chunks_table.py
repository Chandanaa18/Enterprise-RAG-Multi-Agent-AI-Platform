"""Create knowledge_chunks table for pgvector-backed vector store

Revision ID: 0008
Revises: 0007
Create Date: 2026-05-26 00:00:00.000000

Replaces Weaviate as the chunk + embedding store. Uses halfvec(3072) so HNSW
is available for Gemini's 3072-d embeddings (vector type maxes at 2000 dims
for HNSW). ACL is stored as flat columns so the where-clause prunes
unauthorized chunks inside the SQL query (spec §3.6, §13).
"""
from typing import Sequence, Union
from alembic import op

revision: str = '0008'
down_revision: Union[str, Sequence[str], None] = '0007'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.knowledge_chunks (
        chunk_id      UUID PRIMARY KEY,
        doc_id        UUID NOT NULL,
        version_id    UUID NOT NULL,
        connector_id  TEXT NOT NULL,
        source_uri    TEXT,
        chunk_type    TEXT NOT NULL DEFAULT 'text',
        title         TEXT,
        content       TEXT NOT NULL,
        section_path  TEXT[] NOT NULL DEFAULT '{}',
        page_no       INTEGER,
        acl_user_ids  TEXT[] NOT NULL DEFAULT '{}',
        acl_roles     TEXT[] NOT NULL DEFAULT '{}',
        acl_public    BOOLEAN NOT NULL DEFAULT FALSE,
        embedding     halfvec(3072) NOT NULL,
        content_tsv   tsvector GENERATED ALWAYS AS (
            setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
            setweight(to_tsvector('english', coalesce(content, '')), 'B')
        ) STORED
    );
    ''')

    # HNSW on halfvec supports up to 4000 dimensions — fits 3072-d Gemini embeddings.
    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_embedding_hnsw
        ON enterprise_rag_system.knowledge_chunks
        USING hnsw (embedding halfvec_cosine_ops)
        WITH (m = 32, ef_construction = 128);
    ''')

    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_content_tsv_gin
        ON enterprise_rag_system.knowledge_chunks
        USING GIN (content_tsv);
    ''')

    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_acl_user_ids_gin
        ON enterprise_rag_system.knowledge_chunks
        USING GIN (acl_user_ids);
    ''')

    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_acl_roles_gin
        ON enterprise_rag_system.knowledge_chunks
        USING GIN (acl_roles);
    ''')

    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_doc_id_idx
        ON enterprise_rag_system.knowledge_chunks (doc_id);
    ''')

    op.execute('''
    CREATE INDEX IF NOT EXISTS knowledge_chunks_connector_id_idx
        ON enterprise_rag_system.knowledge_chunks (connector_id);
    ''')


def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS enterprise_rag_system.knowledge_chunks CASCADE;')
