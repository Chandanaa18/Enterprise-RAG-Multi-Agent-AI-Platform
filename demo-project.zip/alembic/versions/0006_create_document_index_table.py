"""Create document index table

Revision ID: 0006
Revises: 0005
Create Date: 2024-05-19 12:05:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0006'
down_revision: Union[str, Sequence[str], None] = '0005'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.document_index (
        doc_id UUID PRIMARY KEY,
        connector_id TEXT REFERENCES enterprise_rag_system.connector_configs(connector_id),
        source_url TEXT,
        title TEXT,
        last_synced_at TIMESTAMP WITH TIME ZONE,
        permissions_acl JSONB,
        chunk_count INTEGER,
        metadata JSONB
    );
    ''')

def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS enterprise_rag_system.document_index CASCADE;')
