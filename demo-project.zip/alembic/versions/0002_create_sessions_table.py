"""Create sessions table

Revision ID: 0002
Revises: 0001
Create Date: 2024-05-19 12:01:00.000000

"""
from typing import Sequence, Union
from alembic import op

revision: str = '0002'
down_revision: Union[str, Sequence[str], None] = '0001'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.execute('''
    CREATE TABLE IF NOT EXISTS enterprise_rag_system.sessions (
        session_id UUID PRIMARY KEY,
        user_id UUID REFERENCES enterprise_rag_system.users(user_id),
        created_at TIMESTAMP WITH TIME ZONE,
        last_active_at TIMESTAMP WITH TIME ZONE,
        is_active BOOLEAN,
        agent_last_used TEXT
    );
    ''')

def downgrade() -> None:
    op.execute('DROP TABLE IF EXISTS enterprise_rag_system.sessions CASCADE;')
