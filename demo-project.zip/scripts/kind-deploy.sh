#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

# ── 1. Install kind if missing ────────────────────────────────────────────────
if ! command -v kind &>/dev/null; then
  echo "[kind-deploy] Installing kind..."
  curl -Lo /tmp/kind https://kind.sigs.k8s.io/dl/v0.23.0/kind-linux-amd64
  chmod +x /tmp/kind
  sudo mv /tmp/kind /usr/local/bin/kind
  echo "[kind-deploy] kind installed: $(kind version)"
fi

# ── 2. Create cluster (skip if already exists) ────────────────────────────────
if kind get clusters 2>/dev/null | grep -q "^enterprise-rag$"; then
  echo "[kind-deploy] Cluster 'enterprise-rag' already exists, skipping create."
else
  echo "[kind-deploy] Creating kind cluster..."
  mkdir -p /tmp/rag-pg-backup
  kind create cluster --config k8s/kind-config.yaml
fi

kubectl cluster-info --context kind-enterprise-rag

# ── 3. Build images ───────────────────────────────────────────────────────────
echo "[kind-deploy] Building backend image..."
docker build -t enterprise-rag-backend:latest .

echo "[kind-deploy] Building frontend image..."
docker build -t enterprise-rag-frontend:latest ./frontend

# ── 4. Load images into kind (no registry needed) ─────────────────────────────
echo "[kind-deploy] Loading images into kind cluster..."
kind load docker-image enterprise-rag-backend:latest --name enterprise-rag
kind load docker-image enterprise-rag-frontend:latest --name enterprise-rag

# ── 5. Apply Secret ───────────────────────────────────────────────────────────
echo "[kind-deploy] Applying secrets..."
kubectl create namespace enterprise-rag --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f k8s/secrets.yaml

# ── 6. Apply all manifests ────────────────────────────────────────────────────
echo "[kind-deploy] Applying manifests..."
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/postgres/pvc.yaml
kubectl apply -f k8s/postgres/service.yaml
kubectl apply -f k8s/postgres/deployment.yaml
kubectl apply -f k8s/postgres/backup-cronjob.yaml

# Wait for postgres then run init job (vector ext, schemas, mlflow DB)
echo "[kind-deploy] Waiting for postgres..."
kubectl wait --for=condition=ready pod -l app=postgres -n enterprise-rag --timeout=120s
kubectl apply -f k8s/postgres/init-job.yaml
kubectl wait --for=condition=complete job/postgres-init -n enterprise-rag --timeout=60s
echo "[kind-deploy] DB init complete."
kubectl apply -f k8s/redis/service.yaml
kubectl apply -f k8s/redis/deployment.yaml
kubectl apply -f k8s/mlflow/pvc.yaml
kubectl apply -f k8s/mlflow/service.yaml
kubectl apply -f k8s/mlflow/deployment.yaml
kubectl apply -f k8s/backend/service.yaml
kubectl apply -f k8s/backend/deployment.yaml
kubectl apply -f k8s/worker/deployment.yaml
kubectl apply -f k8s/worker/beat.yaml
kubectl apply -f k8s/frontend/service.yaml
kubectl apply -f k8s/frontend/deployment.yaml
kubectl apply -f k8s/adminer/adminer.yaml

# ── 7. Patch services to NodePort for kind port mappings ─────────────────────
echo "[kind-deploy] Patching services to NodePort..."
kubectl patch svc frontend  -n enterprise-rag -p '{"spec":{"type":"NodePort","ports":[{"port":80,"targetPort":80,"nodePort":30000}]}}'
kubectl patch svc backend   -n enterprise-rag -p '{"spec":{"type":"NodePort","ports":[{"port":8000,"targetPort":8000,"nodePort":30001}]}}'
kubectl patch svc adminer   -n enterprise-rag -p '{"spec":{"type":"NodePort","ports":[{"port":8080,"targetPort":8080,"nodePort":30002}]}}'
kubectl patch svc mlflow    -n enterprise-rag -p '{"spec":{"type":"NodePort","ports":[{"port":5000,"targetPort":5000,"nodePort":30003}]}}'

# ── 8. Wait for pods ──────────────────────────────────────────────────────────
echo "[kind-deploy] Waiting for pods to be ready..."
kubectl wait --for=condition=ready pod -l app=postgres  -n enterprise-rag --timeout=120s
kubectl wait --for=condition=ready pod -l app=redis     -n enterprise-rag --timeout=60s
kubectl wait --for=condition=ready pod -l app=backend   -n enterprise-rag --timeout=180s

echo ""
echo "✅  Deployment complete!"
echo "   Frontend  → http://localhost:3000"
echo "   Backend   → http://localhost:8000"
echo "   Adminer   → http://localhost:8081"
echo "   MLflow    → http://localhost:5001"
echo ""
echo "   Postgres backup runs daily at 2 AM → stored in postgres-backup-pvc"
echo "   Manual backup: kubectl create job --from=cronjob/postgres-backup manual-backup -n enterprise-rag"
