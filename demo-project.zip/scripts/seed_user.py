"""
Seed the default development user: alice@example.com
Roles: employee, admin

Run via:  python3 scripts/seed_user.py
Or via the init script which calls it automatically.
"""
import asyncio
import json
import uuid

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.core.config import settings

DB_URL = settings.db.url


async def seed() -> None:
    engine = create_async_engine(DB_URL, echo=False)
    async with AsyncSession(engine) as db:
        await db.execute(
            text("""
                INSERT INTO enterprise_rag_system.users
                    (user_id, email, display_name, roles, created_at)
                VALUES
                    (CAST(:uid AS uuid), :email, :name, CAST(:roles AS jsonb), NOW())
                ON CONFLICT (email) DO UPDATE
                    SET roles        = EXCLUDED.roles,
                        display_name = EXCLUDED.display_name
            """),
            {
                "uid":   str(uuid.uuid4()),
                "email": "alice@example.com",
                "name":  "Alice (dev)",
                "roles": json.dumps(["employee", "admin"]),
            },
        )
        await db.commit()
    await engine.dispose()
    print("User alice@example.com seeded (roles: employee, admin)")


if __name__ == "__main__":
    asyncio.run(seed())
