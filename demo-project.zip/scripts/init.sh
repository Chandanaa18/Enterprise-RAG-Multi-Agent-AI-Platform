#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# init.sh — one-time infrastructure bootstrap
#
# Run once after you have filled in .env:
#   chmod +x scripts/init.sh
#   ./scripts/init.sh
# -----------------------------------------------------------------------------

set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${GREEN}[✓]${NC} $*"; }
error() { echo -e "${RED}[✗]${NC} $*"; exit 1; }
step()  { echo -e "\n${YELLOW}──▶ $*${NC}"; }

# ── Sanity checks ─────────────────────────────────────────────────────────────
step "Checking prerequisites"
command -v docker      >/dev/null 2>&1 || error "docker not found"
command -v python3     >/dev/null 2>&1 || error "python3 not found"
docker compose version >/dev/null 2>&1 || error "docker compose plugin not found"
[[ -f ".env" ]] || error ".env not found — copy .env.example to .env and fill in your values"
info "Prerequisites OK"

# ── Start infrastructure ──────────────────────────────────────────────────────
step "Starting infrastructure services"
docker compose up -d 
info "Containers started"

# ── Wait helper ───────────────────────────────────────────────────────────────
wait_healthy() {
  local service=$1 max=${2:-60} elapsed=0
  echo -n "  Waiting for ${service}"
  while [[ $elapsed -lt $max ]]; do
    status=$(docker compose ps --format json "$service" 2>/dev/null \
             | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('Health',''))" 2>/dev/null || true)
    if [[ "$status" == "healthy" ]]; then
      echo -e " ${GREEN}healthy${NC}"
      return 0
    fi
    echo -n "."
    sleep 2; ((elapsed+=2))
  done
  echo ""
  error "${service} did not become healthy within ${max}s"
}

# ── Step 1: wait for postgres first ──────────────────────────────────────────
step "Waiting for PostgreSQL"
wait_healthy postgres 60

# ── Step 2: create schemas + mlflow DB NOW (before MLflow starts) ─────────────
# MLflow container needs the 'mlflow' database to exist before it can connect.
# We create it immediately after postgres is ready so MLflow can start cleanly.
step "Initialising PostgreSQL schemas and mlflow database"
docker compose exec -T postgres psql -U rag -d rag <<'SQL'
CREATE EXTENSION IF NOT EXISTS vector;
CREATE SCHEMA IF NOT EXISTS enterprise_rag_system;
CREATE SCHEMA IF NOT EXISTS audit;
SELECT 'CREATE DATABASE mlflow' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'mlflow')\gexec
GRANT ALL PRIVILEGES ON SCHEMA enterprise_rag_system TO rag;
GRANT ALL PRIVILEGES ON SCHEMA audit TO rag;
GRANT ALL PRIVILEGES ON DATABASE mlflow TO rag;
SQL
info "Schemas and mlflow database ready"

# ── Step 3: wait for remaining services ──────────────────────────────────────
step "Waiting for remaining services"
wait_healthy redis    30
wait_healthy mlflow   120

# ── Step 4: run Alembic migrations ───────────────────────────────────────────
step "Running database migrations"
PYTHONPATH=. alembic upgrade head
info "Migrations applied"

# ── Step 5: enable Confluence connector if credentials are present ────────────
step "Checking Confluence configuration"
CONFLUENCE_BASE_URL=$(grep -E '^CONFLUENCE_BASE_URL=' .env | cut -d '=' -f2- | tr -d '[:space:]')

if [[ -n "$CONFLUENCE_BASE_URL" ]]; then
  PYTHONPATH=. python3 - <<'EOF'
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from app.infrastructure.database import model_registry  # noqa: F401 - Register models
from app.domains.confluence.repositories.connector_config_repository import ConnectorConfigRepository
from app.core.config import settings

async def enable():
    engine = create_async_engine(settings.db.url)
    async with AsyncSession(engine) as db:
        await ConnectorConfigRepository(db).upsert(
            "confluence", connector_name="Confluence", enabled=True
        )
    await engine.dispose()

asyncio.run(enable())
EOF
  info "Confluence connector enabled — sync will run on first backend start"
else
  info "CONFLUENCE_BASE_URL not set — skipping Confluence setup (set it in .env to enable)"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Infrastructure ready — start the backend now  ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo "  MLflow UI:    http://localhost:5000"
echo "  Adminer (DB): http://localhost:8081"
echo ""
