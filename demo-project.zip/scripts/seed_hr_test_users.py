"""
Seed HR test users (Apoorva and Chandana) for Permission-Aware Retrieval testing.

What this script does
---------------------
1. Calls the Confluence Cloud API to look up each user's Atlassian accountId
   by their email address.
2. Upserts both users into enterprise_rag_system.users with:
   - roles           — scoped so each user can only access their own document
   - metadata.groups — shared HR team group
   - metadata.connector_accounts.confluence.account_id — Atlassian accountId
     used during ingestion to translate Confluence restrictions → acl_user_ids

Run via:
    PYTHONPATH=. python3 scripts/seed_hr_test_users.py
"""
from __future__ import annotations

import asyncio
import base64
import json
import sys

import httpx
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.core.config import settings

# ── User definitions ─────────────────────────────────────────────────────────

USERS_TO_SEED = [
    {
        "user_id":      "a0000001-0000-0000-0000-000000000001",
        "display_name": "Apoorva",
        "email":        "apoorva.sb@sigmoidanalytics.com",
        "roles":        ["hr.leave_policy.reader", "agent.knowledge_rag"],
        # Full metadata JSONB — groups + connector_accounts in the agreed structure
        "metadata": {
            "groups": ["hr-team"],
            "connector_accounts": {
                # accountId resolved from Confluence page restrictions (page 4128942)
                "confluence": {"account_id": "712020:86a29926-f2c9-43f9-a481-a61efb86dfd6"}
            },
        },
    },
    {
        "user_id":      "c0000002-0000-0000-0000-000000000002",
        "display_name": "Chandana",
        "email":        "chandana.r@sigmoidanalytics.com",
        "roles":        ["hr.onboarding.reader", "agent.knowledge_rag"],
        # Full metadata JSONB — groups + connector_accounts in the agreed structure
        "metadata": {
            "groups": ["hr-team"],
            "connector_accounts": {
                # accountId resolved from Confluence page restrictions (page 4292617)
                "confluence": {"account_id": "712020:6f42391f-81c3-4632-a1e5-08768d9f8ac0"}
            },
        },
    },
]

# ── Confluence account ID lookup ─────────────────────────────────────────────

def _basic_auth_header() -> str:
    raw = f"{settings.confluence.email}:{settings.confluence.api_token}"
    return "Basic " + base64.b64encode(raw.encode()).decode()


async def fetch_confluence_account_id(client: httpx.AsyncClient, email: str) -> str | None:
    """
    Look up a user's Atlassian accountId by their email address.

    Uses the Confluence Cloud user picker API which works with API token auth.
    Falls back to the explicit email endpoint if the picker returns no match.
    """
    # Primary: user picker — searches by email/name on Cloud instances
    resp = await client.get(
        "/wiki/rest/api/user/picker",
        params={"query": email, "showAvatar": "false"},
    )
    if resp.is_success:
        for user in resp.json().get("users", []):
            if user.get("emailAddress", "").lower() == email.lower():
                return user["accountId"]

    # Fallback: explicit email endpoint (requires user profile read scope)
    resp = await client.get(
        "/wiki/rest/api/user/email",
        params={"email": email},
    )
    if resp.is_success:
        data = resp.json()
        account_id = data.get("accountId")
        if account_id:
            return account_id

    return None


async def resolve_account_ids() -> dict[str, str]:
    """
    Return a mapping of {email: atlassian_account_id} for all users to seed.
    Exits with an error if any lookup fails.
    """
    base_url = settings.confluence.base_url.rstrip("/")
    headers  = {
        "Authorization": _basic_auth_header(),
        "Accept":        "application/json",
    }

    account_ids: dict[str, str] = {}

    async with httpx.AsyncClient(base_url=base_url, headers=headers, timeout=15) as client:
        for user in USERS_TO_SEED:
            email = user["email"]
            print(f"  Looking up Confluence accountId for {email} ...", end=" ")
            account_id = await fetch_confluence_account_id(client, email)
            if account_id:
                print(f"found: {account_id}")
                account_ids[email] = account_id
            else:
                print("NOT FOUND")
                print(
                    f"\n  ERROR: Could not find Confluence account for {email}.\n"
                    "  Make sure the user exists in your Confluence instance and\n"
                    "  that the API token has permission to search users.\n"
                    "  You can find accountIds manually via:\n"
                    f"  GET {base_url}/wiki/rest/api/user/search?query={email}\n"
                )
                sys.exit(1)

    return account_ids


# ── Database upsert ───────────────────────────────────────────────────────────

async def upsert_users() -> None:
    """
    Insert or update both HR test users in enterprise_rag_system.users.

    ON CONFLICT (email) updates roles, metadata and display_name so this
    script is safe to re-run.
    """
    engine = create_async_engine(settings.db.url, echo=False)

    async with AsyncSession(engine) as db:
        for user in USERS_TO_SEED:
            await db.execute(
                text("""
                    INSERT INTO enterprise_rag_system.users
                        (user_id, email, display_name, roles, metadata, created_at)
                    VALUES
                        (
                            CAST(:user_id AS uuid),
                            :email,
                            :display_name,
                            CAST(:roles    AS jsonb),
                            CAST(:metadata AS jsonb),
                            NOW()
                        )
                    ON CONFLICT (email) DO UPDATE
                        SET display_name = EXCLUDED.display_name,
                            roles        = EXCLUDED.roles,
                            metadata     = EXCLUDED.metadata
                """),
                {
                    "user_id":      user["user_id"],
                    "email":        user["email"],
                    "display_name": user["display_name"],
                    "roles":        json.dumps(user["roles"]),
                    "metadata":     json.dumps(user["metadata"]),
                },
            )
            account_id = user["metadata"]["connector_accounts"]["confluence"]["account_id"]
            print(
                f"  Upserted {user['display_name']} ({user['email']})\n"
                f"    user_id                                   : {user['user_id']}\n"
                f"    roles                                     : {user['roles']}\n"
                f"    metadata.groups                           : {user['metadata']['groups']}\n"
                f"    metadata.connector_accounts.confluence    : {account_id}"
            )

        await db.commit()

    await engine.dispose()


# ── Entry point ───────────────────────────────────────────────────────────────

async def main() -> None:
    print("\n── Upserting HR test users into PostgreSQL ──────────────────────────────")
    await upsert_users()

    print("\n── Done ─────────────────────────────────────────────────────────────────")
    print(
        "\nNext steps:\n"
        "  1. Set page restrictions in Confluence:\n"
        "       'Employee Leave Policy'   → restrict to Apoorva\n"
        "       'Employee Onboarding Guide' → restrict to Chandana\n"
        "  2. Run a full sync for the HR space:\n"
        "       POST /api/v1/confluence/sync  {\"space_keys\": [\"HR\"], \"force_full\": true}\n"
        "  3. Verify ACL in the DB:\n"
        "       SELECT title, acl_public, acl_user_ids\n"
        "       FROM enterprise_rag_system.knowledge_chunks kc\n"
        "       JOIN enterprise_rag_system.document_index di USING (doc_id)\n"
        "       WHERE di.title IN ('Employee Leave Policy', 'Employee Onboarding Guide');\n"
    )


if __name__ == "__main__":
    asyncio.run(main())
