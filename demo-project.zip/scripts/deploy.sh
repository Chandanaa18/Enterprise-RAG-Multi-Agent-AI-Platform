#!/bin/bash
# deploy.sh — local redeployment helper for Kind cluster
#
# Usage:
#   ./deploy.sh backend     rebuild + reload + restart backend & worker
#   ./deploy.sh frontend    rebuild + reload + restart frontend
#   ./deploy.sh all         rebuild + reload + restart everything
#   ./deploy.sh init        first-time full cluster setup

set -e

CLUSTER_NAME="enterprise-rag"
NAMESPACE="enterprise-rag"
BACKEND_IMAGE="enterprise-rag-backend:latest"
FRONTEND_IMAGE="enterprise-rag-frontend:latest"

# ── Colours ───────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ── Guards ────────────────────────────────────────────────────────────────────
check_cluster() {
    if ! kind get clusters 2>/dev/null | grep -q "^${CLUSTER_NAME}$"; then
        error "Kind cluster '${CLUSTER_NAME}' not found. Run: ./deploy.sh init"
    fi
}

# ── Build + load helpers ──────────────────────────────────────────────────────
build_backend() {
    info "Building backend image..."
    docker build -t "$BACKEND_IMAGE" . || error "Backend Docker build failed"
    info "Loading backend image into Kind..."
    kind load docker-image "$BACKEND_IMAGE" --name "$CLUSTER_NAME"
}

build_frontend() {
    info "Building frontend image..."
    docker build -t "$FRONTEND_IMAGE" ./frontend || error "Frontend Docker build failed"
    info "Loading frontend image into Kind..."
    kind load docker-image "$FRONTEND_IMAGE" --name "$CLUSTER_NAME"
}

restart_backend() {
    info "Restarting backend deployment..."
    kubectl rollout restart deployment/backend -n "$NAMESPACE"
    kubectl rollout restart deployment/worker  -n "$NAMESPACE"
    info "Waiting for backend rollout..."
    kubectl rollout status deployment/backend -n "$NAMESPACE" --timeout=120s
}

restart_frontend() {
    info "Restarting frontend deployment..."
    kubectl rollout restart deployment/frontend -n "$NAMESPACE"
    info "Waiting for frontend rollout..."
    kubectl rollout status deployment/frontend -n "$NAMESPACE" --timeout=120s
}

# ── Commands ──────────────────────────────────────────────────────────────────
cmd_backend() {
    check_cluster
    build_backend
    restart_backend
    info "Backend redeployment complete."
}

cmd_frontend() {
    check_cluster
    build_frontend
    restart_frontend
    info "Frontend redeployment complete."
}

cmd_all() {
    check_cluster
    build_backend
    build_frontend
    restart_backend
    restart_frontend
    info "Full redeployment complete."
}

cmd_init() {
    info "Creating Kind cluster '${CLUSTER_NAME}'..."
    if kind get clusters 2>/dev/null | grep -q "^${CLUSTER_NAME}$"; then
        warn "Cluster already exists — skipping creation."
    else
        kind create cluster --name "$CLUSTER_NAME"
    fi

    info "Building backend image..."
    docker build -t "$BACKEND_IMAGE" .
    kind load docker-image "$BACKEND_IMAGE" --name "$CLUSTER_NAME"

    info "Building frontend image..."
    docker build -t "$FRONTEND_IMAGE" ./frontend
    kind load docker-image "$FRONTEND_IMAGE" --name "$CLUSTER_NAME"

    info "Applying manifests..."
    kubectl apply -f k8s/namespace.yaml
    kubectl apply -f k8s/secret.yaml
    kubectl apply -f k8s/configmap.yaml
    kubectl apply -f k8s/postgres/
    kubectl apply -f k8s/redis/
    kubectl apply -f k8s/mlflow/

    info "Waiting for postgres to be ready..."
    kubectl wait --for=condition=ready pod -l app=postgres \
        -n "$NAMESPACE" --timeout=120s

    kubectl apply -f k8s/backend/
    kubectl apply -f k8s/worker/
    kubectl apply -f k8s/frontend/

    info "Waiting for backend to be ready..."
    kubectl rollout status deployment/backend -n "$NAMESPACE" --timeout=120s
    info "Waiting for frontend to be ready..."
    kubectl rollout status deployment/frontend -n "$NAMESPACE" --timeout=120s

    echo ""
    info "Cluster is up. Run the following in separate terminals:"
    echo "  Terminal 1: kubectl port-forward svc/backend 8000:8000 -n ${NAMESPACE}"
    echo "  Terminal 2: kubectl port-forward svc/frontend 3000:80 -n ${NAMESPACE}"
    echo "  Terminal 3: ngrok http 8000 --domain=gallows-feminism-anthem.ngrok-free.dev"
    echo ""
    info "Frontend UI:  http://localhost:3000"
    info "Swagger UI:   http://localhost:8000/docs"
    info "MLflow UI:    kubectl port-forward svc/mlflow 5001:5000 -n ${NAMESPACE}"
}

cmd_status() {
    check_cluster
    echo ""
    kubectl get pods -n "$NAMESPACE"
    echo ""
    kubectl get svc  -n "$NAMESPACE"
}

# ── Entry point ───────────────────────────────────────────────────────────────
case "${1:-}" in
    backend)  cmd_backend  ;;
    frontend) cmd_frontend ;;
    all)      cmd_all      ;;
    init)     cmd_init     ;;
    status)   cmd_status   ;;
    *)
        echo "Usage: ./deploy.sh [backend|frontend|all|init|status]"
        echo ""
        echo "  init      First-time cluster setup + deploy everything"
        echo "  backend   Rebuild + redeploy backend & worker"
        echo "  frontend  Rebuild + redeploy frontend"
        echo "  all       Rebuild + redeploy everything"
        echo "  status    Show pod and service status"
        exit 1
        ;;
esac
