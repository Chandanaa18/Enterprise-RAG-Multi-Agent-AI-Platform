#!/bin/bash
# Usage: ./scripts/backup-db.sh
# Creates a timestamped SQL dump in data/backups/
set -e

BACKUP_DIR="$(dirname "$0")/../data/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
FILE="$BACKUP_DIR/rag_backup_$TIMESTAMP.sql"

mkdir -p "$BACKUP_DIR"

echo "Backing up database to $FILE ..."
docker compose exec -T postgres pg_dump -U rag -d rag > "$FILE"
echo "Done — $FILE"
