"""
Kibana Dashboard Setup — Enterprise RAG Platform  (spec §6)

Creates the Elasticsearch index template, Kibana data view, and all required
monitoring dashboards via the Kibana Saved Objects API.

Uses aggregation-based visualizations (type: "visualization") which have a
stable, well-documented format across Kibana 8.x releases — avoiding the
version-sensitive internal state format of Lens visualizations.

Run once after the ELK stack is up:
    python observability/kibana/setup_dashboards.py

Idempotent — safe to re-run after a config change.

Dashboards created
------------------
1. Request Volume          — total API requests over time
2. Agent Distribution      — how often each agent is selected
3. Agent Latency           — average response duration per agent
4. Error Rate              — errors and permission denials over time
5. LLM Token Consumption   — token usage over time
6. RAG Retrieval Metrics   — chunks retrieved and reranker score
7. Connector Health        — error rate per connector
8. Audit Activity          — actions per target system
9. Audit Activity          — actions per user
"""
from __future__ import annotations

import json
import sys
import time
from typing import Any

import requests

# ──────────────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────────────

ELASTICSEARCH_URL   = "http://localhost:9200"
KIBANA_URL          = "http://localhost:5601"
INDEX_PATTERN       = "rag-platform-logs-*,.ds-rag-platform-logs-*"
DATA_VIEW_ID        = "rag-platform-logs"
INDEX_TEMPLATE_FILE = "observability/elasticsearch/index_template.json"

KIBANA_HEADERS = {
    "kbn-xsrf":     "true",
    "Content-Type": "application/json",
}


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def wait_for_service(url: str, service_name: str, max_wait_seconds: int = 120) -> None:
    """Poll until the service responds with HTTP 200, or raise after timeout."""
    print(f"Waiting for {service_name} at {url} ...")
    deadline = time.time() + max_wait_seconds
    while time.time() < deadline:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                print(f"  {service_name} is ready.")
                return
        except requests.ConnectionError:
            pass
        time.sleep(3)
    raise RuntimeError(f"{service_name} did not become available within {max_wait_seconds}s.")


def kibana_post(path: str, payload: dict) -> dict:
    """POST to the Kibana API and return the response body."""
    response = requests.post(
        f"{KIBANA_URL}{path}",
        headers=KIBANA_HEADERS,
        json=payload,
        timeout=30,
    )
    if not response.ok:
        raise RuntimeError(
            f"Kibana API error {response.status_code} at {path}: {response.text[:400]}"
        )
    return response.json()


def elasticsearch_put(path: str, payload: dict) -> dict:
    """PUT to the Elasticsearch REST API and return the response body."""
    response = requests.put(
        f"{ELASTICSEARCH_URL}{path}",
        headers={"Content-Type": "application/json"},
        json=payload,
        timeout=30,
    )
    if not response.ok:
        raise RuntimeError(
            f"Elasticsearch API error {response.status_code} at {path}: {response.text[:400]}"
        )
    return response.json()


def create_saved_object(obj: dict) -> None:
    """
    Create or overwrite one Kibana saved object via the individual POST endpoint.

    Uses POST /api/saved_objects/{type}/{id}?overwrite=true instead of the
    bulk NDJSON import endpoint. The bulk import runs every object through
    Kibana's migration transformer which crashes on any unexpected field.
    The individual endpoint creates the object as-is with no migration step.
    """
    object_type = obj["type"]
    object_id   = obj["id"]
    payload     = {
        "attributes": obj["attributes"],
        "references": obj.get("references", []),
    }
    response = requests.post(
        f"{KIBANA_URL}/api/saved_objects/{object_type}/{object_id}?overwrite=true",
        headers=KIBANA_HEADERS,
        json=payload,
        timeout=30,
    )
    if not response.ok:
        raise RuntimeError(
            f"Failed to create {object_type}/{object_id} "
            f"({response.status_code}): {response.text[:400]}"
        )


def create_all_saved_objects(objects: list[dict]) -> None:
    """Create each saved object individually and report progress."""
    for obj in objects:
        create_saved_object(obj)
        print(f"  created: {obj['type']}/{obj['id']}")


# ──────────────────────────────────────────────────────────────────────────────
# Saved object builders
#
# All visualizations use the stable "visualization" saved object type with
# aggregation-based aggs (date_histogram, terms, avg, sum, count).
# The visState and searchSourceJSON are JSON-encoded strings, as Kibana expects.
#
# Kibana 8.x requires every axis to have a `scale` object with `type` and
# `mode` fields. Missing these causes "Cannot read properties of undefined
# (reading 'mode')" at render time — the helpers below include all required
# fields so charts render without errors.
# ──────────────────────────────────────────────────────────────────────────────

def _category_axis(axis_id: str = "CategoryAxis-1", position: str = "bottom") -> dict:
    """Return a fully-specified category axis for Kibana 8.x."""
    return {
        "id":       axis_id,
        "type":     "category",
        "position": position,
        "show":     True,
        "style":    {},
        "scale":    {"type": "linear"},
        "labels":   {"show": True, "filter": True, "truncate": 100},
        "title":    {},
    }


def _value_axis(
    axis_id:  str = "ValueAxis-1",
    name:     str = "LeftAxis-1",
    position: str = "left",
    title:    str = "Count",
) -> dict:
    """Return a fully-specified value axis for Kibana 8.x, including scale.mode."""
    return {
        "id":       axis_id,
        "name":     name,
        "type":     "value",
        "position": position,
        "show":     True,
        "style":    {},
        "scale":    {"type": "linear", "mode": "normal"},   # mode is required
        "labels":   {"show": True, "rotate": 0, "filter": False, "truncate": 100},
        "title":    {"text": title},
    }


def _series_param(
    metric_id:   str = "1",
    label:       str = "Count",
    chart_type:  str = "line",
    value_axis:  str = "ValueAxis-1",
) -> dict:
    """Return a fully-specified seriesParams entry."""
    return {
        "show":                   True,
        "type":                   chart_type,
        "mode":                   "normal",
        "data":                   {"label": label, "id": metric_id},
        "valueAxis":              value_axis,
        "drawLinesBetweenPoints": True,
        "lineWidth":              2,
        "interpolate":            "linear",
        "showCircles":            True,
    }


def _base_xy_params(
    chart_type:   str,
    category_axes: list[dict],
    value_axes:    list[dict],
    series_params: list[dict],
    horizontal:    bool = False,
) -> dict:
    """
    Return the complete `params` block for a line / area / histogram chart.

    Includes all fields that Kibana 8.x migration and render code accesses,
    preventing "Cannot read properties of undefined" errors.
    """
    params = {
        "type":           chart_type,
        "grid":           {"categoryLines": False},
        "categoryAxes":   category_axes,
        "valueAxes":      value_axes,
        "seriesParams":   series_params,
        "addTooltip":     True,
        "addLegend":      True,
        "legendPosition": "right",
        "times":          [],
        "addTimeMarker":  False,
        "labels":         {},
        "thresholdLine":  {
            "show":  False,
            "value": 10,
            "width": 1,
            "style": "full",
            "color": "#E7664C",
        },
    }
    if horizontal:
        params["horizontal"] = True
    return params

def _search_source(kuery_filter: str = "") -> str:
    """Build the kibanaSavedObjectMeta.searchSourceJSON string."""
    return json.dumps({
        "index":  DATA_VIEW_ID,
        "query":  {"language": "kuery", "query": kuery_filter},
        "filter": [],
    })


def _vis_object(
    vis_id:       str,
    title:        str,
    vis_state:    dict,
    kuery_filter: str = "",
) -> dict:
    """Wrap a visState dict into a Kibana saved object ready for import."""
    return {
        "id":   vis_id,
        "type": "visualization",
        "attributes": {
            "title":       title,
            "visState":    json.dumps(vis_state),
            "uiStateJSON": "{}",
            "description": "",
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": _search_source(kuery_filter),
            },
        },
        "references": [
            {
                "id":   DATA_VIEW_ID,
                "name": "kibanaSavedObjectMeta.searchSourceJSON.index",
                "type": "index-pattern",
            }
        ],
    }


# ── Visualisation 1: Request Volume ──────────────────────────────────────────

def build_request_volume_vis() -> dict:
    """Line chart — count of API requests per time bucket."""
    vis_state = {
        "title":  "Request Volume Over Time",
        "type":   "line",
        "params": _base_xy_params(
            chart_type="line",
            category_axes=[_category_axis(position="bottom")],
            value_axes=[_value_axis(title="Request Count")],
            series_params=[_series_param(metric_id="1", label="Requests", chart_type="line")],
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "date_histogram",
             "schema": "segment",
             "params": {"field": "@timestamp", "useNormalizedEsInterval": True,
                        "interval": "auto", "min_doc_count": 1, "extended_bounds": {}}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-request-volume",
        title="Request Volume Over Time",
        vis_state=vis_state,
        kuery_filter='log_event: "request_received"',
    )


# ── Visualisation 2: Agent Distribution ──────────────────────────────────────

def build_agent_distribution_vis() -> dict:
    """Pie chart — proportion of requests handled by each agent."""
    vis_state = {
        "title":  "Agent Selection Distribution",
        "type":   "pie",
        "params": {
            "type":           "pie",
            "addTooltip":     True,
            "addLegend":      True,
            "legendPosition": "right",
            "isDonut":        False,
            "labels":         {"show": True, "values": True, "last_level": True, "truncate": 100},
        },
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "terms",
             "schema": "segment",
             "params": {"field": "agent_name", "size": 10, "order": "desc",
                        "orderBy": "1", "otherBucket": False}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-agent-distribution",
        title="Agent Selection Distribution",
        vis_state=vis_state,
        kuery_filter='log_event: "agent_selected"',
    )


# ── Visualisation 3: Agent Latency ───────────────────────────────────────────

def build_agent_latency_vis() -> dict:
    """Horizontal bar — average duration_seconds per agent."""
    vis_state = {
        "title":  "Average Latency Per Agent",
        "type":   "histogram",
        "params": _base_xy_params(
            chart_type="histogram",
            category_axes=[_category_axis(position="left")],
            value_axes=[_value_axis(name="BottomAxis-1", position="bottom",
                                    title="Avg Latency (seconds)")],
            series_params=[_series_param(metric_id="1", label="Avg Latency",
                                         chart_type="histogram")],
            horizontal=True,
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "avg",
             "schema": "metric", "params": {"field": "duration_seconds"}},
            {"id": "2", "enabled": True, "type": "terms",
             "schema": "segment",
             "params": {"field": "agent", "size": 10, "order": "desc", "orderBy": "1"}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-agent-latency",
        title="Average Latency Per Agent (seconds)",
        vis_state=vis_state,
        kuery_filter='log_event: "response_returned" AND duration_seconds: *',
    )


# ── Visualisation 4: Error Rate ───────────────────────────────────────────────

def build_error_rate_vis() -> dict:
    """Area chart — error log count over time, filtered to level:error."""
    vis_state = {
        "title":  "Error Rate Over Time",
        "type":   "area",
        "params": _base_xy_params(
            chart_type="area",
            category_axes=[_category_axis(position="bottom")],
            value_axes=[_value_axis(title="Error Count")],
            series_params=[_series_param(metric_id="1", label="Errors", chart_type="area")],
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "date_histogram",
             "schema": "segment",
             "params": {"field": "@timestamp", "interval": "auto",
                        "useNormalizedEsInterval": True, "min_doc_count": 0,
                        "extended_bounds": {}}},
        ],
    }
    # Filter at search level — avoids the complex filters bucket agg
    # which requires a different query format depending on Kibana version.
    return _vis_object(
        vis_id="rag-vis-error-rate",
        title="Error Rate Over Time",
        vis_state=vis_state,
        kuery_filter='level: error OR outcome: "DENIED"',
    )


# ── Visualisation 5: LLM Token Consumption ────────────────────────────────────

def build_token_consumption_vis() -> dict:
    """Line chart — sum of total LLM tokens over time."""
    vis_state = {
        "title":  "LLM Token Consumption Over Time",
        "type":   "line",
        "params": _base_xy_params(
            chart_type="line",
            category_axes=[_category_axis(position="bottom")],
            value_axes=[_value_axis(title="Total Tokens")],
            series_params=[_series_param(metric_id="1", label="Total Tokens",
                                         chart_type="line")],
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "sum",
             "schema": "metric", "params": {"field": "total_tokens"}},
            {"id": "2", "enabled": True, "type": "date_histogram",
             "schema": "segment",
             "params": {"field": "@timestamp", "interval": "auto",
                        "useNormalizedEsInterval": True, "min_doc_count": 1}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-token-consumption",
        title="LLM Token Consumption Over Time",
        vis_state=vis_state,
        kuery_filter='log_event: "response_returned" AND total_tokens: *',
    )


# ── Visualisation 6: RAG Retrieval Metrics ────────────────────────────────────

def build_retrieval_metrics_vis() -> dict:
    """Line chart — avg chunks retrieved, avg reranker score, and cache hit rate over time."""
    vis_state = {
        "title":  "RAG Retrieval Metrics",
        "type":   "line",
        "params": _base_xy_params(
            chart_type="line",
            category_axes=[_category_axis(position="bottom")],
            value_axes=[
                _value_axis(axis_id="ValueAxis-1", name="LeftAxis-1",
                            position="left",  title="Avg Chunks / Cache Hit Rate"),
                _value_axis(axis_id="ValueAxis-2", name="RightAxis-1",
                            position="right", title="Avg Reranker Score"),
            ],
            series_params=[
                _series_param(metric_id="1", label="Avg Chunks Retrieved",
                              chart_type="line", value_axis="ValueAxis-1"),
                _series_param(metric_id="2", label="Avg Reranker Score",
                              chart_type="line", value_axis="ValueAxis-2"),
                _series_param(metric_id="3", label="Cache Hit Rate",
                              chart_type="line", value_axis="ValueAxis-1"),
            ],
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "avg",
             "schema": "metric",
             "params": {"field": "retrieval_count", "customLabel": "Avg Chunks Retrieved"}},
            {"id": "2", "enabled": True, "type": "avg",
             "schema": "metric",
             "params": {"field": "avg_retrieval_score", "customLabel": "Avg Reranker Score"}},
            {"id": "3", "enabled": True, "type": "avg",
             "schema": "metric",
             "params": {"field": "cache_hit", "customLabel": "Cache Hit Rate"}},
            {"id": "4", "enabled": True, "type": "date_histogram",
             "schema": "segment",
             "params": {"field": "@timestamp", "interval": "auto",
                        "useNormalizedEsInterval": True, "min_doc_count": 1}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-retrieval-metrics",
        title="RAG Retrieval Metrics",
        vis_state=vis_state,
        kuery_filter='log_event: "response_returned"',
    )


# ── Visualisation 7: Connector Health ─────────────────────────────────────────

def build_connector_health_vis() -> dict:
    """Horizontal bar — error count grouped by connector_id."""
    vis_state = {
        "title":  "Connector Health — Error Rate Per Connector",
        "type":   "histogram",
        "params": _base_xy_params(
            chart_type="histogram",
            category_axes=[_category_axis(position="left")],
            value_axes=[_value_axis(name="BottomAxis-1", position="bottom",
                                    title="Error Count")],
            series_params=[_series_param(metric_id="1", label="Errors",
                                         chart_type="histogram")],
            horizontal=True,
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "terms",
             "schema": "segment",
             "params": {"field": "connector_id", "size": 10,
                        "order": "desc", "orderBy": "1", "otherBucket": False}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-connector-health",
        title="Connector Health — Error Rate Per Connector",
        vis_state=vis_state,
        kuery_filter='log_event: "connector_health" AND connector_id: *',
    )


# ── Visualisation 8a: Audit Activity — Per Target System ──────────────────────

def build_audit_activity_vis() -> dict:
    """Vertical bar — audit action count grouped by target_system."""
    vis_state = {
        "title":  "Audit Activity — Actions Per Target System",
        "type":   "histogram",
        "params": _base_xy_params(
            chart_type="histogram",
            category_axes=[_category_axis(position="bottom")],
            value_axes=[_value_axis(title="Action Count")],
            series_params=[_series_param(metric_id="1", label="Actions",
                                         chart_type="histogram")],
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "terms",
             "schema": "segment",
             "params": {"field": "target_system", "size": 10,
                        "order": "desc", "orderBy": "1", "otherBucket": False}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-audit-activity",
        title="Audit Activity — Actions Per Target System",
        vis_state=vis_state,
        kuery_filter='log_event: "AUDIT_LOG"',
    )


# ── Visualisation 8b: Audit Activity — Per User ───────────────────────────────

def build_audit_per_user_vis() -> dict:
    """Horizontal bar — audit action count grouped by user_id."""
    vis_state = {
        "title":  "Audit Activity — Actions Per User",
        "type":   "histogram",
        "params": _base_xy_params(
            chart_type="histogram",
            category_axes=[_category_axis(position="left")],
            value_axes=[_value_axis(name="BottomAxis-1", position="bottom",
                                    title="Action Count")],
            series_params=[_series_param(metric_id="1", label="Actions",
                                         chart_type="histogram")],
            horizontal=True,
        ),
        "aggs": [
            {"id": "1", "enabled": True, "type": "count",
             "schema": "metric", "params": {}},
            {"id": "2", "enabled": True, "type": "terms",
             "schema": "segment",
             "params": {"field": "user_id", "size": 20,
                        "order": "desc", "orderBy": "1", "otherBucket": False}},
        ],
    }
    return _vis_object(
        vis_id="rag-vis-audit-per-user",
        title="Audit Activity — Actions Per User",
        vis_state=vis_state,
        kuery_filter='log_event: "AUDIT_LOG"',
    )


# ──────────────────────────────────────────────────────────────────────────────
# Dashboard builder
# ──────────────────────────────────────────────────────────────────────────────

def build_dashboard(visualisation_ids: list[str]) -> dict:
    """
    Arrange all visualisations into a single Kibana dashboard.

    Layout: 2-column grid.
    Each panel is 24 grid units wide × 15 grid units tall.
    """
    panel_width   = 24
    panel_height  = 15
    columns_count = 2

    panels: list[dict] = []
    references: list[dict] = []

    for index, vis_id in enumerate(visualisation_ids):
        panel_index = str(index + 1)
        column      = index % columns_count
        row         = index // columns_count

        panels.append({
            "panelIndex": panel_index,
            "gridData": {
                "x": column * panel_width,
                "y": row    * panel_height,
                "w": panel_width,
                "h": panel_height,
                "i": panel_index,
            },
            "version":      "8.15.0",
            "type":         "visualization",
            "panelRefName": f"panel_{panel_index}",
        })

        references.append({
            "id":   vis_id,
            "name": f"panel_{panel_index}",
            "type": "visualization",
        })

    return {
        "id":   "rag-platform-dashboard",
        "type": "dashboard",
        "attributes": {
            "title":       "Enterprise RAG Platform — Monitoring Overview",
            "description": (
                "Request volume · Agent usage · Latency · Errors · "
                "LLM tokens · RAG retrieval · Connector health · Audit activity"
            ),
            "panelsJSON":  json.dumps(panels),
            "optionsJSON": json.dumps({"hidePanelTitles": False, "useMargins": True}),
            "timeRestore": False,
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": json.dumps({
                    "query":  {"language": "kuery", "query": ""},
                    "filter": [],
                }),
            },
        },
        "references": references,
    }


# ──────────────────────────────────────────────────────────────────────────────
# Setup steps
# ──────────────────────────────────────────────────────────────────────────────

def register_index_template() -> None:
    """Apply the Elasticsearch index template so field types are mapped correctly."""
    print("Registering Elasticsearch index template ...")
    with open(INDEX_TEMPLATE_FILE, "r") as template_file:
        template_body = json.load(template_file)
    result = elasticsearch_put("/_index_template/rag-platform-logs", template_body)
    print(f"  acknowledged: {result.get('acknowledged')}")


def create_data_view() -> None:
    """Create the Kibana data view pointing at the daily log indices."""
    print("Creating Kibana data view ...")
    payload = {
        "data_view": {
            "id":            DATA_VIEW_ID,
            "title":         INDEX_PATTERN,
            "name":          "RAG Platform Logs",
            "timeFieldName": "@timestamp",
        },
        "override": True,
    }
    result = kibana_post("/api/data_views/data_view", payload)
    created_id = result.get("data_view", {}).get("id", "unknown")
    print(f"  data view id: {created_id}")


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    print("=" * 60)
    print("Enterprise RAG Platform — Kibana Dashboard Setup")
    print("=" * 60)

    wait_for_service(f"{ELASTICSEARCH_URL}/_cluster/health", "Elasticsearch")
    wait_for_service(f"{KIBANA_URL}/api/status",             "Kibana")

    register_index_template()
    create_data_view()

    print("Building visualisations ...")
    visualisations: list[dict] = [
        build_request_volume_vis(),
        build_agent_distribution_vis(),
        build_agent_latency_vis(),
        build_error_rate_vis(),
        build_token_consumption_vis(),
        build_retrieval_metrics_vis(),
        build_connector_health_vis(),
        build_audit_activity_vis(),
        build_audit_per_user_vis(),
    ]

    visualisation_ids = [vis["id"] for vis in visualisations]
    dashboard = build_dashboard(visualisation_ids)

    print("Creating saved objects in Kibana ...")
    create_all_saved_objects(visualisations + [dashboard])

    print("=" * 60)
    print("Setup complete.")
    print(f"Open Kibana:  {KIBANA_URL}")
    print("Navigate to:  Dashboards → Enterprise RAG Platform — Monitoring Overview")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\nSetup failed: {exc}")
        sys.exit(1)
