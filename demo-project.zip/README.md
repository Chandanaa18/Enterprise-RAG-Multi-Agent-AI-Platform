# Secure Enterprise RAG + Agent Platform

A production-ready multi-agent RAG platform built with FastAPI, LangGraph, PostgreSQL (pgvector), and MLflow.

---

## Architecture

```
FastAPI ──► SupervisorAgent
               └──► KnowledgeRAGAgent (LangGraph — 9 nodes)
                         │
                         ├── load_history       (PostgreSQL session store)
                         ├── parse_intent       (LLM: KNOWLEDGE_FAST)
                         ├── rewrite_query      (LLM: KNOWLEDGE_FAST)
                         ├── retrieve           (retrieval subgraph)
                         │     └── hybrid_search (pgvector dense + BM25) ──► rerank
                         ├── permission_recheck (ACL defence-in-depth)
                         ├── grade_context      (LLM: KNOWLEDGE_FAST)
                         ├── generate_answer    (LLM: KNOWLEDGE_DEFAULT)
                         ├── format_citations   (deterministic)
                         └── persist_turn       (PostgreSQL + audit log)
```

**Background worker** (Celery + Redis):
```
Redis ──► sync_confluence_space
              └──► IngestionPipeline
                   chunk → embed → pgvector + document_index
```

---

## Stack

| Component       | Technology                                          |
|-----------------|-----------------------------------------------------|
| API             | FastAPI + Pydantic v2                               |
| Agent framework | LangGraph 0.2+                                      |
| Vector store    | PostgreSQL 16 + pgvector (HNSW)                     |
| Database        | PostgreSQL 16 + Alembic migrations                  |
| Task queue      | Celery + Redis                                      |
| Observability   | MLflow 3.x (traces, spans, prompt registry, eval)   |
| Auth            | Azure AD (MSAL) — stub mode available for local dev |
| LLM providers   | Google Gemini → OpenRouter (free) → fallback chain  |
| Embeddings      | Gemini `gemini-embedding-001` (3072-d)              |
| Reranking       | `cross-encoder/ms-marco-MiniLM-L-6-v2` (local)     |

---

## Project Layout

```
app/
├── agents/
│   ├── knowledge_rag/      # LangGraph RAG agent (graph + 9 nodes)
│   ├── jira/               # Jira agent
│   └── supervisor/         # Routes requests to the right agent + auth gate
├── api/                    # FastAPI health route
├── bootstrap/              # Azure AD FastAPI dependency wiring
├── core/
│   └── config.py           # All env vars — pydantic-settings (single source of truth)
├── domains/
│   ├── auth/               # Azure AD login/callback + JWT middleware
│   ├── chat/               # POST /api/v1/chat
│   ├── confluence/         # POST /confluence/sync
│   ├── permissions/        # Connector ACL + admin routes
│   ├── sessions/           # GET /api/v1/sessions
│   └── users/              # User management
├── infrastructure/
│   └── database/           # SQLAlchemy engine, session store, model registry
├── ingestion/              # Celery tasks + chunking pipeline
├── llm/
│   ├── registry.py         # Logical model → provider chain config
│   ├── provider_factory.py # Builds LangChain chat models
│   ├── embeddings.py       # Embedder singleton
│   └── reranker.py         # Cross-encoder reranker
├── observability/
│   ├── tracing.py          # MLflow init (tracking URI + experiment setup)
│   ├── prompts.py          # MLflow prompt registry seed + load
│   ├── evaluation.py       # mlflow.evaluate() harness
│   └── logging.py          # Structured logging setup
├── retrieval/
│   ├── vector_store.py     # pgvector client wrapper
│   └── search.py           # RetrievalService (embed → search → rerank)
└── shared/                 # Enums, utils, exception handlers
frontend/                   # React + Vite chat UI (port 3000)
scripts/                    # seed_user.py, seed_hr_test_users.py
alembic/                    # DB migration versions
config/                     # llm.yaml — model chain definitions
```

---

## Quick Start

### Prerequisites

| Tool             | Version | Notes                                    |
|------------------|---------|------------------------------------------|
| Docker + Compose | 24+     | PostgreSQL, Redis, MLflow                |
| Python           | 3.11+   | Backend runtime                          |
| Node.js          | 18+     | Frontend only — skip if not using the UI |
| Google API Key   | —       | Gemini LLM + embeddings (free tier)      |

---

### Step 1 — Environment file

Copy the example and fill in required values:

```bash
cp .env.example .env   # or copy the block below into a new .env
```

Minimum `.env` for local development:

```dotenv
# ── App ───────────────────────────────────────────────────────────────────────
APP_NAME=Enterprise RAG Platform
APP_VERSION=1.0.0
APP_HOST=localhost
APP_PORT=8000
APP_ENABLE_DEBUG_MODE=true

# ── Database ──────────────────────────────────────────────────────────────────
DB_CONNECTION=postgresql+asyncpg
DB_HOST=localhost
DB_PORT=5433
DB_USERNAME=rag
DB_PASSWORD=rag
DB_DATABASE=rag
DATABASE_URL=postgresql+asyncpg://rag:rag@localhost:5433/rag

# ── Redis ─────────────────────────────────────────────────────────────────────
REDIS_URL=redis://localhost:6379/0

# ── MLflow ────────────────────────────────────────────────────────────────────
MLFLOW_TRACKING_URI=http://localhost:5001
MLFLOW_EXPERIMENT_NAME=knowledge_rag

# ── LLM keys  (at least one required) ────────────────────────────────────────
GOOGLE_API_KEY=your_google_api_key_here
# GEMINI_API_KEY=          # alternative alias for GOOGLE_API_KEY
# OPENROUTER_API_KEY=      # free fallback — https://openrouter.ai

# ── RAG tuning ────────────────────────────────────────────────────────────────
LLM_CONFIG_PATH=config/llm.yaml
RAG_CHUNK_STRATEGY=recursive
RAG_CHUNK_SIZE=800
RAG_CHUNK_OVERLAP=120
RAG_TOP_K_DENSE=20
RAG_TOP_K_AFTER_RERANK=6
RAG_ANSWER_PROMPT_VERSION=2

# ── Auth  (set false for local dev — no Azure AD required) ────────────────────
AZURE_AUTH_ENABLED=false
# AZURE_CLIENT_ID=
# AZURE_TENANT_ID=
# AZURE_CLIENT_SECRET=
# AZURE_REDIRECT_URI=http://localhost:8000/auth/callback

# ── Session ───────────────────────────────────────────────────────────────────
SESSION_INACTIVITY_TIMEOUT_HOURS=8

# ── Confluence  (optional — leave blank to skip) ──────────────────────────────
CONFLUENCE_BASE_URL=
CONFLUENCE_EMAIL=
CONFLUENCE_API_TOKEN=
```

---

### Step 2 — Start infrastructure

```bash
docker compose up -d
```

Starts PostgreSQL (pgvector), Redis, MLflow, and Adminer. Wait until all containers are healthy:

```bash
docker compose ps
```

| Service        | URL / port                 |
|----------------|----------------------------|
| PostgreSQL     | `localhost:5433`           |
| Redis          | `localhost:6379`           |
| MLflow UI      | http://localhost:5001      |
| Adminer (DB)   | http://localhost:8081      |

> **Adminer login** — System: `PostgreSQL` · Server: `postgres` · User: `rag` · Password: `rag` · Database: `rag`

---

### Step 3 — Python environment

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

---

### Step 4 — Run database migrations

```bash
make migrate
# or: alembic upgrade head
```

---

### Step 5 — Seed a dev user

```bash
make seed
# Creates alice@example.com with roles ["employee", "admin"]
```

---

### Step 6 — Start the backend

```bash
make dev
# or: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Expected startup log output:
```
Azure AD auth disabled — using X-User-Email stub
MLflow initialized tracking_uri=http://localhost:5001 experiment=knowledge_rag
KnowledgeRAGAgent initialized
SupervisorAgent initialized with authorization gate
Application startup complete.
```

| Service      | URL                                |
|--------------|------------------------------------|
| API Docs     | http://localhost:8000/docs         |
| Health check | http://localhost:8000/health_check |

MLflow prompts (`intent_classify`, `rag_answer`) are seeded automatically on first startup.

---

### Step 7 — Start the frontend (optional)

```bash
cd frontend
npm install
npm run dev
# or from project root: make chat
```

Frontend runs at **http://localhost:3000** and proxies `/api`, `/login`, `/auth` to the backend at port 8000.

---

### Step 8 — Start the Celery worker (required for document ingestion)

```bash
make worker
# or: celery -A app.ingestion.tasks worker --loglevel=info --concurrency=2
```

---

## MLflow UI

MLflow is the observability layer — it captures every chat request as a trace with per-node spans.

### Accessing the UI

Open **http://localhost:5001** in a browser while the Docker stack is running.

### What you will find

| Section | What it shows |
|---|---|
| **Experiments → knowledge_rag** | One run per chat request — token usage, retrieval count, context score |
| **Traces** | Full request trace with child spans for each agent node |
| **Prompt Registry** | Versioned `intent_classify` and `rag_answer` prompts |
| **Evaluation** | Results from `make eval` runs (answer relevance, faithfulness) |

### Span structure per request

```
knowledge_rag_request  (root — opened in KnowledgeRAGAgent)
├── retrieve            (retrieval subgraph)
│   └── retrieve_context
├── parse_intent_llm
├── rewrite_query_llm
├── grade_context_llm
└── generate_answer_llm / generate_smalltalk_llm
```

Each span records inputs, outputs, latency, and model attributes.

### Running an evaluation

```bash
make eval
# Runs mlflow.evaluate() against tests/fixtures/eval_dataset.jsonl
# Results appear in the MLflow UI under the knowledge_rag experiment
```

---

## Integrations

### Azure AD authentication

Disabled by default — the backend uses an `X-User-Email` header stub for local development.

**To enable:**

1. Register an app in [Microsoft Entra ID](https://portal.azure.com) and add a redirect URI:
   `http://localhost:8000/auth/callback` (local) or your production URL.

2. Set in `.env`:
   ```dotenv
   AZURE_AUTH_ENABLED=true
   AZURE_CLIENT_ID=<your-application-client-id>
   AZURE_TENANT_ID=<your-tenant-id>
   AZURE_CLIENT_SECRET=<your-client-secret>
   AZURE_REDIRECT_URI=http://localhost:8000/auth/callback
   ```

3. Restart the backend. The `/login` route redirects to Azure and the `/auth/callback` route exchanges the code for a JWT.

**To disable** — set `AZURE_AUTH_ENABLED=false`. All routes accept `X-User-Email: user@example.com` in the request header instead.

---

### Confluence connector

Syncs a Confluence space into the vector store for RAG retrieval.

**To enable:**

1. Create an [Atlassian API token](https://id.atlassian.com/manage-profile/security/api-tokens).

2. Set in `.env`:
   ```dotenv
   CONFLUENCE_BASE_URL=https://yourcompany.atlassian.net
   CONFLUENCE_EMAIL=you@company.com
   CONFLUENCE_API_TOKEN=<your-token>
   ```

3. Enable the connector in the database:
   ```bash
   curl -X POST http://localhost:8000/api/v1/admin/connector-permissions \
     -H "Content-Type: application/json" \
     -H "X-User-Email: alice@example.com" \
     -d '{"connector_id": "confluence", "enabled": true}'
   ```

4. Trigger a sync:
   ```bash
   curl -X POST http://localhost:8000/confluence/sync \
     -H "X-User-Email: alice@example.com"
   ```

   Or restart the backend — a sync task is queued automatically at startup when the connector is enabled.

**To disable** — set the connector to `enabled=false` via the admin API or directly in the DB:
```sql
UPDATE enterprise_rag_system.connector_configs
SET enabled = false
WHERE connector_id = 'confluence';
```
The platform stays fully functional; disabled connectors return empty results.

---

### LLM providers

Providers are resolved at startup via a priority chain in `config/llm.yaml`. The first provider whose API key is present is used.

**To switch providers** — edit `config/llm.yaml` or reorder the chain for `KNOWLEDGE_DEFAULT` / `KNOWLEDGE_FAST`:

```yaml
# config/llm.yaml
- id: KNOWLEDGE_DEFAULT
  chain:
    - provider: google
      model: gemini-2.5-flash
      requires_key_env: GOOGLE_API_KEY
    - provider: openrouter
      model: google/gemini-2.0-flash-exp:free
      requires_key_env: OPENROUTER_API_KEY
```

**To use OpenRouter (free tier):**
```dotenv
OPENROUTER_API_KEY=<from https://openrouter.ai>
# Leave GOOGLE_API_KEY blank or remove it
```

---

### RAG prompt versions

Two versions of the `rag_answer` prompt are registered in the MLflow prompt registry at startup.

```dotenv
RAG_ANSWER_PROMPT_VERSION=2   # 1 or 2 (default: 2)
```

Change the value and restart — no code change needed.

---

### Chunking strategy

```dotenv
RAG_CHUNK_STRATEGY=recursive   # options: recursive | token | semantic
RAG_CHUNK_SIZE=800
RAG_CHUNK_OVERLAP=120
```

---

## API Reference

### Chat
```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -H "X-User-Email: alice@example.com" \
  -d '{"message": "What is the onboarding process?"}'
```

### Sessions
```bash
# List sessions
curl http://localhost:8000/api/v1/sessions \
  -H "X-User-Email: alice@example.com"

# Get messages for a session
curl http://localhost:8000/api/v1/sessions/{session_id}/messages \
  -H "X-User-Email: alice@example.com"
```

### Health
```bash
curl http://localhost:8000/health_check
```

Full interactive docs with request/response schemas: **http://localhost:8000/docs**

---

## Makefile Reference

### First-time setup (run in order)

```bash
make init        # (optional) chmod init.sh + run it — starts infra
make migrate     # apply all Alembic migrations
make seed        # create alice@example.com dev user
make dev         # start backend (MLflow prompts auto-seeded on first run)
```

### Day-to-day

| Command          | What it does                                      |
|------------------|---------------------------------------------------|
| `make dev`       | Backend with hot-reload on `:8000`                |
| `make worker`    | Celery worker for ingestion tasks                 |
| `make chat`      | Frontend dev server on `:3000`                    |
| `make migrate`   | Apply new migrations after a pull                 |
| `make migrate-down` | Roll back the last migration                   |
| `make clean`     | Remove `__pycache__` / `.pyc` / pytest artifacts  |

### Testing & evaluation

```bash
make test              # all tests
make test-unit         # unit tests — no external services needed
make test-acceptance   # integration tests — requires running infra
make eval              # MLflow evaluation run
```

---

## Useful URLs (local)

| What               | URL                            |
|--------------------|--------------------------------|
| API Docs (Swagger) | http://localhost:8000/docs     |
| Health check       | http://localhost:8000/health_check |
| Frontend chat UI   | http://localhost:3000          |
| MLflow UI          | http://localhost:5001          |
| Adminer (DB UI)    | http://localhost:8081          |

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `User 'x@y.com' not found` | Run `make seed` — the user must exist in `enterprise_rag_system.users` |
| `ModuleNotFoundError` | Activate venv: `source .venv/bin/activate` then `pip install -r requirements.txt` |
| `Connection refused` (Postgres / Redis) | Run `docker compose up -d` and wait for healthy status |
| MLflow traces not showing | Confirm `MLFLOW_TRACKING_URI=http://localhost:5001` and MLflow container is running before the backend |
| Gemini 429 rate limit | Free tier: ~1500 req/day — add `OPENROUTER_API_KEY` as fallback |
| `AZURE_CLIENT_ID must be set` | Either set the Azure vars or set `AZURE_AUTH_ENABLED=false` |
| Empty retrieval / no chunks | Index documents via Confluence sync (Step 8) |
