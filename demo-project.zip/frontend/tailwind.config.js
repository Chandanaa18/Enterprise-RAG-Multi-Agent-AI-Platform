/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0f1f3d',
          light:   '#162848',
          hover:   '#1e3560',
        },
        brand: {
          DEFAULT: '#e8401c',
          dark:    '#cf3416',
        },
        gray: {
          50:  '#f8f9fb',
          100: '#f0f2f5',
          200: '#e2e6ec',
          300: '#c8cdd8',
          500: '#7a8499',
          700: '#3d4758',
          900: '#1a2133',
        },
      },
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
