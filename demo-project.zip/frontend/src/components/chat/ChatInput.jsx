import { useState, useRef } from 'react'
import { useChat } from '../../hooks/useChat'
import { useSessions } from '../../hooks/useSessions'
import { useNavigate } from 'react-router-dom'

const SUGGESTIONS = [
  "How do I set up my VPN?",
  "Who is the lead for Project Apollo?",
  "Summarize the recent Jira tickets for Security.",
  "What are the company policies on remote work?"
]

export default function ChatInput() {
  const [text, setText]         = useState('')
  const textareaRef             = useRef(null)
  const { sendMessage, isSending } = useChat()
  const { currentSessionId, createSession } = useSessions()
  const navigate                = useNavigate()

  function autoResize() {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 140) + 'px'
  }

  async function handleSend(overrideText) {
    const val = overrideText || text
    if (!val.trim() || isSending) return
    let id = currentSessionId
    if (!id) {
      id = await createSession()
      navigate('/chat')
    }
    const msg = val.trim()
    setText('')
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
    await sendMessage(msg)
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div className="bg-[#fcfdff] border-t border-blue-50/50 flex-shrink-0">
      <div className="max-w-3xl mx-auto px-6 pt-4 pb-6">
        
        {/* Dynamic Suggestions */}
        {!text && !isSending && (
          <div className="flex flex-wrap gap-2 mb-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {SUGGESTIONS.map((s, i) => (
              <button
                key={i}
                onClick={() => handleSend(s)}
                className="text-[11px] font-bold text-blue-400 bg-blue-50/30 border border-blue-100/50 rounded-lg px-3 py-1.5 hover:bg-blue-600 hover:text-white hover:border-blue-600 hover:shadow-md transition-all active:scale-95"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        <div className={`relative flex items-end gap-2 bg-white border border-blue-100 rounded-2xl px-4 py-3 shadow-sm transition-all duration-300 ${
          isSending ? 'bg-gray-50/30 overflow-hidden' : 'focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-400/5'
        }`}>
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => { setText(e.target.value); autoResize() }}
            onKeyDown={handleKey}
            placeholder="Search company knowledge..."
            rows={1}
            disabled={isSending}
            className="flex-1 resize-none outline-none text-[15px] text-gray-700 placeholder-gray-300 leading-relaxed max-h-36 overflow-y-auto bg-transparent disabled:opacity-50"
          />
          <button
            onClick={() => handleSend()}
            disabled={!text.trim() || isSending}
            className="w-10 h-10 bg-blue-600 hover:bg-blue-700 disabled:opacity-20 disabled:grayscale text-white rounded-xl flex items-center justify-center text-sm transition-all flex-shrink-0 shadow-md shadow-blue-100 active:scale-95"
          >
            {isSending ? (
              <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            ) : (
              '➤'
            )}
          </button>
        </div>
        
        <div className="flex items-center justify-between mt-3 px-1">
          <div className="text-[10px] text-gray-400 font-medium flex items-center gap-1.5 grayscale opacity-70">
            <span className="w-1 h-1 rounded-full bg-blue-400" />
            AI Retrieval Active
          </div>
          <div className="text-[10px] text-gray-300 font-medium">
            <kbd className="bg-white border border-blue-50 rounded-md px-1.5 py-0.5 inline-flex items-center text-gray-400 font-mono text-[9px] shadow-sm">Enter</kbd> to send
          </div>
        </div>
      </div>
    </div>
  )
}
