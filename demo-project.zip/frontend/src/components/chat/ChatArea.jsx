import { useEffect, useRef } from 'react'
import useAppStore from '../../store/useAppStore'
import BotMessage from './BotMessage'
import EmptyState from './EmptyState'

export default function ChatArea() {
  const { messages, isSending, isLoadingMessages } = useAppStore()
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  if (isLoadingMessages) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <span className="text-gray-400 text-sm">Loading messages…</span>
      </div>
    )
  }

  if (!messages.length) return <EmptyState />

  return (
    <div className="flex-1 overflow-y-auto px-4 py-8 scrollbar-light">
      <div className="max-w-3xl mx-auto flex flex-col gap-8">
        {messages.map((msg) =>
          msg.role === 'user' ? (
            <UserMessage key={msg.id} msg={msg} />
          ) : (
            <BotMessage key={msg.id} msg={msg} />
          )
        )}
        {isSending && <TypingIndicator />}
        <div ref={bottomRef} />
      </div>
    </div>
  )
}

function UserMessage({ msg }) {
  return (
    <div className="flex justify-end items-start gap-3 pl-12">
      <div className="bg-blue-600 text-white px-5 py-3 rounded-2xl rounded-tr-none text-[15px] leading-relaxed shadow-sm shadow-blue-100">
        {msg.content}
      </div>
      <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 text-[11px] font-bold flex-shrink-0 mt-0.5 border border-blue-200/50">
        U
      </div>
    </div>
  )
}

function TypingIndicator() {
  return (
    <div className="flex items-start gap-4 pr-12">
      <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-sm flex-shrink-0 border border-blue-100/50 shadow-sm text-blue-400">⚡</div>
      <div className="bg-gray-50 border border-gray-100 rounded-2xl rounded-tl-none px-6 py-3 text-gray-400 text-[14px] italic shadow-sm">
        Processing query...
      </div>
    </div>
  )
}
