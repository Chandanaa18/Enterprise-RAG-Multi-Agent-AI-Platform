export default function CitationCard({ citation }) {
  const url   = citation.source_uri || citation.url || citation.source || '#'
  
  let sourceIcon = '📄'
  let sourceLabel = 'Doc'

  if (url.includes('atlassian.net/wiki')) {
    sourceIcon = '📘'
    sourceLabel = 'Confluence'
  } else if (url.includes('atlassian.net/browse')) {
    sourceIcon = '🎫'
    sourceLabel = 'Jira'
  } else if (url.includes('sharepoint.com') || url.includes('office.com')) {
    sourceIcon = '📦'
    sourceLabel = 'M365'
  }

  const score = citation.score ? Math.round(citation.score * 100) : null

  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer"
      className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors border-b border-gray-100 last:border-0 group no-underline"
    >
      <span className="text-sm flex-shrink-0">{sourceIcon}</span>
      <div className="flex-1 min-w-0">
        <div className="text-[12px] font-medium text-gray-700 truncate group-hover:text-brand">
          {citation.title || 'Untitled Source'}
        </div>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-[9px] font-bold uppercase tracking-wider text-gray-400">{sourceLabel}</span>
          {citation.page_no && <span className="text-[9px] text-gray-300">· Page {citation.page_no}</span>}
        </div>
      </div>
      {score !== null && (
        <div className="text-[10px] font-bold text-gray-400">
          {score}%
        </div>
      )}
      <span className="text-gray-300 text-[10px] group-hover:text-brand transition-colors">↗</span>
    </a>
  )
}
