import { useChat } from '../../hooks/useChat'
import { useSessions } from '../../hooks/useSessions'
import { useNavigate } from 'react-router-dom'

const STARTERS = [
  { icon: '📋', label: 'Company Policies', sub: 'Leave, travel, expenses', q: 'What is the company remote work and travel policy?' },
  { icon: '📘', label: 'Confluence Docs', sub: 'Project specs, wikis', q: 'Search Confluence for the latest API design guidelines.' },
  { icon: '👋', label: 'Onboarding Info', sub: 'New hire checklist', q: 'What are the first steps for a new engineering hire?' },
  { icon: '🎫', label: 'Jira Updates', sub: 'Tickets, sprints', q: 'Summarize the recent updates on high-priority Jira tickets.' },
  { icon: '💬', label: 'Teams Chats', sub: 'Conversations, threads', q: 'Find recent discussions in Teams about the product launch.' },
  { icon: '⚙️', label: 'Internal Processes', sub: 'Workflows, tools', q: 'How do I request access to internal production servers?' },
]

export default function EmptyState() {
  const { sendMessage } = useChat()
  const { currentSessionId, createSession } = useSessions()
  const navigate = useNavigate()

  async function handleQuick(q) {
    let id = currentSessionId
    if (!id) {
      id = await createSession()
      navigate('/chat')
    }
    sendMessage(q)
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
      <div className="w-16 h-16 rounded-3xl bg-blue-50 border border-blue-100 flex items-center justify-center text-2xl mb-6 shadow-sm shadow-blue-100/50">
        <span className="text-blue-500">🏢</span>
      </div>
      <h2 className="text-xl font-semibold text-gray-900 mb-2">Hi, how can I help you today?</h2>
      <p className="text-sm text-gray-500 max-w-sm leading-relaxed mb-8">
        Your workspace assistant for finding information and getting work done.
      </p>
      <div>
        <div className="text-[10px] font-semibold tracking-widest uppercase text-gray-400 mb-3">Quick start</div>
        <div className="grid grid-cols-3 gap-2 max-w-lg">
          {STARTERS.map((s) => (
            <button
              key={s.label}
              onClick={() => handleQuick(s.q)}
              className="bg-white border border-gray-200 rounded-lg p-3 text-left hover:border-brand hover:bg-orange-50 transition-all hover:-translate-y-0.5 hover:shadow-sm"
            >
              <div className="text-base mb-1">{s.icon}</div>
              <div className="text-[12px] font-medium text-gray-700">{s.label}</div>
              <div className="text-[10px] text-gray-400 mt-0.5">{s.sub}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
