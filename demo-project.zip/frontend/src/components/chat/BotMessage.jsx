import { useState } from 'react'
import CitationCard from './CitationCard'

export default function BotMessage({ msg }) {
  const [feedback, setFeedback]     = useState(null)
  const [copied, setCopied]         = useState(false)
  const [showMetadata, setShowMetadata] = useState(false)
  const [showSources, setShowSources]   = useState(false)

  function handleCopy() {
    navigator.clipboard.writeText(msg.content || '').then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const uniqueDocs = msg.citations?.length
    ? [...new Set(msg.citations.map((c) => c.title))].length
    : 0

  const hasSections = msg.content?.includes('###')
  const contentParts = hasSections ? msg.content.split(/(?=### )/) : [msg.content]

  return (
    <div className="flex items-start gap-4 pr-12 group/msg">
      <div className="w-8 h-8 rounded-xl bg-indigo-950 flex items-center justify-center text-sm flex-shrink-0 mt-0.5 shadow-sm border border-indigo-900/50">
        <span className="text-indigo-200">✨</span>
      </div>

      <div className="flex-1 min-w-0">
        {/* Meta row */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <MetaBadge className={msg.canAnswer === false ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100'}>
            <span className={`w-1.5 h-1.5 rounded-full ${msg.canAnswer === false ? 'bg-amber-500' : 'bg-emerald-500'}`} />
            {msg.canAnswer === false ? 'Response Limited' : 'Answered'}
          </MetaBadge>

          {msg.citations?.length > 0 && (
            <MetaBadge className="bg-blue-50 text-blue-700 border-blue-100">
              Knowledge Base
            </MetaBadge>
          )}

          {msg.agent?.includes('jira') && (
            <MetaBadge className="bg-violet-50 text-violet-700 border-violet-100">
              Jira
            </MetaBadge>
          )}

          {msg.latencyMs && (
            <span className="text-[10px] text-gray-400 ml-auto">
              { (msg.latencyMs / 1000).toFixed(2) }s
            </span>
          )}
        </div>

        {/* Answer text */}
        <div className={`text-[15px] leading-relaxed mb-6 space-y-4 ${msg.isError ? 'text-red-500' : 'text-gray-800'}`}>
          {contentParts.map((part, i) => {
            if (part.startsWith('### ')) {
              const [title, ...rest] = part.split('\n')
              return (
                <div key={i} className="mb-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">{title.replace('### ', '')}</h4>
                  <div className="whitespace-pre-wrap">{rest.join('\n').trim()}</div>
                </div>
              )
            }
            return <div key={i} className="whitespace-pre-wrap">{part.trim()}</div>
          })}
        </div>

        {/* Sources Section */}
        {msg.citations?.length > 0 && (
          <div className="border border-gray-100 rounded-xl overflow-hidden mb-6 bg-white shadow-sm">
            <button
              onClick={() => setShowSources(!showSources)}
              className="w-full flex items-center justify-between px-4 py-3 text-[12px] font-semibold text-gray-500 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className="text-gray-400">📚</span>
                <span>Sources ({msg.citations.length}) • {showSources ? 'Hide Sources' : 'View Sources'}</span>
              </div>
              <span className={`text-[10px] transition-transform duration-200 ${showSources ? 'rotate-180' : ''}`}>▼</span>
            </button>
            
            {showSources && (
              <div className="p-1 pt-0 bg-white border-t border-gray-100 flex flex-col">
                {msg.citations.map((c, i) => (
                  <CitationCard key={i} citation={c} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Bottom Actions & Debug */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 opacity-0 group-hover/msg:opacity-100 transition-opacity">
            <button
              onClick={handleCopy}
              className={`inline-flex items-center gap-1.5 text-[10px] font-medium border rounded-lg px-2.5 py-1.5 transition-all ${
                copied
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                  : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300 hover:text-gray-700 shadow-sm'
              }`}
            >
              {copied ? '✓ Copied' : '📋 Copy Answer'}
            </button>

            <div className="flex items-center gap-1 ml-1">
              <ActionButton onClick={() => setFeedback(feedback === 'up' ? null : 'up')} active={feedback === 'up'} type="up">👍</ActionButton>
              <ActionButton onClick={() => setFeedback(feedback === 'down' ? null : 'down')} active={feedback === 'down'} type="down">👎</ActionButton>
            </div>
          </div>

          <button
            onClick={() => setShowMetadata(!showMetadata)}
            className="text-[10px] text-gray-300 hover:text-gray-500 transition-colors font-medium"
          >
            {showMetadata ? 'Hide Debug' : 'Show Debug'}
          </button>
        </div>

        {/* Developer Panel */}
        {showMetadata && (
          <div className="mt-4 p-4 bg-gray-900 rounded-xl border border-gray-800 text-[11px] font-mono text-gray-400 overflow-x-auto shadow-inner">
            <div className="flex flex-col gap-1">
              <div className="flex gap-2"><span className="text-emerald-500/70 w-24">agent_id:</span> <span className="text-gray-300">{msg.agent}</span></div>
              <div className="flex gap-2"><span className="text-emerald-500/70 w-24">mlflow_run:</span> <span className="text-gray-300">{msg.mlflowRunId}</span></div>
              <div className="flex gap-2"><span className="text-emerald-500/70 w-24">latency:</span> <span className="text-gray-300">{msg.latencyMs}ms</span></div>
              <div className="flex gap-2"><span className="text-emerald-500/70 w-24">timestamp:</span> <span className="text-gray-300">{msg.createdAt}</span></div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function MetaBadge({ children, className }) {
  return (
    <span className={`inline-flex items-center gap-1.5 text-[10px] font-semibold px-2 py-1 rounded-full border shadow-sm ${className}`}>
      {children}
    </span>
  )
}

function ActionButton({ children, onClick, active, type }) {
  const styles = {
    up: active ? 'bg-emerald-50 border-emerald-300 text-emerald-600' : 'hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-600',
    down: active ? 'bg-red-50 border-red-300 text-red-500' : 'hover:bg-red-50 hover:border-red-200 hover:text-red-500',
  }
  return (
    <button
      onClick={onClick}
      className={`w-7 h-7 bg-white border border-gray-200 rounded-lg flex items-center justify-center text-xs transition-all shadow-sm ${styles[type]}`}
    >
      {children}
    </button>
  )
}

