import { useSessions } from '../../hooks/useSessions'
import useAppStore from '../../store/useAppStore'

export default function TopBar() {
  const { sessions, currentSessionId, deleteSession } = useSessions()
  const session = sessions.find((s) => s.session_id === currentSessionId)
  const label   = session?.name || (session ? currentSessionId?.slice(0, 8) + '…' : '—')

  async function handleDelete() {
    if (!currentSessionId) return
    if (window.confirm('Delete this session?')) {
      await deleteSession(currentSessionId)
    }
  }

  return (
    <header className="bg-white border-b border-gray-200 px-6 h-13 flex items-center justify-between flex-shrink-0" style={{ height: 52 }}>
      <div className="flex items-center gap-2">
        <span className="text-[11px] text-gray-500 font-medium">Session</span>
        <span className="bg-gray-100 border border-gray-200 rounded px-2 py-0.5 text-[11px] text-gray-700 font-medium">
          {label}
        </span>
      </div>
      <div className="flex items-center gap-1.5">
        <IconBtn title="Delete session" onClick={handleDelete}>🗑</IconBtn>
        <IconBtn title="Export session">💾</IconBtn>
        <IconBtn title="Menu">☰</IconBtn>
      </div>
    </header>
  )
}

function IconBtn({ children, title, onClick }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="w-8 h-8 border border-gray-200 bg-white rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-50 hover:border-gray-300 text-sm transition-colors"
    >
      {children}
    </button>
  )
}
