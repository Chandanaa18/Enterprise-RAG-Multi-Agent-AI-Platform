/**
 * PendingChanges.jsx
 * Shows the diff of unsaved permission changes + Save button.
 * No API calls — pure display + callback.
 */

export default function PendingChanges({
  pendingChanges,
  saving,
  saveError,
  saveSuccess,
  selectedUser,
  onSave,
}) {
  const hasChanges = pendingChanges.length > 0;

  // Nothing to show if no user selected and no save feedback
  if (!selectedUser && !saveSuccess && !saveError) return null;

  return (
    <div className="space-y-3">
      {/* Pending changes list */}
      {hasChanges && (
        <div className="bg-white border border-amber-200 rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-amber-100 bg-amber-50 flex items-center gap-2">
            <svg className="w-4 h-4 text-amber-500 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
            </svg>
            <h2 className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
              Pending changes ({pendingChanges.length})
            </h2>
          </div>
          <ul className="divide-y divide-amber-50 px-5 py-2">
            {pendingChanges.map((change) => (
              <li key={change.connector} className="flex items-center gap-3 py-2">
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold
                    ${change.action === "grant"
                      ? "bg-emerald-100 text-emerald-700"
                      : "bg-red-100 text-red-700"
                    }`}
                >
                  {change.action === "grant" ? (
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                    </svg>
                  ) : (
                    <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"/>
                    </svg>
                  )}
                  {change.action === "grant" ? "Grant" : "Revoke"}
                </span>
                <span className="text-sm text-gray-700 capitalize font-medium">
                  {change.connector}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Empty state — user selected but no changes */}
      {selectedUser && !hasChanges && !saveSuccess && (
        <p className="text-xs text-gray-400 text-center py-1">
          No changes yet. Toggle connector access above.
        </p>
      )}

      {/* Save error */}
      {saveError && (
        <div className="flex items-start gap-2 px-4 py-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
          <svg className="w-4 h-4 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
          </svg>
          <span>Save failed: {saveError}</span>
        </div>
      )}

      {/* Success toast */}
      {saveSuccess && (
        <div className="flex items-center gap-2 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 text-sm">
          <svg className="w-4 h-4 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
          </svg>
          Permissions saved successfully.
        </div>
      )}

      {/* Save button — always visible, disabled when nothing pending */}
      <button
        type="button"
        onClick={onSave}
        disabled={saving || !hasChanges}
        className="w-full flex items-center justify-center gap-2 px-4 py-3
                   bg-indigo-500 hover:bg-indigo-600 active:bg-indigo-700
                   text-white text-sm font-semibold rounded-xl shadow-md
                   transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:ring-offset-2
                   disabled:opacity-40 disabled:grayscale disabled:cursor-not-allowed transform active:scale-[0.98]"
      >
        {saving ? (
          <>
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
            </svg>
            Saving…
          </>
        ) : (
          <>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/>
            </svg>
            Save changes
          </>
        )}
      </button>
    </div>
  );
}