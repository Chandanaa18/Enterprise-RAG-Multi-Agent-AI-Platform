/**
 * UserSummary.jsx
 * Read-only card showing selected user info and connector counts.
 */

export default function UserSummary({ user, totalConnectors, activeConnectors }) {
  if (!user) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5 flex flex-wrap items-center gap-6 shadow-sm">
      {/* Avatar */}
      <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-700 text-base font-semibold
                      flex items-center justify-center shrink-0">
        {getInitials(user.display_name || user.email)}
      </div>

      {/* Name + email */}
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-gray-900 truncate">
          {user.display_name || "—"}
        </p>
        <p className="text-xs text-gray-500 truncate mt-0.5">{user.email}</p>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-6 shrink-0">
        <Stat label="Total connectors" value={totalConnectors} />
        <div className="w-px h-8 bg-gray-100" />
        <Stat
          label="Active"
          value={activeConnectors}
          green={activeConnectors > 0}
        />
      </div>
    </div>
  );
}

function Stat({ label, value, green }) {
  return (
    <div className="text-center">
      <p
        className={`text-2xl font-bold tabular-nums ${
          green ? "text-emerald-500" : "text-gray-400"
        }`}
      >
        {value}
      </p>
      <p className="text-xs text-gray-400 mt-0.5 whitespace-nowrap">{label}</p>
    </div>
  );
}

function getInitials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join("");
}