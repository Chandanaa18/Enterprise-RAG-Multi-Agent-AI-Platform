/**
 * PermissionList.jsx
 * Always shows all 7 connectors. DB rows override default OFF state.
 */

const ALL_CONNECTORS = [
  {
    key: "confluence",
    label: "Confluence",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M1.26 16.79c-.31.5-.06 1.15.48 1.34l3.93 1.38c.54.19 1.13-.1 1.36-.63.87-2.06 2.5-3.56 4.47-4.18L12 14.5l.5.2c1.97.62 3.6 2.12 4.47 4.18.23.53.82.82 1.36.63l3.93-1.38c.54-.19.79-.84.48-1.34C20.26 12.37 16.41 9.5 12 9.5s-8.26 2.87-10.74 7.29zM22.74 7.21c.31-.5.06-1.15-.48-1.34l-3.93-1.38c-.54-.19-1.13.1-1.36.63-.87 2.06-2.5 3.56-4.47 4.18L12 9.5l-.5-.2C9.53 8.68 7.9 7.18 7.03 5.12c-.23-.53-.82-.82-1.36-.63L1.74 5.87c-.54.19-.79.84-.48 1.34C3.74 11.63 7.59 14.5 12 14.5s8.26-2.87 10.74-7.29z"/>
      </svg>
    ),
  },
  {
    key: "jira",
    label: "Jira",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M11.571 11.513H0a5.218 5.218 0 0 0 5.232 5.215h2.13v2.057A5.215 5.215 0 0 0 12.575 24V12.518a1.005 1.005 0 0 0-1.005-1.005zm5.723-5.756H5.736a5.215 5.215 0 0 0 5.215 5.214h2.129v2.058a5.218 5.218 0 0 0 5.215 5.214V6.762a1.005 1.005 0 0 0-1.001-1.005zM23.013 0H11.455a5.215 5.215 0 0 0 5.215 5.215h2.129v2.057A5.215 5.215 0 0 0 24.019 12.49V1.005A1.005 1.005 0 0 0 23.013 0z"/>
      </svg>
    ),
  },
  {
    key: "sharepoint",
    label: "SharePoint",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M11.5 2a6.5 6.5 0 0 1 6.5 6.5 6.47 6.47 0 0 1-1.06 3.56A5 5 0 0 1 18 21H7a5 5 0 0 1-1.5-9.77A6.5 6.5 0 0 1 11.5 2z"/>
      </svg>
    ),
  },
  {
    key: "teams",
    label: "MS Teams",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20.625 7.875h-3.75a.375.375 0 0 0-.375.375v7.5c0 .207.168.375.375.375h3.75A2.625 2.625 0 0 0 23.25 13.5v-3a2.625 2.625 0 0 0-2.625-2.625zM15 3.75a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0zM14.25 7.5H9.75A2.25 2.25 0 0 0 7.5 9.75v5.25a.75.75 0 0 0 .75.75h7.5a.75.75 0 0 0 .75-.75V9.75A2.25 2.25 0 0 0 14.25 7.5zM6 6.75a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0zM4.5 9.375H2.25A2.25 2.25 0 0 0 0 11.625V15c0 .621.504 1.125 1.125 1.125h3.75c.621 0 1.125-.504 1.125-1.125v-3.375A2.25 2.25 0 0 0 4.5 9.375z"/>
      </svg>
    ),
  },
  {
    key: "m365",
    label: "M365",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0L0 4v16l12 4 12-4V4L12 0zm0 18.5L4 16V8l8 2.5v8zm0-11L4 5l8-2.5 8 2.5-8 2.5zm8 10L12 18.5V10.5l8-2.5v10.5z"/>
      </svg>
    ),
  },
  {
    key: "outlook",
    label: "Outlook",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4.236-8 4.882-8-4.882V6l8 4.882L20 6v2.236z"/>
      </svg>
    ),
  },
  {
    key: "onedrive",
    label: "OneDrive",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M14.59 5.42A6.5 6.5 0 0 0 2.1 10.06 4.5 4.5 0 0 0 4.5 19h14a3.5 3.5 0 0 0 .59-6.95 6.5 6.5 0 0 0-4.5-6.63z"/>
      </svg>
    ),
  },
  {
    key: "calendar",
    label: "Calendar",
    icon: (
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
    ),
  },
];

export default function PermissionList({
  permissions,
  editedPermissions,
  loading,
  error,
  selectedUser,
  onToggle,
}) {
  if (!selectedUser) {
    return (
      <div className="bg-white border border-gray-200 rounded-xl p-10 flex flex-col items-center justify-center text-center shadow-sm">
        <svg className="w-10 h-10 text-gray-300 mb-3" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"/>
        </svg>
        <p className="text-sm text-gray-400">Search and select a user to manage permissions</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <SectionHeader />
        <div className="divide-y divide-gray-100">
          {ALL_CONNECTORS.map((c) => <SkeletonRow key={c.key} />)}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white border border-red-200 rounded-xl p-6 shadow-sm">
        <SectionHeader />
        <div className="flex items-start gap-3 mt-4 text-red-600">
          <svg className="w-5 h-5 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
          </svg>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  // Build a lookup from DB rows: connector_name → enabled
  const dbState = Object.fromEntries(
    permissions.map((p) => [p.connector_name, p.enabled])
  );

  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
      <SectionHeader />
      <ul className="divide-y divide-gray-100">
        {ALL_CONNECTORS.map(({ key, label, icon }) => {
          const edited = editedPermissions[key];
          // DB row exists → use its value, else default OFF
          const dbValue = dbState[key] ?? false;
          const isActive = edited !== undefined ? edited : dbValue;
          const isDirty = edited !== undefined && edited !== dbValue;

          return (
            <li
              key={key}
              className={`flex items-center gap-4 px-5 py-4 transition-colors ${
                isDirty ? "bg-amber-50" : "hover:bg-gray-50"
              }`}
            >
              <span className={`shrink-0 ${isActive ? "text-indigo-500" : "text-gray-300"}`}>
                {icon}
              </span>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {label}
                  {isDirty && (
                    <span className="ml-2 text-xs text-amber-600 font-normal">(unsaved)</span>
                  )}
                </p>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={isActive}
                aria-label={`${isActive ? "Disable" : "Enable"} ${label}`}
                onClick={() => onToggle(key, isActive)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full
                            border-2 border-transparent transition-colors duration-200 focus:outline-none
                            focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            ${isActive ? "bg-indigo-600" : "bg-gray-200"}`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow
                              transform transition-transform duration-200
                              ${isActive ? "translate-x-5" : "translate-x-0"}`}
                />
              </button>

              <span className={`w-8 text-xs font-semibold tabular-nums ${isActive ? "text-indigo-600" : "text-gray-400"}`}>
                {isActive ? "ON" : "OFF"}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function SectionHeader() {
  return (
    <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
      <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
        Connector permissions
      </h2>
    </div>
  );
}

function SkeletonRow() {
  return (
    <li className="flex items-center gap-4 px-5 py-4 animate-pulse">
      <div className="w-5 h-5 rounded bg-gray-200 shrink-0" />
      <div className="flex-1 space-y-1.5">
        <div className="h-3 bg-gray-200 rounded w-28" />
      </div>
      <div className="h-6 w-11 bg-gray-200 rounded-full shrink-0" />
      <div className="h-3 w-6 bg-gray-100 rounded" />
    </li>
  );
}
