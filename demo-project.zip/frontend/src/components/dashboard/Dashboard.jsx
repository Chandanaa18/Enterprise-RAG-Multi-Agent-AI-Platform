export default function Dashboard() {
  return (
    <div className="flex items-center justify-center h-full text-gray-400 text-sm">
      Dashboard coming soon
    </div>
  )
}
