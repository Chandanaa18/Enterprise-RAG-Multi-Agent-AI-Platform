import { useEffect, useRef, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useSessions } from '../../hooks/useSessions'
import SessionList from './SessionList'
import ConnectorStrip from './ConnectorStrip'
import sigmoidLogo from '../../assets/sigmoid-logo.png'
import useAppStore from '../../store/useAppStore'
import { usersApi } from '../../services/api'

export default function Sidebar() {
  const navigate   = useNavigate()
  const location   = useLocation()
  const { loadSessions, createSession } = useSessions()
  const user       = useAppStore((s) => s.user)
  const switchUser = useAppStore((s) => s.switchUser)
  const logout     = useAppStore((s) => s.logout)
  const devEmail   = import.meta.env.VITE_DEV_USER_EMAIL || ''
  const displayName = user?.display_name || user?.email || devEmail || 'User'
  const initial = displayName[0].toUpperCase()

  const [showSwitcher, setShowSwitcher] = useState(false)
  const [azureUsers, setAzureUsers]     = useState([])
  const [loadingUsers, setLoadingUsers] = useState(false)
  const dropdownRef = useRef(null)

  useEffect(() => { loadSessions() }, [])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowSwitcher(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleOpenSwitcher() {
    setShowSwitcher((v) => !v)
    if (azureUsers.length === 0) {
      setLoadingUsers(true)
      try {
        const users = await usersApi.list()
        setAzureUsers(users)
      } catch {
        setAzureUsers([])
      } finally {
        setLoadingUsers(false)
      }
    }
  }

  function handleSelectUser(u) {
    switchUser({
      user_id:      u.user_id,
      email:        u.email,
      display_name: u.display_name || u.email,
      roles:        u.roles,
    })
    setShowSwitcher(false)
    navigate('/chat')
  }

  async function handleNewSession() {
    const id = await createSession()
    if (id) navigate('/chat')
  }

  return (
    <aside className="w-64 min-w-[256px] bg-[#f8faff] border-r border-blue-100/50 flex flex-col h-full overflow-hidden shadow-[1px_0_10px_rgba(0,0,0,0.02)]">

      {/* Logo */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-3">
          <img
            src={sigmoidLogo}
            alt="Sigmoid"
            className="h-9 w-auto object-contain flex-shrink-0"
          />
          <div>
            <div className="text-gray-900 text-sm font-bold tracking-tight">Enterprise RAG</div>
            <div className="text-blue-500/50 text-[10px] font-medium mt-0.5">Knowledge Intelligence</div>
          </div>
        </div>
      </div>

      {/* API status */}
      <div className="flex items-center gap-2 px-6 pb-4">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-gray-400 text-[10px] font-medium uppercase tracking-wider">System Operational</span>
      </div>

      {/* User chip — click to switch user */}
      <div className="mx-4 mb-4 relative" ref={dropdownRef}>
        <button
          onClick={handleOpenSwitcher}
          className="w-full bg-white border border-blue-50/50 rounded-xl px-3 py-2 flex items-center gap-2.5 shadow-sm hover:border-blue-200 hover:shadow-md transition-all group"
        >
          <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-[11px] font-bold flex-shrink-0">
            {initial}
          </div>
          <span className="text-gray-600 text-[11px] font-medium truncate flex-1 text-left">
            {displayName}
          </span>
          <svg
            className={`w-3 h-3 text-gray-400 flex-shrink-0 transition-transform ${showSwitcher ? 'rotate-180' : ''}`}
            fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {showSwitcher && (
          <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-blue-100 rounded-xl shadow-lg z-50 overflow-hidden">
            <div className="px-3 py-2 border-b border-blue-50 flex items-center gap-1.5">
              <svg className="w-3 h-3 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a4 4 0 00-5-4M9 20H4v-2a4 4 0 015-4m6-4a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <span className="text-[10px] font-semibold text-blue-400 uppercase tracking-wider">Switch Azure AD User</span>
            </div>

            {loadingUsers ? (
              <div className="px-3 py-3 text-[11px] text-gray-400 text-center">Loading users…</div>
            ) : azureUsers.length === 0 ? (
              <div className="px-3 py-3 text-[11px] text-gray-400 text-center">No users found</div>
            ) : (
              <ul className="max-h-48 overflow-y-auto py-1">
                {azureUsers.map((u) => {
                  const isActive = u.email === (user?.email)
                  const uInitial = (u.display_name || u.email || '?')[0].toUpperCase()
                  return (
                    <li key={u.user_id}>
                      <button
                        onClick={() => handleSelectUser(u)}
                        className={`w-full px-3 py-2 flex items-center gap-2.5 hover:bg-blue-50 transition-colors ${isActive ? 'bg-blue-50/60' : ''}`}
                      >
                        <div className={`w-6 h-6 rounded-md flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0 ${isActive ? 'bg-blue-600' : 'bg-gray-400'}`}>
                          {uInitial}
                        </div>
                        <div className="flex-1 text-left min-w-0">
                          <div className="text-[11px] font-medium text-gray-700 truncate">
                            {u.display_name || u.email}
                          </div>
                          <div className="text-[10px] text-gray-400 truncate">{u.email}</div>
                        </div>
                        {isActive && (
                          <svg className="w-3 h-3 text-blue-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414L8.414 15l-4.121-4.121a1 1 0 011.414-1.414L8.414 12.172l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        )}
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}

            {/* Sign out */}
            <div className="border-t border-gray-100">
              <button
                onClick={() => { logout(); setShowSwitcher(false) }}
                className="w-full px-3 py-2.5 flex items-center gap-2.5 hover:bg-red-50 transition-colors text-left"
              >
                <div className="w-6 h-6 rounded-md bg-red-50 flex items-center justify-center flex-shrink-0">
                  <svg className="w-3.5 h-3.5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1" />
                  </svg>
                </div>
                <span className="text-[11px] font-medium text-red-600">Sign out</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Nav tabs */}
      <div className="flex mx-4 mb-4 bg-blue-50/30 p-1 rounded-xl border border-blue-50/50">
        <button
          onClick={() => navigate('/chat')}
          className={`flex-1 py-2 rounded-lg text-[11px] font-bold transition-all ${
            location.pathname === '/chat'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          Assistant
        </button>
        <button
          onClick={() => navigate('/dashboard')}
          className={`flex-1 py-2 rounded-lg text-[11px] font-bold transition-all ${
            location.pathname === '/dashboard'
              ? 'bg-white text-blue-600 shadow-sm'
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          Analytics
        </button>
      </div>

      {/* Admin section — only visible to admins */}
      {user?.roles?.includes('admin') && (
        <div className="mx-4 mb-3">
          <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-[11px] font-semibold border ${
            location.pathname.startsWith('/admin')
              ? 'bg-amber-50 border-amber-200 text-amber-700'
              : 'bg-white border-gray-100 text-gray-500'
          }`}>
            <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            Admin Panel
          </div>
          <div className="mt-1 ml-3 flex flex-col gap-0.5">
            <button
              onClick={() => navigate('/admin/access')}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                location.pathname === '/admin/access'
                  ? 'bg-amber-100 text-amber-700'
                  : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
              }`}
            >
              Access Control
            </button>
          </div>
        </div>
      )}

      {/* New session button */}
      <button
        onClick={handleNewSession}
        className="mx-4 mb-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-2.5 text-[12px] font-bold flex items-center justify-center gap-2 px-4 transition-all shadow-md shadow-blue-200 active:scale-[0.98]"
      >
        <span className="text-base">+</span> New Conversation
      </button>

      {/* Session list — scrollable */}
      <SessionList />

      {/* Connector strip — pinned to bottom */}
      <ConnectorStrip />
    </aside>
  )
}
