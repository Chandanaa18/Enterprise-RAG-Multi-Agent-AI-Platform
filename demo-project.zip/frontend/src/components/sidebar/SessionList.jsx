import { useState } from 'react'
import useAppStore from '../../store/useAppStore'
import { useSessions } from '../../hooks/useSessions'
import SessionItem from './SessionItem'

export default function SessionList() {
  const { sessions, isLoadingSessions } = useAppStore()
  const [search, setSearch] = useState('')

  const filtered = sessions.filter((s) =>
    (s.name || 'New Conversation').toLowerCase().includes(search.toLowerCase())
  )

  const pinned   = filtered.filter((s) => s.pinned)
  const unpinned = filtered.filter((s) => !s.pinned)

  if (isLoadingSessions) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <span className="text-gray-300 text-[11px]">Loading…</span>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-transparent">
      {/* Search Bar */}
      <div className="px-4 mb-2">
        <div className="relative group">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search conversations..."
            className="w-full bg-white border border-blue-50 rounded-xl py-2 pl-8 pr-3 text-[11px] text-gray-700 placeholder:text-gray-300 outline-none focus:border-blue-200 focus:shadow-sm transition-all"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] grayscale opacity-50 group-focus-within:opacity-100">🔍</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-4 scrollbar-light">
        {!filtered.length && sessions.length > 0 && (
          <div className="px-4 py-8 text-center">
            <span className="text-gray-300 text-[10px] font-medium">No matches found</span>
          </div>
        )}

        {!sessions.length && (
          <div className="px-6 py-12 text-center">
            <span className="text-gray-400 text-[11px] leading-relaxed">No history found. Try asking a question to start.</span>
          </div>
        )}

        {pinned.length > 0 && (
          <div className="mb-4">
            <SectionLabel>Pinned</SectionLabel>
            <div className="flex flex-col gap-1">
              {pinned.map((s) => <SessionItem key={s.session_id} session={s} />)}
            </div>
          </div>
        )}

        {unpinned.length > 0 && (
          <div>
            <SectionLabel>Recent</SectionLabel>
            <div className="flex flex-col gap-1">
              {unpinned.map((s) => <SessionItem key={s.session_id} session={s} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function SectionLabel({ children }) {
  return (
    <div className="text-[9px] font-bold tracking-widest uppercase text-blue-400/60 px-4 pt-2 pb-2">
      {children}
    </div>
  )
}
