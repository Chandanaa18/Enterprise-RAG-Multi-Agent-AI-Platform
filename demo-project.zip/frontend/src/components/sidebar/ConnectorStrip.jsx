import { useEffect, useState, useCallback } from 'react'
import { connectorsApi } from '../../services/api'

const JIRA_ICON = (
  <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="#2684FF">
    <path d="M11.571 11.513H0a5.218 5.218 0 0 0 5.232 5.215h2.13v2.057A5.215 5.215 0 0 0 12.575 24V12.518a1.005 1.005 0 0 0-1.005-1.005zm5.723-5.756H5.736a5.215 5.215 0 0 0 5.215 5.214h2.129v2.058a5.218 5.218 0 0 0 5.215 5.214V6.762a1.005 1.005 0 0 0-1.001-1.005zM23.013 0H11.455a5.215 5.215 0 0 0 5.215 5.215h2.129v2.057A5.215 5.215 0 0 0 24.019 12.49V1.005A1.005 1.005 0 0 0 23.013 0z"/>
  </svg>
)

const COMING_SOON = [
  {
    label: 'Teams',
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="#6264A7">
        <path d="M20.625 7.875h-3.75a.375.375 0 0 0-.375.375v7.5c0 .207.168.375.375.375h3.75A2.625 2.625 0 0 0 23.25 13.5v-3a2.625 2.625 0 0 0-2.625-2.625zM15 3.75a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0zM14.25 7.5H9.75A2.25 2.25 0 0 0 7.5 9.75v5.25a.75.75 0 0 0 .75.75h7.5a.75.75 0 0 0 .75-.75V9.75A2.25 2.25 0 0 0 14.25 7.5zM6 6.75a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0zM4.5 9.375H2.25A2.25 2.25 0 0 0 0 11.625V15c0 .621.504 1.125 1.125 1.125h3.75c.621 0 1.125-.504 1.125-1.125v-3.375A2.25 2.25 0 0 0 4.5 9.375z"/>
      </svg>
    ),
  },
  {
    label: 'M365',
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="#D83B01">
        <path d="M0 0v11.408h11.408V0zm12.594 0v11.408H24V0zM0 12.594V24h11.408V12.594zm12.594 0V24H24V12.594z"/>
      </svg>
    ),
  },
]

export default function ConnectorStrip() {
  const [status, setStatus]           = useState(null)   // null=loading
  const [connecting, setConnecting]   = useState(false)
  const [disconnecting, setDisconnecting] = useState(false)
  const [hovered, setHovered]         = useState(false)

  const loadStatus = useCallback(async () => {
    try {
      const data = await connectorsApi.jiraStatus()
      setStatus(data)
    } catch {
      setStatus({ connected: false })
    }
  }, [])

  useEffect(() => { loadStatus() }, [loadStatus])

  async function handleConnect() {
    if (connecting) return
    setConnecting(true)
    try {
      const { url } = await connectorsApi.getAtlassianConnectUrl()
      window.location.href = url
    } catch {
      setConnecting(false)
    }
  }

  async function handleDisconnect() {
    if (disconnecting) return
    setDisconnecting(true)
    try {
      await connectorsApi.jiraDisconnect()
      await loadStatus()
    } catch (err) {
      console.error('Disconnect failed:', err)
    } finally {
      setDisconnecting(false)
      setHovered(false)
    }
  }

  const isConnected = status?.connected

  return (
    <div className="border-t border-blue-100/50 px-4 py-4">
      <div className="text-[9px] font-bold tracking-widest uppercase text-blue-400/60 mb-2 px-1">
        Integrations
      </div>
      <div className="flex flex-col gap-1">

        {/* Jira — connect / disconnect */}
        <div
          className="flex items-center gap-3 px-1 py-1 relative"
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
        >
          {JIRA_ICON}
          <span className="text-[11px] text-gray-500 font-medium flex-1">Jira</span>

          {status === null ? (
            <span className="w-1.5 h-1.5 rounded-full bg-gray-200 animate-pulse" />
          ) : isConnected ? (
            hovered ? (
              <button
                onClick={handleDisconnect}
                disabled={disconnecting}
                className="text-[9px] font-semibold text-red-500 hover:text-red-700 border border-red-200 hover:border-red-400 rounded-md px-1.5 py-0.5 transition-all disabled:opacity-50"
                title="Disconnect Atlassian"
              >
                {disconnecting ? '...' : 'Disconnect'}
              </button>
            ) : (
              <span
                className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_0_2px_rgba(74,222,128,0.2)] flex-shrink-0"
                title={`Connected as ${status.atlassian_email || ''}`}
              />
            )
          ) : (
            <button
              onClick={handleConnect}
              disabled={connecting}
              className="text-[9px] font-semibold text-blue-500 hover:text-blue-700 border border-blue-200 hover:border-blue-400 rounded-md px-1.5 py-0.5 transition-all disabled:opacity-50"
              title="Connect your Atlassian account"
            >
              {connecting ? '...' : 'Connect'}
            </button>
          )}
        </div>

        {/* Coming-soon connectors */}
        {COMING_SOON.map(({ label, icon }) => (
          <div key={label} className="flex items-center gap-3 px-1 py-1">
            {icon}
            <span className="text-[11px] text-gray-400 font-medium flex-1">{label}</span>
            <span
              className="text-[8px] font-semibold text-gray-400 bg-gray-100 rounded-full px-1.5 py-0.5 flex-shrink-0"
              title="Coming soon"
            >
              Soon
            </span>
          </div>
        ))}

      </div>
    </div>
  )
}
