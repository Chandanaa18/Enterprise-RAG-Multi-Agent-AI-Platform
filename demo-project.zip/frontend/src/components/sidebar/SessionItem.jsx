import { useNavigate } from 'react-router-dom'
import { useSessions } from '../../hooks/useSessions'
import { timeAgo } from '../../utils/timeAgo'
import { detectTag } from '../../utils/tagDetector'

const TAG_STYLES = {
  security:     'bg-red-500/20 text-red-300',
  rag:          'bg-blue-500/20 text-blue-300',
  governance:   'bg-purple-500/20 text-purple-300',
  architecture: 'bg-green-500/20 text-green-300',
}

export default function SessionItem({ session }) {
  const navigate          = useNavigate()
  const { switchSession, togglePin, currentSessionId } = useSessions()

  const isActive = session.session_id === currentSessionId
  const tag      = detectTag(session.name || '')
  const label    = session.name || 'New conversation'

  async function handleClick() {
    await switchSession(session.session_id)
    navigate('/chat')
  }

  return (
    <div
      className={`group flex items-center gap-2.5 px-3 py-2.5 mx-2 rounded-xl cursor-pointer transition-all ${
        isActive ? 'bg-blue-50/50 border border-blue-100/30 shadow-sm' : 'hover:bg-white border border-transparent'
      }`}
      onClick={handleClick}
    >
      <span className="text-[14px] flex-shrink-0">
        {session.pinned ? '📌' : '💬'}
      </span>

      <div className="flex-1 min-w-0">
        <div className={`text-[12px] font-medium truncate ${isActive ? 'text-blue-700' : 'text-gray-600'}`}>{label}</div>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-[9px] font-bold text-gray-300 uppercase tracking-tight">
            {timeAgo(session.last_active_at || session.created_at)}
          </span>
          {tag && (
            <span className={`text-[8px] px-1 py-0.5 rounded-sm font-bold uppercase tracking-wider ${TAG_STYLES[tag]}`}>
              {tag}
            </span>
          )}
        </div>
      </div>

      {/* Pin button — visible on hover */}
      <button
        onClick={(e) => { e.stopPropagation(); togglePin(session.session_id) }}
        className={`opacity-0 group-hover:opacity-100 text-[11px] p-1 rounded-lg transition-all ${
          session.pinned ? '!opacity-100 text-amber-500 bg-amber-50' : 'text-gray-300 hover:text-amber-500 hover:bg-amber-50'
        }`}
        title={session.pinned ? 'Unpin' : 'Pin'}
      >
        📍
      </button>
    </div>
  )
}
