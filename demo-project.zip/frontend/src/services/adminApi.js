/**
 * adminApi.js
 * Service layer for Access Control Center.
 * Mirrors the pattern in services/api.js — same base URL, same auth header approach.
 * Drop this next to your existing api.js.
 */

const DEV_USER_EMAIL = import.meta.env.VITE_DEV_USER_EMAIL || "";

function getAuthHeaders() {
  const token = localStorage.getItem("access_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(DEV_USER_EMAIL && !token ? { "X-User-Email": DEV_USER_EMAIL } : {}),
  };
}

const BASE_URL = "";

async function handleResponse(res) {
  if (!res.ok) {
    let message = `HTTP ${res.status}`;
    try {
      const body = await res.json();
      message = body.detail || body.message || message;
    } catch (_) {}
    throw new Error(message);
  }
  // 204 No Content — grant/revoke endpoints return this
  if (res.status === 204) return null;
  return res.json();
}

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------

/**
 * Fetches all users.
 * Filtering by name/email is done client-side (per spec).
 * GET /api/v1/users
 */
export async function fetchUsers() {
  const res = await fetch(`${BASE_URL}/admin/users`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(res);
}

// ---------------------------------------------------------------------------
// Connector permissions
// ---------------------------------------------------------------------------

/**
 * Fetches connector permissions for a specific user.
 * GET /admin/users/{user_id}/connectors
 */
export async function fetchUserConnectors(userId) {
  const res = await fetch(`${BASE_URL}/admin/users/${userId}/connectors`, {
    headers: getAuthHeaders(),
  });
  return handleResponse(res);
}

/**
 * Grants a connector permission for a user.
 * POST /admin/users/{user_id}/connectors/{connector}/grant
 */
export async function grantConnector(userId, connector) {
  const res = await fetch(
    `${BASE_URL}/admin/users/${userId}/connectors/${connector}/grant`,
    {
      method: "POST",
      headers: getAuthHeaders(),
    }
  );
  return handleResponse(res);
}

/**
 * Revokes a connector permission for a user.
 * POST /admin/users/{user_id}/connectors/{connector}/revoke
 */
export async function revokeConnector(userId, connector) {
  const res = await fetch(
    `${BASE_URL}/admin/users/${userId}/connectors/${connector}/revoke`,
    {
      method: "POST",
      headers: getAuthHeaders(),
    }
  );
  return handleResponse(res);
}