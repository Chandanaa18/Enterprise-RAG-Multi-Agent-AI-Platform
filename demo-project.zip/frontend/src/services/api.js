/**
 * api.js — single source of truth for all backend calls.
 * Base URL proxied to FastAPI via vite.config.js during dev.
 */

const BASE = '/api/v1'

// Dev fallback — only used when Azure auth is disabled (AZURE_AUTH_ENABLED=false).
const DEV_USER_EMAIL = import.meta.env.VITE_DEV_USER_EMAIL || ''

function getAuthHeaders() {
  const token = localStorage.getItem('access_token')
  if (token) return { Authorization: `Bearer ${token}` }
  const impersonated = localStorage.getItem('dev_impersonate_email')
  if (impersonated) return { 'X-User-Email': impersonated }
  if (DEV_USER_EMAIL) return { 'X-User-Email': DEV_USER_EMAIL }
  return {}
}

async function request(method, path, body = null, extraHeaders = {}) {
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
      ...extraHeaders,
    },
    credentials: 'include',
  }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(`${BASE}${path}`, opts)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Request failed')
  }
  if (res.status === 204) return null
  return res.json()
}

// ── Sessions ────────────────────────────────────────────────────────────────

export const sessionsApi = {
  list:     ()                          => request('GET',    '/sessions'),
  create:   ()                          => request('POST',   '/sessions'),
  patch:    (id, body)                  => request('PATCH',  `/sessions/${id}`, body),
  delete:   (id)                        => request('DELETE', `/sessions/${id}`),
  messages: (id)                        => request('GET',    `/sessions/${id}/messages`),
}

// ── Chat ─────────────────────────────────────────────────────────────────────

export const chatApi = {
  /**
   * Send a message. Returns the full ChatResponse from your backend.
   * session_id is sent as a header so get_current_session dep can pick it up.
   */
  send: (message, sessionId) =>
    request('POST', '/chat', { message }, sessionId ? { 'X-Session-ID': sessionId } : {}),
}

// ── Connectors ───────────────────────────────────────────────────────────────

// Atlassian OAuth routes live at /auth/... (no /api/v1 prefix) — use raw fetch.
async function authRequest(method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    credentials: 'include',
  }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(path, opts)
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Request failed')
  }
  if (res.status === 204) return null
  return res.json()
}

export const connectorsApi = {
  /**
   * Returns the current user's connector access.
   * Shape: { jira: bool, teams: bool, m365: bool }
   * Wire this up in app/api/connectors.py when ready.
   */
  myAccess: () => request('GET', '/connectors/my-access'),

  /**
   * Returns the Atlassian OAuth authorization URL.
   * Frontend redirects browser to this URL to start the OAuth flow.
   */
  getAtlassianConnectUrl: () => authRequest('GET', '/auth/atlassian/connect-url'),

  /** Returns { connected, atlassian_email, atlassian_account_id } for the current user. */
  jiraStatus: () => authRequest('GET', '/auth/atlassian/status'),

  /** Revokes the current user's Atlassian connection. */
  jiraDisconnect: () => authRequest('DELETE', '/auth/atlassian/disconnect'),
}

// ── Users ─────────────────────────────────────────────────────────────────────

export const usersApi = {
  list: () => request('GET', '/users'),
}

// ── Admin — Connector Permissions ─────────────────────────────────────────────

export const adminApi = {
  // List all enabled connectors from connector_configs
  listConnectors: () => request('GET', '/admin/connectors'),

  // Get all connector permissions for a user
  getUserConnectors:    (userId)               => request('GET',  `/admin/users/${userId}/connectors`),
  // Grant / revoke a connector for a user
  grantUserConnector:   (userId, connector)    => request('POST', `/admin/users/${userId}/connectors/${connector}/grant`),
  revokeUserConnector:  (userId, connector)    => request('POST', `/admin/users/${userId}/connectors/${connector}/revoke`),
}

// ── Dashboard ────────────────────────────────────────────────────────────────

export const dashboardApi = {
  /**
   * Returns metrics, agent usage, recent activity.
   * Wire this up in app/api/dashboard.py when ready.
   */
  summary: () => request('GET', '/dashboard/summary'),
}
