import { useCallback } from 'react'
import { chatApi } from '../services/api'
import useAppStore from '../store/useAppStore'
import { useSessions } from './useSessions'

/**
 * Handles sending a message and appending both user + bot messages
 * to the store. Also triggers session naming on first message.
 */
export function useChat() {
  const { isSending, setIsSending, appendMessage, messages } = useAppStore()
  const { currentSessionId, nameSession, sessions } = useSessions()

  const sendMessage = useCallback(async (text) => {
    // Read fresh state from the store — avoids stale closure when session is
    // created and sendMessage is called in the same tick (e.g. first message).
    const sessionId = useAppStore.getState().currentSessionId
    if (!text.trim() || !sessionId || isSending) return

    // Optimistically append user message
    const userMsg = {
      id:        crypto.randomUUID(),
      role:      'user',
      content:   text,
      createdAt: new Date().toISOString(),
    }
    appendMessage(userMsg)
    setIsSending(true)

    // Auto-name session from first user message
    const { sessions: currentSessions, messages: currentMessages } = useAppStore.getState()
    const session = currentSessions.find((s) => s.session_id === sessionId)
    const isFirstMessage = currentMessages.filter((m) => m.role === 'user').length === 1
    if (isFirstMessage && session && !session.name) {
      nameSession(sessionId, text)
    }

    try {
      const data = await chatApi.send(text, sessionId)

      const botMsg = {
        id:          crypto.randomUUID(),
        role:        'assistant',
        content:     data.response,
        agent:       data.agent,
        canAnswer:   data.can_answer,
        citations:   data.citations || [],
        mlflowRunId: data.mlflow_run_id,
        latencyMs:   data.latency_ms ?? null,
        createdAt:   new Date().toISOString(),
      }
      appendMessage(botMsg)
    } catch (err) {
      appendMessage({
        id:        crypto.randomUUID(),
        role:      'assistant',
        content:   'Something went wrong. Please try again.',
        isError:   true,
        createdAt: new Date().toISOString(),
      })
      console.error('Chat error:', err)
    } finally {
      setIsSending(false)
    }
  }, [currentSessionId, isSending, messages, sessions])

  return { sendMessage, isSending }
}
