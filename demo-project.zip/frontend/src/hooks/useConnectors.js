import { useEffect } from 'react'
import { connectorsApi } from '../services/api'
import useAppStore from '../store/useAppStore'

/**
 * Fetches connector access for the current user on mount.
 * Falls back to all-false if the endpoint isn't wired yet.
 */
export function useConnectors() {
  const { connectors, setConnectors } = useAppStore()

  useEffect(() => {
    connectorsApi.myAccess()
      .then(setConnectors)
      .catch(() => {
        // Endpoint not wired yet — show all as no access
        setConnectors({ jira: false, teams: false, m365: false })
      })
  }, [])

  return connectors
}
