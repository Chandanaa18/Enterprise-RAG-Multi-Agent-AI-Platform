/**
 * useAccessControl.js
 * All state and side-effects for the Access Control Center.
 * Follows the same hook pattern as useChat.js / useSessions.js.
 */

import { useState, useCallback } from "react";
import {
  fetchUsers,
  fetchUserConnectors,
  grantConnector,
  revokeConnector,
} from "../services/adminApi";

export function useAccessControl() {
  // ── User search ──────────────────────────────────────────────────────────
  const [allUsers, setAllUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [usersLoading, setUsersLoading] = useState(false);
  const [usersError, setUsersError] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // ── Selected user ─────────────────────────────────────────────────────────
  const [selectedUser, setSelectedUser] = useState(null);

  // ── Permissions ───────────────────────────────────────────────────────────
  const [permissions, setPermissions] = useState([]);          // server state
  const [editedPermissions, setEditedPermissions] = useState({}); // local edits
  const [permissionsLoading, setPermissionsLoading] = useState(false);
  const [permissionsError, setPermissionsError] = useState(null);

  // ── Save ──────────────────────────────────────────────────────────────────
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // ── Derived: filtered suggestions ────────────────────────────────────────
  const suggestions = searchQuery.trim().length < 2
    ? []
    : allUsers.filter((u) => {
        const q = searchQuery.toLowerCase();
        return (
          (u.display_name || "").toLowerCase().includes(q) ||
          (u.email || "").toLowerCase().includes(q)
        );
      }).slice(0, 8);

  // ── Derived: pending changes — compare editedPermissions against DB state ──
  const ALL_CONNECTOR_KEYS = [
    "confluence", "jira", "sharepoint", "teams", "m365", "outlook", "onedrive", "calendar"
  ];
  const dbState = Object.fromEntries(permissions.map((p) => [p.connector_name, p.enabled]));

  const pendingChanges = ALL_CONNECTOR_KEYS.reduce((acc, key) => {
    const original = dbState[key] ?? false;
    const edited = editedPermissions[key];
    if (edited !== undefined && edited !== original) {
      acc.push({ connector: key, action: edited ? "grant" : "revoke" });
    }
    return acc;
  }, []);

  // ── Derived: counts for UserSummary ──────────────────────────────────────
  const totalConnectors = ALL_CONNECTOR_KEYS.length;
  const activeConnectors = ALL_CONNECTOR_KEYS.filter((key) => {
    const edited = editedPermissions[key];
    return edited !== undefined ? edited : (dbState[key] ?? false);
  }).length;

  // ── Actions ───────────────────────────────────────────────────────────────

  const loadUsers = useCallback(async () => {
    if (allUsers.length > 0) return; // already loaded
    setUsersLoading(true);
    setUsersError(null);
    try {
      const data = await fetchUsers();
      // API may return { users: [...] } or bare array — handle both
      setAllUsers(Array.isArray(data) ? data : (data.users ?? []));
    } catch (err) {
      setUsersError(err.message);
    } finally {
      setUsersLoading(false);
    }
  }, [allUsers.length]);

  const handleSearchChange = useCallback((value) => {
    setSearchQuery(value);
    setShowSuggestions(true);
    if (!value.trim()) {
      setShowSuggestions(false);
    }
  }, []);

  const selectUser = useCallback(async (user) => {
    setSelectedUser(user);
    setSearchQuery(user.display_name || user.email);
    setShowSuggestions(false);
    setPermissions([]);
    setEditedPermissions({});
    setSaveSuccess(false);
    setSaveError(null);

    setPermissionsLoading(true);
    setPermissionsError(null);
    try {
      const data = await fetchUserConnectors(user.id);
      const list = Array.isArray(data) ? data : (data.connectors ?? []);
      setPermissions(list);
    } catch (err) {
      setPermissionsError(err.message);
    } finally {
      setPermissionsLoading(false);
    }
  }, []);

  const togglePermission = useCallback((connectorName, currentValue) => {
    setEditedPermissions((prev) => ({
      ...prev,
      [connectorName]: !currentValue,
    }));
    setSaveSuccess(false);
  }, []);

  const saveChanges = useCallback(async () => {
    if (!selectedUser || pendingChanges.length === 0) return;
    setSaving(true);
    setSaveError(null);
    setSaveSuccess(false);

    try {
      // Sequential — keeps the backend simple, avoids race conditions
      for (const change of pendingChanges) {
        if (change.action === "grant") {
          await grantConnector(selectedUser.id, change.connector);
        } else {
          await revokeConnector(selectedUser.id, change.connector);
        }
      }

      // Refresh from server
      const data = await fetchUserConnectors(selectedUser.id);
      const list = Array.isArray(data) ? data : (data.connectors ?? []);
      setPermissions(list);
      setEditedPermissions({});
      setSaveSuccess(true);

      // Auto-dismiss success toast after 3 s
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  }, [selectedUser, pendingChanges]);

  const dismissSuggestions = useCallback(() => {
    setShowSuggestions(false);
  }, []);

  return {
    // search
    searchQuery,
    suggestions,
    showSuggestions,
    usersLoading,
    usersError,
    // user
    selectedUser,
    // permissions
    permissions,
    editedPermissions,
    permissionsLoading,
    permissionsError,
    // derived
    pendingChanges,
    totalConnectors,
    activeConnectors,
    // save
    saving,
    saveError,
    saveSuccess,
    // actions
    loadUsers,
    handleSearchChange,
    selectUser,
    togglePermission,
    saveChanges,
    dismissSuggestions,
  };
}