import { useCallback } from 'react'
import { sessionsApi } from '../services/api'
import useAppStore from '../store/useAppStore'

/**
 * All session operations. Components call these functions —
 * they hit the API and update the Zustand store in one shot.
 */
export function useSessions() {
  const {
    sessions,
    currentSessionId,
    setSessions,
    setCurrentSession,
    updateSession,
    addSession,
    removeSession,
    setIsLoadingSessions,
    setMessages,
    setIsLoadingMessages,
    appendMessage,
  } = useAppStore()

  // Load all sessions for the current user
  const loadSessions = useCallback(async () => {
    setIsLoadingSessions(true)
    try {
      const data = await sessionsApi.list()
      setSessions(data.items)
    } catch (err) {
      console.error('Failed to load sessions:', err)
    } finally {
      setIsLoadingSessions(false)
    }
  }, [])

  // Create a new session and switch to it
  const createSession = useCallback(async () => {
    try {
      const data = await sessionsApi.create()
      const newSession = {
        session_id:      data.session_id,
        created_at:      data.created_at,
        last_active_at:  data.created_at,
        name:            null,
        pinned:          false,
        is_active:       true,
        agent_last_used: null,
      }
      addSession(newSession)
      setCurrentSession(data.session_id)
      return data.session_id
    } catch (err) {
      console.error('Failed to create session:', err)
    }
  }, [])

  // Switch to an existing session and load its messages
  const switchSession = useCallback(async (id) => {
    setCurrentSession(id)
    setIsLoadingMessages(true)
    try {
      const data = await sessionsApi.messages(id)
      // Map backend message shape to frontend shape
      const mapped = data.items.map((m) => ({
        id:           m.message_id,
        role:         m.role,
        content:      m.content,
        agent:        m.agent_name,
        createdAt:    m.created_at,
        tokenUsage:   m.token_usage,
        mlflowRunId:  m.mlflow_run_id,
        latencyMs:    m.latency_ms,
        citations:    [],
      }))
      setMessages(mapped)
    } catch (err) {
      console.error('Failed to load messages:', err)
      setMessages([])
    } finally {
      setIsLoadingMessages(false)
    }
  }, [])

  // Toggle pin state
  const togglePin = useCallback(async (id) => {
    const session = sessions.find((s) => s.session_id === id)
    if (!session) return
    const newPinned = !session.pinned
    updateSession(id, { pinned: newPinned })
    try {
      await sessionsApi.patch(id, { pinned: newPinned })
    } catch (err) {
      // Revert on failure
      updateSession(id, { pinned: session.pinned })
      console.error('Failed to pin session:', err)
    }
  }, [sessions])

  // Auto-name a session from the first user message
  const nameSession = useCallback(async (id, firstMessage) => {
    const words   = firstMessage.trim().split(/\s+/).slice(0, 5).join(' ')
    const name    = words.length > 38 ? words.slice(0, 36) + '…' : words
    updateSession(id, { name })
    try {
      await sessionsApi.patch(id, { name })
    } catch (err) {
      console.error('Failed to name session:', err)
    }
  }, [])

  // Soft delete
  const deleteSession = useCallback(async (id) => {
    removeSession(id)
    try {
      await sessionsApi.delete(id)
    } catch (err) {
      console.error('Failed to delete session:', err)
    }
  }, [])

  return {
    sessions,
    currentSessionId,
    loadSessions,
    createSession,
    switchSession,
    togglePin,
    nameSession,
    deleteSession,
    appendMessage,
  }
}
