import { useState } from 'react'
import sigmoidLogo from '../assets/sigmoid-logo.png'

export default function LoginPage({ authError }) {
  const [loading, setLoading] = useState(false)

  function handleSignIn() {
    setLoading(true)
    window.location.href = '/login'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/40 flex items-center justify-center p-4">

      {/* Background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-100/40 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-100/40 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-4xl flex rounded-3xl overflow-hidden shadow-2xl shadow-blue-900/10 border border-white/80">

        {/* ── Left panel ── */}
        <div className="hidden md:flex flex-col justify-between w-1/2 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 p-10 text-white">

          <div className="flex items-center gap-3">
            <div className="bg-white rounded-lg px-2 py-1.5 flex-shrink-0">
              <img src={sigmoidLogo} alt="Sigmoid" className="h-6 w-auto object-contain" />
            </div>
            <div>
              <div className="text-white font-bold text-sm leading-tight">Enterprise RAG</div>
              <div className="text-blue-200 text-[10px] font-medium">Knowledge Intelligence Platform</div>
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-3xl font-bold leading-tight">Unlock your enterprise knowledge</h1>
            <p className="text-blue-100 text-sm leading-relaxed">
              AI-powered search across Confluence, Jira, Teams, and M365 — secured by Microsoft Azure AD.
            </p>
          </div>

          <div className="space-y-3">
            {[
              { Icon: SearchIcon,  label: 'Semantic search across all connectors' },
              { Icon: ShieldIcon,  label: 'Role-based access control per document' },
              { Icon: BoltIcon,    label: 'Multi-agent answers with citations' },
              { Icon: LockIcon,    label: 'Single sign-on via Azure Active Directory' },
            ].map(({ Icon, label }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-white/15 flex items-center justify-center flex-shrink-0">
                  <Icon />
                </div>
                <span className="text-blue-100 text-xs">{label}</span>
              </div>
            ))}
          </div>

          <p className="text-blue-300/60 text-[10px]">© 2025 Sigmoid Analytics. All rights reserved.</p>
        </div>

        {/* ── Right panel ── */}
        <div className="flex-1 bg-white flex flex-col justify-center px-10 py-12">

          {/* Mobile logo */}
          <div className="flex md:hidden items-center gap-2 mb-8">
            <img src={sigmoidLogo} alt="Sigmoid" className="h-7 w-auto object-contain" />
            <span className="font-bold text-gray-800 text-sm">Enterprise RAG</span>
          </div>

          <div className="max-w-xs mx-auto w-full space-y-7">

            <div>
              <h2 className="text-2xl font-bold text-gray-900">Welcome back</h2>
              <p className="text-gray-500 text-sm mt-1.5">
                Sign in with your organisation account to continue.
              </p>
            </div>

            {authError && (
              <div className="flex items-start gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3">
                <div className="w-4 h-4 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-white text-[9px] font-bold">!</span>
                </div>
                <p className="text-red-700 text-xs leading-relaxed">{authError}</p>
              </div>
            )}

            {/* Sign-in button */}
            <button
              onClick={handleSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 bg-[#0078d4] hover:bg-[#006cbf] active:bg-[#005ba1] disabled:opacity-70 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl px-5 py-3.5 transition-all shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  Redirecting to Microsoft…
                </>
              ) : (
                <>
                  <MicrosoftLogo />
                  Sign in with Microsoft
                </>
              )}
            </button>

            {/* Azure AD badge */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">secured by</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>

            <div className="flex items-center gap-2.5 py-3 px-4 bg-gray-50 rounded-xl border border-gray-100">
              <AzureEntraIcon />
              <div>
                <div className="text-xs font-semibold text-gray-700">Microsoft Entra ID</div>
                <div className="text-[10px] text-gray-400">Azure Active Directory</div>
              </div>
              <div className="ml-auto flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span className="text-[10px] text-emerald-600 font-medium">Active</span>
              </div>
            </div>

            <p className="text-[10px] text-gray-400 text-center leading-relaxed">
              By signing in you agree to your organisation's security policies.
              Your credentials are never stored by this application.
            </p>

          </div>
        </div>
      </div>
    </div>
  )
}

// ── Icons ────────────────────────────────────────────────────────────────────

function MicrosoftLogo() {
  return (
    <svg width="18" height="18" viewBox="0 0 21 21" fill="none">
      <rect x="1"  y="1"  width="9" height="9" fill="#F25022" />
      <rect x="11" y="1"  width="9" height="9" fill="#7FBA00" />
      <rect x="1"  y="11" width="9" height="9" fill="#00A4EF" />
      <rect x="11" y="11" width="9" height="9" fill="#FFB900" />
    </svg>
  )
}

function AzureEntraIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 96 96" fill="none">
      <defs>
        <linearGradient id="az" x1="0.5" y1="0" x2="0.5" y2="1">
          <stop stopColor="#0078D4" />
          <stop offset="1" stopColor="#1B4AC2" />
        </linearGradient>
      </defs>
      <path d="M48 4L88 24V72L48 92L8 72V24L48 4Z" fill="url(#az)" />
      <path d="M34 38L48 28L62 38V58L48 68L34 58V38Z" fill="white" />
    </svg>
  )
}

function SearchIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" />
    </svg>
  )
}

function ShieldIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  )
}

function BoltIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
    </svg>
  )
}

function LockIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  )
}
