import TopBar from '../components/shared/TopBar'
import ChatArea from '../components/chat/ChatArea'
import ChatInput from '../components/chat/ChatInput'

export default function ChatPage() {
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBar />
      <ChatArea />
      <ChatInput />
    </div>
  )
}
