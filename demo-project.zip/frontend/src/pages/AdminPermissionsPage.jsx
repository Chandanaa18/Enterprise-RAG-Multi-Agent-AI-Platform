/**
 * AdminPermissionsPage — manage connector access per user.
 *
 * Process:
 *  1. Page loads → fetches all users + all connectors from connector_configs
 *  2. For the selected user → fetches their current connector_permissions rows
 *  3. Admin can toggle ON / OFF per connector → calls grant / revoke API
 *
 * Connectors are read live from connector_configs (no hardcoding).
 * Only users with the "admin" role can reach this page.
 */
import { useEffect, useState, useCallback } from 'react'
import { usersApi, adminApi } from '../services/api'

export default function AdminPermissionsPage() {
  const [users,         setUsers]         = useState([])
  const [connectors,    setConnectors]    = useState([])
  const [selectedUser,  setSelectedUser]  = useState(null)
  const [userPerms,     setUserPerms]     = useState({})   // { connector_name: bool }
  const [loadingUsers,  setLoadingUsers]  = useState(true)
  const [loadingPerms,  setLoadingPerms]  = useState(false)
  const [togglingKey,   setTogglingKey]   = useState(null) // "userId:connector"
  const [toast,         setToast]         = useState(null)

  // ── Load users + connectors on mount ──────────────────────────────────────
  useEffect(() => {
    Promise.all([usersApi.list(), adminApi.listConnectors()])
      .then(([u, c]) => {
        setUsers(u)
        setConnectors(c.filter(c => c.enabled))
      })
      .catch(() => showToast('Failed to load data', 'error'))
      .finally(() => setLoadingUsers(false))
  }, [])

  // ── Load permissions when a user is selected ──────────────────────────────
  const loadPerms = useCallback(async (user) => {
    setSelectedUser(user)
    setLoadingPerms(true)
    try {
      const rows = await adminApi.getUserConnectors(user.user_id)
      const map = {}
      rows.forEach(r => { map[r.connector_name] = r.enabled })
      setUserPerms(map)
    } catch {
      showToast('Failed to load permissions', 'error')
      setUserPerms({})
    } finally {
      setLoadingPerms(false)
    }
  }, [])

  // ── Toggle a connector for the selected user ───────────────────────────────
  async function handleToggle(connector) {
    if (!selectedUser) return
    const key     = `${selectedUser.user_id}:${connector}`
    const current = userPerms[connector] ?? false

    setTogglingKey(key)
    try {
      if (current) {
        await adminApi.revokeUserConnector(selectedUser.user_id, connector)
        setUserPerms(p => ({ ...p, [connector]: false }))
        showToast(`Revoked "${connector}" for ${selectedUser.display_name || selectedUser.email}`, 'success')
      } else {
        await adminApi.grantUserConnector(selectedUser.user_id, connector)
        setUserPerms(p => ({ ...p, [connector]: true }))
        showToast(`Granted "${connector}" to ${selectedUser.display_name || selectedUser.email}`, 'success')
      }
    } catch (e) {
      showToast(e.message || 'Failed to update permission', 'error')
    } finally {
      setTogglingKey(null)
    }
  }

  function showToast(msg, type = 'success') {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="flex-1 overflow-auto bg-gray-50/50 p-6">

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-bold text-gray-900">Connector Permissions</h1>
        <p className="text-sm text-gray-500 mt-0.5">
          Control which Azure AD users can query each data connector.
          Connectors are sourced live from connector_configs.
        </p>
      </div>

      <div className="flex gap-5 items-start">

        {/* ── User list ── */}
        <div className="w-64 flex-shrink-0 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-2">
            <UsersIcon />
            <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Users</span>
          </div>

          {loadingUsers ? (
            <div className="p-4 text-center text-sm text-gray-400">Loading…</div>
          ) : (
            <ul className="divide-y divide-gray-50 max-h-[calc(100vh-220px)] overflow-y-auto">
              {users.map(u => {
                const active  = selectedUser?.user_id === u.user_id
                const initial = (u.display_name || u.email || '?')[0].toUpperCase()
                return (
                  <li key={u.user_id}>
                    <button
                      onClick={() => loadPerms(u)}
                      className={`w-full px-4 py-3 flex items-center gap-3 text-left transition-colors ${active ? 'bg-blue-50' : 'hover:bg-gray-50'}`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0 ${active ? 'bg-blue-600' : 'bg-gray-400'}`}>
                        {initial}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-gray-800 truncate">
                          {u.display_name || u.email}
                        </div>
                        <div className="text-[10px] text-gray-400 truncate">{u.email}</div>
                        <div className="flex gap-1 mt-0.5 flex-wrap">
                          {(u.roles || []).map(r => (
                            <span key={r} className="text-[9px] bg-gray-100 text-gray-500 rounded px-1 py-0.5 font-medium">{r}</span>
                          ))}
                        </div>
                      </div>
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
        </div>

        {/* ── Permissions matrix ── */}
        <div className="flex-1 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldIcon />
              <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider">
                {selectedUser
                  ? `Access for ${selectedUser.display_name || selectedUser.email}`
                  : 'Select a user to manage access'}
              </span>
            </div>
            {selectedUser && (
              <span className="text-[10px] text-gray-400">
                {connectors.filter(c => userPerms[c.connector_id]).length} / {connectors.length} connectors enabled
              </span>
            )}
          </div>

          {!selectedUser ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <ArrowLeftIcon />
              <p className="text-sm mt-2">Select a user from the list</p>
            </div>
          ) : loadingPerms ? (
            <div className="flex items-center justify-center py-20 text-gray-400 text-sm">Loading permissions…</div>
          ) : connectors.length === 0 ? (
            <div className="flex items-center justify-center py-20 text-gray-400 text-sm">No connectors configured</div>
          ) : (
            <ul className="divide-y divide-gray-50">
              {connectors.map(c => {
                const key     = `${selectedUser.user_id}:${c.connector_id}`
                const enabled = userPerms[c.connector_id] ?? false
                const busy    = togglingKey === key

                return (
                  <li key={c.connector_id} className="px-5 py-4 flex items-center gap-4">
                    {/* Connector icon */}
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-lg ${enabled ? 'bg-blue-50' : 'bg-gray-100'}`}>
                      {connectorEmoji(c.connector_id)}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-gray-800 capitalize">
                        {c.connector_name || c.connector_id}
                      </div>
                      <div className="text-[11px] text-gray-400 mt-0.5">
                        ID: <code className="font-mono">{c.connector_id}</code>
                      </div>
                    </div>

                    {/* Status badge */}
                    <span className={`text-[10px] font-semibold px-2 py-1 rounded-full ${enabled ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-400'}`}>
                      {enabled ? 'Access granted' : 'No access'}
                    </span>

                    {/* Toggle */}
                    <button
                      onClick={() => handleToggle(c.connector_id)}
                      disabled={busy}
                      className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${enabled ? 'bg-blue-600' : 'bg-gray-200'} ${busy ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:opacity-90'}`}
                      title={enabled ? 'Click to revoke' : 'Click to grant'}
                    >
                      {busy ? (
                        <span className="absolute inset-0 flex items-center justify-center">
                          <svg className="animate-spin w-3 h-3 text-white" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                          </svg>
                        </span>
                      ) : (
                        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                      )}
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-5 right-5 px-4 py-3 rounded-xl text-sm font-medium shadow-lg transition-all ${toast.type === 'error' ? 'bg-red-600 text-white' : 'bg-gray-900 text-white'}`}>
          {toast.msg}
        </div>
      )}
    </div>
  )
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function connectorEmoji(id) {
  const map = {
    confluence: '📘',
    jira:       '🟦',
    teams:      '💬',
    m365:       '📧',
    sharepoint: '📁',
    uploads:    '📤',
  }
  return map[id] ?? '🔌'
}

function UsersIcon() {
  return (
    <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a4 4 0 00-5-4M9 20H4v-2a4 4 0 015-4m6-4a4 4 0 11-8 0 4 4 0 018 0z" />
    </svg>
  )
}

function ShieldIcon() {
  return (
    <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  )
}

function ArrowLeftIcon() {
  return (
    <svg className="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
  )
}
