/**
 * AccessControlPage.jsx
 * Route: /admin/access
 *
 * Enterprise Access Control Center — single page, no modals, no redirects.
 * Follows the same page structure as ChatPage.jsx and DashboardPage.jsx.
 */

import { useEffect } from "react";
import sigmoidLogo from "../assets/sigmoid-logo.png";
import { useAccessControl } from "../hooks/useAccessControl";
import SearchBar from "../components/admin/SearchBar";
import UserSummary from "../components/admin/UserSummary";
import PermissionList from "../components/admin/PermissionList";
import PendingChanges from "../components/admin/PendingChanges";

export default function AccessControlPage() {
  const {
    // search
    searchQuery,
    suggestions,
    showSuggestions,
    usersLoading,
    usersError,
    // user
    selectedUser,
    // permissions
    permissions,
    editedPermissions,
    permissionsLoading,
    permissionsError,
    // derived
    pendingChanges,
    totalConnectors,
    activeConnectors,
    // save
    saving,
    saveError,
    saveSuccess,
    // actions
    loadUsers,
    handleSearchChange,
    selectUser,
    togglePermission,
    saveChanges,
    dismissSuggestions,
  } = useAccessControl();

  // Pre-load user list on mount so suggestions are instant
  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden">
      {/* ── Page header ───────────────────────────────────────────────────── */}
      <header className="bg-white border-b border-gray-200 shrink-0">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={sigmoidLogo} alt="Sigmoid" className="h-8 w-auto" />
            <div>
              <h1 className="text-lg font-semibold text-gray-900 tracking-tight">
                Enterprise Access Control Center
              </h1>
              <p className="text-xs text-gray-400 mt-0.5">
                Manage connector permissions for individual users
              </p>
            </div>
          </div>
          {/* Admin badge */}
          <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 text-xs font-semibold">
            Admin
          </span>
        </div>
      </header>

      {/* ── Main content scrollable ───────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">

          {/* SECTION 1 — User search */}
          <section>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Search user
            </label>
            <SearchBar
              query={searchQuery}
              suggestions={suggestions}
              showSuggestions={showSuggestions}
              loading={usersLoading}
              error={usersError}
              onQueryChange={handleSearchChange}
              onSelectUser={selectUser}
              onFocus={loadUsers}
              onDismiss={dismissSuggestions}
            />
          </section>

          {/* SECTION 2 — User summary (only after selection) */}
          {selectedUser && (
            <section>
              <UserSummary
                user={selectedUser}
                totalConnectors={totalConnectors}
                activeConnectors={activeConnectors}
              />
            </section>
          )}

          {/* SECTION 3 — Connector access (full width, stacked) */}
          <section>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              Connector access
            </label>
            <PermissionList
              permissions={selectedUser ? permissions : []}
              editedPermissions={editedPermissions}
              loading={permissionsLoading}
              error={permissionsError}
              selectedUser={selectedUser}
              onToggle={togglePermission}
            />
          </section>

          {/* SECTION 4 — Review & save (below permissions, only when user selected) */}
          {selectedUser && (
            <section className="pb-12">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                Review &amp; save
              </label>
              <PendingChanges
                pendingChanges={pendingChanges}
                saving={saving}
                saveError={saveError}
                saveSuccess={saveSuccess}
                selectedUser={selectedUser}
                onSave={saveChanges}
              />
            </section>
          )}

        </div>
      </main>
    </div>
  );
}