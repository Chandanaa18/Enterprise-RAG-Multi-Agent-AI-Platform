import { useEffect, useState, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import { connectorsApi } from '../services/api'

// ── Connector definitions ─────────────────────────────────────────────────────

const CONNECTORS = [
  {
    key: 'jira',
    label: 'Jira',
    description: 'Query and manage your Jira issues using natural language.',
    connectable: true,
    icon: (
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="#2684FF">
        <path d="M11.571 11.513H0a5.218 5.218 0 0 0 5.232 5.215h2.13v2.057A5.215 5.215 0 0 0 12.575 24V12.518a1.005 1.005 0 0 0-1.005-1.005zm5.723-5.756H5.736a5.215 5.215 0 0 0 5.215 5.214h2.129v2.058a5.218 5.218 0 0 0 5.215 5.214V6.762a1.005 1.005 0 0 0-1.001-1.005zM23.013 0H11.455a5.215 5.215 0 0 0 5.215 5.215h2.129v2.057A5.215 5.215 0 0 0 24.019 12.49V1.005A1.005 1.005 0 0 0 23.013 0z"/>
      </svg>
    ),
  },
  {
    key: 'teams',
    label: 'Microsoft Teams',
    description: 'Search conversations and files from Teams channels.',
    connectable: false,
    icon: (
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="#6264A7">
        <path d="M20.625 7.875h-3.75a.375.375 0 0 0-.375.375v7.5c0 .207.168.375.375.375h3.75A2.625 2.625 0 0 0 23.25 13.5v-3a2.625 2.625 0 0 0-2.625-2.625zM15 3.75a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0zM14.25 7.5H9.75A2.25 2.25 0 0 0 7.5 9.75v5.25a.75.75 0 0 0 .75.75h7.5a.75.75 0 0 0 .75-.75V9.75A2.25 2.25 0 0 0 14.25 7.5zM6 6.75a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0zM4.5 9.375H2.25A2.25 2.25 0 0 0 0 11.625V15c0 .621.504 1.125 1.125 1.125h3.75c.621 0 1.125-.504 1.125-1.125v-3.375A2.25 2.25 0 0 0 4.5 9.375z"/>
      </svg>
    ),
  },
  {
    key: 'm365',
    label: 'Microsoft 365',
    description: 'Access SharePoint, OneDrive, and Office documents.',
    connectable: false,
    icon: (
      <svg className="w-6 h-6" viewBox="0 0 24 24" fill="#D83B01">
        <path d="M0 0v11.408h11.408V0zm12.594 0v11.408H24V0zM0 12.594V24h11.408V12.594zm12.594 0V24H24V12.594z"/>
      </svg>
    ),
  },
]

// ── Toast ─────────────────────────────────────────────────────────────────────

function Toast({ message, type, onDismiss }) {
  useEffect(() => {
    const t = setTimeout(onDismiss, 4000)
    return () => clearTimeout(t)
  }, [onDismiss])

  return (
    <div
      className={`fixed top-6 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg text-sm font-medium animate-fade-in ${
        type === 'success'
          ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
          : 'bg-red-50 border border-red-200 text-red-800'
      }`}
    >
      {type === 'success' ? (
        <svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>
      ) : (
        <svg className="w-4 h-4 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      )}
      {message}
      <button onClick={onDismiss} className="ml-2 opacity-50 hover:opacity-100">
        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  )
}

// ── Jira connector card ───────────────────────────────────────────────────────

function JiraCard({ icon, label, description }) {
  const [status, setStatus]       = useState(null)   // null=loading, {connected, ...}
  const [connecting, setConnecting] = useState(false)
  const [disconnecting, setDisconnecting] = useState(false)
  const [toast, setToast] = useState(null)

  const loadStatus = useCallback(async () => {
    try {
      const data = await connectorsApi.jiraStatus()
      setStatus(data)
    } catch {
      setStatus({ connected: false, atlassian_email: null, atlassian_account_id: null })
    }
  }, [])

  useEffect(() => { loadStatus() }, [loadStatus])

  async function handleConnect() {
    if (connecting) return
    setConnecting(true)
    try {
      const { url } = await connectorsApi.getAtlassianConnectUrl()
      window.location.href = url
    } catch (err) {
      setConnecting(false)
      setToast({ message: err.message || 'Failed to start connection. Please try again.', type: 'error' })
    }
  }

  async function handleDisconnect() {
    if (disconnecting) return
    setDisconnecting(true)
    try {
      await connectorsApi.jiraDisconnect()
      await loadStatus()
      setToast({ message: 'Atlassian account disconnected.', type: 'success' })
    } catch (err) {
      setToast({ message: err.message || 'Failed to disconnect. Please try again.', type: 'error' })
    } finally {
      setDisconnecting(false)
    }
  }

  const isConnected = status?.connected

  return (
    <>
    {toast && <Toast message={toast.message} type={toast.type} onDismiss={() => setToast(null)} />}
    <div className="bg-white border border-blue-100/70 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-sm font-semibold text-gray-800">{label}</span>
            {status === null ? (
              <span className="w-1.5 h-1.5 rounded-full bg-gray-200 animate-pulse" />
            ) : isConnected ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-full px-2 py-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Connected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-gray-500 bg-gray-50 border border-gray-200 rounded-full px-2 py-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-gray-300" />
                Not connected
              </span>
            )}
          </div>
          <p className="text-[11px] text-gray-500 mb-3">{description}</p>

          {isConnected && status.atlassian_email && (
            <p className="text-[11px] text-gray-400 mb-3">
              Connected as <span className="font-medium text-gray-600">{status.atlassian_email}</span>
            </p>
          )}

          <div className="flex gap-2">
            {isConnected ? (
              <button
                onClick={handleDisconnect}
                disabled={disconnecting}
                className="text-[11px] font-semibold text-red-600 hover:text-red-700 border border-red-200 hover:border-red-300 bg-red-50 hover:bg-red-100 rounded-lg px-3 py-1.5 transition-all disabled:opacity-50"
              >
                {disconnecting ? 'Disconnecting…' : 'Disconnect'}
              </button>
            ) : (
              <button
                onClick={handleConnect}
                disabled={connecting || status === null}
                className="text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg px-3 py-1.5 transition-all disabled:opacity-50 shadow-sm shadow-blue-200"
              >
                {connecting ? 'Redirecting…' : 'Connect Atlassian'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
    </>
  )
}

// ── Coming-soon card ──────────────────────────────────────────────────────────

function ComingSoonCard({ icon, label, description }) {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 opacity-60">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center flex-shrink-0">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-sm font-semibold text-gray-700">{label}</span>
            <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 rounded-full px-2 py-0.5">
              Coming soon
            </span>
          </div>
          <p className="text-[11px] text-gray-400">{description}</p>
        </div>
      </div>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function ConnectionsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [toast, setToast] = useState(null)

  // Handle ?jira=connected or ?jira=error from OAuth callback
  useEffect(() => {
    const jira = searchParams.get('jira')
    if (jira === 'connected') {
      setToast({ message: 'Atlassian account connected successfully.', type: 'success' })
      setSearchParams({}, { replace: true })
    } else if (jira === 'error') {
      setToast({ message: 'Failed to connect Atlassian. Please try again.', type: 'error' })
      setSearchParams({}, { replace: true })
    }
  }, [searchParams, setSearchParams])

  return (
    <div className="flex-1 overflow-y-auto bg-[#f8faff] p-8">
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onDismiss={() => setToast(null)}
        />
      )}

      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-xl font-bold text-gray-900 mb-1">Connections</h1>
          <p className="text-sm text-gray-500">
            Connect your work tools so the assistant can act on your behalf.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          {CONNECTORS.map(({ key, label, description, icon, connectable }) =>
            connectable ? (
              <JiraCard key={key} icon={icon} label={label} description={description} />
            ) : (
              <ComingSoonCard key={key} icon={icon} label={label} description={description} />
            )
          )}
        </div>
      </div>
    </div>
  )
}
