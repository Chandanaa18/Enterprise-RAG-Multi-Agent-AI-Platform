import TopBar from '../components/shared/TopBar'
import Dashboard from '../components/dashboard/Dashboard'

export default function DashboardPage() {
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBar />
      <Dashboard />
    </div>
  )
}
