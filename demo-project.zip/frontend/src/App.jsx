import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/sidebar/Sidebar'
import ChatPage from './pages/ChatPage'
import DashboardPage from './pages/DashboardPage'
import AdminPermissionsPage from './pages/AdminPermissionsPage'
import AccessControlPage from './pages/AccessControlPage'
import ConnectionsPage from './pages/ConnectionsPage'
import LoginPage from './pages/LoginPage'
import useAppStore from './store/useAppStore'

// Dev mode: if VITE_DEV_USER_EMAIL is set and Azure auth is not used,
// skip the login screen entirely.
const DEV_USER_EMAIL = import.meta.env.VITE_DEV_USER_EMAIL || ''

export default function App() {
  const { login, user } = useAppStore()
  const [authError, setAuthError] = useState(null)
  const [checked, setChecked] = useState(false)

  useEffect(() => {
    // 1. Parse token from URL fragment after Azure AD callback
    const hash = window.location.hash.slice(1)
    if (hash && hash.includes('access_token=')) {
      const params = Object.fromEntries(new URLSearchParams(hash))
      login(params)
      window.history.replaceState(null, '', window.location.pathname + window.location.search)
      setChecked(true)
      return
    }

    // 2. Rehydrate user from a still-valid token already in localStorage
    const token     = localStorage.getItem('access_token')
    const expiresAt = Number(localStorage.getItem('token_expires_at') || 0)
    if (token && Date.now() < expiresAt) {
      const storedEmail       = localStorage.getItem('dev_impersonate_email') || ''
      const storedDisplayName = localStorage.getItem('user_display_name') || storedEmail
      const storedUserId      = localStorage.getItem('user_id') || ''
      const storedRoles       = (localStorage.getItem('user_roles') || '').split(',').filter(Boolean)
      if (storedEmail || storedUserId) {
        login({
          access_token: token,
          expires_in:   Math.floor((expiresAt - Date.now()) / 1000),
          user_email:   storedEmail,
          display_name: storedDisplayName,
          user_id:      storedUserId,
          roles:        storedRoles.join(','),
        })
      }
    }

    // 3. Check for auth error query param from backend redirect
    const searchParams = new URLSearchParams(window.location.search)
    const err = searchParams.get('auth_error')
    if (err) {
      setAuthError(decodeURIComponent(err))
      window.history.replaceState(null, '', window.location.pathname)
    }

    // 4. Handle Atlassian OAuth callback result
    const jiraStatus = searchParams.get('jira')
    if (jiraStatus) {
      window.history.replaceState(null, '', window.location.pathname)
      if (jiraStatus === 'connected') {
        // Connector strip will re-fetch on next render — nothing else needed
        console.info('Atlassian connected successfully')
      }
    }

    setChecked(true)
  }, [login])

  if (!checked) return null

  const devMode = !user && !!DEV_USER_EMAIL

  if (!user && !devMode) {
    return <LoginPage authError={authError} />
  }

  return (
    <BrowserRouter>
      <div className="flex h-full overflow-hidden">
        <Sidebar />
        <div className="flex-1 overflow-hidden">
          <Routes>
            <Route path="/" element={<Navigate to="/chat" replace />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/admin/permissions" element={<AdminPermissionsPage />} />
            <Route path="/admin/access" element={<AccessControlPage />} />
            <Route path="/settings/connections" element={<ConnectionsPage />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  )
}
