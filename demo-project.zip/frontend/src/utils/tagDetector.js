const TAG_KEYWORDS = {
  security:     ['security', 'owasp', 'injection', 'jailbreak', 'pii', 'guardrail', 'vulnerabilit', 'prompt inject'],
  rag:          ['rag', 'retrieval', 'chunk', 'embed', 'rerank', 'ragas', 'faithfulness', 'recall', 'precision', 'vector', 'citation'],
  governance:   ['governance', 'compliance', 'audit', 'responsible', 'policy', 'approval', 'human-in'],
  architecture: ['architect', 'layer', 'orchestrat', 'pipeline', 'gateway'],
}

/**
 * Returns a topic tag string based on message content.
 * Used for sidebar session tags.
 */
export function detectTag(text) {
  const lower = text.toLowerCase()
  for (const [tag, keywords] of Object.entries(TAG_KEYWORDS)) {
    if (keywords.some((kw) => lower.includes(kw))) return tag
  }
  return null
}
