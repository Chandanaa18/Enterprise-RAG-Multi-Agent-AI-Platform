import { create } from 'zustand'

/**
 * Global app state via Zustand.
 * Sessions, current session, messages, connectors all live here.
 */
const useAppStore = create((set, get) => ({
  // ── Sessions ──────────────────────────────────────────────────────────────
  sessions:        [],
  currentSessionId: null,

  setSessions: (sessions) => set({ sessions }),

  setCurrentSession: (id) => set({ currentSessionId: id, messages: [] }),

  updateSession: (id, patch) =>
    set((state) => ({
      sessions: state.sessions.map((s) =>
        s.session_id === id ? { ...s, ...patch } : s
      ),
    })),

  addSession: (session) =>
    set((state) => ({ sessions: [session, ...state.sessions] })),

  removeSession: (id) =>
    set((state) => ({
      sessions: state.sessions.filter((s) => s.session_id !== id),
      currentSessionId:
        state.currentSessionId === id ? null : state.currentSessionId,
    })),

  // ── Messages ──────────────────────────────────────────────────────────────
  messages: [],

  setMessages: (messages) => set({ messages }),

  appendMessage: (msg) =>
    set((state) => ({ messages: [...state.messages, msg] })),

  // ── Loading states ────────────────────────────────────────────────────────
  isSending:       false,
  isLoadingSessions: false,
  isLoadingMessages: false,

  setIsSending:          (v) => set({ isSending: v }),
  setIsLoadingSessions:  (v) => set({ isLoadingSessions: v }),
  setIsLoadingMessages:  (v) => set({ isLoadingMessages: v }),

  // ── Connectors ────────────────────────────────────────────────────────────
  // null = not loaded yet, true = access, false = no access
  connectors: { jira: null, teams: null, m365: null },
  setConnectors: (connectors) => set({ connectors }),

  // ── User / Auth ───────────────────────────────────────────────────────────
  user: null,
  setUser: (user) => set({ user }),

  login: ({ access_token, user_email, display_name, user_id, roles, expires_in }) => {
    localStorage.setItem('access_token', access_token)
    const expiresAt = Date.now() + Number(expires_in || 3600) * 1000
    localStorage.setItem('token_expires_at', String(expiresAt))
    // Persist profile so App.jsx can rehydrate on hard refresh
    if (user_email)   localStorage.setItem('dev_impersonate_email', user_email)
    if (display_name) localStorage.setItem('user_display_name', display_name)
    if (user_id)      localStorage.setItem('user_id', user_id)
    if (roles)        localStorage.setItem('user_roles', roles)
    set({
      user: { email: user_email, display_name, user_id, roles: roles?.split(',') ?? [] },
    })
  },

  // Dev-mode user switch: persist impersonated email so getAuthHeaders() picks it up.
  switchUser: ({ user_id, email, display_name, roles }) => {
    localStorage.setItem('dev_impersonate_email', email)
    set({
      user: { user_id, email, display_name, roles },
      sessions: [],
      messages: [],
      currentSessionId: null,
    })
  },

  logout: () => {
    localStorage.removeItem('access_token')
    localStorage.removeItem('token_expires_at')
    localStorage.removeItem('dev_impersonate_email')
    localStorage.removeItem('user_display_name')
    localStorage.removeItem('user_id')
    localStorage.removeItem('user_roles')
    set({ user: null, sessions: [], messages: [], currentSessionId: null })
  },

  isAuthenticated: () => {
    const token = localStorage.getItem('access_token')
    const expiresAt = Number(localStorage.getItem('token_expires_at') || 0)
    return !!token && Date.now() < expiresAt
  },
}))

export default useAppStore
